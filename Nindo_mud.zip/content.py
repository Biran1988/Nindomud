"""
Phase 7 content: builds out each village with a Kage chamber, mission
board, a combat/mission area ("Outskirts") with respawning mobs, and
three shops (a General Store, a Weapons Shop, and a Blacksmith) --
linked onto the existing village square from Section 25/49. Call
`populate()` once at startup after `world.WORLD`, `combat`, and `olc`
are importable.

Shops are real shopkeeper MOBS (per the "shopkeeper flag" system --
see olc.py's mset additem/removeitem and combat.py's is_shopkeeper()),
not a hardcoded room-based dict. A builder can place a shopkeeper
anywhere the same way these are built: `mset <vnum> flags Shopkeeper`,
then `mset additem <vnum> <object vnum>` for each item they should
carry, priced at that object's own oset-set `cost`. The item prototypes
registered below (kunai, sword, shuriken, consumables, armor pieces)
are ordinary object prototypes -- nothing here is special-cased beyond
what any builder-made shopkeeper could also do.

SHOPS (the old room-vnum -> plain dict structure) is kept only as a
legacy fallback path in commands.py's cmd_list/cmd_buy/cmd_sell; it's
no longer populated by this module.
"""

import chunin_exam
import combat
import data_headbands
import data_villages
import territory
import farming
import gemcutter
import fishing
import data_crafting
import lumberjack
import mining
import cooking
import olc
import jutsu_scroll_catalog
import playershops
import spawn_points
import world
from world import Room, WORLD

# Legacy fallback -- see module docstring. No longer populated here.
SHOPS = {}

_VILLAGE_ROOMS = {
    "whirlpool": dict(square=None, hospital=None, kage=80001, board=None, outskirts=None, shop=None,
                      weapons_shop=None, blacksmith=None, apartment_district=None),
    "leaf": dict(square=None, hospital=None, kage=1, board=None, outskirts=None, shop=None,
                 weapons_shop=None, blacksmith=None, apartment_district=None),
    "stone": dict(square=None, hospital=None, kage=2501, board=None, outskirts=None, shop=None,
                  weapons_shop=None, blacksmith=None, apartment_district=None),
    "water": dict(square=None, hospital=None, kage=5001, board=None, outskirts=None, shop=None,
                  weapons_shop=None, blacksmith=None, apartment_district=None),
    "cloud": dict(square=None, hospital=None, kage=7501, board=None, outskirts=None, shop=None,
                  weapons_shop=None, blacksmith=None, apartment_district=None),
    "sand": dict(square=None, hospital=None, kage=10001, board=None, outskirts=None, shop=None,
                 weapons_shop=None, blacksmith=None, apartment_district=None),
}

# Shared object prototypes every village's shopkeepers draw from -- one
# set of vnums, not duplicated per village. weapon_type is set where the
# weapon-proficiency system (data_weapons.py) applies.
_ITEM_VNUMS_EXAM = {"heaven_scroll": 20800, "earth_scroll": 20801}

_ITEM_VNUMS = {
    "kunai": 9700, "sword": 9701, "shuriken": 9702, "salve": 9703, "pill": 9704,
    "rice_ball": 9705, "ramen": 9706, "canteen": 9707, "tea": 9708,
    "shirt": 9709, "pants": 9710, "sandals": 9711,
    "war_club": 9712, "spear": 9713, "chain_sickle": 9714,
    "rod_kindling": 20000, "rod_birch": 20001, "rod_oak": 20002, "rod_ironwood": 20003,
    "rod_masterwork_oak": 20004, "rod_heartwood": 20005,
    "iron_ingot": 9724, "sturdy_oak_log": 9725, "steel_ingot": 9726,
    "masterwork_oak_log": 9727, "chakra_steel_ingot": 9728,
    "ore_iron": 20400, "ore_steel": 20401, "ore_chakra_steel": 20402,
    # Miner loot table
    "rough_quartz": 9731,
    "raw_sapphire": 9732, "raw_ruby": 9733, "raw_diamond": 9734,
    "pickaxe_copper": 20100, "pickaxe_iron": 20101, "pickaxe_steel": 20102,
    "pickaxe_chakra_steel": 20103, "pickaxe_blacksteel": 20104, "pickaxe_diamond_tipped": 20105,
    # Lumberjack loot table
    "kindling": 9736, "birch_branch": 9737, "ironwood_log": 9738, "heartwood_log": 9739,
    "yew_log": 9758, "alloy_ingot": 9759,
    "weeds": 9760,
    "pot_copper": 20500, "pot_iron": 20501, "pot_steel": 20502,
    "pot_chakra_steel": 20503, "pot_blacksteel": 20504, "pot_diamond_studded": 20505,
    "cooked_minnow": 9762, "cooked_sardine": 9763, "cooked_trout": 9764, "cooked_bass": 9765,
    "cooked_salmon": 9766, "cooked_swordfish": 9767, "cooked_koi": 9768, "leviathan_fillet": 9769,
    "hoe_copper": 20802, "chisel_copper": 20803,
    "hoe_iron": 20301, "hoe_steel": 20302,
    "hoe_chakra_steel": 20303, "hoe_blacksteel": 20304, "hoe_diamond_bladed": 20305,
    "gem_quartz": 9790, "gem_jade": 9791, "gem_amber": 9792, "gem_garnet": 9793,
    "gem_amethyst": 9794, "gem_topaz": 9795, "gem_sapphire": 9796, "gem_emerald": 9797,
    "gem_ruby": 9798, "gem_diamond": 9799,
    "cut_jade": 20950, "cut_amber": 20951, "cut_garnet": 20952,
    "cut_amethyst": 20953, "cut_topaz": 20954, "cut_emerald": 20955,
    # Weaponsmith crafted goods
    "iron_kunai_smith": 9740, "steel_sword_smith": 9741, "chakra_steel_shuriken_smith": 9742,
    # Armorsmith crafted goods
    "iron_shirt_smith": 9743, "steel_pants_smith": 9744, "chakra_steel_sandals_smith": 9745,
    # Gemcutter crafted goods
    "cut_quartz": 9746, "cut_sapphire": 9747, "cut_ruby": 9748, "cut_diamond": 9749,
    # Lumberjack tools (Mining's own moved to the new 20100+ range)
    "axe_copper": 20200, "axe_iron": 20201, "axe_steel": 20202,
    "axe_chakra_steel": 20203, "axe_blacksteel": 20204, "axe_diamond_edged": 20205,
    "genin_study_scroll": jutsu_scroll_catalog.vnum_for("shadow shuriken technique"),
    "track_scroll": jutsu_scroll_catalog.vnum_for("track"),
    "chakra_paper": 9801,
    "demon_wind": 9802, "exploding_note": 9803, "smoke_bomb": 9804,
    "poison_gas_bomb": 9805, "exploding_clay": 9806, "mighty_fan": 9807,
    "glue_pot": 9808,
    "medicinal_herbs": 9809,
    "death_scroll": jutsu_scroll_catalog.vnum_for("1000 years of death"),
    "info_scroll": 9811,
    "advanced_clone_scroll": jutsu_scroll_catalog.vnum_for("advanced shadow clone jutsu"),
    # Fixed, craft-only containers; never replace builder-owned existing objects.
    "backpack_iron": 20980, "backpack_steel": 20981, "backpack_chakra": 20982,
}


def _register_shared_items() -> None:
    had_shared_items = _ITEM_VNUMS["kunai"] in olc.OBJECT_TEMPLATES
    def make(vnum, name, item_type, cost, weapon_type="", rarity="", wear_loc=None):
        if vnum in olc.OBJECT_TEMPLATES:
            return  # preserve builder edits while adding newly introduced stock
        obj = olc.default_object(vnum, name)
        obj["item_type"] = item_type
        obj["cost"] = cost
        if weapon_type:
            obj["weapon_type"] = weapon_type
        if rarity:
            obj["rarity"] = rarity
        # Auto-derive for weapons/tools (always the same slot regardless
        # of which specific weapon/tool it is) -- explicit wear_loc
        # still wins if passed, e.g. for armor, where it varies per item.
        if wear_loc is not None:
            obj["wear_loc"] = wear_loc
        elif item_type == "weapon":
            obj["wear_loc"] = "wielded"
        elif item_type == "tool":
            obj["wear_loc"] = "tool"
        olc.OBJECT_TEMPLATES[vnum] = obj

    make(_ITEM_VNUMS["kunai"], "A Basic Kunai", "weapon", 15, weapon_type="kunai")
    make(_ITEM_VNUMS["sword"], "A Basic Ninja Sword", "weapon", 40, weapon_type="sword")
    make(_ITEM_VNUMS["shuriken"], "A Throwing Shuriken", "weapon", 10, weapon_type="shuriken")
    make(_ITEM_VNUMS["demon_wind"], "A Demon Wind Shuriken", "weapon", 120, weapon_type="shuriken")
    make(_ITEM_VNUMS["exploding_note"], "An Exploding Note", "misc", 60)
    make(_ITEM_VNUMS["smoke_bomb"], "A Smoke Bomb", "misc", 70)
    make(_ITEM_VNUMS["poison_gas_bomb"], "A Poison Gas Bomb", "misc", 100)
    make(_ITEM_VNUMS["exploding_clay"], "A Wad of Exploding Clay", "misc", 150)
    make(_ITEM_VNUMS["mighty_fan"], "A Mighty Fan", "weapon", 180, weapon_type="exotic")
    make(_ITEM_VNUMS["glue_pot"], "A Pot of Glue", "misc", 50)
    make(_ITEM_VNUMS["medicinal_herbs"], "Medicinal Herbs", "misc", 150)
    # Blank writing scrolls are distinct from jutsu-teaching scrolls.
    # Existing saved object prototypes always take precedence on boot.
    make(_ITEM_VNUMS["info_scroll"], "An Info Scroll", "scroll", 25)
    info_proto = olc.OBJECT_TEMPLATES.get(_ITEM_VNUMS["info_scroll"])
    if (info_proto and info_proto.get("short_desc") == "An Info Scroll"
            and info_proto.get("item_type") == "scroll"
            and not info_proto.get("scroll_jutsu")):
        info_proto["scroll_message_writable"] = True
    jutsu_scroll_catalog.install(migrate_saved=False)
    # Backfill persistent tiered tool prototypes on existing servers as well:
    # this must run BEFORE the legacy early-return for old shared items.
    for _kind, _vnumprefix in (("rod", "rod"), ("pickaxe", "pickaxe"), ("axe", "axe")):
        for _tier, _vnumkey in (("iron", "oak" if _kind == "rod" else "iron"),
                               ("steel", "ironwood" if _kind == "rod" else "steel"),
                               ("chakra", "heartwood" if _kind == "rod" else "chakra_steel")):
            _id = _ITEM_VNUMS[f"{_vnumprefix}_{_vnumkey}"]
            _name = data_crafting.job_tool_name(_kind, _tier)
            make(_id, _name, "tool", data_crafting.TOOL_RECIPES[_tier]["price"])
            # Dedicated fixed IDs are reserved for these new crafted tools.
            _proto = olc.OBJECT_TEMPLATES[_id]
            _proto["short_desc"] = _name
            _proto["keywords"] = _name.lower().split()
            _proto["long_desc"] = f"{_name} lies here."
            _proto["wear_loc"] = "tool"
            _proto["item_type"] = "tool"
            _proto["max_uses"] = data_crafting.TOOL_RECIPES[_tier]["uses"]
    # New cooked farm dishes use a separate, unused prototype range.
    # Register missing dishes even on established worlds; make() skips
    # existing VNUMs, preserving all saved /data and builder edits.
    for _crop_index, _crop_recipe in enumerate(farming.EDIBLE_CROPS.values()):
        make(21050 + _crop_index, _crop_recipe["dish"], "food", _crop_recipe["sell_price"])
    if had_shared_items:
        return  # old templates are registered; preserve other builder edits
    make(_ITEM_VNUMS["war_club"], "A Wooden War Club", "weapon", 35, weapon_type="blunt")
    make(_ITEM_VNUMS["spear"], "A Bamboo Spear", "weapon", 45, weapon_type="polearm")
    make(_ITEM_VNUMS["chain_sickle"], "A Chain Sickle", "weapon", 60, weapon_type="exotic")
    make(_ITEM_VNUMS["salve"], "A Healing Salve", "medical", 25)
    make(_ITEM_VNUMS["pill"], "A Soldier Pill", "medical", 30)
    make(_ITEM_VNUMS["chakra_paper"], "A Sheet of Chakra Paper", "misc", 20)
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["chakra_paper"]]["long_desc"] = "A blank sheet of chakra paper lies here, waiting to react."
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["chakra_paper"]]["description"] = (
        "A thin sheet of paper made from a rare tree, sensitive to chakra. Channel your "
        "own chakra into it and it will react -- crumpling, burning, dampening, or splitting, "
        "depending on what it reveals about your own elemental nature. It's consumed the "
        "instant it reacts."
    )
    make(_ITEM_VNUMS["rice_ball"], "A Rice Ball", "food", 5)
    make(_ITEM_VNUMS["ramen"], "A Bowl of Ramen", "food", 12)
    make(_ITEM_VNUMS["canteen"], "A Canteen of Water", "drink", 5)
    make(_ITEM_VNUMS["tea"], "A Cup of Green Tea", "drink", 6)
    make(_ITEM_VNUMS["shirt"], "A Basic Ninja Shirt", "armor", 20, wear_loc="body")
    make(_ITEM_VNUMS["pants"], "Basic Ninja Pants", "armor", 20, wear_loc="legs")
    make(_ITEM_VNUMS["sandals"], "A Basic Ninja Sandals", "armor", 15, wear_loc="feet")

    # A real item prototype for each village's headband, for EVERY
    # rank tier (data_headbands.RANK_HEADBAND_TITLE). The
    # starting Student-rank headband keeps its EXACT original vnum/name (no
    # rank word, no stat suffix, since its bonus is 0) so nothing
    # about the original starting headband changes; the 7 higher
    # tiers are for promotions (currently disabled game-wide except
    # for the user's own future mob-program-driven student ->
    # genin promotion, but wired in correctly for when the rest
    # aren't). See data_headbands.py's own docstring for the full
    # "colored via existing rarity tiers, stat-boosted via the
    # existing crafted-item name-suffix mechanism" design.
    for _village_data in data_villages.VILLAGES.values():
        make(
            _village_data["default_headband_vnum"],
            f"A {_village_data['village_short_name']} Headband",
            "armor", 25, wear_loc="head",
        )
    _headband_vnum = 20700
    _RANK_COST = {
        "genin": 100, "chunin": 500, "special jonin": 2000,
        "jonin": 8000, "kage": 500000,
    }
    for _village_data in data_villages.VILLAGES.values():
        for _rank in data_headbands.RANK_ORDER[1:]:  # Student headband is already registered above
            _name = data_headbands.headband_base_name(_village_data["village_short_name"], _rank)
            make(_headband_vnum, _name, "armor", _RANK_COST[_rank],
                 rarity=data_headbands.RANK_HEADBAND_RARITY[_rank], wear_loc="head")
            _ac_bonus = data_headbands.RANK_HEADBAND_AC_BONUS.get(_rank, 0)
            if _ac_bonus:
                olc.OBJECT_TEMPLATES[_headband_vnum]["stat_bonuses"]["armor_class"] = _ac_bonus
            _headband_vnum += 1

    # Each craftable backpack owns its actual storage limit, NOT an increase
    # to a character's ordinary 20 inventory slots. Existing OLC edits win.
    for tier, recipe in data_crafting.BACKPACK_RECIPES.items():
        vnum = _ITEM_VNUMS["backpack_" + tier]
        if vnum not in olc.OBJECT_TEMPLATES:
            make(vnum, recipe["name"], "container", recipe["price"])
            olc.OBJECT_TEMPLATES[vnum]["container_capacity"] = recipe["capacity"]
            olc.OBJECT_TEMPLATES[vnum]["description"] = (
                f"A reinforced backpack holding up to {recipe['capacity']} items.")

    # Kindling base rod, upgraded tiers registered above.
    make(_ITEM_VNUMS["rod_kindling"], "A Kindling Fishing Rod", "tool", 50)

    # Every fish (fishing.FIND_TABLE -- 8 species, single non-tiered
    # items now, per the crafting revamp). Registered directly from
    # the table so item prototypes stay in sync with fishing.py.
    _FISH_COST = [2, 6, 30, 36, 200, 300, 2000, 20000]
    for _fish_index, (_fish_name, _req, _weight, _xp) in enumerate(fishing.FIND_TABLE):
        _fish_vnum = 20006 + _fish_index
        _display = " ".join(word.capitalize() for word in _fish_name.split())
        make(_fish_vnum, _display, "misc", _FISH_COST[_fish_index])

    # Cooked fish dishes keep their existing VNUMs. Farm dishes are
    # registered independently above, so these identifiers never shift.
    for _dish_index, (_raw, _data) in enumerate(
            (pair for pair in cooking.INGREDIENTS.items()
             if pair[0] not in farming.EDIBLE_CROPS)):
        _dish_vnum = 20050 + _dish_index
        make(_dish_vnum, _data["dish"], "food", _data["base_cost"])

    make(_ITEM_VNUMS["iron_ingot"], "An Iron Ingot", "material", 200)
    make(_ITEM_VNUMS["sturdy_oak_log"], "A Sturdy Oak Log", "material", 300)
    make(_ITEM_VNUMS["steel_ingot"], "A Steel Ingot", "material", 2000)
    make(_ITEM_VNUMS["masterwork_oak_log"], "A Masterwork Oak Log", "material", 3000)
    make(_ITEM_VNUMS["chakra_steel_ingot"], "A Chakra Steel Ingot", "material", 60000)

    # Smeltable ore (mining.SMELTING_RECIPES) -- the raw form of the
    # ingots above. Priced as a fraction of the ingot's own cost, same
    # "raw material cheaper than the processed good" economics as
    # every other tier ladder.
    make(_ITEM_VNUMS["ore_iron"], "An Iron Ore", "material", 80)
    make(_ITEM_VNUMS["ore_steel"], "A Steel Ore", "material", 800)
    make(_ITEM_VNUMS["ore_chakra_steel"], "A Chakra Steel Ore", "material", 8000)

    # Existing legacy raw gems remain usable even though new Mining gives
    # ONLY ores as primary finds. All ten gems can be cut after rare drops.
    import gem_inlays
    for raw_key, raw_name, cut_key, cut_name, rarity, raw_cost in (
        ("rough_quartz", "A Rough Quartz", "cut_quartz", "A Cut Quartz", "uncommon", 50),
        ("raw_sapphire", "A Raw Sapphire", "cut_sapphire", "A Cut Sapphire", "epic", 800),
        ("raw_ruby", "A Raw Ruby", "cut_ruby", "A Cut Ruby", "epic", 1200),
        ("raw_diamond", "A Raw Diamond", "cut_diamond", "A Cut Diamond", "legendary", 50000),
    ):
        make(_ITEM_VNUMS[raw_key], raw_name, "material", raw_cost, rarity=rarity)
        make(_ITEM_VNUMS[cut_key], cut_name, "material", raw_cost * 3 // 2, rarity=rarity)
        gem_key = cut_name.rsplit(" ", 1)[-1].casefold()
        points = gem_inlays.strength(gem_key)
        olc.OBJECT_TEMPLATES[_ITEM_VNUMS[cut_key]]["gem_bonuses"] = {
            "hitroll": points, "damroll": points,
        }
    for gem_key, rarity, cost in (
        ("jade", "uncommon", 25), ("amber", "rare", 60),
        ("garnet", "rare", 70), ("amethyst", "epic", 500),
        ("topaz", "epic", 500), ("emerald", "epic", 500),
    ):
        cut_key = "cut_" + gem_key
        make(_ITEM_VNUMS[cut_key], gem_inlays.cut_name(gem_key), "material",
             cost * 3 // 2, rarity=rarity)
        points = gem_inlays.strength(gem_key)
        olc.OBJECT_TEMPLATES[_ITEM_VNUMS[cut_key]]["gem_bonuses"] = {
            "hitroll": points, "damroll": points,
        }

    # Lumberjack loot table
    make(_ITEM_VNUMS["kindling"], "A Bundle of Kindling", "material", 1, rarity="common")
    make(_ITEM_VNUMS["birch_branch"], "A Birch Branch", "material", 2, rarity="common")
    make(_ITEM_VNUMS["ironwood_log"], "An Ironwood Log", "material", 600, rarity="rare")
    make(_ITEM_VNUMS["heartwood_log"], "An Ancient Heartwood Log", "material", 40000, rarity="legendary")

    # Copper base pickaxe, upgraded tiers registered above.
    make(_ITEM_VNUMS["pickaxe_copper"], "A Copper Pickaxe", "tool", 50)

    # Lumberjack tools
    # Crafted iron, steel and chakra-steel axes registered above.
    make(_ITEM_VNUMS["axe_copper"], "A Copper Axe", "tool", 50)

    # Lumberjack finds (lumberjack.FIND_TABLE) -- single, non-tiered
    # items registered directly from that table.
    _WOOD_COST = [1, 2, 300, 600, 3000, 40000, 40000]
    for _wood_index, (_wood_name, _req, _weight, _xp) in enumerate(lumberjack.FIND_TABLE):
        _wood_vnum = (_ITEM_VNUMS["yew_log"] if "yew log" in _wood_name else 20206 + _wood_index)
        _wood_display = " ".join(word.capitalize() for word in _wood_name.split())
        make(_wood_vnum, _wood_display, "material", _WOOD_COST[_wood_index])

    # Master Fishing Rod materials (kept for now, may be used by future crafting)
    make(_ITEM_VNUMS["yew_log"], "A Yew Log", "material", 40000)
    make(_ITEM_VNUMS["alloy_ingot"], "An Alloy Ingot", "material", 20000)
    make(_ITEM_VNUMS["weeds"], "A Bundle of Weeds", "material", 1)

    # Cooking tool and dishes
    # Cooking tools -- just one pot for now (crafting revamp).
    make(_ITEM_VNUMS["pot_copper"], "A Copper Cooking Pot", "tool", 30)
    make(_ITEM_VNUMS["cooked_minnow"], "A Cooked Minnow", "food", 4)
    make(_ITEM_VNUMS["cooked_sardine"], "A Cooked Sardine", "food", 6)
    make(_ITEM_VNUMS["cooked_trout"], "A Cooked Trout", "food", 30)
    make(_ITEM_VNUMS["cooked_bass"], "A Cooked Bass", "food", 36)
    make(_ITEM_VNUMS["cooked_salmon"], "A Cooked Salmon", "food", 200)
    make(_ITEM_VNUMS["cooked_swordfish"], "A Cooked Swordfish", "food", 300)
    make(_ITEM_VNUMS["cooked_koi"], "A Cooked Golden Koi", "food", 2000, rarity="epic")
    make(_ITEM_VNUMS["leviathan_fillet"], "A Leviathan Fillet", "food", 20000, rarity="legendary")

    # Farming tools
    # Farming tools -- just one hoe for now (crafting revamp).
    make(_ITEM_VNUMS["hoe_copper"], "A Copper Hoe", "tool", 50)
    # The chisel is worn by the Gemcutter job's gemcut action.
    make(_ITEM_VNUMS["chisel_copper"], "A Copper Chisel", "tool", 50)

    # Farming finds (farming.FIND_TABLE) -- single, non-tiered items.
    _CROP_COST = [2, 2, 15, 15, 100, 100, 1000, 10000]
    for _crop_index, (_crop_name, _req, _weight, _xp) in enumerate(farming.FIND_TABLE):
        # Medicinal Herbs are already registered above as VNUM 9809,
        # a crafting ingredient. Do not replace or duplicate that item
        # with an automatically numbered food prototype.
        if _crop_name == "medicinal herbs":
            continue
        _crop_vnum = 20306 + _crop_index
        _crop_display = " ".join(word.capitalize() for word in _crop_name.split())
        make(_crop_vnum, _crop_display, "food", _CROP_COST[_crop_index])

    # Rare bonus gem finds (gems.py), all now usable with Gemcutter.
    make(_ITEM_VNUMS["gem_quartz"], "A Quartz", "misc", 15, rarity="uncommon")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_quartz"]]["long_desc"] = "A clear quartz crystal lies here."
    make(_ITEM_VNUMS["gem_jade"], "A Jade", "misc", 25, rarity="uncommon")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_jade"]]["long_desc"] = "A smooth green jade stone lies here."
    make(_ITEM_VNUMS["gem_amber"], "An Amber", "misc", 60, rarity="rare")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_amber"]]["long_desc"] = "A golden orange piece of amber lies here."
    make(_ITEM_VNUMS["gem_garnet"], "A Garnet", "misc", 70, rarity="rare")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_garnet"]]["long_desc"] = "A deep red garnet lies here."
    make(_ITEM_VNUMS["gem_amethyst"], "An Amethyst", "misc", 90, rarity="rare")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_amethyst"]]["long_desc"] = "A purple amethyst crystal lies here."
    make(_ITEM_VNUMS["gem_topaz"], "A Topaz", "misc", 100, rarity="rare")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_topaz"]]["long_desc"] = "A golden yellow topaz lies here."
    make(_ITEM_VNUMS["gem_sapphire"], "A Sapphire", "misc", 400, rarity="epic")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_sapphire"]]["long_desc"] = "A brilliant blue sapphire lies here."
    make(_ITEM_VNUMS["gem_emerald"], "An Emerald", "misc", 500, rarity="epic")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_emerald"]]["long_desc"] = "A vivid green emerald lies here."
    make(_ITEM_VNUMS["gem_ruby"], "A Ruby", "misc", 600, rarity="epic")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_ruby"]]["long_desc"] = "A deep red ruby lies here."
    make(_ITEM_VNUMS["gem_diamond"], "A Diamond", "misc", 5000, rarity="legendary")
    olc.OBJECT_TEMPLATES[_ITEM_VNUMS["gem_diamond"]]["long_desc"] = "A brilliant clear diamond lies here, catching the light."

    # Chunin Exam scrolls (chunin_exam.py). NOT no_sac protected --
    # per an earlier, explicit request, every item in the game must be
    # sacrificeable, with no exceptions (verified directly by
    # test_every_registered_item_can_be_sacrificed, which exercises
    # every single registered item). A player CAN accidentally
    # sacrifice a scroll they worked to obtain; that's a real, known
    # risk, kept consistent with that established rule rather than
    # quietly carving out an exception to it.
    make(_ITEM_VNUMS_EXAM["heaven_scroll"], chunin_exam.HEAVEN_SCROLL, "trash", 500, rarity="epic")
    make(_ITEM_VNUMS_EXAM["earth_scroll"], chunin_exam.EARTH_SCROLL, "trash", 500, rarity="epic")


def _make_shopkeeper(vnum: int, name: str, room_vnum: int, item_keys, buys_categories) -> None:
    t = combat.default_template(vnum, name)
    t["level"] = 1
    t["hit_dice"] = "1d1+9999"  # irrelevant -- shopkeepers can't be attacked
    t["act_flags"] = ["Npc", "Sentinel", "Shopkeeper"]
    t["shop_items"] = [_ITEM_VNUMS[key] for key in item_keys]
    t["shop_buys_categories"] = list(buys_categories)
    if buys_categories in (["weapon"], ["armor"]):
        import shop_flags
        shop_flags.set_type(t, "weapons" if buys_categories == ["weapon"] else "blacksmith")
    combat.MOB_TEMPLATES[vnum] = t
    # Per direct request/confirmation (Section 138): no longer auto-spawned --
    # content.py's own hardcoded startup call was unconditionally re-registering
    # this spawn point every server restart, silently undoing a staff member's
    # real, deliberate removal. The mob's own real template still registers
    # here (spawnable via 'spawnpoint add'), it just no longer auto-spawns.


def populate() -> None:
    from data_villages import VILLAGES
    from kage import kage_title
    import areas

    areas.ensure_single_village_areas()
    areas.ensure_hidden_village_areas()
    _register_shared_items()
    import reaper_seal
    reaper_seal.register_items()
    import lightsabers
    lightsabers.register_items()

    # Shopkeeper mob template vnums: village index * 10 + role, in the
    # 6000 block (distinct from the 5000-block bandit templates).
    village_index = {key: index for index, key in enumerate(VILLAGES)}

    for village, rooms in _VILLAGE_ROOMS.items():
        v = VILLAGES[village]
        if v.get("hidden_at_creation", False):
            area = areas.find_area(village)
            if not area or not area.vnum_start <= rooms["kage"] <= area.vnum_end:
                continue  # Do not seed a hidden home inside someone else's reservation.
        short = v["village_short_name"]

        # Per direct request/confirmation (Section 143): "convert
        # these into 1 leaf village not expansions...give each area
        # 2500 vnums to work with no expansions so that they are
        # single areas...create a single room for each that will be
        # the hokage room in this new are its ok to wipe old areas in
        # this one instance." Every OTHER real room this loop used to
        # build (mission board, shops, gambling den, roulette room,
        # apartments, Main Street, gathering spots) is genuinely gone
        # -- confirmed directly this is fine to wipe entirely. Every
        # ordinary MOB TEMPLATES below (shopkeeper, villager, banker,
        # gambling attendant, etc.) stay registered, but the old
        # village mission bandits and rogue tiers are retired. Survivors
        # won't spawn anywhere until staff places them via
        # 'spawnpoint add' at whatever new rooms they build.
        kage_room = Room(rooms["kage"], f"{short} Kage Chamber",
            f"The office of {kage_title(village)}. Try 'say mission' or 'ask kage promotion'.")
        if village == "whirlpool":
            kage_room.name = "Uzushio Sealing Hall"
            kage_room.description = (
                "Ocean winds circle a quiet hall carved with spiral seals. The Uzumaki "
                "clan keeps the village's traditions here, under the care of its leader. "
                "Try 'say mission' or 'ask kage promotion'."
            )
        kage_room.safe = True
        kage_room.flags.append("accelerated_healing")
        WORLD.add_room(kage_room)

        # A persistent-build-compatible stat trainer TEMPLATE, not an
        # automatic spawn. Staff position it with spawnpoint add mob <vnum>
        # <room>; the saved world and its custom spawn layout remain theirs.
        trainer_vnum = 6000 + village_index[village] * 10 + 9
        trainer = combat.default_template(trainer_vnum, f"a {short} shinobi training instructor")
        trainer["act_flags"] = ["Npc", "Sentinel", "Trainer"]
        trainer["level"] = 1
        trainer["hit_dice"] = "1d1+9999"
        trainer["description"] = (
            "A veteran shinobi oversees strength drills, chakra-control "
            "tree walking, meditation, target detection, and other stat exercises."
        )
        combat.MOB_TEMPLATES[trainer_vnum] = trainer

        attendant_vnum = 6000 + village_index[village] * 10 + 4
        attendant = combat.default_template(attendant_vnum, f"a {short} gambling den attendant")
        attendant["level"] = 1
        attendant["hit_dice"] = "1d1+9999"  # irrelevant -- can't be attacked, same as shopkeepers
        attendant["act_flags"] = ["Npc", "Sentinel"]
        attendant["gambler"] = True
        combat.MOB_TEMPLATES[attendant_vnum] = attendant
        # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

        roulette_attendant_vnum = 6000 + village_index[village] * 10 + 8
        roulette_attendant = combat.default_template(roulette_attendant_vnum, f"a {short} roulette croupier")
        roulette_attendant["level"] = 1
        roulette_attendant["hit_dice"] = "1d1+9999"  # irrelevant -- can't be attacked, same as shopkeepers
        roulette_attendant["act_flags"] = ["Npc", "Sentinel"]
        roulette_attendant["gambler"] = True
        combat.MOB_TEMPLATES[roulette_attendant_vnum] = roulette_attendant
        # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

        if village == "leaf":
            # The one generic Shopkeeper template every player shop
            # reuses -- shop_items stays empty (real stock lives on the
            # OWNER's own shop_stock, not the shared template), and it
            # doesn't buy anything either (player shops only sell what
            # their owner stocked, not buy from random players).
            shopkeeper_template = combat.default_template(
                playershops.SHOPKEEPER_TEMPLATE_VNUM, "a shopkeeper"
            )
            shopkeeper_template["level"] = 1
            shopkeeper_template["hit_dice"] = "1d1+9999"  # irrelevant -- can't be attacked, same as other shopkeepers
            shopkeeper_template["act_flags"] = ["Npc", "Sentinel", "Shopkeeper"]
            shopkeeper_template["shop_items"] = []
            shopkeeper_template["shop_buys_categories"] = []
            combat.MOB_TEMPLATES[playershops.SHOPKEEPER_TEMPLATE_VNUM] = shopkeeper_template

        # Original rank-specific bandits/rogues have been retired. Only
        # staff-marked Mission prototypes from the current world qualify.

        idx = village_index[village]
        _make_shopkeeper(
            6000 + idx * 10 + 1, f"a {short} general store shopkeeper", rooms["shop"],
            ["kunai", "shuriken", "exploding_note", "smoke_bomb", "poison_gas_bomb", "exploding_clay", "glue_pot", "medicinal_herbs", "info_scroll", "salve", "pill", "chakra_paper", "rice_ball", "ramen", "canteen", "tea",
             "rod_kindling", "axe_copper", "pickaxe_copper", "pot_copper", "hoe_copper", "chisel_copper"],
            buys_categories=[],
        )
        _make_shopkeeper(
            6000 + idx * 10 + 2, f"a {short} weapons shopkeeper", rooms["weapons_shop"],
            ["kunai", "sword", "shuriken", "demon_wind", "mighty_fan", "war_club", "spear", "chain_sickle"],
            buys_categories=["weapon"],
        )
        _make_shopkeeper(
            6000 + idx * 10 + 3, f"a {short} blacksmith", rooms["blacksmith"],
            ["shirt", "pants", "sandals"],
            buys_categories=["armor"],
        )
        villager = combat.default_template(6000 + idx * 10 + 5, f"a {short} villager")
        villager["level"] = 1
        villager["hit_dice"] = "1d1+9999"  # can't be attacked, matching shopkeepers/gambling den attendants
        villager["act_flags"] = ["Npc", "Sentinel"]
        combat.MOB_TEMPLATES[6000 + idx * 10 + 5] = villager
        # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

        # Bingo Book office -- lets any player use 'place bounty' here
        # (see commands.cmd_place), closing the gap where the
        # BountyOffice flag existed but no actual mob anywhere in the
        # game used it. One per village, at the village square (same
        # high-visibility spot as the villager above), not gated to
        # Leaf only like the gambling den -- posting a bounty is a
        # core, village-agnostic feature.
        bounty_office = combat.default_template(6000 + idx * 10 + 6, f"a {short} Bingo Book office attendant")
        bounty_office["level"] = 1
        bounty_office["hit_dice"] = "1d1+9999"  # can't be attacked, matching shopkeepers/villager above
        bounty_office["act_flags"] = ["Npc", "Sentinel", "BountyOffice"]
        combat.MOB_TEMPLATES[6000 + idx * 10 + 6] = bounty_office
        # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

        # Banker -- lets any player deposit/withdraw ryo safely away
        # from death-penalty loss and PvP (see bank.py, commands.
        # cmd_bank). One per village, at the village square, same
        # placement as the Bingo Book office right above.
        banker = combat.default_template(6000 + idx * 10 + 7, f"a {short} banker")
        banker["level"] = 1
        banker["hit_dice"] = "1d1+9999"  # can't be attacked, matching shopkeepers/villager above
        banker["act_flags"] = ["Npc", "Sentinel", "Banker"]
        combat.MOB_TEMPLATES[6000 + idx * 10 + 7] = banker
        # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

    # --- War/territory system: garrison mob templates (Section 79) ---
    # One real, fightable mob template per village+tier combo (15
    # total), driven directly from territory.py's own tier/vnum
    # definitions so these can never drift out of sync with what
    # territory.buy_garrison() actually spawns. Not spawned anywhere
    # here -- a garrison mob only exists once a village's treasury pays
    # to station one at a specific capture point (see cmd_garrison).
    for _village_key in data_villages.VILLAGES:
        _village_short = data_villages.VILLAGES[_village_key]["village_short_name"]
        for _tier_key, _tier_info in territory.GARRISON_TIERS.items():
            _garrison_vnum = territory.garrison_mob_vnum(_village_key, _tier_key)
            combat.register_template(
                _garrison_vnum, f"a {_village_short} {_tier_info['display_name'].lower()}",
                level=_tier_info["level"], max_health=_tier_info["max_health"],
                min_damage=_tier_info["min_damage"], max_damage=_tier_info["max_damage"],
                experience_reward=_tier_info["level"] * 5, ryo_reward=_tier_info["level"] * 2,
            )
            combat.MOB_TEMPLATES[_garrison_vnum]["act_flags"] = ["Npc", "Garrison"]

    # Trap/bomb mob templates (10 total, 5 villages x 2 types) -- same
    # driven-from-territory.py reasoning as garrison mobs above. Given
    # modest, killable HP (not unkillable like garrison/shopkeepers),
    # so an enemy who actually spots one can fight and disarm it
    # rather than only ever being able to walk into it blind. Zero
    # attack damage of their own -- their real "damage" is the
    # trigger-on-entry hit (territory.check_trap_trigger), not normal
    # mob combat, so they shouldn't also independently attack back.
    for _village_key in data_villages.VILLAGES:
        _village_short = data_villages.VILLAGES[_village_key]["village_short_name"]
        for _trap_key, _trap_info in territory.TRAP_TYPES.items():
            _trap_vnum = territory.trap_mob_vnum(_village_key, _trap_key)
            combat.register_template(
                _trap_vnum, f"a {_village_short} {_trap_info['display_name'].lower()}",
                level=20, max_health=150, min_damage=0, max_damage=0,
                experience_reward=50, ryo_reward=10,
            )
            combat.MOB_TEMPLATES[_trap_vnum]["act_flags"] = ["Npc", "Trap"]

    # 25x25 Forest of Death, VNUM 45..669. Saved world rooms restore later;
    # the main entry point performs one explicitly authorized, bounded
    # migration over the live /data world on the first updated startup.
    import forest_of_death_grid
    forest_of_death_grid.populate_world(WORLD)
    forest_of_death_grid.populate_final_room(WORLD)

    combat.register_template(
        chunin_exam.HEAVEN_GUARDIAN_VNUM, "a Heaven Scroll guardian", level=15,
        max_health=250, min_damage=8, max_damage=18,
        experience_reward=400, ryo_reward=200,
        loot_items=[chunin_exam.HEAVEN_SCROLL],
    )
    # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

    combat.register_template(
        chunin_exam.EARTH_GUARDIAN_VNUM, "an Earth Scroll guardian", level=15,
        max_health=250, min_damage=8, max_damage=18,
        experience_reward=400, ryo_reward=200,
        loot_items=[chunin_exam.EARTH_SCROLL],
    )
    # No hardcoded spawn point (Section 138) -- staff adds it via 'spawnpoint add'.

    # Legendary Kage-sold items (Section 76, per explicit request) --
    # registered once here, same as every other piece of shipped item
    # content, before spawn_points.apply_all() runs.
    import legendary_items
    legendary_items.register_all(olc, combat)

    # Restore builder-created prototypes before applying the saved world so
    # every snapshot reference resolves safely.
    spawn_points.restore_custom_templates()

    # Apply the manually-saved room/mob/item snapshot over hardcoded content.
    import world_persistence
    world_persistence.apply_saved_world()

    # Existing builder-created village rooms predate the registered areas.
    # Rehome the old rooms and their saved spawn references before spawning.
    import village_room_relocation
    village_room_relocation.relocate_saved_rooms()

    # Spawn points are the FINAL reconciliation pass. Reapply their latest
    # authoritative prototypes, then restore only genuinely missing mobs and
    # items. This ordering prevents a stale world snapshot from making a
    # registered spawn disappear after reboot.
    spawn_points.restore_custom_templates()
    # Retire only the 30 obsolete mission mob IDs from old builder snapshots
    # and saved spawn points; preserve every unrelated saved /data record.
    import legacy_mission_mobs
    legacy_mission_mobs.retire_saved_mobs()
    # VNUM 6 remains fully builder-editable, and existing /data saves win.
    # Guarantee an available prototype for installations without one.
    if 6 not in combat.MOB_TEMPLATES:
        dummy = combat.default_template(6, "an immortal shinobi training dummy")
        dummy["level"] = 1
        dummy["auto_balance"] = False
        dummy["hit_dice"] = "1d1+999999"
        dummy["damage_dice"] = "0d1+0"
        dummy["act_flags"] = ["Npc", "Sentinel"]
        dummy["description"] = "A motionless training dummy that can withstand endless jutsu practice."
        combat.MOB_TEMPLATES[6] = dummy
    spawn_points.apply_all()

    # Existing installations restore saved general-store templates over
    # built-in stock. Add this new ingredient after that reconciliation too.
    from data_villages import VILLAGES as _villages_for_herbs
    for village_index_for_herbs in range(len(_villages_for_herbs)):
        general_store = combat.MOB_TEMPLATES.get(6000 + village_index_for_herbs * 10 + 1)
        if general_store is not None:
            stock = general_store.setdefault("shop_items", [])
            if _ITEM_VNUMS["medicinal_herbs"] not in stock:
                stock.append(_ITEM_VNUMS["medicinal_herbs"])
            # Add Info Scrolls to existing general stores without touching
            # unrelated builder-created items at the reserved item VNUM.
            blank = olc.OBJECT_TEMPLATES.get(_ITEM_VNUMS["info_scroll"])
            if (blank and blank.get("short_desc") == "An Info Scroll"
                    and blank.get("item_type") == "scroll"
                    and _ITEM_VNUMS["info_scroll"] not in stock):
                stock.append(_ITEM_VNUMS["info_scroll"])

    # Persistent Teams (Section 82, per explicit request) -- loads
    # whatever teams already exist in teams.json back into memory.
    # Order relative to the rest of populate() doesn't actually
    # matter (teams don't reference any room/mob/item content at
    # all), but placed last to match this function's own established
    # convention of loading player-created persistent state after
    # every static system exists.
    import teams
    teams.load_all()

    # OOC chat log (Section 93, per direct request) -- persisted
    # across restarts, matching teams.load_all()'s own pattern.
    import chatlog
    chatlog.load_all()

    # The Duel Arena (Section 89, per direct request) -- a genuine,
    # permanent 10-room area, built the same way as every other static
    # room in the game.
    import duel_arena
    duel_arena.build_arena(world)

    # The Jail Cell (Section 94, per direct request) -- a genuine,
    # permanent, exit-less room, built the same way as every other
    # static room in the game.
    import jail
    jail.build_jail(world)

    # Tailed Beasts (Section 127, per direct request/confirmation) --
    # registers all 9 real beast mob templates so they're ready the
    # instant an immortal uses 'unleash beast', matching every other
    # hardcoded mob's own registration convention.
    import tailed_beasts
    tailed_beasts.register_all_beast_templates(combat)

    # Arena and jail rooms are built after the saved snapshot is applied.
    # Enforce area deletions again so these hardcoded rooms stay removed.
    world_persistence.apply_deleted_areas()

    # Add Chuunin shop stock only AFTER all saved builder objects and mob
    # templates have won. Existing /data prototypes are never overwritten;
    # collisions are skipped, and staff-owned shop mobs are not fabricated.
    import chuunin_shops
    chuunin_shops.install()
    # Iron gathering tools and the missing hoe/pot tiers use the same
    # post-restore, builder-safe installer; mob 779 is never synthesized.
    import iron_tool_shop
    iron_tool_shop.install()
    # Rank-tier weapon/armor shops (784/786), including elemental auras.
    import jounin_shops
    jounin_shops.install()

    reaper_seal.restore_world()
    import technique_names
    technique_names.migrate_templates()
    # Final pass after saved world, spawn templates, and all builder edits win.
    # Register ordered 31501-32000 scrolls, migrate old scroll object IDs,
    # and leave the user's rooms and non-scroll objects untouched.
    jutsu_scroll_catalog.install()

    # Special event proctor is guaranteed without creating a saved spawn point.
    chunin_exam.ensure_proctor()


def register_default_spawn_points_for_testing() -> None:
    """TEST-ONLY. Per direct request/confirmation (Section 138): "i
    dont want any hardcoded spawnpoitns at all staff will add the
    spawnpoints and if there are spawnpoiitns mobs will spawn" -- the
    real game (populate(), above) genuinely has zero hardcoded
    add_spawn_point calls anymore; staff builds the entire spawn
    layout manually via 'spawnpoint add', and content.py's own
    hardcoded startup code will never silently undo a real removal
    again.

    Per direct correction (Section 143): every village is now
    genuinely a SINGLE real room (the Kage/Hokage chamber) -- every
    other room this helper used to reference (shop, mission board,
    outskirts, gambling den) no longer exists at all until staff
    builds one themselves, so every real mob below spawns at that one
    genuinely real room instead. This is the CORRECT, current state
    of the game, not a placeholder -- there is no separate
    "already-configured server" to simulate anymore.

    This function exists ONLY so the existing test suite (which
    assumes a banker/shopkeeper/villager/bandit/etc. is already
    present) doesn't need a wholesale rewrite. Call this once after
    populate() in a test's own setup, then spawn_points.apply_all()
    to actually spawn from what it just registered. Never called by
    the real game itself (main.py, session.py)."""
    from data_villages import VILLAGES
    village_index = {key: index for index, key in enumerate(VILLAGES)}

    for village, rooms in _VILLAGE_ROOMS.items():
        idx = village_index[village]
        kage_room = rooms["kage"]

        # Every real mob template spawns at the one room that
        # genuinely exists per village (Section 143) -- the Kage
        # room. 3 real shopkeepers.
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 1, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 2, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 3, kage_room)
        # Villager, gambling attendant, banker.
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 5, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 6, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 7, kage_room)
        # Gambling den + roulette room attendants.
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 4, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 8, kage_room)
        spawn_points.add_spawn_point("mob", 6000 + idx * 10 + 9, kage_room)  # stat trainer
        # Historical mission-target mobs are retired and no longer spawned.

    # Chunin Exam forest guardians.
    import chunin_exam
    spawn_points.add_spawn_point("mob", chunin_exam.HEAVEN_GUARDIAN_VNUM, chunin_exam.FOREST_VNUMS[0])
    spawn_points.add_spawn_point("mob", chunin_exam.EARTH_GUARDIAN_VNUM, chunin_exam.FOREST_VNUMS[2])
