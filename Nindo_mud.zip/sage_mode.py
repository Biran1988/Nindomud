"""Elder-taught Sage Mode for each summoning family.

Ninken, slug, and monkey Sage Modes are game extensions of the summon
contracts; the slow nature-energy training follows the toad/snake theme.
"""
import random
import time

import data_summons
import combat
import six_paths
MIN_LEVEL = 80
TRAIN_INTERVAL = 60 * 60
TRAIN_SUCCESS_PERCENT = 5
MASTERY_REQUIRED = 100
IDLE_CHAKRA_UPKEEP = 12  # every 10 seconds while online and out of combat
COMBAT_CHAKRA_UPKEEP = 16  # each combat round
COMBAT_STAMINA_UPKEEP = 8
SUMMON_COST = 40


def chosen_contract(player):
    """The first valid signed family is the player's permanent choice."""
    return next((key for key in player.signed_summoning_contracts if key in data_summons.CONTRACTS), "")


def active_contract(player):
    contract = player.sage_active_contract
    if (contract in data_summons.CONTRACTS
            and contract == chosen_contract(player)
            and player.sage_mastery.get(contract, 0) >= MASTERY_REQUIRED):
        return contract
    return ""


def outgoing(player, damage, jutsu=False, weapon=False):
    if six_paths.active(player):
        return six_paths.outgoing(player, damage)
    contract = active_contract(player)
    if not contract:
        return damage
    bonus = 20 + (10 if contract == "snake" and jutsu else 0) + (10 if contract == "monkey" and weapon else 0)
    return max(1, damage * (100 + bonus) // 100)


def accuracy(player):
    if six_paths.active(player):
        return six_paths.accuracy(player)
    contract = active_contract(player)
    return 10 + (5 if contract == "toad" else 0) if contract else 0


def extra_attacks(player):
    """Ninken Sage Mode grants one extra ordinary strike each combat round."""
    return 1 if active_contract(player) == "ninken" else 0


def incoming(player, damage):
    if six_paths.active(player):
        return six_paths.incoming(player, damage)
    return max(0, damage * 90 // 100) if active_contract(player) else damage


def combat_pulse(session):
    six_paths.combat_pulse(session)
    import upkeep_reports
    player = session.player
    contract = active_contract(player)
    if not contract:
        if player.sage_active_contract:
            for message in upkeep_reports.flush(player, "Sage Mode"):
                session.send(message)
            player.sage_active_contract = ""
            session.send("Your Sage Mode ends because its contract or mastery is no longer valid.")
        return
    if player.chakra < COMBAT_CHAKRA_UPKEEP or player.stamina < COMBAT_STAMINA_UPKEEP:
        for message in upkeep_reports.flush(player, "Sage Mode"):
            session.send(message)
        player.sage_active_contract = ""
        session.send("Your chakra and stamina give out -- your Sage Mode fades.")
        return
    player.chakra -= COMBAT_CHAKRA_UPKEEP
    player.stamina -= COMBAT_STAMINA_UPKEEP
    for message in upkeep_reports.record(player, "Sage Mode", COMBAT_CHAKRA_UPKEEP, COMBAT_STAMINA_UPKEEP):
        session.send(message)
    if contract == "slug" and player.health > 0:
        amount = min(player.maximum_health - player.health, max(1, player.maximum_health // 20))
        if amount > 0:
            player.health += amount
            session.send(f"Slug Sage Mode restores {amount} health.")


def idle_upkeep(session):
    """Charge on the idle timer; report whether anything was sent."""
    player = session.player
    import upkeep_reports
    if not player.sage_active_contract:
        return False
    if not active_contract(player) or player.chakra < IDLE_CHAKRA_UPKEEP:
        for message in upkeep_reports.flush(player, "Sage Mode"):
            session.send(message)
        player.sage_active_contract = ""
        session.send("Your chakra gives out -- your Sage Mode fades.")
        return True
    player.chakra -= IDLE_CHAKRA_UPKEEP
    messages = upkeep_reports.record(player, "Sage Mode", IDLE_CHAKRA_UPKEEP)
    for message in messages:
        session.send(message)
    return bool(messages)


def elder_families(player):
    """Only living, builder-configured elders in the current room count."""
    families = set()
    for mob in combat.mobs_in_room(player.room_vnum):
        template = combat.MOB_TEMPLATES.get(mob.template_vnum, {})
        family = template.get("summon_family", "")
        if mob.health > 0 and "SummonElder" in template.get("act_flags", []) and family in data_summons.CONTRACTS:
            families.add(family)
    return families


def command(session, args):
    player = session.player
    if args and args[0].lower() == "status":
        chosen = chosen_contract(player)
        lines = ["Sage Mode training:"]
        if chosen:
            info = data_summons.CONTRACTS[chosen]
            pct = max(0, min(100, player.sage_mastery.get(chosen, 0)))
            lines.append(f"  Permanent contract: {info['display_name']} -- {info['hideout_name']}")
            lines.append(f"  Mastery: {pct}%")
        else:
            lines.append("  No summoning contract signed. Choose one family at its elder.")
        lines.append(f"Active: {active_contract(player) or 'none'}")
        lines.append("Use sage train at an elder; sage [on <family>] toggles your mastered mode.")
        session.send("\n".join(lines))
        return
    action = args[0].lower() if args else "toggle"
    if action == "off" or (action == "toggle" and active_contract(player)):
        if not active_contract(player):
            session.send("You are not in Sage Mode.")
            return
        import upkeep_reports
        for message in upkeep_reports.flush(player, "Sage Mode"):
            session.send(message)
        player.sage_active_contract = ""
        session.send("You release your Sage Mode.")
        return
    if action not in ("train", "on", "activate", "toggle") and action not in data_summons.CONTRACTS:
        session.send("Usage: sage [on <family>|off|status] | sage train [family]")
        return
    if action == "train" and (session.combat_target or session.pvp_target):
        session.send("You must finish fighting first.")
        return
    if action == "train":
        families = elder_families(player)
        contract = args[1].lower() if len(args) > 1 else (next(iter(families)) if len(families) == 1 else None)
        if contract not in families:
            session.send("Choose an elder here: sage train <" + "|".join(sorted(families)) + ">")
            return
        if contract is None:
            session.send("Only a summon elder at their hideout can teach Sage Mode.")
            return
    else:
        if action in ("on", "activate"):
            contract = args[1].lower() if len(args) > 1 else player.sage_preferred_contract
        else:
            contract = player.sage_preferred_contract if action == "toggle" else action
        if not contract:
            chosen = chosen_contract(player)
            contract = chosen if player.sage_mastery.get(chosen, 0) >= MASTERY_REQUIRED else ""
        if contract not in data_summons.CONTRACTS:
            session.send("Choose a mastered family: sage on <toad|snake|slug|ninken|monkey>.")
            return
    chosen = chosen_contract(player)
    import whirlpool_fuinjutsu
    if action != "train" and whirlpool_fuinjutsu.blocks_summoning(player):
        session.send("A Whirlpool contract seal prevents Sage Mode activation.")
        return
    if contract != chosen:
        session.send(f"Your {chosen.title()} contract is permanent; you cannot learn another family's Sage Mode." if chosen
                     else "You must sign this family's summoning contract first.")
        return
    if action == "train":
        if player.level < MIN_LEVEL:
            session.send(f"The elder will only teach a level {MIN_LEVEL} shinobi.")
            return
        pct = max(0, min(100, player.sage_mastery.get(contract, 0)))
        if pct >= MASTERY_REQUIRED:
            session.send("You have already mastered this family's Sage Mode.")
            return
        now = time.time()
        ready = player.sage_training_ready_at.get(contract, 0)
        if now < ready:
            session.send(f"The elder asks you to meditate longer. Try again in {int((ready - now + 3599) // 3600)} hours.")
            return
        player.sage_training_ready_at[contract] = now + TRAIN_INTERVAL
        if random.randint(1, 100) <= TRAIN_SUCCESS_PERCENT:
            player.sage_mastery[contract] = pct + 1
            session.send(f"The {contract} elder guides you through stillness and natural energy. {contract.title()} Sage mastery: {pct + 1}%." +
                         (" You can now activate this Sage Mode!" if pct + 1 == 100 else ""))
        else:
            session.send(f"The {contract} elder steadies your unstable natural energy. You learn from the attempt, but mastery remains {pct}%.")
        return
    if player.sage_mastery.get(contract, 0) < MASTERY_REQUIRED:
        session.send(f"You must reach 100% mastery with the {contract} elder first.")
        return
    if active_contract(player):
        session.send("You are already in Sage Mode. Use 'sage off' before choosing another family.")
        return
    required_chakra = COMBAT_CHAKRA_UPKEEP if session.combat_target or session.pvp_target else IDLE_CHAKRA_UPKEEP
    if player.chakra < required_chakra or player.stamina < COMBAT_STAMINA_UPKEEP:
        session.send("You need chakra and stamina to sustain Sage Mode.")
        return
    if player.six_paths_active:
        session.send("Release your Six Paths mode before entering summon Sage Mode.")
        return
    player.sage_active_contract = contract
    player.sage_preferred_contract = contract
    session.send(f"You gather natural energy and enter {contract.title()} Sage Mode. Use 'sage off' to release it.")


def summon_command(session, args):
    player = session.player
    if args and args[0].lower() == "dismiss":
        if session.combat_target or session.pvp_target:
            session.send("You cannot dismiss a summon while fighting.")
            return
        if combat.dismiss_summon(player):
            session.send("You dismiss your summon.")
        else:
            session.send("You have no summon to dismiss.")
        return
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.blocks_summoning(player):
        session.send("A Whirlpool contract seal prevents summoning or signing a contract.")
        return
    if args and args[0].lower() == "sign":
        sign_command(session, args[1:])
        return
    if not args or args[0].lower() not in data_summons.CONTRACTS:
        session.send("Usage: summon <toad|snake|slug|ninken|monkey|salamander> [stomach <enemy>] | summon sign [family] | summon dismiss")
        return
    contract = args[0].lower()
    chosen = chosen_contract(player)
    if contract != chosen:
        session.send(f"Your {chosen.title()} contract is permanent; you cannot summon another family." if chosen
                     else "You have not signed that summoning contract.")
        return
    tier = data_summons.best_available_tier(contract, player.level)
    if (session.combat_target or session.pvp_target) and (
            not tier or tier.get("mechanic") != "trap"):
        session.send("You cannot change living summons while fighting.")
        return
    stomach_target = None
    if contract == "toad" and len(args) > 1 and args[1].lower() == "stomach":
        if player.level < 90:
            session.send("You need level 90 to manifest the Toad Stomach barrier.")
            return
        tier = data_summons.tier_by_key("toad_4")
    if tier and tier.get("mechanic") == "trap":
        target_words = args[2:] if len(args) > 1 and args[1].lower() == "stomach" else args[1:]
        stomach_target = (combat.find_mob(player.room_vnum, " ".join(target_words))
                          if target_words else session.combat_target)
        if (stomach_target is None or stomach_target.health <= 0 or
                stomach_target.room_vnum != player.room_vnum or
                any((combat.is_shopkeeper(stomach_target), combat.is_gambler(stomach_target),
                     combat.is_teacher(stomach_target), combat.is_immortal_mob(stomach_target)))):
            session.send("Choose an active hostile enemy here: summon toad stomach <enemy> (level 90+) "
                         "or summon toad <enemy> (level 250 Great Stomach).")
            return
    if tier is None or player.chakra < SUMMON_COST:
        session.send(f"You need level 20 and {SUMMON_COST} chakra to summon this family.")
        return
    player.chakra -= SUMMON_COST
    combat.dismiss_summon(player)
    summon = combat.spawn_summon(player, tier)
    if summon is None:
        session.send("The summoning seal fails to form.")
        return
    if stomach_target is not None:
        summon.stomach_target_instance_id = stomach_target.instance_id
    if getattr(summon, "is_toad_stomach_barrier", False):
        session.send(f"&RYou manifest {summon.name} as a living barrier around {stomach_target.name}! "
                     "Every exit is sealed and the stomach begins devouring its prisoner. "
                     "Chakra upkeep maintains the seal; summon dismiss releases it.&x")
    else:
        session.send(f"You summon {summon.name} to fight beside you.")


def order_command(session, args):
    """Direct one summoned partner; the command never affects other mobs."""
    if not args or args[0].lower() != "summon":
        session.send("Usage: order summon <follow me|stay|guard|sleep|wake|rest|sit|stand|attack enemy|assist|stop|status|help>")
        return
    summon = combat.active_summon(session.player)
    if summon is None:
        session.send("You have no active summon to command.")
        return
    words = [a.lower() for a in args[1:]]
    if words == ["help"]:
        session.send("Orders: follow me, stay, guard, sleep, wake, rest, sit, stand, "
                     "attack <enemy>, assist, stop, status. A Toad Stomach is a barrier, "
                     "not a movable animal; use summon dismiss to release it.")
        return
    if not words or words == ["status"]:
        session.send(f"{summon.name}: {summon.health}/{summon.max_health} HP, "
                     f"order '{summon.summon_order}', room {summon.room_vnum}.")
        return
    if getattr(summon, "is_toad_stomach_barrier", False):
        session.send("The Toad Stomach is a fixed chakra barrier, not an animal that follows orders. "
                     "Use 'summon dismiss' to release it.")
        return
    if words[0] == "attack":
        if summon.room_vnum != session.player.room_vnum:
            session.send("Your summon must be in this room to attack.")
            return
        target = combat.find_mob(session.player.room_vnum, " ".join(args[2:]))
        if (not target or target is summon or target.health <= 0
                or combat.is_shopkeeper(target) or combat.is_gambler(target)
                or combat.is_teacher(target) or combat.is_immortal_mob(target)):
            session.send("Order your summon to attack a valid hostile mob in this room.")
            return
        summon.summon_order = "attack"
        summon.summon_attack_target_id = target.instance_id
        session.send(f"You order {summon.name} to attack {target.name}!")
        return
    if words[0] == "follow":
        summon.summon_order = "follow"
        summon.summon_attack_target_id = 0
        session.send(f"{summon.name} will follow you between rooms.")
        return
    if words[0] in {"stay", "guard", "sleep", "assist", "stop", "rest", "sit", "stand"}:
        summon.summon_order = {"rest": "sleep", "sit": "sleep", "stand": "follow"}.get(words[0], words[0])
        summon.summon_attack_target_id = 0
        session.send(f"{summon.name} obeys your {words[0]} order.")
        return
    if words[0] == "wake":
        summon.summon_order = "follow"
        session.send(f"{summon.name} wakes and follows you.")
        return
    session.send("Usage: order summon <follow me|stay|guard|sleep|wake|rest|sit|stand|attack enemy|assist|stop|status|help>")


def sign_command(session, args=None):
    player = session.player
    if session.combat_target or session.pvp_target:
        session.send("You must finish fighting first.")
        return
    chosen = chosen_contract(player)
    if chosen:
        session.send(f"You already chose the {chosen.title()} family. A summoning contract is permanent; you cannot sign another.")
        return
    families = elder_families(player)
    contract = args[0].lower() if args else (next(iter(families)) if len(families) == 1 else None)
    if contract not in families:
        session.send("Choose an elder here: summon sign <" + "|".join(sorted(families)) + ">")
        return
    if contract is None:
        session.send("Find the summon family's hidden sanctuary to sign its contract.")
    elif player.level < data_summons.CONTRACTS[contract]["unlock_level"]:
        session.send("You must reach level 20 to sign a summoning contract.")
    else:
        player.signed_summoning_contracts = [contract]
        session.send(f"You permanently choose the {contract.title()} summoning contract before its elder. Use 'summon {contract}' to call a partner.")
