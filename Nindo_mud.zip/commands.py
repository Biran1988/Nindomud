"""
Command parser and handlers.

Covers: movement, social commands, equipment,
prompt/password management, score/who display, real combat
(auto-attacks via the pulse loop + jutsu commands), training/practice,
missions, Kage interactions, shop buying, and staff OLC commands.
"""

import jutsu_colors
import random
import re
import time
from typing import List, Optional

import colors
import ui_palette
import combat
import chunin_exam
import config
import data_headbands
import consumables
import content
import corpses
import data_crafting
import fishing
import groups
import staff_invisibility
import teams
import inventory
import jobs
import lumberjack
import cooking
import farming
import tool_durability
import gems
import mining
import armorsmith
import weaponsmith
import gemcutter
import apartments
import auction
import playershops
import weather
import data_appearance
import data_clans
import biomes
import data_jutsu
import data_kekkei_genkai
import hyuga
import data_rarity
import data_passives
import data_shops
import data_weapons
import damage_messages
import derived_stats
import help_system
import item_types
import kage
import legendary_items
import leveling
import missions
import security
import roulette
import slots
import status_effects
import sage_mode
import sword_styles
import storage
import village_perks
import olc
import programs
import world
import door_links
from models import Player
from data_villages import VILLAGES
from prompt import PRESETS

WORLD = world.WORLD

TRAINABLE_ATTRIBUTES = [
    "strength", "wisdom", "constitution", "intelligence", "dexterity",
    "luck", "perception", "willpower", "chakra_control",
]
TRAIN_ATTRIBUTE_NAMES = {
    "str": "strength", "wis": "wisdom", "con": "constitution",
    "int": "intelligence", "dex": "dexterity", "luk": "luck",
    "per": "perception", "perc": "perception", "wil": "willpower",
    "will": "willpower", "will power": "willpower",
    "cc": "chakra_control", "chakra control": "chakra_control",
    "chakractrl": "chakra_control", "chakracontrol": "chakra_control",
}


BARE_NAME_JUTSU_CATEGORIES = ("taijutsu", "bukijutsu")  # physical, not chakra-incantation


def has_silent_genjutsu(player) -> bool:
    """Whether player has learned the Silent Genjutsu passive
    (Section 122, level 75) -- the single real gate every place this
    passive's effects apply (bare-name dispatch, skipping hand signs,
    hiding the target's own cast message at 100% mastery) checks
    against. Always on once learned, per direct confirmation -- no
    toggle exists."""
    return "Silent Genjutsu" in player.learned_skills



# Sleeping is a deliberate resting position. Only non-physical essentials and
# commands that wake the character may execute until they stand up.
SLEEPING_ALLOWED_COMMANDS = frozenset({"wizinvis", "setallprac", "ip", "spy", "stand", "wake", "help", "who", "score", "level", "uptime", "jinchuriki", "mastery", "skills", "jutsu", "quit", "save", "ooc"})


def _blocked_while_sleeping(session, verb: str) -> bool:
    if (session.player is not None
            and session.player.position == "sleeping"
            and verb.lower() not in SLEEPING_ALLOWED_COMMANDS):
        session.send("You are sleeping. Wake up before doing that.")
        return True
    return False


def dispatch_line(session, line: str) -> None:
    """Resolve exact commands and explicit shortcuts before legacy jutsu names.

    The new one-word shortcuts work directly for every class. Traditional
    Taijutsu/Bukijutsu names remain direct; other full names use perform.
    """
    if getattr(getattr(session, "state", None), "name", "") == "LINKDEAD":
        return
    words = line.split()
    if not words:
        return
    lower_words = [w.lower() for w in words]
    # Contract consent is a direct yes/no prompt only while a live request
    # belongs to this specific player; ordinary yes/no semantics are unchanged.
    if len(lower_words) == 1 and lower_words[0] in {"yes", "no"}:
        import whirlpool_fuinjutsu
        if whirlpool_fuinjutsu.has_pending_consent(session):
            whirlpool_fuinjutsu.contract_consent(session, lower_words)
            return
    import reaper_seal
    # Staff may use emergency reversal even while afflicted by another spell.
    if (session.player and combat.is_immortal_immune_to_defeat(session)
            and lower_words[:4] == ["perform", "reverse", "reaper", "seal"]):
        reaper_seal.cast(session, reaper_seal.REVERSE_KEY, words[4:])
        return
    import izanami_loops
    if izanami_loops.blocks_command(session, lower_words[0]):
        return
    if reaper_seal.blocks_command(session, lower_words[0]):
        return
    if _blocked_while_sleeping(session, lower_words[0]):
        return
    # Tsukuyomi's target cannot initiate a new attack or jutsu while
    # frozen. Check before bare-name jutsu and direction matching so
    # staff commands and every combat entry point follow the same rule.
    if (session.player and session.player.tsukuyomi_frozen
            and lower_words[0] not in {"wizinvis", "look", "l", "help", "who", "score", "level", "uptime", "jinchuriki", "mastery", "jutsu", "inventory",
                                       "inv", "skills", "prac", "setallprac", "ip", "imms", "immortal",
                                       "immortals", "changes", "say", "ooc", "quit", "save"}):
        session.send("You are frozen inside Tsukuyomi and cannot act.")
        return
    if session.player and "asleep" in session.player.active_status_effects and lower_words[0] not in ("wizinvis", "setallprac", "ip", "look", "l", "help", "who", "uptime", "jinchuriki", "mastery", "jutsu", "quit", "save"):
        session.send("You are asleep beneath Nehan Shōja and cannot act yet.")
        return

    # The full phrase is recognized without being published as a jutsu,
    # listed skill, shortcut, or help topic (an intentionally hidden art).
    if lower_words == ["reverse", "summoning", "jutsu"]:
        # Route through normal command safeguards (downed/frozen/etc.),
        # while keeping the secret phrase out of the public registry.
        dispatch(session, "perform", words)
        return

    if world.normalize_direction(lower_words[0]):
        dispatch(session, words[0], words[1:])
        return

    if lower_words[0] in COMMANDS or lower_words[0] in data_jutsu.SHORTCUT_JUTSU:
        dispatch(session, words[0], words[1:])
        return

    jutsu_key, consumed = data_jutsu.match_prefix(lower_words)
    if jutsu_key:
        jutsu_class = data_jutsu.JUTSU[jutsu_key]["class_requirement"]
        if data_jutsu.JUTSU[jutsu_key].get("jutsu_type") == "general_utility" or jutsu_class in BARE_NAME_JUTSU_CATEGORIES or (
            jutsu_class == "genjutsu" and session.player and has_silent_genjutsu(session.player)
        ):
            cmd_use_jutsu(session, jutsu_key, words[consumed:])
            return

    verb, args = words[0], words[1:]
    dispatch(session, verb, args)


def dispatch(session, verb: str, args: List[str]) -> None:
    if getattr(getattr(session, "state", None), "name", "") == "LINKDEAD":
        return
    verb = verb.lower()
    import reaper_seal
    import izanami_loops
    if izanami_loops.blocks_command(session, verb):
        return
    if reaper_seal.blocks_command(session, verb):
        return

    if _blocked_while_sleeping(session, verb):
        return

    if session.player and verb not in ("look", "l", "say", "ooc"):
        player = session.player
        if player.downed_by:
            session.send("&RYou're gravely wounded and at someone's mercy -- you can't do that right now.&x")
            return
        if player.frozen_until and time.time() < player.frozen_until:
            session.send("&RYou're gravely wounded and can't move.&x")
            return
        if player.rampage_until:
            if time.time() < player.rampage_until:
                session.send("&RYou're consumed by the beast's rage -- you have no control over your own body!&x")
                return
            player.rampage_until = 0.0

    direction = world.normalize_direction(verb)
    if direction:
        cmd_move(session, direction)
        return

    if verb.startswith("@"):
        cmd_emote(session, [verb] + args)
        return

    handler = COMMANDS.get(verb)
    if handler:
        handler(session, args)
        return
    jutsu_key = data_jutsu.SHORTCUT_JUTSU.get(verb)
    if jutsu_key:
        cmd_use_jutsu(session, jutsu_key, args)
        return
    session.send("Huh?")


# --- Movement --------------------------------------------------------

def _wake_and_stand(session) -> None:
    """Auto-cancel resting/sleeping the moment a player moves or fights,
    since those positions only ever affect regen rate, not combat itself."""
    player = session.player
    if player.position != "standing":
        previous = player.position
        player.position = "standing"
        session.send(f"You stop {previous} and stand up.")
        import room_actions
        room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} wakes and stands up." if previous == "sleeping" else f"{player.name} stands up.")


def _broadcast_globally(message: str) -> None:
    """Sends message to every connected, playing session -- matches
    kage.py's own real "has been promoted" announcement pattern
    exactly, since no shared global-broadcast function exists yet."""
    import session as session_module
    for s in session_module.ACTIVE_SESSIONS:
        if s.state.name == "PLAYING":
            s.send(message)
            s.send_prompt()


def _fire_enter_triggers(session) -> None:
    """Fires the destination room's 'enter' programs, then each mob
    present's 'greet' programs, in that order. Shared by every way a
    player can arrive in a new room -- walking (cmd_move) and recall.
    Also checks for a war/territory trap in the new room (see
    territory.check_trap_trigger)."""
    player = session.player
    room = WORLD.get(player.room_vnum)
    if room and room.programs:
        programs.fire_programs(session, room.programs, "enter", speaker_name=room.name)
    for mob in combat.mobs_in_room(player.room_vnum):
        t = combat.MOB_TEMPLATES.get(mob.template_vnum)
        if t and t.get("mob_programs"):
            import general_skills
            if general_skills.concealed_from(mob, player):
                continue
            programs.fire_programs(session, t["mob_programs"], "greet", speaker_name=mob.name.capitalize(), mob=mob)

    import territory
    trap_message = territory.check_trap_trigger(player)
    if trap_message:
        session.send(trap_message)


def cmd_move(session, direction: str) -> None:
    player = session.player
    import izanami_loops
    if izanami_loops.blocks_command(session, direction):
        return

    if player.illusion_walk_caster is not None:
        # Willpower can break this ordinary illusion before the victim
        # pays another movement-triggered stamina penalty.
        if status_effects.willpower_breaks(player):
            player.illusion_walk_caster = None
            player.illusion_walk_real_room_vnum = None
            player.illusion_walk_range = 0
            player.illusion_walk_steps_taken = 0
            session.send("&CYour Willpower shatters Illusion Walk. You see the real world again!&x")
            cmd_look(session, [])
            return
        player.stamina = max(0, player.stamina // 2)
        if player.stamina <= ILLUSION_WALK_STAMINA_FLOOR:
            caster_name = player.illusion_walk_caster
            player.illusion_walk_caster = None
            player.illusion_walk_real_room_vnum = None
            player.illusion_walk_range = 0
            player.illusion_walk_steps_taken = 0
            session.send(
                f"&YExhausted, the illusion shatters -- you can see {caster_name} again, real and solid in front of you!&x"
            )
            cmd_look(session, [])
            return
        player.illusion_walk_steps_taken += 1
        if player.illusion_walk_steps_taken > player.illusion_walk_range:
            player.illusion_walk_steps_taken = 0
            session.send(f"&YThe world snaps back into focus -- you're still exactly where you started!&x")
            real_room = WORLD.get(player.illusion_walk_real_room_vnum)
            if real_room:
                session.send(ui_palette.color_room_name(real_room.name))
                session.send(ui_palette.color_room_description(real_room.description))
            return
        import areas
        area = areas.find_area_for_vnum(player.illusion_walk_real_room_vnum)
        candidates = []
        if area:
            candidates = [
                vnum for vnum in WORLD.rooms.keys()
                if vnum != player.illusion_walk_real_room_vnum and area.vnum_start <= vnum <= area.vnum_end
            ]
        if not candidates:
            fake_room = WORLD.get(player.illusion_walk_real_room_vnum)
        else:
            fake_room = WORLD.get(random.choice(candidates))
        session.send(f"&YYou walk {direction}.&x")
        if fake_room:
            session.send(ui_palette.color_room_name(fake_room.name))
            session.send(ui_palette.color_room_description(fake_room.description))
        return

    room = WORLD.get(player.room_vnum)

    if player.in_chunin_exam and player.room_vnum == chunin_exam.FINAL_ARENA_VNUM:
        session.send("&RThe final arena is sealed. Defeat your shadow or use leave confirm to forfeit.&x")
        return
    if player.in_chunin_exam and player.room_vnum not in (chunin_exam.ENTRANCE_VNUM, *chunin_exam.FOREST_VNUMS, chunin_exam.TOWER_VNUM, chunin_exam.FINAL_ARENA_VNUM):
        session.send("&RYou have stepped outside the Exam arena. Leave confirm forfeits the attempt.&x")
        return

    if player.jailed_until:
        if time.time() >= player.jailed_until:
            import jail as jail_module
            jail_module.release(player)
            session.send("&GYour jail sentence is up. You are released.&x")
            cmd_look(session, [])
            return
        else:
            remaining_minutes = int((player.jailed_until - time.time()) / 60) + 1
            session.send(f"&DYou are jailed for {remaining_minutes} more minute(s) and cannot leave.&x")
            return

    if session.combat_target is not None:
        session.send("You can't leave while you're fighting!")
        return
    if status_effects.has_effect(player.active_status_effects, "entangled"):
        session.send("You're entangled and can't move!")
        return
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.is_active(player, "fuinjutsu_rooted"):
        session.send("Whirlpool binding script pins your feet in place.")
        return
    if player.stamina <= 0:
        session.send("&RYou're too exhausted to walk! Rest until you recover stamina.&x")
        return

    if direction not in room.exits:
        session.send("You can't go that way.")
        return

    import whirlpool_fuinjutsu
    barrier_message = whirlpool_fuinjutsu.check_movement(player, room.vnum, direction)
    if barrier_message and not (session.account and session.account.staff_level != "player"):
        session.send(barrier_message)
        return

    is_staff = session.account is not None and session.account.staff_level != "player"
    if "door" in room.exit_flags.get(direction, []) and not room.exit_door_open.get(direction, False) and not is_staff:
        session.send(f"The door to the {direction} is closed.")
        return
    if not is_staff:
        for mob in combat.mobs_in_room(player.room_vnum):
            t = combat.MOB_TEMPLATES.get(mob.template_vnum)
            if t and t.get("mob_programs") and programs.check_level_gate(session, t["mob_programs"], direction, speaker_name=mob.name.capitalize()):
                return

    # Scripted mob "move" trigger: fire before leaving while the
    # triggering player and guard still share a room. A script may
    # transfer the player, in which case do not perform a second move.
    if not is_staff:
        previous_direction = getattr(session, "_mudprog_direction", "")
        session._mudprog_direction = direction
        try:
            for mob in list(combat.mobs_in_room(player.room_vnum)):
                template = combat.MOB_TEMPLATES.get(mob.template_vnum)
                if template and any(p.get("trigger") == "move" and "script" in p
                                    for p in template.get("mob_programs", ())):
                    programs.fire_programs(session, template["mob_programs"], "move",
                                           speaker_name=mob.name.capitalize(), mob=mob)
                    if player.room_vnum != room.vnum:
                        return
        finally:
            session._mudprog_direction = previous_direction

    destination_vnum = room.exits[direction]
    if (player.in_chunin_exam
            and destination_vnum not in (chunin_exam.ENTRANCE_VNUM, *chunin_exam.FOREST_VNUMS, chunin_exam.TOWER_VNUM, chunin_exam.FINAL_ARENA_VNUM)):
        session.send("&RThe exam proctor bars this exit. Leaving means failing and repeating the entire Chunin Exam. Use 'leave confirm' to forfeit.&x")
        return
    if not olc._require_assigned_vnum(session, destination_vnum):
        return
    destination = WORLD.get(destination_vnum)
    if destination and not destination.enabled and not is_staff:
        session.send("That area is currently closed.")
        return
    if destination and destination.apartment and destination.owner and destination.owner != player.name and not is_staff:
        session.send("The door is locked. This is someone's private home.")
        return

    # Walking requires enough Stamina to pay the full 1-2 point cost.
    # Refuse before movement hooks or messages, and never allow a free step
    # from zero (or spend Stamina on an unsuccessful attempt).
    movement_cost = random.randint(1, 2)
    if player.stamina < movement_cost:
        session.send(
            f"&RYou're too exhausted to walk {direction}! "
            f"You need {movement_cost} stamina. Rest to recover.&x"
        )
        return

    _wake_and_stand(session)
    import general_skills
    player.stamina -= movement_cost
    general_skills.before_move(session)
    general_skills.broadcast_movement(session, f"{player.name} leaves {direction}.")
    player.room_vnum = room.exits[direction]
    combat.follow_owner_summon(player, room.vnum, player.room_vnum)
    general_skills.broadcast_movement(session, f"{player.name} arrives from the {world.OPPOSITE_DIRECTION.get(direction, direction)}.")

    if session.trade is not None:
        import trade as trade_module
        other = session.trade.other(session)
        trade_module.cancel_trade(session.trade)
        session.send("&DYou walk away, cancelling the trade.&x")
        other.send(f"&D{player.name} walks away, cancelling the trade.&x")

    cmd_look(session, [])
    _fire_enter_triggers(session)

    # Only an actual completed walk by the group leader is copied.
    # Room enter scripts may transfer or disband the leader; never
    # teleport followers after such special moves.
    if player.room_vnum == destination_vnum:
        groups.follow_leader_step(session, direction, room.vnum, destination_vnum)


def cmd_open(session, args: List[str]) -> None:
    player = session.player
    room = WORLD.get(player.room_vnum)
    if not args:
        session.send("Open what direction?")
        return
    direction = world.normalize_direction(args[0])
    if not direction or direction not in room.exits or "door" not in room.exit_flags.get(direction, []):
        session.send("There's no door that way.")
        return
    if room.exit_door_open.get(direction, False):
        session.send("It's already open.")
        return
    if "locked" in room.exit_flags.get(direction, []):
        session.send("It's locked.")
        return
    room.exit_door_open[direction] = True
    door_links.mirror(room, direction)
    session.send(f"You open the door to the {direction}.")


def cmd_close(session, args: List[str]) -> None:
    player = session.player
    room = WORLD.get(player.room_vnum)
    if not args:
        session.send("Close what direction?")
        return
    direction = world.normalize_direction(args[0])
    if not direction or direction not in room.exits or "door" not in room.exit_flags.get(direction, []):
        session.send("There's no door that way.")
        return
    if not room.exit_door_open.get(direction, False):
        session.send("It's already closed.")
        return
    room.exit_door_open[direction] = False
    door_links.mirror(room, direction)
    session.send(f"You close the door to the {direction}.")


def cmd_unlock(session, args: List[str]) -> None:
    player = session.player
    room = WORLD.get(player.room_vnum)
    if not args:
        session.send("Unlock what direction?")
        return
    direction = world.normalize_direction(args[0])
    flags_here = room.exit_flags.get(direction, []) if direction else []
    if not direction or direction not in room.exits or "door" not in flags_here:
        session.send("There's no door that way.")
        return
    if "locked" not in flags_here:
        session.send("It isn't locked.")
        return

    if "keyitem" in flags_here:
        required = room.exit_key_item.get(direction, "")
        if not any(_item_matches(required, item) for item in player.inventory):
            session.send(f"You don't have the right key.")
            return
    elif "passcode" in flags_here:
        given = " ".join(args[1:]).strip()
        if given != room.exit_passcode.get(direction, ""):
            session.send("That's not the right passcode.")
            return

    flags_here.remove("locked")
    door_links.mirror(room, direction)
    session.send(f"You unlock the door to the {direction}.")


def cmd_lock(session, args: List[str]) -> None:
    player = session.player
    room = WORLD.get(player.room_vnum)
    if not args:
        session.send("Lock what direction?")
        return
    direction = world.normalize_direction(args[0])
    flags_here = room.exit_flags.get(direction, []) if direction else []
    if not direction or direction not in room.exits or "door" not in flags_here:
        session.send("There's no door that way.")
        return
    if room.exit_door_open.get(direction, False):
        session.send("You'll need to close it first.")
        return
    if "locked" in flags_here:
        session.send("It's already locked.")
        return
    flags_here.append("locked")
    door_links.mirror(room, direction)
    session.send(f"You lock the door to the {direction}.")


FLEE_SUCCESS_CHANCE = 75  # percent -- the "low level" flee: a flat
# chance, no stat scaling yet. A higher-tier version that flees AND
# lands a free attack on the way out is planned as a later addition,
# per the request that introduced this command.


def cmd_wimpy(session, args: List[str]) -> None:
    """Sets (or shows) the wimpy auto-flee threshold -- a percentage of
    max health at or below which combat.py automatically attempts
    cmd_flee on the player's behalf, both in PvE and PvP (see
    resolve_pulse/resolve_pvp_pulse). 0 disables it, the default --
    nothing changes for a player who never sets one."""
    player = session.player
    if not args:
        if player.wimpy_percent > 0:
            session.send(f"Your wimpy threshold is currently {player.wimpy_percent}%.")
        else:
            session.send("Your wimpy threshold is currently disabled. Usage: wimpy <0-100>")
        return
    if not args[0].isdigit() or not (0 <= int(args[0]) <= 100):
        session.send("Usage: wimpy <0-100>  (0 disables it)")
        return
    percent = int(args[0])
    player.wimpy_percent = percent
    if percent == 0:
        session.send("Wimpy disabled -- you will no longer auto-flee.")
    else:
        session.send(
            f"Wimpy set to {percent}% -- you'll attempt to flee once your health "
            f"drops to or below that."
        )


def cmd_auction(session, args: List[str]) -> None:
    """The Auction House (auction.py) -- list an item from inventory
    for other players to bid on, with an optional instant buyout
    price. A listing resolves periodically (not the instant it
    technically expires, same as weather/mob-respawn). No escrow: a
    bid just records a promise, checked again for real ryo at
    resolution time -- see auction.py's own docstring for the full
    reasoning. Works whether the seller/winning bidder are online or
    offline when a listing actually resolves."""
    player = session.player
    usage = (
        "Usage: auction list | auction sell <item> <starting bid> [buyout price] [duration minutes]\n"
        "       auction bid <id> <amount> | auction buyout <id> | auction cancel <id>"
    )

    if not args:
        session.send(usage)
        return

    subcommand = args[0].lower()

    if subcommand == "list":
        listings = auction.all_listings()
        if not listings:
            session.send("There are no active auction listings.")
            return
        lines = ["&WActive Auction Listings:&x"]
        now = time.time()
        for auction_id, entry in sorted(listings.items(), key=lambda kv: int(kv[0])):
            remaining = max(0, entry["expires_at"] - now)
            bidder_str = f" (high bidder: {entry['current_bidder']})" if entry["current_bidder"] else " (no bids yet)"
            buyout_str = f", buyout {entry['buyout_price']:,} ryo" if entry["buyout_price"] else ""
            lines.append(
                f"  #{auction_id}: {entry['item_name']} -- seller {entry['seller']}, "
                f"current bid {entry['current_bid']:,} ryo{bidder_str}{buyout_str}, "
                f"{auction.format_duration(remaining)} left"
            )
        session.send("\n".join(lines))
        return

    if subcommand == "sell":
        if auction.has_active_listing(player.name):
            session.send("You already have an active auction listing -- wait for it to sell, buyout, or be cancelled first.")
            return

        rest = args[1:]
        numeric_trailing = []
        while rest and rest[-1].isdigit() and len(numeric_trailing) < 3:
            numeric_trailing.insert(0, rest.pop())
        item_query = " ".join(rest)
        if not item_query or not numeric_trailing:
            session.send(usage)
            return

        starting_bid = int(numeric_trailing[0])
        buyout_price = int(numeric_trailing[1]) if len(numeric_trailing) >= 2 else None
        duration_minutes = int(numeric_trailing[2]) if len(numeric_trailing) >= 3 else None

        if starting_bid <= 0:
            session.send("Starting bid must be a positive amount.")
            return
        if buyout_price is not None and buyout_price <= starting_bid:
            session.send("Buyout price must be higher than the starting bid.")
            return

        duration_seconds = auction.DEFAULT_DURATION_SECONDS
        if duration_minutes is not None:
            duration_seconds = duration_minutes * 60
            if not (auction.MIN_DURATION_SECONDS <= duration_seconds <= auction.MAX_DURATION_SECONDS):
                session.send(
                    f"Duration must be between {auction.MIN_DURATION_SECONDS // 60} and "
                    f"{auction.MAX_DURATION_SECONDS // 60} minutes."
                )
                return

        match = find_indexed_item(item_query, player.inventory)
        if not match:
            session.send("You aren't carrying that.")
            return

        import crafted_provenance
        if crafted_provenance.denied(match, player, session=session):
            session.send(crafted_provenance.DENIED)
            return
        player.inventory.remove(match)
        auction_id = auction.create_listing(player.name, match, starting_bid, duration_seconds, buyout_price)
        session.send(
            f"You list {rarity_colored_name(match)} for auction (#{auction_id}), "
            f"starting bid {starting_bid:,} ryo."
        )
        return

    if subcommand == "bid":
        if len(args) != 3 or not args[1].isdigit() or not args[2].isdigit():
            session.send("Usage: auction bid <id> <amount>")
            return
        ok, message = auction.place_bid(int(args[1]), player.name, int(args[2]))
        session.send(message)
        return

    if subcommand == "buyout":
        if len(args) != 2 or not args[1].isdigit():
            session.send("Usage: auction buyout <id>")
            return
        ok, message = auction.buyout_listing(int(args[1]), player.name)
        session.send(message)
        return

    if subcommand == "cancel":
        if len(args) != 2 or not args[1].isdigit():
            session.send("Usage: auction cancel <id>")
            return
        ok, message = auction.cancel_listing(int(args[1]), player.name)
        if ok:
            player.inventory.append(message)  # message holds the returned item's name on success
            session.send(f"You cancel the listing and get back {rarity_colored_name(message)}.")
        else:
            session.send(message)
        return

    session.send(usage)


def cmd_flee(session, args: List[str]) -> None:
    """Escapes an ongoing fight (PvE or PvP) -- themed as using the
    Body Replacement Technique (Kawarimi), the classic Naruto
    substitution/escape jutsu, rather than a generic "you run away."
    Not guaranteed: FLEE_SUCCESS_CHANCE governs it, and a failed
    attempt still costs the round (the fight continues, the next pulse
    resolves normally). On success, moves to a random valid exit --
    same door-open/closed rules as normal movement, so fleeing can't
    bypass a closed door -- and clears combat state on both sides for
    PvP, notifying the other player."""
    player = session.player
    if session.combat_target is None and session.pvp_target is None:
        session.send("You aren't fighting anyone.")
        return
    if player.in_chunin_exam and chunin_exam.final_opponent(session):
        session.send("&RThe final Chunin 1v1 has sealed the exits! Leaving would forfeit your exam; use 'leave confirm' to surrender.&x")
        return
    if player.summon_flee_locked:
        session.send("&RYou're bound tight and can't get away!&x")
        return

    room = WORLD.get(player.room_vnum)
    is_staff = session.account is not None and session.account.staff_level != "player"
    valid_exits = [
        (direction, dest_vnum) for direction, dest_vnum in room.exits.items()
        if is_staff or "door" not in room.exit_flags.get(direction, [])
        or room.exit_door_open.get(direction, False)
    ]
    if not valid_exits:
        session.send("There's nowhere to flee to!")
        return

    if random.randint(1, 100) > FLEE_SUCCESS_CHANCE:
        session.send("&RYou attempt the Body Replacement Technique to escape, but fumble it!&x")
        return

    direction, destination_vnum = random.choice(valid_exits)
    if not olc._require_assigned_vnum(session, destination_vnum):
        return

    if session.pvp_target is not None:
        opponent = session.pvp_target
        session.pvp_target = None
        opponent.pvp_target = None
        opponent.send(f"&Y{player.name} uses the Body Replacement Technique and flees {direction}!&x")
        combat.reset_summon_round_state(opponent.player)
    session.combat_target = None
    combat.reset_summon_round_state(player)

    old_room_vnum = player.room_vnum
    player.room_vnum = destination_vnum
    combat.follow_owner_summon(player, old_room_vnum, destination_vnum)
    session.send(f"&YYou use the Body Replacement Technique, substituting yourself with a nearby log, and flee {direction}!&x")
    cmd_look(session, [])


def _find_downed_target_for(attacker_name: str):
    """The (session, player) of whoever currently has downed_by
    pointing at attacker_name, or (None, None) if nobody does -- see
    combat.handle_pvp_defeat's own Mangekyo betrayal branch (Section
    116), which is the only place downed_by is ever set."""
    import session as session_module
    for s in session_module.ACTIVE_SESSIONS:
        if s.player and s.player.downed_by == attacker_name:
            return s, s.player
    return None, None


def cmd_finish_downed_yes(session, args: List[str]) -> None:
    """'yes' -- per direct request/confirmation (Section 116), the
    attacker's real choice to finish off their own downed, most-
    grouped partner and claim the Mangekyo Sharingan. Genuinely a
    no-op (falls through to "Huh?"-style silence, matches ordinary
    unmatched-command behavior) for anyone with nobody currently
    downed by them -- 'yes' isn't reserved as a special word outside
    this one real, active decision."""
    player = session.player
    downed_session, downed_player = _find_downed_target_for(player.name)
    if not downed_session:
        session.send("Yes what?")
        return

    # Check *both* actual socket IP addresses before granting any eye
    # techniques or applying the sacrifice penalties. A confirmed match
    # suspends the attacker's login for seven real days, not the shared
    # IP (other household players should not be automatically banned).
    import mangekyo_ip_guard
    comparison = mangekyo_ip_guard.ip_comparison(session, downed_session)
    if comparison is not False:
        if comparison is True:
            try:
                mangekyo_ip_guard.suspend_awakener(session)
            except (OSError, ValueError) as error:
                # Fail closed: no awakening if the suspension cannot be saved.
                session.send(f"&RThe awakening was denied; account suspension could not be saved: {error}&x")
                return
            session.send("&RYour Mangekyo awakening is denied: both participants share an IP address. Your account is locked for seven days.&x")
            downed_session.send("&YThe Mangekyo ritual was rejected. You are released from the sacrifice.&x")
        else:
            session.send("&RThe awakening was denied because both players' connection IP addresses could not be verified.&x")
            downed_session.send("&YThe Mangekyo ritual was cancelled because connection validation was unavailable.&x")

        # Resolve the downed partner's ordinary PvP defeat instead of
        # inflicting the special 25% XP/mastery and 24-hour penalties.
        downed_player.downed_by = None
        import combat as combat_module
        combat_module.handle_pvp_defeat(
            winner_session=session, loser_session=downed_session,
            skip_mangekyo_check=True)
        if comparison is True:
            session.request_close()  # enforce the seven-day suspension now
        return

    import data_mangekyo
    player.bloodline_mangekyo = True
    player.mangekyo_eye_1, player.mangekyo_eye_2 = data_mangekyo.roll_two_eye_techniques()
    eye_1_name = data_mangekyo.TECHNIQUE_ROSTER[player.mangekyo_eye_1]["display_name"]
    eye_2_name = data_mangekyo.TECHNIQUE_ROSTER[player.mangekyo_eye_2]["display_name"]
    session.send(
        f"&RYou end {downed_player.name}'s life without hesitation. Power floods through you -- "
        f"the Mangekyo Sharingan is yours.&x"
    )
    session.send(f"&RYour eyes have awakened: {eye_1_name} and {eye_2_name}.&x")

    xp_loss = int(downed_player.experience * 0.25)
    downed_player.experience = max(0, downed_player.experience - xp_loss)
    ryo_loss = downed_player.ryo // 2
    downed_player.ryo -= ryo_loss
    practiced = set(getattr(downed_player, "practiced_skills", ()))
    for skill_name, current in list(downed_player.skill_proficiencies.items()):
        reduced = int(current * 0.75)
        # Mangekyo's sacrifice reduces proficiency but never erases an
        # earned skill. Include legacy/special-grant skills with positive
        # proficiency as well as explicitly teacher-practiced skills.
        # Unpracticed zero-percent skills must remain at zero.
        if current > 0 or skill_name in practiced:
            reduced = max(1, reduced)
        downed_player.skill_proficiencies[skill_name] = reduced

    downed_player.downed_by = None
    downed_player.frozen_until = time.time() + 24 * 60 * 60
    downed_player.health = 1

    downed_session.send(
        f"&R{player.name} shows no mercy. Everything goes dark...&x\n"
        f"&YYou lose {xp_loss:,} experience, {ryo_loss:,} ryo, and feel your training slip -- "
        f"every skill you've practiced is noticeably duller.&x\n"
        f"&RYou are gravely wounded and will need 24 hours to recover. Only 'look', 'say', "
        f"and 'ooc' work until then.&x"
    )
    downed_session.send_prompt()


def cmd_finish_downed_no(session, args: List[str]) -> None:
    """'no' -- per direct request/confirmation (Section 116), the
    attacker's choice to spare their downed, most-grouped partner.
    Falls all the way through to a completely ordinary PvP defeat by
    directly reusing combat.handle_pvp_defeat -- the exact same code
    a ordinary, non-Mangekyo-eligible kill would run -- so a spared
    loss carries the SAME real consequences (kill count, bounty
    claim, scroll theft, XP/ryo loss, hospital respawn) as any other
    PvP defeat, nothing special or reduced. Genuinely a no-op for
    anyone with nobody currently downed by them."""
    player = session.player
    downed_session, downed_player = _find_downed_target_for(player.name)
    if not downed_session:
        session.send("No what?")
        return

    session.send(f"&YYou can't bring yourself to do it. You let {downed_player.name} live.&x")
    downed_session.send(f"&Y{player.name} hesitates, then lets you live.&x")
    downed_player.downed_by = None

    import combat as combat_module
    combat_module.handle_pvp_defeat(winner_session=session, loser_session=downed_session, skip_mangekyo_check=True)


def cmd_release(session, args: List[str]) -> None:
    """'release <target>' -- per direct request/confirmation (Section
    120): ends the caster's own active Illusion Walk genjutsu on
    someone early, the ONLY way it ever ends besides the illusion's
    own snap-back-and-repeat cycle (no in-game "Kai"/release
    mechanic for the VICTIM to break it themselves exists yet,
    confirmed as a deliberate future gap). Only the actual caster of
    a given Illusion Walk can release it -- releasing someone else's
    victim, or someone not actually under the effect at all, is
    refused."""
    player = session.player
    if not args:
        session.send("Release who from Illusion Walk?")
        return
    query = " ".join(args).lower()
    target_session = next(
        (s for s in session.active_sessions() if s.player and query in s.player.name.lower()),
        None,
    )
    if not target_session or target_session.player.illusion_walk_caster != player.name:
        session.send("You aren't holding anyone in an Illusion Walk by that name.")
        return

    target_session.player.illusion_walk_caster = None
    target_session.player.illusion_walk_real_room_vnum = None
    target_session.player.illusion_walk_range = 0
    target_session.player.illusion_walk_steps_taken = 0
    session.send(f"&YYou release {target_session.player.name} from the illusion.&x")
    target_session.send(f"&YThe illusion around you shatters -- you're back in reality.&x")


def cmd_unleash(session, args: List[str]) -> None:
    """Release a random available beast, or select its tail count (1-9)."""
    if (not args or args[0].lower() != "beast" or len(args) > 2
            or (len(args) == 2 and args[1] not in {str(n) for n in range(1, 10)})):
        session.send("Usage: unleash beast [1-9]")
        return
    if not olc._require_builder(session):
        return
    import tailed_beasts
    import storage
    import world as world_module
    if tailed_beasts.any_beast_currently_roaming(combat):
        session.send("A Tailed Beast is already loose in the world -- it must be sealed, killed, or despawn before another can be released.")
        return
    online_players = [s.player for s in session.active_sessions() if s.player]
    online_names = {p.name for p in online_players}
    offline_players = [p for p in storage.all_players() if p.name not in online_names]
    all_players = online_players + offline_players
    if len(args) == 2:
        import data_tailed_beasts
        beast = next(b for b in data_tailed_beasts.TAILED_BEASTS if b["tails"] == int(args[1]))
        if not tailed_beasts.is_beast_available(beast["key"], all_players):
            session.send(f"{beast['display_name']} is already sealed into a player and cannot be released.")
            return
    else:
        beast = tailed_beasts.pick_random_available_beast(all_players)
    if beast is None:
        session.send("Every Tailed Beast is already sealed into a player -- there's nothing left to release.")
        return
    mob = tailed_beasts.release_beast(beast, world_module, combat)
    session.send(f"&RYou unleash {beast['display_name']} into the world at room {mob.room_vnum}!&x")
    _broadcast_globally(tailed_beasts.announcement(beast))


def cmd_rest(session, args: List[str]) -> None:
    player = session.player
    if session.combat_target is not None:
        session.send("You can't rest while you're fighting!")
        return
    if player.position == "resting":
        session.send("You are already resting.")
        return
    player.position = "resting"
    session.send("You sit down and rest, recovering a bit faster than usual.")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} sits down to rest.")


CHAKRA_CHARGE_STEP_SECONDS = 4
CHAKRA_CHARGE_STEPS = 5  # 20% of the selected Stamina every four seconds


def _finish_chakra_charge(session, interrupted: bool = False) -> None:
    charge = session.chakra_charge
    session.chakra_charge = None
    if charge["spent"]:
        combat.grow_skill_from_usage(session.player, "Chakra Charge")
    outcome = "stops" if interrupted else "finishes"
    session.send(f"&CChakra Charge {outcome}: {charge['spent']} Stamina became {charge['gained']} Chakra.&x")


def process_chakra_charge(session, now: Optional[float] = None) -> None:
    """Apply due fifths of the chosen amount; no cost is paid up front."""
    charge = getattr(session, "chakra_charge", None)
    if not charge:
        return
    if now is None:
        now = time.time()
    player = session.player
    if player.position == "sleeping" or combat._is_action_blocked(player):
        _finish_chakra_charge(session, interrupted=True)
        session.send_prompt()
        return
    while charge["steps"] < CHAKRA_CHARGE_STEPS and now >= charge["next_at"]:
        charge["steps"] += 1
        charge["next_at"] += CHAKRA_CHARGE_STEP_SECONDS
        # Fractional fifths carry forward, so an odd/small amount still
        # transfers exactly the chosen Stamina by the fifth interval.
        due = charge["total"] * charge["steps"] // CHAKRA_CHARGE_STEPS - charge["scheduled"]
        charge["scheduled"] += due
        missing = max(0, player.maximum_chakra - player.chakra)
        spent = min(due, player.stamina, (missing + 1) // 2)
        gained = min(missing, spent * 2)
        player.stamina -= spent
        player.chakra += gained
        charge["spent"] += spent
        charge["gained"] += gained
        if charge["steps"] == CHAKRA_CHARGE_STEPS or player.stamina <= 0 or player.chakra >= player.maximum_chakra:
            _finish_chakra_charge(session, interrupted=False)
            session.send_prompt()
            return


def cmd_charge(session, args: List[str]) -> None:
    """Channel a chosen amount of Stamina into Chakra over 20 seconds."""
    player = session.player
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.blocks_chakra_regen(player) and args != ["stop"]:
        session.send("Your chakra coils are sealed; you cannot charge Chakra.")
        return
    if "Chakra Charge" not in player.learned_skills:
        session.send(f"Chakra Charge unlocks at level {data_jutsu.CHAKRA_CHARGE_LEVEL}.")
        return
    if len(args) == 1 and args[0].lower() == "stop":
        if getattr(session, "chakra_charge", None):
            _finish_chakra_charge(session, interrupted=True)
        else:
            session.send("You are not charging Chakra.")
        return
    if args and (len(args) != 1 or not args[0].isdigit() or int(args[0]) < 1):
        session.send("Syntax: charge [stamina amount] | charge stop")
        return
    if getattr(session, "chakra_charge", None):
        session.send("You are already charging Chakra. Use 'charge stop' first.")
        return
    import skill_training
    if skill_training.needs_first_practice(player, "Chakra Charge"):
        session.send("Practice Chakra Charge with a teacher at least once before using it.")
        return
    if session.is_busy() or getattr(session, "pending_cast", None) is not None:
        session.send("You're already busy with something.")
        return
    if player.position == "sleeping" or combat._is_action_blocked(player):
        session.send("You cannot focus your chakra right now.")
        return
    missing = player.maximum_chakra - player.chakra
    if missing <= 0:
        session.send("Your Chakra is already full.")
        return
    if player.stamina <= 0:
        session.send("You don't have any Stamina to convert.")
        return
    requested = int(args[0]) if args else player.stamina
    if requested > player.stamina:
        session.send(f"You only have {player.stamina} Stamina to charge.")
        return
    total = min(requested, (missing + 1) // 2)
    session.chakra_charge = {"total": total, "steps": 0, "scheduled": 0,
                             "spent": 0, "gained": 0,
                             "next_at": time.time() + CHAKRA_CHARGE_STEP_SECONDS}
    session.send(f"&CYou begin charging {total} Stamina into Chakra over 20 seconds (20% every 4 seconds).&x")


def cmd_sleep(session, args: List[str]) -> None:
    player = session.player
    if session.combat_target is not None:
        session.send("You can't sleep while you're fighting!")
        return
    if player.position == "sleeping":
        session.send("You are already sleeping.")
        return
    player.position = "sleeping"
    session.send("You lie down and drift off to sleep, recovering much faster than usual.")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} lies down and falls asleep.")


def cmd_stand(session, args: List[str]) -> None:
    player = session.player
    if player.position == "standing":
        session.send("You are already standing.")
        return
    _wake_and_stand(session)


# Exit text now follows the live, persistent ui_palette.EXIT_COLOR.
CARDINAL_ORDER = ["north", "east", "south", "west"]
DIAGONAL_ORDER = ["northeast", "southeast", "southwest", "northwest"]
VERTICAL_ORDER = ["up", "down"]
def _format_exits(room, is_staff: bool = False) -> List[str]:
    """Render visible exits on a single compact line in cardinal, diagonal,
    vertical order. Preserve closed-door labels and staff-only hidden exit
    markers; players do not see hidden exits. Colors remain configurable."""
    directions = []
    for direction in CARDINAL_ORDER + DIAGONAL_ORDER + VERTICAL_ORDER:
        if direction not in room.exits:
            continue
        flags_here = room.exit_flags.get(direction, [])
        if "hidden" in flags_here and not is_staff:
            continue
        label = direction.title()
        if "door" in flags_here and not room.exit_door_open.get(direction, False):
            label += " (closed)"
        import whirlpool_fuinjutsu
        if whirlpool_fuinjutsu.current_barrier(room.vnum, direction):
            label += " (sealed)"
        if is_staff and "hidden" in flags_here:
            label += " (hidden)"
        directions.append(label)
    if not directions:
        return [f"{ui_palette.EXIT_COLOR}Exits: none&x"]

    # A closed door and staff-visible hidden exit retain their status labels.
    colored = " ".join(f"{ui_palette.EXIT_COLOR}{label}&x" for label in directions)
    return [f"{ui_palette.EXIT_COLOR}Exits:&x {colored}"]


def cmd_look(session, args: List[str]) -> None:
    import genjutsu
    player = session.player
    if player.illusion_walk_caster is not None and not args:
        import areas
        area = areas.find_area_for_vnum(player.illusion_walk_real_room_vnum)
        candidates = []
        if area:
            candidates = [
                vnum for vnum in WORLD.rooms.keys()
                if vnum != player.illusion_walk_real_room_vnum and area.vnum_start <= vnum <= area.vnum_end
            ]
        fake_room = WORLD.get(random.choice(candidates)) if candidates else WORLD.get(player.illusion_walk_real_room_vnum)
        if fake_room:
            session.send(ui_palette.color_room_name(fake_room.name))
            session.send(ui_palette.color_room_description(fake_room.description))
        return
    room = WORLD.get(player.room_vnum)
    if room is None:
        # Same root cause as the login-time check in
        # Session._enter_world (a room that only existed in memory,
        # e.g. builder-created via 'rset create', vanished on a server
        # restart) -- but guarded here too in case it happens mid-
        # session instead, so this degrades gracefully instead of
        # crashing on room.name below.
        from data_villages import VILLAGES
        village_start = VILLAGES[player.village]["starting_room_vnum"]
        player.room_vnum = village_start if WORLD.get(village_start) else next(iter(WORLD.rooms))
        session.send("&Y(That room no longer exists -- you've been moved to a safe room.)&x")
        room = WORLD.get(player.room_vnum)

    is_staff = session.account is not None and session.account.staff_level != "player"

    if args:
        query = " ".join(args).lower()
        # Physical currency piles can be examined like dropped objects.
        if query == "ryo" or (query.endswith(" ryo")
                              and query.split()[0].isdigit()):
            piles = getattr(room, "ground_ryo", ())
            requested = int(query.split()[0]) if query != "ryo" else None
            amount = next((p for p in piles if requested is None or p == requested), None)
            if amount is not None:
                session.send(f"&Y{amount:,} Ryo&x\nA pile of coins lying on the ground.")
            else:
                session.send("You don't see that pile of Ryo here.")
            return
        import seasonal_events
        if "tree" in query and seasonal_events.tree_visible(player.room_vnum):
            session.send("A decorated Christmas tree glows beside the Kage. Santa has presents for visitors.")
            return
        original_body = getattr(session, "_clone_original_player", None)
        if (original_body is not None and query not in ("self", "me")
                and query in original_body.name.lower()
                and original_body.room_vnum == player.room_vnum):
            # To the pilot, examining their body looks the same as
            # examining any other player. Never expose a control status.
            description = original_body.description or f"{original_body.name} hasn't set a description."
            session.send(f"&C{original_body.name}&x\n{description}")
            return
        if query in ("self", "me") or query in player.name.lower():
            lines = [f"&C{player.name}&x"]
            lines.append(player.description if player.description else "You haven't set a description.")
            session.send("\n".join(lines))
            return
        for other in session.active_sessions():
            if other.player and other is not session and other.player.room_vnum == player.room_vnum \
                    and query in genjutsu.apparent_name(other.player).lower() and not _player_hidden_from(player, other.player):
                if player.illusion_walk_caster is not None:
                    session.send("You don't see anyone here by that name.")
                    return
                target = other.player
                apparent = genjutsu.apparent_name(target)
                lines = [f"&C{apparent}&x"]
                lines.append(target.description if target.description else f"{apparent} hasn't set a description.")
                if target.genjutsu_item_illusions:
                    lines.append("Apparent item: " + ", ".join(
                        entry["alias"] for item, entry in target.genjutsu_item_illusions.items()
                        if item in target.inventory
                    ))
                session.send("\n".join(lines))
                return
        mob = combat.find_mob(player.room_vnum, query)
        if mob and not _is_invisible_mob(mob):
            mob_template = combat.MOB_TEMPLATES.get(mob.template_vnum, {})
            mob_description = mob_template.get("description")
            lines = [f"&C{mob.name}&x"]
            lines.append(mob_description if mob_description else f"{mob.name} hasn't set a description.")
            session.send("\n".join(lines))
            return
        inv_match = find_indexed_item(query, player.inventory)
        if inv_match:
            session.send(f"{rarity_colored_name(inv_match)}\nYou are carrying it.")
            return
        ground_match = find_indexed_item(query, room.ground_items)
        if ground_match and not _is_invisible_item(ground_match):
            session.send(f"{rarity_colored_name(ground_match)}\nIt's lying here on the ground.")
            return
        import room_jutsu_objects
        jutsu_object = room_jutsu_objects.find(room, query)
        if jutsu_object:
            session.send(f"{jutsu_object.name}\n{jutsu_object.description}")
            return
        if any(query in decoy["name"].lower() for decoy in genjutsu.decoys_in_room(room.vnum)):
            session.send("It looks real at a glance, but your hand passes through the illusion.")
            return
        session.send("You don't see that here.")
        return

    room_header = ui_palette.color_room_name(room.name)
    if is_staff and player.staff_show_vnums:
        flag_suffix = f" | {', '.join(room.flags)}" if room.flags else ""
        if not room.enabled:
            flag_suffix += " | &RDISABLED&x&D"
        room_header += f" &D[{room.vnum}{flag_suffix}]&x"

    lines = [room_header, ""]
    if room.description:
        lines.append(ui_palette.color_room_description(room.description))
        lines.append("")
    import seasonal_events
    if seasonal_events.tree_visible(room.vnum):
        lines.append("&GAn ornamented Christmas tree sparkles beside the Kage.&x")
        lines.append("")
    import halloween_event
    halloween_decor = halloween_event.decorate_village(room.vnum)
    if halloween_decor:
        lines.append(halloween_decor)
        lines.append("")
    lines.extend(_format_exits(room, is_staff))
    lines.append("")
    for other in session.active_sessions():
        if other.player and other is not session and other.player.room_vnum == player.room_vnum and not _player_hidden_from(player, other.player):
            afk_tag = " &R[AFK]&x" if other.player.afk else ""
            activity = ""
            if other.player.position == "sleeping":
                activity = " &D[Sleeping]&x"
            elif other.player.position == "resting":
                activity = " &D[Resting]&x"
            elif (getattr(other, "combat_target", None) is not None
                  and getattr(other.combat_target, "health", 0) > 0
                  and getattr(other.combat_target, "room_vnum", None) == room.vnum
                  and not _is_invisible_mob(other.combat_target)):
                activity = f" &R[Fighting {other.combat_target.name}]&x"
            elif (getattr(other, "pvp_target", None) is not None
                  and getattr(other.pvp_target, "player", None) is not None
                  and other.pvp_target.player.room_vnum == room.vnum
                  and not _player_hidden_from(player, other.pvp_target.player)):
                opponent_name = genjutsu.apparent_name(other.pvp_target.player)
                activity = f" &R[Fighting {opponent_name}]&x"
            lines.append(f"  &G{genjutsu.apparent_name(other.player)}&x is here.{activity}{afk_tag}")
    # Linkdead characters remain physically present but are untargetable.
    import session as session_module
    for other in session_module.ACTIVE_SESSIONS:
        if (getattr(other, "state", None) == session_module.State.LINKDEAD and other.player
                and other.player.room_vnum == player.room_vnum
                and other is not session and not _player_hidden_from(player, other.player)):
            lines.append(f"  &D{genjutsu.apparent_name(other.player)}&x is here. &[244][LINKDEAD - Protected]&x")
    # A pilot viewing the original room must still see their physical
    # body, but as an ordinary character. Spectators already see it via
    # the normal active-session loop; never show control metadata.
    original_body = getattr(session, "_clone_original_player", None)
    if original_body is not None and original_body.room_vnum == room.vnum:
        lines.append(f"  &G{original_body.name}&x is here.")
    mobs = combat.mobs_in_room(player.room_vnum)
    for mob in mobs:
        if mob is getattr(session, "controlled_clone", None):
            continue  # first-person scout view never lists the clone as a separate bystander
        if _is_invisible_mob(mob):
            continue
        if combat.is_shadow_clone(mob):
            lines.append(f"  &G{mob.name}&x is here.")
            continue
        lines.append(f"  {mob.name} is here.{_staff_vnum_suffix(session, mob=mob)}")
    for corpse in corpses.corpses_in_room(player.room_vnum):
        contents = []
        if corpse.ryo > 0:
            contents.append(f"{corpse.ryo} ryo")
        if corpse.items:
            contents.append(f"{len(corpse.items)} item(s)")
        detail = f" ({', '.join(contents)})" if contents else " (empty)"
        lines.append(f"  &D{corpse.name}&x is here.{detail}")
    import room_jutsu_objects
    lines.extend(f"  {obj.room_line}" for obj in room_jutsu_objects.active_objects(room))
    if room.ground_items:
        ground_counts = inventory.slot_counts(room.ground_items)
        for name, count in ground_counts.items():
            if _is_invisible_item(name):
                continue
            proto = _find_object_prototype_by_name(name)
            long_desc = proto.get("long_desc") if proto else None
            if long_desc:
                shown_line = f"{long_desc} (x{count})" if count > 1 else long_desc
                lines.append(f"  {shown_line}{_staff_vnum_suffix(session, item_name=name)}")
            else:
                shown = f"{rarity_colored_name(name)} (x{count})" if count > 1 else rarity_colored_name(name)
                lines.append(f"  {shown} is lying here.{_staff_vnum_suffix(session, item_name=name)}")
    for amount in getattr(room, "ground_ryo", ()):
        lines.append(f"  &Y{amount:,} Ryo&x is lying here.")
    for decoy in genjutsu.decoys_in_room(room.vnum):
        lines.append(f"  &M{decoy['name']}&x seems to be lying here.")
    session.send("\n".join(lines))


SCAN_LEVEL = leveling.SCAN_LEVEL


def _is_invisible_player(player) -> bool:
    return bool(getattr(player, "invisible", False) or
                "invisible" in getattr(player, "active_status_effects", {}))


def _player_hidden_from(viewer, target) -> bool:
    import general_skills
    import hidden_mist
    return (staff_invisibility.hidden_player(viewer, target)
            or _is_invisible_player(target)
            or hidden_mist.conceals_from_view(viewer, target)
            or general_skills.concealed_from(viewer, target))


def _is_invisible_mob(mob) -> bool:
    template = combat.MOB_TEMPLATES.get(mob.template_vnum, {})
    return bool(getattr(mob, "invisible", False) or
                "invisible" in mob.active_status_effects or
                "Invis" in template.get("act_flags", []) or
                "invis" in template.get("affected_by", []))


def _is_invisible_item(name: str) -> bool:
    proto = _find_object_prototype_by_name(name)
    return bool(proto and "invis" in proto.get("extra_flags", []))


def cmd_scan(session, args: List[str]) -> None:
    import genjutsu
    import hidden_mist
    player = session.player
    if player.level < SCAN_LEVEL or "Scan" not in player.learned_skills:
        session.send("You learn Scan at level 3.")
        return
    import skill_training
    if skill_training.needs_first_practice(player, "Scan"):
        session.send("Practice Scan with a teacher at least once before using it.")
        return
    if len(args) != 1:
        session.send("Scan which direction? Usage: scan <direction>.")
        return
    direction = world.normalize_direction(args[0])
    if not direction:
        session.send("That isn't a direction.")
        return
    room = WORLD.get(player.room_vnum)
    is_staff = session.account is not None and session.account.staff_level != "player"
    if not room or direction not in room.exits or (
        "hidden" in room.exit_flags.get(direction, []) and not is_staff
    ):
        session.send("You can't scan that way.")
        return
    if "door" in room.exit_flags.get(direction, []) and not room.exit_door_open.get(direction, False):
        session.send(f"The door to the {direction} is closed.")
        return
    target = WORLD.get(room.exits[direction])
    if not target or (not is_staff and (not target.enabled or
        (target.apartment and target.owner and target.owner != player.name))):
        session.send("You can't scan that way.")
        return
    lines = [f"&CScanning {direction}:&x {ui_palette.color_room_name(target.name)}"]
    for other in session.active_sessions():
        if other.player and other.player.room_vnum == target.vnum and not _player_hidden_from(player, other.player):
            lines.append(f"  &G{genjutsu.apparent_name(other.player)}&x is here.")
    # Scanning with the clone must also reveal the original character
    # standing in the neighboring room, without a special status tag.
    original_body = getattr(session, "_clone_original_player", None)
    if original_body is not None and original_body.room_vnum == target.vnum:
        lines.append(f"  &G{original_body.name}&x is here.")
    for mob in combat.mobs_in_room(target.vnum):
        if not _is_invisible_mob(mob):
            if combat.is_shadow_clone(mob):
                lines.append(f"  &G{mob.name}&x is here.")
            else:
                lines.append(f"  {mob.name} is here.")
    for corpse in corpses.corpses_in_room(target.vnum):
        lines.append(f"  &D{corpse.name}&x is here.")
    import room_jutsu_objects
    lines.extend(f"  {obj.room_line}" for obj in room_jutsu_objects.active_objects(target))
    for name, count in inventory.slot_counts(target.ground_items).items():
        if not _is_invisible_item(name):
            suffix = f" (x{count})" if count > 1 else ""
            lines.append(f"  {rarity_colored_name(name)}{suffix} is lying here.")
    for amount in getattr(target, "ground_ryo", ()):
        lines.append(f"  &Y{amount:,} Ryo&x is lying here.")
    for decoy in genjutsu.decoys_in_room(target.vnum):
        lines.append(f"  &M{decoy['name']}&x seems to be lying here.")
    if len(lines) == 1:
        lines.append("  Nothing visible is there.")
    # Perception gives practiced scouts longer sight lines without
    # bypassing hidden exits, closed doors, inaccessible rooms, or
    # Camouflage. The normal adjacent-room scan stays unchanged.
    distant_rooms = 1 if player.perception < 40 else 2 if player.perception < 65 else 3
    last_room = target
    for distance in range(2, distant_rooms + 1):
        if direction not in last_room.exits:
            break
        if "hidden" in last_room.exit_flags.get(direction, []) and not is_staff:
            break
        if "door" in last_room.exit_flags.get(direction, []) and not last_room.exit_door_open.get(direction, False):
            break
        farther = WORLD.get(last_room.exits[direction])
        if (not farther or (not is_staff and
                (not farther.enabled or (farther.apartment and farther.owner
                                        and farther.owner != player.name)))):
            break
        lines.append(f"&CPerception sees {distance} rooms {direction}:&x {ui_palette.color_room_name(farther.name)}")
        seen = 0
        for other in session.active_sessions():
            if (other.player and other.player.room_vnum == farther.vnum
                    and not _player_hidden_from(player, other.player)):
                lines.append(f"  &G{genjutsu.apparent_name(other.player)}&x is here.")
                seen += 1
        for mob in combat.mobs_in_room(farther.vnum):
            if not _is_invisible_mob(mob):
                lines.append(f"  {mob.name} is here.")
                seen += 1
        if not seen:
            lines.append("  No visible shinobi or mobs.")
        last_room = farther
    # Clone views are temporary copies; award mastery and XP to the real body.
    combat.grow_skill_from_usage(original_body or player, "Scan", session=session)
    session.send("\n".join(lines))


# --- Social ------------------------------------------------------------

def _is_silenced(session) -> bool:
    """Whether player is CURRENTLY silenced (Section 94, per direct
    request: "Create a silence command...player will remain silenced
    ...for time automatically being released when timer is up").
    Auto-clears an expired silence the moment it's checked -- there's
    no separate background sweep needed, since a silence only ever
    matters at the exact moment the player tries to say/ooc/vchat
    something, which is exactly when this gets called."""
    player = session.player
    if not player.silenced_until:
        return False
    if time.time() >= player.silenced_until:
        player.silenced_until = 0.0
        return False
    remaining_minutes = int((player.silenced_until - time.time()) / 60) + 1
    session.send(f"&DYou are silenced for {remaining_minutes} more minute(s) and cannot speak.&x")
    return True


def cmd_say(session, args: List[str]) -> None:
    if not args:
        session.send("Say what?")
        return
    if _is_silenced(session):
        return
    import chat_moderation
    if chat_moderation.record_and_check_spam(session):
        session.send("&D(You're talking too fast! You have been silenced for 10 minutes.)&x")
        return
    message = chat_moderation.censor(" ".join(args))
    player = session.player
    session.send(f"&gYou say, '{message}'&x")
    session.broadcast_room(f"&g{player.name} says, '{message}'&x", exclude_self=True)
    # The academy exam begins only with this exact spoken phrase.
    # The live Iruka mob's VNUM 11 must be present; do not let any
    # older graduation speech script grant or start it another way.
    if " ".join(message.lower().split()) == "start genin exam":
        import genin_exam
        genin_exam.start_exam(session)
        return
    if player.room_vnum == chunin_exam.TOWER_VNUM and message.strip().lower() in ("ready", "submit scrolls", "final trial"):
        if chunin_exam.start_final_trial(session):
            cmd_look(session, [])
        return
    if message.strip().lower() in ("present", "gift", "merry christmas"):
        import seasonal_events
        if seasonal_events.claim_present(session):
            return
    if message.strip().lower() in ("fireworks", "fourth of july", "july 4", "happy fourth"):
        import seasonal_events
        if seasonal_events.claim_july_fourth(session):
            return

    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    if village_rooms and player.room_vnum == village_rooms["kage"] and "mission" in message.lower():
        session.send(kage.handle_mission_redirect(player))

    for mob in combat.mobs_in_room(player.room_vnum):
        t = combat.MOB_TEMPLATES.get(mob.template_vnum)
        if t and t.get("mob_programs"):
            if programs.fire_speech_programs(session, t["mob_programs"], message, speaker_name=mob.name.capitalize(), mob_template=t, mob=mob):
                break  # only one mob responds per utterance, even if several are listening


def cmd_restore(session, args: List[str]) -> None:
    if not olc._require_admin(session):
        return
    if args:
        session.send("Usage: restore (restores every online player)")
        return
    import admin_actions
    count = admin_actions.restore_online()
    session.send(f"Restored HP, chakra, and stamina for {count} online player(s).")



def cmd_vperk(session, args: List[str]) -> None:
    """Immortal-only, free, reboot-safe 24-hour MUD-wide village perks.

    Staff perks override the same category in every village without
    spending mission points or altering its normal Kage purchases.
    """
    if not session.account or session.account.staff_level not in config.STAFF_LEVELS[1:]:
        session.send("&ROnly immortals may manage village perks.&x")
        return

    usage = (
        "Usage: vperk list\n"
        "       vperk status\n"
        "       vperk <perk name> on|off\n"
        "       vperk on|off <perk name>\n"
        "Examples: vperk double exp on | vperk triple ryo off\n"
        "Every immortal perk affects ALL villages for 24 hours. "
        "Only one perk per category can be active at a time."
    )
    if not args or args[0].lower() in ("list", "help"):
        lines = [usage, "", "Available perks:"]
        lines.extend(f"  {info['display_name']} ({key})"
                     for key, info in village_perks.PERK_TYPES.items())
        session.send("\n".join(lines))
        return

    if args[0].lower() == "status":
        if len(args) != 1:
            session.send(usage)
            return
        active = village_perks.staff_perks_display("all")
        session.send("&CImmortal perks (entire MUD):&x\n" +
                     ("\n".join("  " + entry for entry in active)
                      if active else "  No global immortal perks are active."))
        return

    # Keep 'all' as a backward-compatible optional marker, but never
    # accept a village name: immortal perks cannot target one village.
    words = [str(word).lower() for word in args]
    if words and words[0] == "all":
        words = words[1:]
    if words and words[0] in ("on", "off"):
        action, perk_words = words[0], words[1:]
    elif words and words[-1] in ("on", "off"):
        action, perk_words = words[-1], words[:-1]
    else:
        session.send(usage)
        return
    if perk_words and perk_words[0] == "all":
        perk_words = perk_words[1:]
    if not perk_words:
        session.send(usage)
        return
    query = " ".join(perk_words)
    perk_key = next(
        (key for key, info in village_perks.PERK_TYPES.items()
         if query in (key, info["display_name"].lower())),
        None,
    )
    if perk_key is None:
        session.send("Unknown village perk. All immortal bonuses are MUD-wide. "
                     "Use 'vperk list' for valid perk names.")
        return

    try:
        if action == "on":
            village_perks.set_staff_perk("all", perk_key)
            changed = True
        else:
            changed = village_perks.clear_staff_perk("all", perk_key)
    except OSError as exc:
        session.send(f"&RFailed to save global village perk: {exc}&x")
        return

    display_name = village_perks.PERK_TYPES[perk_key]["display_name"]
    if not changed:
        session.send(f"&D{display_name} is not the active immortal perk.&x")
        return

    verb = "activated for 24 hours" if action == "on" else "disabled"
    session.send(f"&G{display_name} {verb} across the entire MUD.&x")
    for village in VILLAGES:
        if action == "on":
            message = f"&Y[Global event: {display_name} active for 24 hours!]&x"
        else:
            message = f"&D[Global event: {display_name} has been disabled.]&x"
        session.broadcast_village(village, message, exclude_self=True)


def cmd_respawn(session, args: List[str]) -> None:
    if not olc._require_admin(session):
        return
    if args:
        session.send("Usage: respawn (restores missing mob populations worldwide)")
        return
    import admin_actions
    count = admin_actions.respawn_missing()
    session.send(f"Respawned {count} missing mob(s). Existing mobs were left untouched.")


def cmd_emotes(session, args: List[str]) -> None:
    import emotes
    session.send_paginated(emotes.list_text())


def cmd_emote(session, args: List[str], ooc: bool = False) -> None:
    import emotes
    if len(args) != 1 or not args[0].startswith("@"):
        session.send("Usage: @yawn or ooc @yawn (no extra words). Type 'emotes' for the list.")
        return
    name = args[0][1:].lower()
    phrases = emotes.EMOTES.get(name)
    if phrases is None:
        session.send("Unknown emote. Type 'emotes' for the list.")
        return
    if _is_silenced(session):
        return
    import chat_moderation
    if chat_moderation.record_and_check_spam(session):
        session.send("&D(You're talking too fast! You have been silenced for 10 minutes.)&x")
        return
    own, other = phrases
    prefix = "&M[OOC]&x " if ooc else ""
    session.send(f"{prefix}You {own}")
    if ooc:
        # Titles are character-display decorations, not OOC chat labels.
        session.broadcast_all(f"{prefix}{session.player.name} {other}", exclude_self=True)
        import chatlog
        chatlog.record(session.player.name, f"[emote] {other}")
    else:
        session.broadcast_room(f"{prefix}{session.player.name} {other}", exclude_self=True)


def cmd_ooc(session, args: List[str]) -> None:
    if not args:
        session.send("OOC what?")
        return
    if args[0].startswith("@"):
        cmd_emote(session, args, ooc=True)
        return
    if _is_silenced(session):
        return
    import chat_moderation
    if chat_moderation.record_and_check_spam(session):
        session.send("&D(You're talking too fast! You have been silenced for 10 minutes.)&x")
        return
    message = chat_moderation.censor(" ".join(args))
    player = session.player
    session.send(f"&M[OOC] You:&x {message}")
    session.broadcast_all(f"&M[OOC] {player.name}:&x {message}", exclude_self=True)
    import chatlog
    chatlog.record(player.name, message)


def cmd_village_chat(session, args: List[str]) -> None:
    if not args:
        session.send("Say what to your village?")
        return
    if _is_silenced(session):
        return
    import chat_moderation
    if chat_moderation.record_and_check_spam(session):
        session.send("&D(You're talking too fast! You have been silenced for 10 minutes.)&x")
        return
    message = chat_moderation.censor(" ".join(args))
    player = session.player
    village_name = VILLAGES[player.village]["village_short_name"]
    session.send(f"&C[{village_name}] You:&x {message}")
    session.broadcast_village(player.village, f"&C[{village_name}] {player.name}:&x {message}", exclude_self=True)


def cmd_chatlog(session, args: List[str]) -> None:
    """Shows the last 25 OOC messages (chatlog.py), per direct request
    ("add a command in game that shows the last 25 ooc chats by
    typing chatlog"). Persisted across restarts. Oldest first, most
    recent last, matching how a natural scrollback reads."""
    import chatlog
    if not chatlog.ENTRIES:
        session.send("No OOC chat has been logged yet.")
        return
    # Historical OOC entries may retain old title metadata, but never show
    # it: titles are excluded from OOC including persisted chat history.
    lines = [f"&M[OOC] {entry['speaker']}:&x {entry['message']}" for entry in chatlog.ENTRIES]
    session.send("\n".join(lines))


def cmd_ask(session, args: List[str]) -> None:
    if len(args) < 2:
        session.send("Ask whom about what?")
        return
    topic = " ".join(args[1:]).lower()
    if args[0].lower() == "jedi" and topic.replace("about ", "", 1) in ("gift", "gifts", "lightsaber", "may 4"):
        import seasonal_events
        if seasonal_events.claim_may_fourth(session):
            return
    if (args[0].lower() == "sam" and topic in ("gift", "gifts", "fireworks", "july 4")) or (
            len(args) >= 3 and args[0].lower() == "uncle" and args[1].lower() == "sam"
            and " ".join(args[2:]).lower() in ("gift", "gifts", "fireworks", "july 4")):
        import seasonal_events
        if seasonal_events.claim_july_fourth(session):
            return
    if "santa" in args[0].lower() and topic in ("present", "gift", "christmas"):
        import seasonal_events
        if seasonal_events.claim_present(session):
            return
    player = session.player
    if (args[0].lower() in ("proctor", "examiner")
            and topic.replace("about ", "", 1) in ("exam", "trial", "final", "final trial", "scrolls", "submit")):
        if chunin_exam.start_final_trial(session):
            cmd_look(session, [])
        return
    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    if village_rooms and player.room_vnum == village_rooms["kage"] and "promotion" in topic:
        session.send(kage.handle_promotion_request(player))
        return
    session.send("There is no one here to ask about that.")


VILLAGE_FULL_NAME_COLORS = {
    "whirlpool": (39, 87),
    "leaf": (34, 118),    # Konohagakure
    "cloud": (33, 255),   # Kumogakure
    "water": (38, 67),    # Kirigakure
    "sand": (214, 220),   # Sunagakure
    "stone": (130, 244),  # Iwagakure
}
CLASS_WHO_LABEL = {"taijutsu": "Tai", "ninjutsu": "Nin", "genjutsu": "Gen", "bukijutsu": "Buk"}
CLASS_WHO_COLOR = {
    "taijutsu": "&R",   # red -- physical combat
    "ninjutsu": "&B",   # blue -- chakra techniques
    "genjutsu": "&M",   # magenta -- illusion
    "bukijutsu": "&Y",  # yellow -- weapons/steel
}
RANK_WHO_LABEL = {
    "academy student": "Student", "genin": "Genin", "chunin": "Chunin",
    "special jonin": "Sp.Jonin", "jonin": "Jonin", "elite jonin": "El.Jonin",
    "village elder": "V.Elder",
}
# Colored low-to-high, so rank is visible at a glance without reading the text.
RANK_WHO_COLOR = {
    "academy student": "&D",   # dim gray -- lowest
    "genin": "&G",              # green
    "chunin": "&C",             # cyan
    "special jonin": "&B",      # blue
    "jonin": "&Y",              # yellow
    "elite jonin": "&M",        # magenta
    "village elder": "&R",       # red -- top shinobi rank, just below Kage
}
KAGE_WHO_COLOR = "&O"  # orange -- above every other rank color
WHO_LEADER_STAFF_LEVELS = {"helper", "builder", "area leader", "administrator", "implementor"}  # all immortals
WHO_NAME_COLORS = ["&G", "&C", "&B", "&Y", "&O", "&M"]  # cycled per shinobi line for visual variety
WHO_RANK_WIDTH = 8
WHO_CLASS_WIDTH = 3
WHO_LEVEL_COLOR = "&C"  # confirmed directly: a new "Lv 42" field, right after Village and before Rank
WHO_VILLAGE_WIDTH = max(len(v["village_name"]) for v in VILLAGES.values())
WHO_CLAN_WIDTH = max(len("None"), max((len(k) for k in data_clans.CLANS), default=0))  # confirmed directly (Section 139): sized to the longest real clan name
NEW_CHARACTER_LEVEL_THRESHOLD = 5  # shown with a [NEW] tag at or below this level


def village_name_colored(village: str) -> str:
    """Full village name (Konohagakure, not 'Leaf'/'Konoha'), colored
    with the exact same per-village xterm-256 alternating scheme as
    the who-list (see _who_village_name below) -- but with no fixed-
    width padding or trailing reset, since this is meant for a single
    banner line, not a table column that needs to line up with the
    rows after it."""
    full_name = VILLAGES.get(village, {}).get("village_name", village.title())
    color_a, color_b = VILLAGE_FULL_NAME_COLORS.get(village, (255, 255))
    letters = []
    for i, ch in enumerate(full_name):
        color = color_a if i % 2 == 0 else color_b
        letters.append(f"&[{color}]{ch}")
    return "".join(letters) + "&x"


def _who_village_name(village: str) -> str:
    """Full village name (Konohagakure, not 'Leaf'/'Konoha'), each
    letter alternating between the village's two assigned xterm-256
    colors, then padded with plain spaces (after the color reset, so
    they don't inherit any color) to WHO_VILLAGE_WIDTH -- village full
    names vary in length, so without this the rank/class columns after
    it wouldn't line up from one line to the next."""
    full_name = VILLAGES.get(village, {}).get("village_name", village.title())
    color_a, color_b = VILLAGE_FULL_NAME_COLORS.get(village, (255, 255))
    letters = []
    for i, ch in enumerate(full_name):
        color = color_a if i % 2 == 0 else color_b
        letters.append(f"&[{color}]{ch}")
    padding = " " * (WHO_VILLAGE_WIDTH - len(full_name))
    return "".join(letters) + "&D" + padding


def _who_banner(fill_char: str, fill_color: str, label: str, width: int = 68, label_color: str = None) -> str:
    inner_visible = f"[ {label} ]"
    pad = max(0, width - len(inner_visible))
    left = pad // 2
    right = pad - left
    inner = f"[ {label_color or fill_color}{label}{fill_color} ]"
    return f"{fill_color}{fill_char * left}{inner}{fill_char * right}&D"


def _who_tags(p) -> str:
    tags = ""
    if p.afk:
        tags += " &R[AFK]&D"
    if p.level <= NEW_CHARACTER_LEVEL_THRESHOLD:
        tags += " &G[NEW]&D"
    return tags


def cmd_imms(session, args: List[str]) -> None:
    """List staff accounts with rank and online status, without secrets."""
    # An invisible immortal is absent even from the staff roster;
    # keeping an "offline" entry would leak the hidden connection.
    hidden_names = {s.account.name.lower() for s in session.active_sessions()
                    if staff_invisibility.is_hidden(s)}
    online = {s.account.name.lower(): s.account for s in session.active_sessions()
              if s.player and s.account and not staff_invisibility.is_hidden(s)}
    accounts = {account.name.lower(): account for account in storage.all_staff_accounts()
                if account.name.lower() not in hidden_names}
    accounts.update(online)
    staff = sorted((account for account in accounts.values() if account.staff_level != "player"),
                   key=lambda a: (-config.STAFF_LEVELS.index(a.staff_level)
                                  if a.staff_level in config.STAFF_LEVELS else 0, a.name.lower()))
    if not staff:
        session.send("No immortals are listed yet.")
        return
    lines = ["&WImmortals and staff:&x"]
    for account in staff:
        status = "&Gonline&x" if account.name.lower() in online else "&Doffline&x"
        lines.append(f"  {account.name} - {account.staff_level.title()} ({status})")
    session.send("\n".join(lines))


def cmd_who(session, args: List[str]) -> None:
    online = [s for s in session.active_sessions()
              if s.player and staff_invisibility.visible_to(session, s)]

    lines = [_who_banner("=", "&Y", "SHINOBI ONLINE", label_color="&C")]

    import ooc_titles
    for s in online:
        p = s.player
        village_display = _who_village_name(p.village)
        level_label = f"{WHO_LEVEL_COLOR}{p.level:>5}&W"
        village_info = VILLAGES.get(p.village)
        clan_text = (p.clan.title() if p.clan and p.clan != "none" else "None").ljust(WHO_CLAN_WIDTH)
        if p.village_rank == "kage" and village_info:
            rank_label = f"{KAGE_WHO_COLOR}{'Kage'.center(WHO_RANK_WIDTH)}&W"
            name_text = f"{ooc_titles.player_display(p)}, the {village_info['kage_title']} of {village_info['village_name']}"
        else:
            # Staff shown here too now (Section 139: no more separate
            # section), using their real rank badge, not a false Kage
            # title.
            rank_text = RANK_WHO_LABEL.get(p.village_rank, p.village_rank.title()).ljust(WHO_RANK_WIDTH)
            rank_color = RANK_WHO_COLOR.get(p.village_rank, "&W")
            rank_label = f"{rank_color}{rank_text}&W"
            name_text = ooc_titles.player_display(p)
        lines.append(f"&W[{village_display}&W][{rank_label}][{level_label}]&W[{clan_text}]&Y {name_text}&D{_who_tags(p)}")

    # Retained characters are listed separately: present in the world,
    # but not connected, attackable, or counted as currently online.
    import session as session_module
    linkdead = [s for s in session_module.ACTIVE_SESSIONS
                if s.state == session_module.State.LINKDEAD and s.player
                and staff_invisibility.visible_to(session, s)]
    for s in linkdead:
        remaining = max(0, int((s.linkdead_until - time.time() + 59) // 60))
        lines.append(f"&D[LINKDEAD] {ooc_titles.player_display(s.player)} - protected ({remaining}m until logout)&x")

    count = len(online)
    noun = "shinobi is" if count == 1 else "shinobi are"
    lines.append(f"&Y{count} {noun} currently online.&x")
    session.send("\n".join(lines))


def cmd_whois(session, args: List[str]) -> None:
    """Shows an online player's description plus basic info -- village,
    level, class, rank, clan -- matching the same identity fields the
    who-list already treats as defining for a player. Unlike 'look',
    which only finds a player standing in the same room, 'whois'
    looks server-wide across every online player, same as 'who' does."""
    if not args:
        session.send("Usage: whois <player name>")
        return
    query = " ".join(args).lower()
    match = next(
        (s for s in session.active_sessions()
         if s.player and query in s.player.name.lower()
         and staff_invisibility.visible_to(session, s)),
        None,
    )
    if match is None:
        session.send(f"No player named '{' '.join(args)}' is currently online.")
        return

    p = match.player
    village_display = _who_village_name(p.village)
    rank_text = RANK_WHO_LABEL.get(p.village_rank, p.village_rank.title())
    lines = [f"&C{p.name}&x"]
    lines.append(p.description if p.description else f"{p.name} hasn't set a description.")
    lines.append("")
    lines.append(f"&WVillage:&x {village_display}   &WLevel:&x {p.level}   &WClass:&x {p.primary_class.capitalize()}")
    lines.append(f"&WRank:&x {rank_text}   &WClan:&x {p.clan.title() if p.clan and p.clan != 'none' else 'None'}")
    session.send("\n".join(lines))


SHARINGAN_DODGE_BONUS_PERCENT = 13.5  # 10% below the former 15-point additive bonus
SHARINGAN_DODGE_BONUS_PERCENT_TOMOE_6 = 22.5  # 10% below the former 25-point additive bonus

# 3-tomoe perks, per direct follow-up request and design confirmation:
# a hitroll bonus (same shape as tomoe 1's dodge bonus, just offense
# instead of defense) plus Movement Prediction -- a genuinely separate
# roll from dodge, only checked when the dodge roll itself already
# failed ("chance outside of dodge"), reducing the attack's damage
# rather than blocking it outright ("reduces damage by a set amount/
# percentage rather than blocking it entirely"). Passive, not player-
# triggered, but its own real cost: unlocking it bumps chakra upkeep
# back up ("passive but increases upkeep").
SHARINGAN_HITROLL_BONUS_PERCENT = 10  # added on top of normal to-hit while active, tomoe 3-5
ILLUSION_WALK_STAMINA_FLOOR = 10  # per direct confirmation (Section 121): stamina halves every real movement check-in (including the snap-back step); reaching this floor releases the victim early, distinct from the normal range-based snap-back
SHARINGAN_HITROLL_BONUS_PERCENT_TOMOE_6 = 18  # the tomoe-6 capstone's amplified version
SHARINGAN_PREDICTION_CHANCE_PERCENT = 25  # chance to reduce damage on a failed dodge, tomoe 3-5
SHARINGAN_PREDICTION_CHANCE_PERCENT_TOMOE_6 = 40  # the tomoe-6 capstone's amplified version -- "predictive counter" per the table
SHARINGAN_PREDICTION_DAMAGE_REDUCTION_PERCENT = 40  # how much damage a successful Prediction cuts -- unchanged by tomoe count, tomoe 3's own specific perk

# 4-tomoe perk: genjutsu resistance. Genjutsu
# resistance reduces (not fully negates) the duration of any incoming
# genjutsu-sourced status effect -- built correctly wired even though
# no jutsu can currently target a player at all (see combat.
# use_jutsu_on_player, new this pass), same "build the hook ahead of
# what will eventually use it" discipline data_kekkei_genkai.
# attempt_awaken/eligible_for_awakening_quest were already built with.
SHARINGAN_GENJUTSU_RESIST_REDUCTION_PERCENT = 50  # how much shorter an incoming genjutsu effect's duration becomes, tomoe 4+

# 5-tomoe perk: Copy Jutsu, per direct design confirmation ("sharingan
# copy has a chance to copy the other users jutsu when toggled on but
# has a cost of double the other users chakra to copy"). A chance,
# each time an opponent casts a jutsu against this player, to copy
# that exact jutsu into a one-use cast of their own -- at DOUBLE what
# the original caster paid for it, not what it would normally cost
# this player.
SHARINGAN_COPY_JUTSU_CHANCE_PERCENT = 20  # chance to copy an opponent's jutsu on being hit by one, tomoe 5+

# Per-round COMBAT chakra upkeep while the Sharingan is active, keyed
# by tomoe count -- lower with more tomoe at first, per direct request
# ("the technique becomes less taxing with more eyes open"), but
# tomoe 3 bumps it back up -- Movement Prediction is real, ongoing
# upkeep of its own, on top of what came before ("passive but
# increases upkeep"). Tomoe 4 drops back down (genjutsu resistance is
# a passive check, not an ongoing drain of its own -- Sharingan
# Genjutsu has its own separate chakra_cost like any other jutsu, not
# folded into this upkeep). Tomoe 6 is the lowest COMBAT rate in the
# whole progression, matching the table's own "lowest upkeep"
# capstone description -- but never below idle upkeep, per a later follow-up
# request ("make sharingan cost upkeep at all times and increases
# during combat vs its not combat settings") that added a separate,
# always-on idle rate (SHARINGAN_IDLE_CHAKRA_UPKEEP below): a combat
# combat rate below idle would have been cheaper than simply having the ability on
# while idle, backwards from "increases during combat". Falls back to
# tomoe 1's rate for any tomoe count beyond what's been designed here
# (there's no tomoe 0, the ability can't be toggled on without at
# least 1). Stamina upkeep stays flat regardless of tomoe count;
# discounting it further would
# make the ability free of that resource entirely rather than merely
# cheaper.
SHARINGAN_CHAKRA_UPKEEP_BY_TOMOE = {1: 12, 2: 6, 3: 12, 4: 6, 5: 6, 6: 6}
SHARINGAN_STAMINA_UPKEEP = 6


def sharingan_chakra_upkeep(tomoe_count: int) -> int:
    """The per-round COMBAT chakra upkeep for a given tomoe count --
    see SHARINGAN_CHAKRA_UPKEEP_BY_TOMOE above. Falls back to tomoe
    1's rate for any tomoe count beyond what's been designed (1-6 now
    cover the full progression), rather than guessing at a value."""
    return SHARINGAN_CHAKRA_UPKEEP_BY_TOMOE.get(tomoe_count, SHARINGAN_CHAKRA_UPKEEP_BY_TOMOE[1])


# Idle (non-combat) chakra upkeep, per direct follow-up request ("make
# sharingan cost upkeep at all times and increases during combat vs
# its not combat settings"). Deliberately flat regardless of tomoe
# count, unlike the combat table above -- the point of this is a
# simple "having it active costs something, always" baseline, not
# another tomoe-scaled curve. This is charged on the separate idle
# timer, less often than combat rounds. Tomoe 1/3 also cost more
# Chakra per combat round; the higher tomoe tiers match the idle
# per-tick amount but drain more frequently in combat.
SHARINGAN_IDLE_CHAKRA_UPKEEP = 6


def _sharingan_eye_description(tomoe_count: int) -> str:
    """A short, accurate description of the Sharingan's current state
    for the given tomoe count (1-6, see data_kekkei_genkai.
    SHARINGAN_MAX_TOMOE) -- 1-3 tomoe are a single eye still
    developing, 4-6 mean both eyes now carry tomoe (2 eyes x 3 tomoe
    each is the full progression), matching the numbers the mastery
    system actually tracks rather than a generic, unchanging line
    regardless of how far the player has actually progressed."""
    if tomoe_count <= 3:
        return f"{tomoe_count} tomoe spin into focus"
    tomoe_per_eye = tomoe_count - 3
    return f"both eyes ignite -- {tomoe_per_eye} tomoe now spin in each"


def cmd_sharingan(session, args: List[str]) -> None:
    """Toggles the Sharingan's active perks on/off: reading an
    opponent's attacks well enough to dodge them (see derived_stats.py
    for the dodge bonus itself), plus whatever additional perks the
    player's current tomoe count has unlocked (combat.py's own
    resolve_pulse/resolve_pvp_pulse apply all of them each combat
    round -- this command only flips the toggle). Costs a small
    chakra+stamina upkeep every combat round it stays on, nothing
    while not fighting. Refuses with the exact same generic "haven't
    learned that skill" wording used everywhere else in the game for
    an unknown ability -- deliberately reveals nothing about whether
    this player has a hidden, un-awakened bloodline roll at all, same
    security stance the rest of this framework was built around (see
    data_kekkei_genkai.py's own docstring). The activation/
    deactivation message reflects the player's actual current tomoe
    count (see _sharingan_eye_description above), per direct follow-up
    request -- it no longer says "one tomoe" regardless of how far the
    player has actually progressed."""
    player = session.player
    if (player.bloodline_id != "sharingan" or player.bloodline_tomoe < 1) and not combat._staff_testing_mangekyo(player):
        session.send("You haven't learned that skill or jutsu.")
        return

    player.sharingan_active = not player.sharingan_active
    if player.sharingan_active:
        eye_description = _sharingan_eye_description(player.bloodline_tomoe or 1)
        session.send(
            f"&RYour eyes bleed to red -- {eye_description}. You can read your "
            "opponent's every movement.&x"
        )
    else:
        import upkeep_reports
        for message in upkeep_reports.flush(player, "Sharingan"):
            session.send(message)
        session.send(f"&RYour {max(1, player.bloodline_tomoe)}-tomoe Sharingan fades back to black.&x")


def _tsukuyomi_torture_action(session, command_name: str) -> None:
    """Shared real logic for all 5 Tsukuyomi torture commands (Section
    140, per direct confirmation) -- validates the caster genuinely
    has an active Tsukuyomi running, applies that command's own real
    effect (data_mangekyo.TSUKUYOMI_COMMANDS) to the target, advances
    the real hidden countdown by that command's own cost, and ends
    the technique (mangekyo.end_tsukuyomi) once it hits 0 or an
    early-end roll succeeds (crush only)."""
    import random
    import data_mangekyo
    import mangekyo
    import world as world_module

    player = session.player
    target_name = player.tsukuyomi_active_target_name
    if not target_name:
        session.send("You're not currently inside Tsukuyomi.")
        return
    target_session = next(
        (s for s in session.active_sessions() if s.player and s.player.name == target_name),
        None,
    )
    if target_session is None:
        session.send("Your target is no longer there!")
        return

    spec = data_mangekyo.TSUKUYOMI_COMMANDS[command_name]
    target = target_session.player
    lo, hi = spec["hp_damage"]
    if hi > 0:
        dmg = random.randint(lo, hi)
        dmg = status_effects.reduce_incoming_damage(target.active_status_effects, dmg)
        target.health -= dmg
    else:
        dmg = 0
    stamina_lo, stamina_hi = spec.get("stamina_drain", (0, 0))
    if stamina_hi > 0:
        target.stamina = max(0, target.stamina - random.randint(stamina_lo, stamina_hi))
    chakra_lo, chakra_hi = spec.get("chakra_drain", (0, 0))
    if chakra_hi > 0:
        target.chakra = max(0, target.chakra - random.randint(chakra_lo, chakra_hi))

    session.send(f"&RYou use {command_name} on {target.name} -- {damage_messages.describe_damage(dmg)} damage.&x" if dmg else f"&RYou use {command_name} on {target.name}.&x")
    target_session.send(f"&R{player.name} uses {command_name} on you -- {damage_messages.describe_damage(dmg)} damage!&x" if dmg else f"&R{player.name} uses {command_name} on you!&x")

    player.tsukuyomi_actions_remaining -= spec["countdown_cost"]
    early_end_chance = spec.get("early_end_chance_pct", 0)
    genuinely_ended_early = early_end_chance and random.randint(1, 100) <= early_end_chance

    if player.tsukuyomi_actions_remaining <= 0 or genuinely_ended_early:
        target.stamina = 0
        target.health = max(1, min(target.health, int(target.maximum_health * 0.05)))
        session.send("&RThe technique runs its course -- reality snaps back into place.&x")
        target_session.send("&RThe torment finally ends -- you're released, exhausted and broken.&x")
        mangekyo.end_tsukuyomi(session, target_session, world_module)


def cmd_stab(session, args: List[str]) -> None:
    """'stab' -- one of the 5 real Tsukuyomi torture commands (Section
    140), a moderate, consistent damage source."""
    _tsukuyomi_torture_action(session, "stab")


def cmd_impale(session, args: List[str]) -> None:
    """'impale' -- one of the 5 real Tsukuyomi torture commands
    (Section 140), heavier damage than stab, but costs 2 of the real
    hidden countdown instead of 1."""
    _tsukuyomi_torture_action(session, "impale")


def cmd_burn(session, args: List[str]) -> None:
    """'burn' -- one of the 5 real Tsukuyomi torture commands (Section
    140), moderate damage plus a real stamina drain."""
    _tsukuyomi_torture_action(session, "burn")


def cmd_crush(session, args: List[str]) -> None:
    """'crush' -- one of the 5 real Tsukuyomi torture commands
    (Section 140), the single highest per-hit damage option, with a
    real chance to end the whole technique one action early."""
    _tsukuyomi_torture_action(session, "crush")


def cmd_unmake(session, args: List[str]) -> None:
    """'unmake' -- one of the 5 real Tsukuyomi torture commands
    (Section 140), no direct HP damage at all, but a heavy real
    stamina and chakra drain together."""
    _tsukuyomi_torture_action(session, "unmake")


def cmd_guess(session, args: List[str]) -> None:
    """One guess per 15-second Izanami cycle; failures injure the victim."""
    import izanami_loops
    izanami_loops.guess(session, args)


def cmd_izanagi(session, args: List[str]) -> None:
    """Toggles Izanagi on/off -- per direct confirmation (Section 140):
    a real, deliberate stance the player must proactively activate,
    NOT automatic. Mirrors cmd_sharingan/cmd_tailed_beast_mode's own
    established toggle pattern. Only usable if the player genuinely
    rolled Izanagi as one of their 2 real Mangekyo eye techniques.
    Blocked while on its own real, once-per-real-day cooldown after a
    genuine trigger (see combat.py's own defeat-check, which fires
    the actual save and sets izanagi_cooldown_until)."""
    player = session.player
    import combat
    if (not combat._staff_testing_mangekyo(player) and
            (player.bloodline_id != "sharingan" or not player.bloodline_mangekyo
             or (player.mangekyo_eye_1 != "izanagi" and player.mangekyo_eye_2 != "izanagi"))):
        jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
        return
    if not player.sharingan_active and not player.izanagi_active and not combat._staff_testing_mangekyo(player):
        jutsu_colors.send(session, "Activate your Sharingan before using Mangekyo techniques.")
        return
    now = time.time()
    if now < player.izanagi_cooldown_until:
        remaining = player.izanagi_cooldown_until - now
        jutsu_colors.send(session, f"Izanagi is still recovering ({remaining / 3600:.1f} hours).")
        return

    player.izanagi_active = not player.izanagi_active
    if player.izanagi_active:
        import mangekyo_discovery
        mangekyo_discovery.record_use(player, "izanagi")
        jutsu_colors.send(session, "&RReality bends around you -- fate itself now answers to your will.&x")
    else:
        jutsu_colors.send(session, "&RYou release your grip on fate. Izanagi fades.&x")


def cmd_jinchuriki(session, args: List[str]) -> None:
    """Show the player's sealed beast and its separate combat mastery."""
    if args:
        session.send("Usage: jinchuriki")
        return
    import data_tailed_beasts
    player = session.player
    beast = data_tailed_beasts.TAILED_BEASTS_BY_KEY.get(player.jinchuriki_beast_key)
    if beast is None:
        session.send("You do not have a Tailed Beast sealed within you.")
        return
    session.send("\n".join((
        "&WJinchuriki Mastery&x",
        f"&CBeast:&x {beast['display_name']} ({beast['tails']} {'tail' if beast['tails'] == 1 else 'tails'})",
        f"&CMastery:&x {player.jinchuriki_mastery}%",
    )))


def cmd_tailed_beast_mode(session, args: List[str]) -> None:
    """Toggles Tailed Beast Mode on/off -- per direct confirmation
    (Section 127 continued): "Tailed beast mode is much like
    sharingan on/off." Mirrors cmd_sharingan's own exact established
    pattern. Only ever togglable ON at genuinely full (100%)
    jinchuriki_mastery -- confirmed directly this represents having
    achieved real, free control over the beast's own power. The real
    combat/stat bonus itself (tailed_beasts.mode_bonus_percent,
    scaled by the specific beast's own tail count) is applied
    automatically by combat.py's own resolution wherever the
    personality-trait/rampage bonuses already are -- this command
    only flips the toggle. Blocked while rampaging (a defensive
    safeguard per direct confirmation, since these 2 states can't
    naturally co-occur given the real mastery gates on each)."""
    player = session.player
    if not player.jinchuriki_beast_key:
        session.send("You haven't learned that skill or jutsu.")
        return
    if player.jinchuriki_mastery < 100:
        session.send("You haven't mastered your beast's power well enough to control it yet.")
        return
    if player.rampage_until:
        session.send("You're consumed by the beast's rage -- you have no control over your own body!")
        return

    player.tailed_beast_mode_active = not player.tailed_beast_mode_active
    import data_tailed_beasts
    beast = data_tailed_beasts.TAILED_BEASTS_BY_KEY[player.jinchuriki_beast_key]
    if player.tailed_beast_mode_active:
        session.send(f"&R{beast['display_name']}'s chakra cloaks you -- you feel its full power flow through you, under your own control.&x")
    else:
        session.send(f"&RThe cloak of {beast['display_name']}'s chakra fades.&x")


def cmd_aff(session, args: List[str]) -> None:
    """Shows every status effect (stunned, bleeding, confused, etc. --
    see status_effects.EFFECT_DEFS) currently active on the player,
    with remaining duration, same formatting score's own sheet already
    uses (see _format_active_effects above, extracted so the two can't
    drift apart). Also shows the Sharingan toggle when it's on -- the
    player already knows they activated it themselves, so this is
    ordinary visible ability state, not a Kekkei Genkai security
    concern the way raw mastery/tomoe numbers would be."""
    player = session.player
    lines = ["&WActive effects:&x " + _format_active_effects(player.active_status_effects)]
    if player.taijutsu_stance:
        lines.append(f"&YTaijutsu stance: {data_jutsu.JUTSU[player.taijutsu_stance]['display_name']}&x")
    if player.sharingan_active:
        lines.append("&RYour Sharingan is active.&x")
    if player.samurai_sabre_active:
        lines.append("&CYour Samurai Sabre is active.&x")
    import hidden_mist
    if hidden_mist.owned_room(player):
        lines.append("&CHidden Mist Jutsu is ON (1 Chakra every 5 seconds).&x")
    session.send("\n".join(lines))


def cmd_afk(session, args: List[str]) -> None:
    player = session.player
    player.afk = not player.afk
    session.send("You are now AFK." if player.afk else "You are no longer AFK.")


def cmd_goto(session, args: List[str]) -> None:
    """Teleports the user directly to a room (by vnum) or to wherever
    another online player currently is (by name) -- an immortal/staff
    convenience for getting places instantly. Distinct from 'rset
    goto', which only changes which room subsequent OLC commands
    (rset/oset/mset) are editing, without moving the character at all.
    Bypasses any "locked"/"private" room restrictions the same way
    staff already can when walking normally -- this sets room_vnum
    directly rather than going through a directional move command."""
    if not olc.can_build(session):
        session.send("You do not have builder access.")
        return
    if not args:
        session.send("Usage: goto <vnum>  OR  goto <player name>")
        return

    query = " ".join(args)
    if query.isdigit():
        vnum = int(query)
        if not olc._require_assigned_vnum(session, vnum):
            return
        if vnum not in WORLD.rooms:
            WORLD.add_room(world.Room(vnum, "An Unfinished Room", "You see nothing special."))
            olc._log(session.player.name, "room", vnum, "auto-created via goto")
            session.send(f"Room {vnum} didn't exist yet -- created it.")
        destination = vnum
    else:
        target_session = next(
            (
                s for s in session.active_sessions()
                if s is not session and s.player and query.lower() in s.player.name.lower()
            ),
            None,
        )
        if not target_session:
            session.send(f"No player named '{query}' is online.")
            return
        destination = target_session.player.room_vnum

    if not olc._require_assigned_vnum(session, destination):
        return

    session.player.room_vnum = destination
    session.send("You vanish in a puff of smoke.")
    cmd_look(session, [])
    _fire_enter_triggers(session)



def cmd_force(session, args: List[str]) -> None:
    """Immortal force: execute a reviewed ordinary command as an online player.

    Matching is case-insensitive, exact name preferred, unambiguous prefix
    allowed. Higher staff may force ordinary players, never staff peers;
    only administrators/Implementors may use a safe mass-social 'all'.
    """
    import force_commands
    if not session.account or session.account.staff_level not in config.STAFF_LEVELS[1:]:
        session.send("Only immortals can force a player command.")
        return
    if len(args) < 2:
        session.send("Usage: force <player name> <allowed command>  |  force all <safe social command|save> (administrator+)")
        return
    who, cmd = args[0].strip(), " ".join(args[1:])
    # Deliberately special-case administrator 'force all save': never expose
    # save to generic mpforce or to ordinary player-command forcing.
    if who.lower() == "all" and cmd.strip().lower() == "save":
        if session.account.staff_level not in {"administrator", "implementor"}:
            session.send("Only administrators and Implementors may use force all save.")
            return
        targets = [s for s in session.active_sessions()
                   if s is not session and s.player and s.account
                   and getattr(getattr(s, "state", None), "name", None) == "PLAYING"
                   and s.account.staff_level == "player"]
        if len(targets) > 50:
            session.send("Refused: force all save is limited to 50 online characters.")
            return
        for target in targets:
            storage.save_player(target.player)
            olc._log(session.player.name, "force", target.player.name, "command: save")
        session.send(f"Saved {len(targets)} online player character(s).")
        return
    error = force_commands.validate_forced_command(cmd)
    if error:
        session.send(error)
        return
    online = [s for s in session.active_sessions()
              if s.player and s.account and
              getattr(getattr(s, "state", None), "name", None) == "PLAYING"]
    if who.lower() == "all":
        if session.account.staff_level not in {"administrator", "implementor"}:
            session.send("Only administrators and Implementors may use force all.")
            return
        # Bulk force is deliberately informational/social, not a way to
        # move or attack the entire server in one command.
        if cmd.split()[0].lower() not in {"look", "l", "say", "emote", "stand", "wake", "rest"}:
            session.send("force all is limited to look, say, emote, stand, wake, rest and save.")
            return
        targets = [s for s in online if s is not session and s.account.staff_level == "player"]
        if not targets:
            session.send("No ordinary players are online to force.")
            return
        if len(targets) > 50:
            session.send("Refused: force all is limited to 50 online characters.")
            return
    else:
        matches = [s for s in online if s.player.name.casefold() == who.casefold()]
        if not matches:
            matches = [s for s in online if s.player.name.casefold().startswith(who.casefold())]
        if len(matches) != 1:
            session.send("No unique online character matches that name.")
            return
        targets = matches
    successes = 0
    for target in targets:
        ok, why = force_commands.run_forced_player_command(
            target, cmd, f"Immortal {session.player.name}")
        if ok:
            successes += 1
            olc._log(session.player.name, "force", target.player.name,
                     f"command: {cmd}")
        elif len(targets) == 1:
            session.send(why)
    if successes:
        session.send(f"Forced {successes} character(s) to execute: {cmd}")


def cmd_transfer(session, args: List[str]) -> None:
    """Teleports another (real, online) player directly to the
    caller's own current room -- per direct request/confirmation
    (Section 126): "add a transfer command and return so an imm can
    trasnfer a player to their location and it remembers where they
    where to transfer back." Saves that player's own real room first
    (pre_transfer_room_vnum), so 'return' can send them back later --
    a genuine, single saved value per player: transferring them again
    while already away just overwrites it with wherever they were at
    THAT moment, confirmed directly, not a stack of past locations."""
    if not olc._require_builder(session):
        return
    if session.account.staff_level == "builder":
        session.send("Only higher staff can transfer players.")
        return
    if not args:
        session.send("Usage: transfer <player name>")
        return

    query = " ".join(args)
    target_session = next(
        (
            s for s in session.active_sessions()
            if s is not session and s.player and query.lower() in s.player.name.lower()
        ),
        None,
    )
    if not target_session:
        session.send(f"No player named '{query}' is online.")
        return

    target_session.player.pre_transfer_room_vnum = target_session.player.room_vnum
    target_session.player.room_vnum = session.player.room_vnum
    session.last_transferred_player_name = target_session.player.name

    session.send(f"You transfer {target_session.player.name} to your location.")
    target_session.send(f"{session.player.name} transfers you elsewhere in a puff of smoke!")
    _fire_enter_triggers(target_session)


def cmd_return(session, args: List[str]) -> None:
    """Sends whoever the caller most recently transferred back to
    their own real, original room -- per direct request/confirmation
    (Section 126). Confirmed directly: takes no argument, always
    targeting the caller's own last transfer (session.
    last_transferred_player_name), not a name the caller specifies
    fresh each time. Refuses cleanly if that player isn't online
    anymore, or has already been returned (or never had a saved room
    at all)."""
    if not olc._require_builder(session):
        return
    if session.account.staff_level == "builder":
        session.send("Only higher staff can return transferred players.")
        return
    if not session.last_transferred_player_name:
        session.send("You haven't transferred anyone yet.")
        return

    target_session = next(
        (
            s for s in session.active_sessions()
            if s.player and s.player.name == session.last_transferred_player_name
        ),
        None,
    )
    if not target_session:
        session.send(f"{session.last_transferred_player_name} isn't online anymore.")
        return
    if target_session.player.pre_transfer_room_vnum is None:
        session.send(f"{target_session.player.name} doesn't have anywhere saved to return to.")
        return

    target_session.player.room_vnum = target_session.player.pre_transfer_room_vnum
    target_session.player.pre_transfer_room_vnum = None
    session.last_transferred_player_name = None

    session.send(f"You send {target_session.player.name} back to where they were.")
    target_session.send(f"{session.player.name} sends you back to where you were in a puff of smoke!")
    _fire_enter_triggers(target_session)


def cmd_reload(session, args: List[str]) -> None:
    """Spawns back any registered spawn point (mob or item) in the
    room the player is currently standing in that's genuinely
    missing right now -- per direct request/confirmation ("add a
    command reload that reloads all items and mobs set to spawn in
    that room"). Confirmed: only spawns what's genuinely absent, no
    duplicates for anything already present, matching the exact same
    "missing-only" guarantee already established for mob spawn points
    via area resets, now extended to cover items too. See
    spawn_points.reload_room for the actual logic."""
    import spawn_points

    if not olc._require_builder(session):
        return

    player = session.player
    result = spawn_points.reload_room(player.room_vnum)
    if result["mobs"] == 0 and result["items"] == 0:
        session.send("Nothing to reload -- every spawn point registered in this room is already present.")
        return
    parts = []
    if result["mobs"]:
        parts.append(f"{result['mobs']} mob(s)")
    if result["items"]:
        parts.append(f"{result['items']} item(s)")
    session.send(f"Reloaded {' and '.join(parts)} into this room.")


def cmd_spawnpoint(session, args: List[str]) -> None:
    """'spawnpoint add mob|item <vnum>' -- registers a persistent
    spawn point in the room you're standing in right now (always the
    room you're in, matching how 'rset' works -- no separate targeting
    needed) and immediately spawns one instance too. It'll keep
    existing there across server restarts; for mobs, dying and
    respawning after that was already automatic (see spawn_points.py).
    'spawnpoint remove mob|item <vnum>' unregisters one (in the room
    you're standing in). 'spawnpoint remove all' unregisters every
    spawn point in the room at once, per direct request. 'spawnpoint
    list' shows every registered spawn point in the room you're
    standing in, with its own cap info alongside it.

    'spawnpoint cap mob|item <vnum> <total> <per_period>' -- per
    direct request/confirmation (Section 152: "why do we have
    setspawn AND spawnpoint...they move need to be merged into one
    command"), this folds the real, formerly-separate 'setspawn'
    command's own cap-setting ability in here as a subcommand instead
    of a whole second top-level command. Sets a real population cap
    on a spawn point (registering one at the caller's current room
    first if it doesn't already exist, same convenience 'spawnpoint
    add' already has). <total> is the max number of that vnum allowed
    to exist across the WHOLE containing area at once; <per_period>
    is the max NEW ones the area's own 15-minute reset sweep (see
    'help area') is allowed to add in a single pass, never exceeding
    the total. Use 'off' for either number to remove that cap
    (uncapped). 'spawnpoint cap mob|item <vnum>' with no numbers
    shows the current caps instead of changing them. Caps only ever
    affect mob spawn points in practice -- the area-reset sweep that
    actually enforces them is mob-only (see spawn_points.
    respawn_missing_mobs_in_area), matching that same design scope,
    though the caps themselves are stored the same way for either
    kind in case a future sweep extends to items."""
    import spawn_points

    if not olc._require_builder(session):
        return
    if not args:
        session.send(
            "Usage: spawnpoint add mob|item <vnum>\n"
            "       spawnpoint remove mob|item <vnum>\n"
            "       spawnpoint remove all\n"
            "       spawnpoint list\n"
            "       spawnpoint cap mob|item <vnum> <total> <per_period>\n"
            "       spawnpoint cap mob|item <vnum>   (shows current caps)"
        )
        return

    sub = args[0].lower()
    player = session.player
    if (session.account and session.account.staff_level == "builder" and
            len(args) > 2 and args[2].isdigit() and
            not olc._require_assigned_vnum(session, int(args[2]))):
        return

    if sub == "list":
        points = spawn_points.list_spawn_points(player.room_vnum)
        if not points:
            session.send("No spawn points registered in this room.")
            return
        lines = ["&WSpawn points in this room:&x"]
        for point in points:
            if point["kind"] == "mob":
                proto = combat.MOB_TEMPLATES.get(point["vnum"])
            else:
                proto = olc.OBJECT_TEMPLATES.get(point["vnum"])
            display = proto["short_desc"] if proto else f"(missing {point['kind']} {point['vnum']})"
            total_cap, per_period_cap = spawn_points.get_spawn_caps(point["kind"], point["vnum"], player.room_vnum)
            total_text = str(total_cap) if total_cap is not None else "uncapped"
            per_period_text = str(per_period_cap) if per_period_cap is not None else "uncapped"
            lines.append(
                f"  [{point['kind']}] vnum {point['vnum']} -- {display} "
                f"(total cap {total_text}, per-period cap {per_period_text})"
            )
        session.send("\n".join(lines))
        return

    if sub == "remove" and len(args) == 2 and args[1].lower() == "all":
        removed = spawn_points.remove_all_spawn_points(player.room_vnum)
        if not removed:
            session.send("No spawn points registered in this room.")
            return
        session.send(f"Removed all {removed} spawn point(s) registered in this room.")
        return

    if sub == "cap":
        if len(args) not in (3, 5) or args[1].lower() not in ("mob", "item") or not args[2].isdigit():
            session.send(
                "Usage: spawnpoint cap mob|item <vnum> <total> <per_period>\n"
                "       spawnpoint cap mob|item <vnum>   (shows current caps)"
            )
            return

        kind, vnum = args[1].lower(), int(args[2])

        if len(args) == 3:
            total_cap, per_period_cap = spawn_points.get_spawn_caps(kind, vnum, player.room_vnum)
            total_text = str(total_cap) if total_cap is not None else "uncapped"
            per_period_text = str(per_period_cap) if per_period_cap is not None else "uncapped"
            session.send(f"{kind.capitalize()} vnum {vnum} in this room: total cap {total_text}, per-period cap {per_period_text}.")
            return

        total_text, per_period_text = args[3], args[4]
        total_cap = None if total_text.lower() == "off" else (int(total_text) if total_text.isdigit() else None)
        per_period_cap = None if per_period_text.lower() == "off" else (int(per_period_text) if per_period_text.isdigit() else None)
        if (total_text.lower() != "off" and not total_text.isdigit()) or (per_period_text.lower() != "off" and not per_period_text.isdigit()):
            session.send("Both <total> and <per_period> must be a number or 'off'.")
            return
        if total_cap is not None and per_period_cap is not None and per_period_cap > total_cap:
            session.send(f"Per-period cap ({per_period_cap}) can't be higher than the total cap ({total_cap}).")
            return

        # Register the spawn point first if it doesn't exist yet --
        # same convenience 'spawnpoint add' already offers, so staff
        # don't need a separate add first just to set caps.
        existing = [p for p in spawn_points.list_spawn_points(player.room_vnum) if p["kind"] == kind and p["vnum"] == vnum]
        if not existing:
            error = spawn_points.add_spawn_point(kind, vnum, player.room_vnum)
            if error:
                session.send(error)
                return

        error = spawn_points.set_spawn_caps(kind, vnum, player.room_vnum, total_cap, per_period_cap)
        if error:
            session.send(error)
            return

        total_display = str(total_cap) if total_cap is not None else "uncapped"
        per_period_display = str(per_period_cap) if per_period_cap is not None else "uncapped"
        session.send(f"{kind.capitalize()} vnum {vnum} in this room: total cap set to {total_display}, per-period cap set to {per_period_display}.")
        cmd_look(session, [])
        return

    if sub not in ("add", "remove") or len(args) != 3 or args[1].lower() not in ("mob", "item") or not args[2].isdigit():
        session.send(
            "Usage: spawnpoint add mob|item <vnum>\n"
            "       spawnpoint remove mob|item <vnum>\n"
            "       spawnpoint remove all\n"
            "       spawnpoint list\n"
            "       spawnpoint cap mob|item <vnum> <total> <per_period>\n"
            "       spawnpoint cap mob|item <vnum>   (shows current caps)"
        )
        return

    kind, vnum = args[1].lower(), int(args[2])

    if sub == "add":
        error = spawn_points.add_spawn_point(kind, vnum, player.room_vnum)
        if error:
            session.send(error)
            return
        session.send(f"Spawn point registered: a {kind} (vnum {vnum}) will now always exist in this room.")
        return

    removed = spawn_points.remove_spawn_point(kind, vnum, player.room_vnum)
    if not removed:
        session.send("No matching spawn point registered in this room.")
        return
    session.send(f"Spawn point removed: a {kind} (vnum {vnum}) will no longer be re-placed here on server start.")


def cmd_recall(session, args: List[str]) -> None:
    player = session.player
    import mangekyo
    if mangekyo.is_inside_kamui_pocket(player, world):
        session.send("&RYou cannot recall out of a Kamui pocket dimension. Only the caster can release you.&x")
        return
    if player.in_chunin_exam:
        session.send("&RRecall is denied during the Chunin Exam. Leaving means failing and restarting; 'leave confirm' forfeits your attempt.&x")
        return
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.blocks_teleport(player):
        session.send("A teleportation anchor prevents your recall.")
        return
    if session.combat_target is not None:
        session.send("You can't recall while you're fighting!")
        return
    if player.apartment_room_vnum is None:
        session.send("You don't own an apartment yet -- try 'buy apartment'.")
        return
    room = WORLD.get(player.apartment_room_vnum)
    if not room or not room.apartment or room.owner != player.name:
        session.send("Something's wrong with your apartment's deed -- contact a builder.")
        return
    old_room_vnum = player.room_vnum
    player.room_vnum = room.vnum
    combat.follow_owner_summon(player, old_room_vnum, room.vnum)
    session.send(f"&CYou recall home to {room.name}.&x")
    cmd_look(session, [])
    _fire_enter_triggers(session)


ANKI_COOLDOWN_SECONDS = 5 * 60.0  # confirmed directly: "5 minute cooldown between use"


def cmd_anki(session, args: List[str]) -> None:
    """'anki' -- per direct request/confirmation (Section 136): "like
    recall but it will teleport the player to their village Kage room
    with a 5 minute cooldown between use." Confirmed directly: the
    same "can't use while fighting" restriction as recall, no level
    requirement at all, and auto-known by every character from
    creation (see data_jutsu.UNIVERSAL_STARTING_SKILLS).

    Fixed a real, genuine bug caught by direct user correction
    ("anki was supposed to be the kage room not village square"):
    VILLAGES[village]["starting_room_vnum"] is actually the Village
    Square, not the Kage room -- the real Kage room lives in a
    completely separate, real place, content._VILLAGE_ROOMS[village]
    ["kage"] (e.g. vnum 1010 for Leaf, distinct from the square's
    1000), the same real room used elsewhere for the Hokage's own
    chamber."""
    player = session.player
    import mangekyo
    if mangekyo.is_inside_kamui_pocket(player, world):
        session.send("&RAnki cannot escape a Kamui pocket dimension. Only the caster can release you.&x")
        return
    if player.in_chunin_exam:
        session.send("&RAnki cannot remove you from the Chunin Exam. Leaving means failure and a full restart. Use 'leave confirm' to forfeit.&x")
        return
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.blocks_teleport(player):
        session.send("A teleportation anchor prevents Anki.")
        return
    if session.combat_target is not None:
        session.send("You can't use Anki while you're fighting!")
        return
    now = time.time()
    cooldown_ready_at = player.cooldowns.get("anki", 0)
    if now < cooldown_ready_at:
        session.send(f"Anki is still recovering ({cooldown_ready_at - now:.1f}s).")
        return
    import content
    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    if not village_rooms:
        session.send("Something's wrong with your village registration -- contact a builder.")
        return
    room = WORLD.get(village_rooms["kage"])
    if not room:
        session.send("Something's wrong with your village's Kage room -- contact a builder.")
        return
    player.cooldowns["anki"] = now + ANKI_COOLDOWN_SECONDS
    old_room_vnum = player.room_vnum
    player.room_vnum = room.vnum
    combat.follow_owner_summon(player, old_room_vnum, room.vnum)
    session.send(f"&CYou focus your chakra and recall the way home -- you arrive in {room.name}.&x")
    cmd_look(session, [])
    _fire_enter_triggers(session)


def cmd_apartment(session, args: List[str]) -> None:
    """Customize your OWNED apartment's name and description -- nothing
    else. Must be standing inside it (matching the 'buy apartment'
    restriction, so a player can't redecorate a home they aren't in)."""
    player = session.player
    if not args or args[0].lower() not in ("name", "desc", "description"):
        session.send("Usage: apartment name <text>  OR  apartment desc <text>")
        return
    if player.apartment_room_vnum is None:
        session.send("You don't own an apartment.")
        return
    room = WORLD.get(player.room_vnum)
    if not room or not room.apartment or room.owner != player.name:
        session.send("You have to be standing inside your own apartment to customize it.")
        return
    sub, rest = args[0].lower(), args[1:]
    if not rest:
        session.send(f"Usage: apartment {sub} <text>")
        return
    text = " ".join(rest)
    if sub == "name":
        room.name = text
        player.apartment_name = text
        storage.save_player(player)
        session.send(f"Your apartment is now called '{text}'.")
    else:
        room.description = text
        player.apartment_description = text
        storage.save_player(player)
        session.send("Your apartment's description has been updated.")


def _find_any_player(name: str):
    """Case-insensitive exact-name lookup for viewing purposes -- open
    to any player, not just staff (unlike olc._find_target_player,
    which is admin-only and used for editing). Checks online sessions
    first (so a just-written edit shows immediately), falling back to
    the save file for an offline character."""
    from session import ACTIVE_SESSIONS
    name_lower = name.lower()
    for s in ACTIVE_SESSIONS:
        if s.player and s.player.name.lower() == name_lower:
            return s.player
    return storage.load_player(name)


def cmd_description(session, args: List[str]) -> None:
    """Opens the guided line editor (same one used for help-topic
    authoring) to write a short roleplay description of your own
    character -- shown to others via 'look <you>'."""
    if args:
        session.send("Usage: 'description' with no arguments opens the editor to write your own.")
        return
    player = session.player

    def save(text: str) -> None:
        player.description = text
        storage.save_player(player)
        session.send("Description saved.")

    session.enter_editor(
        save, initial_text=player.description,
        header="Write a short description others will see when they 'look' at you.",
    )


def cmd_biography(session, args: List[str]) -> None:
    """With no arguments, opens the guided line editor to write your
    own character's longer roleplay backstory. With a name, shows that
    player's biography (online or offline, open to any player)."""
    if not args:
        player = session.player

        def save(text: str) -> None:
            player.biography = text
            storage.save_player(player)
            session.send("Biography saved.")

        session.enter_editor(
            save, initial_text=player.biography,
            header="Write your character's biography/backstory.",
        )
        return

    target = _find_any_player(" ".join(args))
    if not target:
        session.send(f"No player named '{' '.join(args)}' was found.")
        return
    if not target.biography:
        session.send(f"{target.name} hasn't written a biography yet.")
        return
    session.send(f"&Y{target.name}'s Biography:&x\n\n{target.biography}")


# --- Equipment -----------------------------------------------------------

def cmd_inventory(session, args: List[str]) -> None:
    player = session.player
    if not player.inventory:
        session.send("You aren't carrying anything.")
        return
    counts = inventory.slot_counts(player.inventory)
    lines = []
    for name, count in counts.items():
        colored = rarity_colored_name(tool_durability.display_name(name))
        shown = f"{colored} (x{count})" if count > 1 else colored
        illusion = player.genjutsu_item_illusions.get(name)
        if illusion:
            shown += f" &M(appears as {illusion['alias']})&x"
        lines.append(f"{shown}{_staff_vnum_suffix(session, item_name=name)}")
    session.send(
        "You are carrying:\n  " + "\n  ".join(lines)
        + f"\n&D({len(counts)}/{inventory.MAX_INVENTORY_SLOTS} slots used)&x"
    )


def cmd_equipment(session, args: List[str]) -> None:
    player = session.player
    lines = ["You are using:"]
    preferred_order = ("head", "neck", "piercing", "body", "back", "hands",
                       "finger", "waist", "legs", "feet", "chakra aura",
                       "wielded", "offhand", "tool")
    slots = [slot for slot in preferred_order if slot in olc.WEAR_LOCATIONS or slot == "offhand"]
    slots.extend(sorted((olc.WEAR_LOCATIONS | player.equipment.keys()) - set(slots)))
    for slot in slots:
        item = player.equipment.get(slot)
        lines.append(f"  <{slot}> {rarity_colored_name(tool_durability.display_name(item)) if item else '&D(nothing)&x'}")
    session.send("\n".join(lines))


def cmd_wear(session, args: List[str]) -> None:
    if args and " ".join(args).lower() == "all":
        _wear_all(session)
        return
    _equip_item(session, args, accepted_locs=olc.ARMOR_WEAR_LOCATIONS | {"wielded"}, verb="wear")


def cmd_wield(session, args: List[str]) -> None:
    _equip_item(session, args, accepted_locs={"wielded"}, verb="wield")


def cmd_hold(session, args: List[str]) -> None:
    """Equips a tool (a crafted fishing rod, etc.) in its own 'tool'
    slot -- separate from wielded weapons and worn armor, so a player
    can hold a rod and still fight with their weapon equipped."""
    _equip_item(session, args, accepted_locs={"tool"}, verb="hold")


def _item_wear_loc(item_name: str):
    """The wear_loc an item's own prototype declares, or None if it
    has none set (not equippable at all) or no prototype exists."""
    proto = _find_object_prototype_by_name(item_name)
    return proto.get("wear_loc") or None if proto else None


def _learn_weapon_skill_if_new(player, weapon_type: str):
    """Grants the weapon skill for weapon_type (data_weapons.WEAPON_TYPES)
    the first time a player wields a weapon of that type, if they
    don't already have it -- fixes a previously-flagged gap where no
    weapon skill (Kunai, Sword, etc.) was ever actually granted to any
    player anywhere in the codebase, despite being defined in the
    catalog and shown under General Skills in 'prac'. Returns a
    one-time announcement message, or None if the player already had
    it."""
    weapon_info = data_weapons.WEAPON_TYPES.get(weapon_type)
    if not weapon_info:
        return None
    skill_name = weapon_info["skill"]
    if skill_name in player.learned_skills:
        return None
    player.learned_skills.append(skill_name)
    player.skill_proficiencies[skill_name] = leveling.initial_proficiency(player)
    return f"&GYou've learned the basics of {skill_name}!&x"


_EQUIPMENT_STAT_BONUS_PLAYER_FIELDS = {
    "max_health": "maximum_health",
    "max_chakra": "maximum_chakra",
    "max_stamina": "maximum_stamina",
    "strength": "strength",
    "dexterity": "dexterity",
    "intelligence": "intelligence",
    "wisdom": "wisdom",
    "luck": "luck",
    "constitution": "constitution",
}


def _apply_equipment_stat_bonuses(player, item_name: str, sign: int) -> None:
    """Applies (sign=+1, on equip) or reverses (sign=-1, on unequip) an
    item's stat_bonuses for the 9 categories beyond hitroll/damroll/
    armor_class -- those 3 are already summed dynamically each time
    they're needed (see equipped_weapon_hitroll_bonus and friends),
    but max_health/max_chakra/max_stamina and the 6 attributes are
    read directly all over the codebase (regen caps, the score sheet,
    damage formulas), so baking the bonus permanently into the
    player's own field here, exactly once at the moment of equipping,
    keeps every one of those existing reads correct automatically
    rather than needing each individually rewritten to account for
    equipment. Deliberately no cap check here -- an equipment bonus
    can push an attribute past config.MAX_ATTRIBUTE_VALUE, same
    established precedent as a completed armor set's bonus in
    derived_stats.py (that cap only applies to raw training). For the
    3 resource pools, the current value moves by the same delta as the
    max (so equipping doesn't look like a sudden % drop, nor unequip a
    sudden overflow), then clamped to a sane [0, max] range as a
    safety net."""
    proto = _find_object_prototype_by_name(item_name)
    if not proto:
        return
    for stat_key, player_field in _EQUIPMENT_STAT_BONUS_PLAYER_FIELDS.items():
        bonus = proto.get("stat_bonuses", {}).get(stat_key, 0)
        if not bonus:
            continue
        setattr(player, player_field, getattr(player, player_field) + sign * bonus)
        if stat_key == "max_health":
            player.health = max(0, min(player.maximum_health, player.health + sign * bonus))
        elif stat_key == "max_chakra":
            player.chakra = max(0, min(player.maximum_chakra, player.chakra + sign * bonus))
        elif stat_key == "max_stamina":
            player.stamina = max(0, min(player.maximum_stamina, player.stamina + sign * bonus))


def _equip_item(session, args: List[str], accepted_locs, verb: str) -> None:
    """Equips an item into ITS OWN wear_loc (an item's own prototype
    field, not a slot forced by which command the player typed) --
    provided that wear_loc is one this command actually accepts.
    'wear' accepts both armor and weapons; 'wield' accepts weapons."""
    player = session.player
    if not args:
        session.send(f"{verb.capitalize()} what?")
        return
    query = " ".join(args).lower()

    already_equipped = next((item for item in player.equipment.values() if _item_matches(query, item)), None)
    if already_equipped:
        session.send(f"You are already using {already_equipped}.")
        return

    match = find_indexed_item(query, player.inventory)
    if not match:
        session.send(f"You aren't carrying anything like '{query}'.")
        return

    wear_loc = _item_wear_loc(match)
    if wear_loc not in accepted_locs:
        session.send(f"You can't {verb} {match}.")
        return

    player.inventory.remove(match)
    previous = player.equipment.get(wear_loc)
    if previous and previous != match:
        ok, reason = inventory.add_item(player.inventory, previous)
        if ok:
            session.send(f"You stop using {rarity_colored_name(previous)}.")
            _apply_equipment_stat_bonuses(player, previous, sign=-1)
        else:
            # Only reachable if the player somehow already has 2,000 of
            # this exact item sitting loose in inventory -- no
            # drop-to-room mechanic exists in this game, so be
            # honest that it's lost rather than claiming it's
            # retrievable somewhere.
            session.send(inventory.full_message(reason, previous))
            session.send(f"With nowhere to put it, {rarity_colored_name(previous)} is lost.")
            _apply_equipment_stat_bonuses(player, previous, sign=-1)
    player.equipment[wear_loc] = match
    _apply_equipment_stat_bonuses(player, match, sign=1)
    if wear_loc == "wielded":
        weapon_type = data_weapons.weapon_type_for_item(match)
        if weapon_type:
            session.send(f"You wield {rarity_colored_name(match)} ({data_weapons.display_name(weapon_type)}-style weapon).")
            learn_msg = _learn_weapon_skill_if_new(player, weapon_type)
            if learn_msg:
                session.send(learn_msg)
        else:
            session.send(f"You wield {rarity_colored_name(match)}.")
    elif wear_loc == "tool":
        session.send(f"You hold {rarity_colored_name(tool_durability.display_name(match))}.")
    else:
        session.send(f"You wear {rarity_colored_name(match)}.")
    _fire_item_trigger(session, match, "wear")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} {'wields' if wear_loc == 'wielded' else 'puts on'} {match}.")



def _wear_all(session) -> None:
    """'wear all' -- per explicit request. Equips every equippable
    item in inventory (any wear_loc: armor, weapon, or tool) into its
    OWN slot, not all into one. Skips a slot that's already occupied
    rather than silently swapping out whatever's there -- an explicit
    single-item wear/wield/hold is how you replace something on
    purpose. Replaces the old 'wear all', which forced everything into
    a single hardcoded slot and silently dropped all but the first
    match due to a dict.setdefault bug."""
    player = session.player
    equipped_count = 0
    for item in list(player.inventory):
        wear_loc = _item_wear_loc(item)
        if wear_loc not in olc.WEAR_LOCATIONS:
            continue
        if wear_loc in player.equipment:
            continue
        player.inventory.remove(item)
        player.equipment[wear_loc] = item
        _apply_equipment_stat_bonuses(player, item, sign=1)
        if wear_loc == "wielded":
            weapon_type = data_weapons.weapon_type_for_item(item)
            if weapon_type:
                learn_msg = _learn_weapon_skill_if_new(player, weapon_type)
                if learn_msg:
                    session.send(learn_msg)
        _fire_item_trigger(session, item, "wear")
        equipped_count += 1
    if equipped_count:
        session.send(f"You put on {equipped_count} item(s).")
        import room_actions
        room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} equips {equipped_count} items.")
    else:
        session.send("You have nothing new to wear.")


def cmd_remove(session, args: List[str]) -> None:
    player = session.player
    if not args:
        session.send("Remove what?")
        return
    query = " ".join(args).lower()

    if query == "all":
        _remove_all(session)
        return

    match_slot = "offhand" if query in ("offhand", "off hand") and player.equipment.get("offhand") else next(
        (slot for slot, item in player.equipment.items() if _item_matches(query, item)), None
    )
    if not match_slot:
        session.send(f"You aren't wearing or wielding anything like '{query}'.")
        return

    item = player.equipment[match_slot]
    ok, reason = inventory.add_item(player.inventory, item)
    if not ok:
        session.send(inventory.full_message(reason, item))
        return
    del player.equipment[match_slot]
    _apply_equipment_stat_bonuses(player, item, sign=-1)
    session.send(f"You remove {item}.")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} removes {item}.")
    if match_slot == "wielded" and player.equipment.get("offhand"):
        player.equipment["wielded"] = player.equipment.pop("offhand")
        session.send("Your off-hand weapon becomes your main weapon.")


def _remove_all(session) -> None:
    """'remove all' -- per explicit request. Removes everything
    currently equipped, one slot at a time, adding each back to
    inventory. If inventory is full partway through, whatever's left
    stays equipped rather than being lost -- same "don't destroy items
    on a full inventory" principle used everywhere else in the game."""
    player = session.player
    removed_count = 0
    for slot in list(player.equipment.keys()):
        item = player.equipment[slot]
        ok, reason = inventory.add_item(player.inventory, item)
        if not ok:
            session.send(inventory.full_message(reason, item))
            session.send(f"With nowhere to put it, {rarity_colored_name(item)} stays equipped.")
            continue
        del player.equipment[slot]
        _apply_equipment_stat_bonuses(player, item, sign=-1)
        removed_count += 1
    if removed_count:
        session.send(f"You remove {removed_count} item(s).")
        import room_actions
        room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} removes {removed_count} equipped items.")
    else:
        session.send("You aren't wearing or wielding anything.")


CONSIDER_THRESHOLDS = [
    (-10, "&GYou can kill it with a single blow.&x"),
    (-5, "&GIt looks like an easy kill.&x"),
    (-1, "&GThe odds are in your favor.&x"),
    (0, "&YThe perfect match for your skills!&x"),
    (4, "&YYou should be cautious.&x"),
    (9, "&RYou would need some luck!&x"),
    (float("inf"), "&RDeath will thank you for your gift.&x"),
]


def _consider_verdict(level_diff: int) -> str:
    for threshold, verdict in CONSIDER_THRESHOLDS:
        if level_diff <= threshold:
            return verdict
    return CONSIDER_THRESHOLDS[-1][1]


def cmd_weather(session, args: List[str]) -> None:
    """Reports the current world-wide weather and time of day
    (weather.py) -- both change periodically via the main pulse loop,
    not per-room. Purely informational; the actual mechanical effects
    (gathering fail chance, combat accuracy, night dodge bonus) apply
    automatically without needing to check this first."""
    session.send(weather.status_line())


def cmd_consider(session, args: List[str]) -> None:
    """Gauges how dangerous a mob would be to fight, based on the level
    gap between it and the player -- a quick, cheap way to check before
    committing to 'attack', not a full combat simulation. Mobs only,
    matching the classic convention (a player's level/rank is already
    visible via 'who' or 'look' for a PvP read)."""
    player = session.player
    if not args:
        session.send("Consider fighting whom?")
        return
    mob = combat.find_mob(player.room_vnum, " ".join(args))
    if not mob:
        session.send("You don't see that here.")
        return
    verdict = _consider_verdict(mob.level - player.level)
    session.send(f"You consider {mob.name}.\n{verdict}")


def cmd_attack(session, args: List[str]) -> None:
    player = session.player

    if not args:
        session.send("Attack what?")
        return
    mob = combat.find_mob(player.room_vnum, " ".join(args))
    if mob:
        if (getattr(mob, "chunin_exam_owner", "")
                and (not player.in_chunin_exam or mob.chunin_exam_owner != player.name)):
            session.send("That exam shadow is bound to another candidate.")
            return
        if combat.is_shopkeeper(mob) or combat.is_gambler(mob) or combat.is_teacher(mob) or combat.is_immortal_mob(mob):
            session.send(f"{mob.name.capitalize()} is protected and cannot be attacked.")
            return
        _wake_and_stand(session)
        combat.start_attack(session, mob)
        session.send(f"You attack {mob.name}!")
        import room_actions
        room_actions.emit(session, f"&R{player.name} attacks {mob.name}!&x")
        return

    query = " ".join(args).lower()
    target_session = next(
        (
            s for s in session.active_sessions()
            if s is not session and s.player and s.player.room_vnum == player.room_vnum
            and query in s.player.name.lower()
        ),
        None,
    )
    if not target_session:
        session.send("There is nothing here for you to attack.")
        return
    if player.illusion_walk_caster is not None:
        session.send("There is nothing here for you to attack.")
        return

    room = world.WORLD.get(player.room_vnum)
    if room and room.safe:
        session.send("This is a PvP-safe zone. You cannot attack other players here.")
        return
    if target_session.player.izanami_trapped:
        session.send(f"{target_session.player.name} is lost in a loop, untouched by reality -- you cannot reach them.")
        return
    if target_session.player.health <= 0:
        session.send(f"{target_session.player.name} is already down.")
        return
    import hidden_mist
    import general_skills
    if general_skills.concealed_from(player, target_session.player):
        session.send("You cannot see that camouflaged ninja. Use Sensory Detect to locate them.")
        return
    if hidden_mist.obscures(player, target_session.player):
        session.send("The mist hides your target. You cannot lock onto them.")
        return

    _wake_and_stand(session)
    combat.start_pvp_attack(session, target_session)
    session.send(f"You attack {target_session.player.name}!")
    target_session.send(f"&R{player.name} attacks you!&x")
    import room_actions
    room_actions.emit(session, f"&R{player.name} attacks {target_session.player.name}!&x", exclude=(target_session,))


def _current_jutsu_opponent(session) -> List[str]:
    """Use only a live opponent here, including combat started by NPC aggro."""
    player = session.player
    rival = getattr(session, "pvp_target", None)
    if (rival and getattr(rival, "player", None) and rival.player.health > 0
            and rival.player.room_vnum == player.room_vnum
            and getattr(getattr(rival, "state", None), "name", "PLAYING") == "PLAYING"):
        return [rival.player.name]
    mob = getattr(session, "combat_target", None)
    if (mob and mob.health > 0 and mob.room_vnum == player.room_vnum
            and any(existing is mob for existing in combat.mobs_in_room(player.room_vnum))):
        # Preserve the actual opponent when several NPCs share a name.
        matches = [m for m in combat.mobs_in_room(player.room_vnum)
                   if mob.name.lower() in m.name.lower()]
        index = next(i for i, match in enumerate(matches, 1) if match is mob)
        return [f"{index}.{mob.name}"]
    return []


def cmd_use_jutsu(session, jutsu_key: str, target_words: List[str]) -> None:
    player = session.player
    jutsu_data = data_jutsu.JUTSU.get(jutsu_key, {})
    # Actual resource costs follow ninja level, art tier and maximum pools.
    # Upkeep/toggles continue using their separate established maintenance.
    import jutsu_balance
    scaled_chakra_cost = jutsu_balance.cast_cost(player, jutsu_data, "chakra")
    scaled_stamina_cost = jutsu_balance.cast_cost(player, jutsu_data, "stamina")

    # Kamui owners can dismiss an existing pocket from OUTSIDE without
    # entering it, paying upkeep, or needing the target to be in this room.
    # Closing is an emergency release of a previously owned dimension;
    # it doesn't recast Kamui or confer access to anyone else's pocket.
    if (jutsu_key == "kamui pocket dimension"
            and [w.casefold() for w in target_words] in
            (["close"], ["collapse"], ["dismiss"])):
        import mangekyo
        import world as world_module
        try:
            returned = mangekyo.close_pocket_dimension(session, world_module)
        except ValueError as exc:
            jutsu_colors.send(session, str(exc))
            return
        jutsu_colors.send(session, f"&CYou close your Kamui pocket dimension from reality. {returned} occupant(s) return to the real world.&x")
        return

    opponent_types = {"instant_kill", "ambush", "attack", "track", "sealing",
                      "beast_release", "beast_bomb", "illusion_walk", "thrown", "trap",
                      "fan_art", "blade_strike", "mangekyo_tsukuyomi", "mangekyo_amaterasu",
                      "mangekyo_kamui_pocket_dimension", "mangekyo_kamui_limb_removal",
                      "mangekyo_izanami", "mirror", "sevenfold"}
    implicit_player = None
    implicit_mob = None
    if not target_words and (jutsu_data.get("damage") is not None
                             or jutsu_data.get("jutsu_type") in opponent_types
                             or jutsu_key == "reaper death seal"):
        target_words = _current_jutsu_opponent(session)
        rival = getattr(session, "pvp_target", None)
        if rival and getattr(rival, "player", None) and target_words == [rival.player.name]:
            implicit_player = rival
        elif target_words:
            implicit_mob = getattr(session, "combat_target", None)
        if not target_words:
            # A departed or defeated opponent must not survive as a fallback
            # through the older generic casting path below.
            session.combat_target = session.pvp_target = None
    import reaper_seal
    if (reaper_seal.imprisoned(player) and jutsu_key != reaper_seal.REVERSE_KEY and not combat.is_immortal_immune_to_defeat(session)):
        session.send("The Reaper's seal binds your soul; you cannot perform jutsu.")
        return
    import whirlpool_fuinjutsu
    suppressed = whirlpool_fuinjutsu.blocked_jutsu(player, jutsu_data)
    if suppressed:
        session.send(suppressed)
        return
    if jutsu_data.get("jutsu_type") == "whirlpool_seal":
        whirlpool_fuinjutsu.cast(session, jutsu_key, target_words)
        return
    if jutsu_data.get("jutsu_type") == "reaper_seal":
        reaper_seal.cast(session, jutsu_key, target_words)
        return
    if jutsu_data.get("jutsu_type") == "hyuga_mode":
        hyuga.cast(session, jutsu_key, target_words)
        return
    if jutsu_data.get("jutsu_type") == "general_utility":
        import general_skills
        general_skills.activate(session, jutsu_key, target_words)
        return
    import skill_training
    if (jutsu_data and skill_training.needs_first_practice(
            player, jutsu_data["display_name"])
            and not combat._staff_testing_mangekyo(player)):
        jutsu_colors.send(session,
                          f"&YPractice {jutsu_data['display_name']} with a teacher at least once before using it.&x")
        return
    if jutsu_data.get("damage") or jutsu_data.get("jutsu_type") in {
            "instant_kill", "room_sleep", "illusion_walk", "trap",
            "mangekyo_tsukuyomi", "mangekyo_amaterasu", "mangekyo_kamui_pocket_dimension",
            "mangekyo_kamui_limb_removal", "mangekyo_izanami"}:
        import general_skills
        general_skills.break_camouflage(session)
    if jutsu_data.get("jutsu_type") == "six_paths_recovery":
        import six_paths
        six_paths.vital_surge(session, target_words)
        return
    if jutsu_data.get("jutsu_type") == "six_paths_mode":
        import six_paths
        if not six_paths.eligible(player, jutsu_data["kkg_gate"].removeprefix("six_paths_")):
            session.send("That Six Paths form does not match your level and inherited soul.")
            return
        six_paths.command(session, target_words, soul=jutsu_data["kkg_gate"].removeprefix("six_paths_"))
        return
    if jutsu_data.get("jutsu_type") in ("dual_wield", "chokkan", "instant_kill"):
        import legacy_techniques
        if jutsu_data["jutsu_type"] == "instant_kill" and implicit_player:
            legacy_techniques.instant_kill(session, target_words, preferred_player=implicit_player)
            return
        {"dual_wield": legacy_techniques.dual_wield,
         "chokkan": legacy_techniques.chokkan,
         "instant_kill": legacy_techniques.instant_kill}[jutsu_data["jutsu_type"]](session, target_words)
        return
    if jutsu_data.get("jutsu_type") == "combat_passive":
        jutsu_colors.send(session, f"{jutsu_data['display_name']} works automatically in combat.")
        return
    if jutsu_key == "amaterasu" and target_words and target_words[0].lower() == "extinguish":
        if (combat._staff_testing_mangekyo(player) or
                (player.bloodline_id == "sharingan" and player.bloodline_mangekyo
                 and "amaterasu" in (player.mangekyo_eye_1, player.mangekyo_eye_2))):
            import mangekyo_mobs
            mangekyo_mobs.extinguish(session, target_words[1:])
        else:
            jutsu_colors.send(session, "You cannot control Amaterasu's flames.")
        return
    if (jutsu_data.get("kkg_gate") == "mangekyo_technique" and not player.sharingan_active
            and not combat._staff_testing_mangekyo(player)):
        roster_key = jutsu_data.get("mangekyo_roster_key", jutsu_key)
        if (player.bloodline_id == "sharingan" and player.bloodline_mangekyo
                and roster_key in (player.mangekyo_eye_1, player.mangekyo_eye_2)):
            jutsu_colors.send(session, "Activate your Sharingan before using Mangekyo techniques.")
        else:
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
        return
    fan_direction = None
    if jutsu_data.get("jutsu_type") == "fan_art" and target_words:
        for idx in (0, len(target_words) - 1):
            direction = world.normalize_direction(target_words[idx].lower())
            if direction:
                fan_direction = direction
                target_words = target_words[:idx] + target_words[idx + 1:]
                break
    import hidden_mist
    if target_words and jutsu_data.get("jutsu_type") not in {"mist", "chisei"}:
        query = " ".join(target_words).lower()
        import general_skills
        if any(s is not session and s.player and s.player.room_vnum == player.room_vnum
               and query in s.player.name.lower() and general_skills.concealed_from(player, s.player)
               for s in getattr(session, "active_sessions", lambda: [])()):
            jutsu_colors.send(session, "You cannot see that camouflaged ninja. Use Sensory Detect to locate them.")
            return
        if any(s is not session and s.player and s.player.room_vnum == player.room_vnum
               and query in s.player.name.lower() and hidden_mist.obscures(player, s.player)
               for s in getattr(session, "active_sessions", lambda: [])()):
            jutsu_colors.send(session, "The mist hides your target. You cannot lock onto them.")
            return
    if jutsu_key in ("amaterasu", "tsukuyomi", "izanami", "kamui pocket dimension", "kamui limb removal") and target_words:
        query = " ".join(target_words).lower()
        player_match = any(s is not session and s.player and s.player.room_vnum == player.room_vnum
                           and query in s.player.name.lower() for s in session.active_sessions())
        if not player_match and query not in ("self", "me") and query not in player.name.lower():
            mob = combat.find_mob(player.room_vnum, query)
            if mob:
                import mangekyo_mobs
                mangekyo_mobs.cast(session, jutsu_key, mob)
                return
    if jutsu_data.get("jutsu_type") == "mist":
        if target_words and (len(target_words) != 1 or target_words[0].lower() not in {"on", "off"}):
            jutsu_colors.send(session, "Usage: perform hidden mist jutsu [on|off]")
            return
        mode = target_words[0].lower() if target_words else "toggle"
        maintained = hidden_mist.owned_room(player)
        if mode == "off" or (mode == "toggle" and maintained):
            hidden_mist.dismiss(session)
            return
        if maintained:
            session.send("Your Hidden Mist Jutsu is already ON.")
            return
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You have not learned Hidden Mist Jutsu or lack the water element.")
            return
        if session.pending_cast is not None:
            jutsu_colors.send(session, "You're already forming hand signs for another jutsu!")
            return
        combat.begin_pending_cast(session, jutsu_key, session, is_pvp=False)
        return
    if jutsu_data.get("jutsu_type") == "weapon_art":
        import ninja_arts
        if jutsu_key == "water release: glue technique" and hasattr(session, "start_timed_action"):
            import data_handsigns
            if session.is_busy():
                jutsu_colors.send(session, "You're already busy with something.")
                return
            if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
                jutsu_colors.send(session, "You don't know this Water Release technique or lack the water element.")
                return
            signs = data_handsigns.sequence_for(jutsu_key)
            jutsu_colors.send(session, f"&WYou begin forming hand signs: {' -> '.join(signs)}...&x")
            session.broadcast_room(f"&W{player.name} forms hand signs: {' -> '.join(signs)}...&x", exclude_self=True)
            session.start_timed_action(jutsu_key, data_handsigns.casting_delay_seconds(player.skill_proficiencies.get("Handsigns", 0)),
                                       lambda: ninja_arts.use_weapon_art(session, jutsu_key, target_words))
            return
        ninja_arts.use_weapon_art(session, jutsu_key, target_words)
        return
    if jutsu_data.get("jutsu_type") == "sabre_buff":
        if target_words:
            jutsu_colors.send(session, "Usage: samurai sabre")
            return
        import ninja_arts
        ninja_arts.use_samurai_sabre(session)
        return
    if jutsu_data.get("jutsu_type") == "trap_disable":
        import ninja_arts
        query = " ".join(target_words).lower()
        mob = combat.find_mob(player.room_vnum, query) if query else session.combat_target
        target_session = next((s for s in session.active_sessions() if s is not session and s.player
                               and s.player.room_vnum == player.room_vnum and query in s.player.name.lower()), None) if query else session.pvp_target
        target = mob or (target_session.player if target_session else player if not query else None)
        if target is None:
            jutsu_colors.send(session, "There is nobody here by that name.")
            return
        ninja_arts.use_disable(session, target)
        return
    if jutsu_data.get("jutsu_type") in ("disguise", "item_illusion", "item_decoy", "chisei", "room_sleep"):
        import genjutsu
        genjutsu.begin_cast(session, jutsu_key, target_words)
        return
    if jutsu_data.get("jutsu_type") == "stance":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You don't know that stance.")
            return
        if session.combat_target is not None or session.pvp_target is not None:
            jutsu_colors.send(session, "You cannot change stance while fighting.")
            return
        if combat._is_action_blocked(player):
            jutsu_colors.send(session, "You are unable to act!")
            return
        if player.taijutsu_stance == jutsu_key:
            player.taijutsu_stance = ""
            jutsu_colors.send(session, f"You leave {jutsu_data['display_name']} and return to a normal stance.")
            return
        if player.stamina < scaled_stamina_cost:
            jutsu_colors.send(session, "You don't have enough stamina.")
            return
        player.stamina -= scaled_stamina_cost
        player.taijutsu_stance = jutsu_key
        combat.grow_skill_from_usage(player, jutsu_data["display_name"])
        jutsu_colors.send(session, f"You enter {jutsu_data['display_name']} stance.")
        return
    if jutsu_data.get("jutsu_type") == "ambush":
        if session.combat_target is not None or session.pvp_target is not None:
            jutsu_colors.send(session, f"You can't use {jutsu_data['display_name']} mid-fight. They already know you're there!")
            return
        if not target_words:
            jutsu_colors.send(session, f"Sneak up on whom? Usage: perform {jutsu_key} <target>.")
            return
    if jutsu_data.get("jutsu_type") == "buff":
        combat.use_barrier(session)
        return
    if jutsu_data.get("jutsu_type") == "elemental_clone":
        combat.use_elemental_clone_jutsu(session, jutsu_key)
        return
    if jutsu_data.get("jutsu_type") == "summon":
        if jutsu_key == "shadow clone jutsu":
            combat.use_shadow_clone_jutsu(session)
        return
    if jutsu_data.get("jutsu_type") == "track_upgrade":
        jutsu_colors.send(session, "Advanced Tracking is a passive upgrade. Use 'perform track <target>'.")
        return
    if jutsu_data.get("jutsu_type") == "track":
        import tracking
        import areas
        import session as session_module

        # A real learned scroll (or staff powers) is required; merely
        # knowing the command name must never grant free tracking.
        advanced = tracking.has_advanced_tracking(player)
        normal = (player.level >= jutsu_data["level_requirement"]
                  and jutsu_data["display_name"] in player.learned_skills)
        if not (advanced or normal or combat._staff_testing_mangekyo(player)):
            jutsu_colors.send(session, "You must learn Track or Advanced Tracking from a scroll "
                              "and meet the technique's level requirement.")
            return
        if not target_words:
            jutsu_colors.send(session, "Track who or what?")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("track", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WTrack&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return

        query = " ".join(target_words)
        target_mob = (None if implicit_player else implicit_mob or
                      tracking.find_mob_anywhere_in_world(combat, query))
        target_player_session = implicit_player
        if target_mob is None and target_player_session is None:
            target_player_session = tracking.find_online_player_anywhere(session_module, query, viewer=player)
        if target_mob is None and target_player_session is None:
            jutsu_colors.send(session, f"You can't find any trace of '{query}' anywhere.")
            return

        target_room_vnum = target_mob.room_vnum if target_mob else target_player_session.player.room_vnum
        area = areas.find_area_for_vnum(target_room_vnum)
        if area is None and not advanced:
            jutsu_colors.send(session, "You can't get a fix on their location.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["track"] = now + jutsu_data["cooldown"]
        tracking.start_tracking(
            player,
            target_mob=target_mob,
            target_player_name=target_player_session.player.name if target_player_session else None,
            area_name=area.name if area else None,
        )
        target_name = target_mob.name if target_mob else target_player_session.player.name
        message = (f"&YYour advanced senses follow {target_name}'s trail across country borders...&x"
                   if advanced else f"&YYou focus your senses and pick up {target_name}'s trail...&x")
        jutsu_colors.send(session, message)
        return
    if jutsu_data.get("jutsu_type") == "sealing":
        if not target_words:
            jutsu_colors.send(session, "Seal what?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        query = " ".join(target_words)
        mob = None if implicit_player else combat.find_mob(player.room_vnum, query)
        if mob is None or not getattr(mob, "tailed_beast_key", None):
            jutsu_colors.send(session, "There's no Tailed Beast here by that name.")
            return
        if mob.tailed_beast_downed_until == 0.0:
            jutsu_colors.send(session, f"{mob.name} is still fighting back -- you can't seal it yet.")
            return

        player.chakra -= scaled_chakra_cost
        beast_key = mob.tailed_beast_key
        import data_tailed_beasts
        beast = data_tailed_beasts.TAILED_BEASTS_BY_KEY[beast_key]
        combat.remove_mob(mob)
        player.jinchuriki_beast_key = beast_key
        player.jinchuriki_mastery = 0
        jutsu_colors.send(session, f"&RYou complete the seal -- {beast['display_name']} is bound within you now!&x")
        import tailed_beasts
        _broadcast_globally(tailed_beasts.announcement(beast, sealed_by=player.name))
        return
    if jutsu_data.get("jutsu_type") == "beast_release":
        if not target_words:
            jutsu_colors.send(session, "Release the beast from who?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        query = " ".join(target_words).lower()
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player and query in s.player.name.lower()),
            None,
        )
        if not target_session or not target_session.player.jinchuriki_beast_key:
            jutsu_colors.send(session, "That player isn't a jinchuriki.")
            return
        if target_session.player.health > 0:
            jutsu_colors.send(session, f"You must defeat {target_session.player.name} in combat first.")
            return

        player.chakra -= scaled_chakra_cost
        beast_key = target_session.player.jinchuriki_beast_key
        import data_tailed_beasts
        import tailed_beasts as tailed_beasts_module
        import world as world_module
        beast = data_tailed_beasts.TAILED_BEASTS_BY_KEY[beast_key]
        target_session.player.jinchuriki_beast_key = None
        target_session.player.jinchuriki_mastery = 0
        mob = tailed_beasts_module.release_beast(beast, world_module, combat)
        jutsu_colors.send(session, f"&RYou tear {beast['display_name']} free from {target_session.player.name}!&x")
        jutsu_colors.send(target_session, f"&R{player.name} rips {beast['display_name']} out of you!&x")
        _broadcast_globally(tailed_beasts_module.announcement(
            beast, freed_from=target_session.player.name))
        return
    if jutsu_data.get("jutsu_type") == "beast_bomb":
        if not player.tailed_beast_mode_active:
            jutsu_colors.send(session, "You can only unleash this while Tailed Beast Mode is active.")
            return
        if not target_words:
            jutsu_colors.send(session, "Unleash the Tailed Beast Bomb on who?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("tailed beast bomb", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WTailed Beast Bomb&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return

        query = " ".join(target_words)
        mob = None if implicit_player else combat.find_mob(player.room_vnum, query)
        target_session = implicit_player
        if mob is None:
            target_session = next(
                (s for s in session.active_sessions() if s is not session and s.player and query.lower() in s.player.name.lower()),
                None,
            )
        if mob is None and target_session is None:
            jutsu_colors.send(session, "There's nothing here by that name.")
            return

        if not combat.engage_damage_attack(
                session, mob if mob is not None else target_session.player, target_session):
            return
        player.chakra -= scaled_chakra_cost
        player.cooldowns["tailed beast bomb"] = now + jutsu_data["cooldown"]
        import tailed_beasts as tailed_beasts_module
        dmg = tailed_beasts_module.bomb_damage(player)
        import data_tailed_beasts
        beast = data_tailed_beasts.TAILED_BEASTS_BY_KEY[player.jinchuriki_beast_key]
        if mob is not None:
            mob.health -= dmg
            jutsu_colors.send(session, f"&RYou unleash a {beast['display_name']} Bomb on {mob.name} for {damage_messages.describe_damage(dmg)} damage!&x")
            if mob.health <= 0:
                combat.handle_mob_defeat(session, mob)
        else:
            dmg = status_effects.reduce_incoming_damage(target_session.player.active_status_effects, dmg)
            target_session.player.health -= dmg
            jutsu_colors.send(session, f"&RYou unleash a {beast['display_name']} Bomb on {target_session.player.name} for {damage_messages.describe_damage(dmg)} damage!&x")
            jutsu_colors.send(target_session, f"&R{player.name} unleashes a {beast['display_name']} Bomb on you for {damage_messages.describe_damage(dmg)} damage!&x")
            if target_session.player.health <= 0:
                if combat.is_immortal_immune_to_defeat(target_session):
                    combat.clamp_immortal_health(target_session)
                else:
                    combat.handle_pvp_defeat(winner_session=session, loser_session=target_session)
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_tsukuyomi":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if not target_words:
            jutsu_colors.send(session, "Trap who in Tsukuyomi?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("tsukuyomi", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WTsukuyomi&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return

        query = " ".join(target_words)
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query.lower() in s.player.name.lower()),
            None,
        )
        if target_session is None:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["tsukuyomi"] = now + jutsu_data["cooldown"]
        if has_silent_genjutsu(player):
            combat.resolve_tsukuyomi_cast(session, target_session)
        else:
            combat.begin_pending_cast(session, "tsukuyomi", target_session, is_pvp=True, start_combat_on_resolve=False)
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_amaterasu":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if not target_words:
            jutsu_colors.send(session, "Unleash Amaterasu on who?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("amaterasu", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WAmaterasu&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return

        query = " ".join(target_words)
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query.lower() in s.player.name.lower()),
            None,
        )
        if target_session is None:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["amaterasu"] = now + jutsu_data["cooldown"]
        if has_silent_genjutsu(player):
            combat.resolve_amaterasu_cast(session, target_session)
        else:
            combat.begin_pending_cast(session, "amaterasu", target_session, is_pvp=True, start_combat_on_resolve=False)
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_kamui_pocket_dimension":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if not target_words:
            jutsu_colors.send(session, "Open the pocket dimension on who?")
            return
        query = " ".join(target_words).lower()

        # A self cast enters an opened pocket or creates a new solo one.
        if query in ("self", "me") or query in player.name.lower():
            import mangekyo
            try:
                entered = mangekyo.enter_own_pocket_dimension(session)
            except ValueError as exc:
                jutsu_colors.send(session, str(exc))
                return
            if not entered:
                jutsu_colors.send(session, "You are already inside your pocket dimension.")
                return
            import mangekyo_discovery
            mangekyo_discovery.record_use(player, jutsu_key)
            jutsu_colors.send(session, "&RYou step through a rift into your pocket dimension.&x")
            return

        # Step 1: targeting another player opens it and sends them alone.
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query in s.player.name.lower()),
            None,
        )
        if target_session is None:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        import mangekyo
        import world as world_module
        try:
            mangekyo.open_pocket_dimension(session, target_session, world_module)
        except ValueError as exc:
            jutsu_colors.send(session, str(exc))
            return
        import mangekyo_discovery
        mangekyo_discovery.record_use(player, jutsu_key)
        jutsu_colors.send(session, f"&RYou tear open a rift and cast {target_session.player.name} into a pocket dimension.&x")
        jutsu_colors.send(target_session, f"&R{player.name}'s eyes flash -- reality tears open and swallows you whole!&x")
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_kamui_intangibility":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("kamui intangibility", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WKamui: Intangibility&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return
        player.chakra -= scaled_chakra_cost
        player.cooldowns["kamui intangibility"] = now + jutsu_data["cooldown"]
        import data_mangekyo
        player.kamui_intangibility_rounds_left = data_mangekyo.KAMUI_INTANGIBILITY_ROUNDS
        import mangekyo_discovery
        mangekyo_discovery.record_use(player, jutsu_key)
        jutsu_colors.send(session, "&RYour body turns to mist -- nothing can touch you for a moment.&x")
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_kamui_limb_removal":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if not target_words:
            jutsu_colors.send(session, "Unleash Kamui: Limb Removal on who?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("kamui limb removal", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WKamui: Limb Removal&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return

        query = " ".join(target_words)
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query.lower() in s.player.name.lower()),
            None,
        )
        if target_session is None:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["kamui limb removal"] = now + jutsu_data["cooldown"]
        import random
        import data_mangekyo
        delay = random.uniform(*data_mangekyo.KAMUI_LIMB_REMOVAL_CAST_SECONDS)
        session.pending_cast = combat.PendingCast("kamui limb removal", target_session, is_pvp=True, remaining_seconds=delay, start_combat_on_resolve=False)
        jutsu_colors.send(session, f"&WYou begin tearing a rift through space, blade poised to strike {target_session.player.name}...&x")
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_izanami":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if not target_words:
            jutsu_colors.send(session, "Trap who in Izanami?")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("izanami", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WIzanami&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return

        query = " ".join(target_words)
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query.lower() in s.player.name.lower()),
            None,
        )
        if target_session is None:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["izanami"] = now + jutsu_data["cooldown"]
        if has_silent_genjutsu(player):
            combat.resolve_izanami_cast(session, target_session)
        else:
            combat.begin_pending_cast(session, "izanami", target_session, is_pvp=True, start_combat_on_resolve=False)
        return
    if jutsu_data.get("jutsu_type") == "mangekyo_kekkei_no_me":
        if not combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("kekkei no me", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WKekkei no Me&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return
        player.chakra -= scaled_chakra_cost
        player.cooldowns["kekkei no me"] = now + jutsu_data["cooldown"]
        if has_silent_genjutsu(player):
            combat.resolve_kekkei_no_me_cast(session)
        else:
            combat.begin_pending_cast(session, "kekkei no me", session, is_pvp=False, start_combat_on_resolve=False)
        return
    if jutsu_data.get("jutsu_type") == "illusion_walk":
        if not target_words:
            jutsu_colors.send(session, "Cast Illusion Walk on who?")
            return
        now = time.time()
        cooldown_ready_at = player.cooldowns.get("illusion walk", 0)
        if now < cooldown_ready_at:
            jutsu_colors.send(session, f"&WIllusion Walk&x is still recovering ({cooldown_ready_at - now:.1f}s).")
            return
        if player.chakra < scaled_chakra_cost:
            jutsu_colors.send(session, "You don't have enough chakra.")
            return
        if session.pending_cast is not None:
            jutsu_colors.send(session, "You're already in the middle of forming hand signs for another jutsu!")
            return
        query = " ".join(target_words).lower()
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query in s.player.name.lower()),
            None,
        )
        if not target_session:
            jutsu_colors.send(session, "There's nobody here by that name.")
            return

        player.chakra -= scaled_chakra_cost
        player.cooldowns["illusion walk"] = now + jutsu_data["cooldown"]
        if has_silent_genjutsu(player):
            combat.resolve_illusion_walk_cast(session, target_session)
        else:
            combat.begin_pending_cast(session, "illusion walk", target_session, is_pvp=True, start_combat_on_resolve=False)
        return
    if jutsu_data.get("jutsu_type") in ("counter", "silent_genjutsu_passive"):
        jutsu_colors.send(session, f"{jutsu_data['display_name']} is a passive ability -- it triggers automatically, you don't use it directly.")
        return
    if jutsu_data.get("jutsu_type") == "area" and not target_words and session.combat_target is None:
        mob = next((m for m in combat.mobs_in_room(player.room_vnum)
                    if m.health > 0 and not combat.is_shadow_clone(m)
                    and not (combat.is_shopkeeper(m) or combat.is_gambler(m)
                             or combat.is_teacher(m) or combat.is_immortal_mob(m))), None)
    elif target_words:
        mob = None if implicit_player else combat.find_mob(player.room_vnum, " ".join(target_words))
    else:
        mob = session.combat_target
    if mob:
        if jutsu_data.get("jutsu_type") == "ambush" and mob.health < mob.max_health:
            jutsu_colors.send(session, f"{mob.name} is hurt and alert; you cannot sneak up on them.")
            return
        if combat.is_shopkeeper(mob) or combat.is_gambler(mob) or combat.is_teacher(mob) or combat.is_immortal_mob(mob):
            jutsu_colors.send(session, f"{mob.name.capitalize()} is protected and cannot be attacked.")
            return
        if session.pending_cast is not None:
            jutsu_colors.send(session, "You're already in the middle of forming hand signs for another jutsu!")
            return
        if session.combat_target is None and combat._can_use_jutsu(player, jutsu_data, jutsu_key):
            shortfall = combat.jutsu_resource_shortfall(player, jutsu_data, jutsu_key)
            if shortfall:
                jutsu_colors.send(session, shortfall)
                return
        import data_handsigns
        starting_fresh = session.combat_target is None
        if data_handsigns.has_handsigns(jutsu_data) and combat._can_use_jutsu(player, jutsu_data, jutsu_key) and not has_silent_genjutsu(player):
            if starting_fresh:
                _wake_and_stand(session)
            combat.begin_pending_cast(session, jutsu_key, mob, is_pvp=False, start_combat_on_resolve=starting_fresh)
        else:
            if starting_fresh:
                _wake_and_stand(session)
                combat.start_attack(session, mob)
            if fan_direction:
                combat.use_jutsu(session, jutsu_key, mob, fan_direction=fan_direction)
            else:
                combat.use_jutsu(session, jutsu_key, mob)
        return

    # No mob matched -- per direct request ("make jutsu pvp enabled"),
    # fall back to another player in the room, same targeting
    # convention cmd_attack already uses.
    target_session = None
    if target_words:
        query = " ".join(target_words).lower()
        target_session = next(
            (
                s for s in session.active_sessions()
                if s is not session and s.player and s.player.room_vnum == player.room_vnum
                and query in s.player.name.lower()
            ),
            None,
        )
    elif session.pvp_target is not None:
        target_session = session.pvp_target

    if not target_session:
        jutsu_colors.send(session, "There is nothing here to use that on.")
        return
    if player.illusion_walk_caster is not None:
        jutsu_colors.send(session, "There is nothing here to use that on.")
        return

    room = world.WORLD.get(player.room_vnum)
    if room and room.safe:
        jutsu_colors.send(session, "This is a PvP-safe zone. You cannot attack other players here.")
        return
    if target_session.player.health <= 0:
        jutsu_colors.send(session, f"{target_session.player.name} is already down.")
        return
    if jutsu_data.get("jutsu_type") == "ambush" and target_session.player.health < target_session.player.maximum_health:
        jutsu_colors.send(session, f"{target_session.player.name} is hurt and alert; you cannot sneak up on them.")
        return
    if session.pending_cast is not None:
        jutsu_colors.send(session, "You're already in the middle of forming hand signs for another jutsu!")
        return

    if session.pvp_target is None and combat._can_use_jutsu(player, jutsu_data, jutsu_key):
        shortfall = combat.jutsu_resource_shortfall(player, jutsu_data, jutsu_key)
        if shortfall:
            jutsu_colors.send(session, shortfall)
            return

    import data_handsigns
    starting_fresh = session.pvp_target is None
    if data_handsigns.has_handsigns(jutsu_data) and combat._can_use_jutsu(player, jutsu_data, jutsu_key) and not has_silent_genjutsu(player):
        if starting_fresh:
            _wake_and_stand(session)
        combat.begin_pending_cast(session, jutsu_key, target_session, is_pvp=True, start_combat_on_resolve=starting_fresh)
    else:
        if starting_fresh:
            _wake_and_stand(session)
            combat.start_pvp_attack(session, target_session)
        if fan_direction:
            combat.use_jutsu_on_player(session, jutsu_key, target_session, fan_direction=fan_direction)
        else:
            combat.use_jutsu_on_player(session, jutsu_key, target_session)


def cmd_perform(session, args: List[str]) -> None:
    """Cast by full/partial name or an explicit one-word shortcut.

    Shortcuts work for every class; traditional full Taijutsu/Bukijutsu
    names still use their direct command path.
    """
    if not args:
        session.send("Perform what?")
        return
    lower_words = [w.lower() for w in args]
    if lower_words == ["reverse", "summoning", "jutsu"]:
        import reverse_summoning
        reverse_summoning.cast(session)
        return
    jutsu_key, consumed = data_jutsu.match_prefix(lower_words)
    if not jutsu_key:
        session.send("You don't know a jutsu by that name.")
        return
    jutsu = data_jutsu.JUTSU[jutsu_key]
    if (jutsu["class_requirement"] in BARE_NAME_JUTSU_CATEGORIES
            and lower_words[0] not in data_jutsu.SHORTCUT_JUTSU):
        jutsu_colors.send(session, f"{jutsu['display_name']} is a {jutsu['class_requirement'].capitalize()} technique -- just use its name directly, no 'perform' needed.")
        return
    cmd_use_jutsu(session, jutsu_key, args[consumed:])


WEEDS_DELAY_SECONDS = 6.0


def _find_villager(room_vnum: int):
    for mob in combat.mobs_in_room(room_vnum):
        if "villager" in mob.name.lower():
            return mob
    return None


def cmd_pullweeds(session, args: List[str]) -> None:
    """Pulls one bundle of weeds from a villager's garden -- feeds the
    'Weed the Garden' gather-type mission (missions.py), but isn't
    itself gated on having that mission active, matching how mining/
    lumberjacking are also an open economy rather than mission-locked.
    Always yields exactly 1 bundle (no rarity table -- this is a plain
    menial chore, not a skill-based catch). Takes WEEDS_DELAY_SECONDS,
    same delayed-action treatment as every other gather/craft/gamble
    action (session.start_timed_action)."""
    player = session.player
    if not _find_villager(player.room_vnum):
        session.send("There's no garden to pull weeds from here.")
        return
    if session.is_busy():
        session.send("You're already busy with something.")
        return

    def resolve() -> None:
        ok, reason = inventory.add_item(player.inventory, "A Bundle of Weeds")
        if not ok:
            session.send(f"You pull a bundle of weeds, but had nowhere to put it!")
            session.send(inventory.full_message(reason, "A Bundle of Weeds"))
            return
        session.send("You pull a bundle of weeds from the garden.")

    session.send("You crouch down and start pulling weeds...")
    session.start_timed_action("pullweeds", WEEDS_DELAY_SECONDS, resolve)


def cmd_deliver(session, args: List[str]) -> None:
    """Hands over every 'A Bundle of Weeds' the player is carrying (up
    to however many the active gather-type mission still needs) to a
    villager mob in the current room, advancing that mission's
    progress (missions.on_weeds_delivered) -- partial delivery across
    multiple trips works fine, since progress accumulates rather than
    requiring the full target_count in one go."""
    player = session.player
    villager = _find_villager(player.room_vnum)
    if not villager:
        session.send("There's no one here to deliver anything to.")
        return

    carried = sum(1 for item in player.inventory if item.lower() == "a bundle of weeds")
    if carried == 0:
        session.send("You aren't carrying any bundles of weeds to deliver.")
        return

    for _ in range(carried):
        player.inventory.remove(next(item for item in player.inventory if item.lower() == "a bundle of weeds"))

    session.send(f"You hand {villager.name} {carried} bundle(s) of weeds.")
    for message in missions.on_weeds_delivered(player, villager.template_vnum, carried):
        session.send(message)


def cmd_follow(session, args: List[str]) -> None:
    """Follow a nearby player even before joining their group."""
    current = getattr(session, "follow_target", None)
    if not args:
        if (current and getattr(current, "player", None)
                and getattr(getattr(current, "state", None), "name", "") == "PLAYING"):
            session.send(f"&GYou are following {current.player.name}. Type 'follow off' to stop.&x")
        elif getattr(session, "group", None) and session.group.leader is not session and session.follow_group_leader:
            session.send(f"&GYou are following {session.group.leader.player.name}. Type 'follow off' to stop.&x")
        else:
            session.send("You aren't following anyone. Type 'follow <player>' to follow them.")
        return
    choice = " ".join(args).strip().casefold()
    if choice in ("off", "stop", "none", "no"):
        if current or session.follow_group_leader:
            session.follow_target = None
            session.follow_group_leader = False
            session.send("&YYou stop following.&x")
        else:
            session.send("You aren't following anyone.")
        return
    if choice in ("leader", "on"):
        target = session.group.leader if session.group else None
        if target is None or target is session:
            session.send("You have no group leader to follow. Type 'follow <player>'.")
            return
    else:
        target = next(
            (s for s in session.active_sessions()
             if s is not session and s.player and s.player.name.casefold() == choice
             and getattr(getattr(s, "state", None), "name", "") == "PLAYING"),
            None,
        )
        if target is None and len(choice) >= 2:
            matches = [
                s for s in session.active_sessions()
                if s is not session and s.player
                and s.player.name.casefold().startswith(choice)
                and getattr(getattr(s, "state", None), "name", "") == "PLAYING"
            ]
            if len(matches) == 1:
                target = matches[0]
        if target is None:
            session.send("There's no available player here by that name.")
            return
    if (not getattr(target, "player", None)
            or getattr(getattr(target, "state", None), "name", "") != "PLAYING"):
        session.send("That player isn't available to follow.")
        return
    if (getattr(getattr(target, "player", None), "room_vnum", None)
            != session.player.room_vnum):
        session.send("You must be in the same room to begin following someone.")
        return
    if current is target or (
            session.group and session.group.leader is target and session.follow_group_leader):
        session.send(f"You are already following {target.player.name}.")
        return
    session.follow_target = target
    session.follow_group_leader = bool(session.group and session.group.leader is target)
    session.send(f"&GYou begin following {target.player.name}.&x")
    target.send(f"&G{session.player.name} begins following you.&x")


def cmd_group(session, args: List[str]) -> None:
    """Follow a player first, then the leader uses 'group all' to recruit.
    Groups share NPC kills and automatically assist one another in combat."""
    player = session.player

    if not args:
        if not session.group:
            session.send("You aren't in a group. Follow a player and have them type 'group all'.")
            return
        lines = [f"&WYour group (maximum {groups.GROUP_XP_LEVEL_RANGE} ninja-level spread for XP):&x"]
        for member in session.group.members:
            if not member.player:
                continue
            leader_tag = " &Y(Leader)&x" if member is session.group.leader else ""
            elsewhere = "" if member.player.room_vnum == player.room_vnum else " &D(elsewhere)&x"
            following = (" &C(Following)&x" if member is not session.group.leader
                         and (getattr(member, "follow_target", None) is session.group.leader
                              or getattr(member, "follow_group_leader", False)) else "")
            lines.append(
                f"  {member.player.name}{leader_tag} - "
                f"HP: {member.player.health}/{member.player.maximum_health}{elsewhere}{following}"
            )
        session.send("\n".join(lines))
        return

    sub = args[0].lower()

    if sub == "follow":
        cmd_follow(session, args[1:] or ["leader"])
        return

    if sub == "all":
        if session.group and session.group.leader is not session:
            session.send("Only the group leader can use 'group all'.")
            return
        followers = [
            s for s in session.active_sessions()
            if s is not session and s.player
            and getattr(s, "follow_target", None) is session
            and getattr(getattr(s, "state", None), "name", "") == "PLAYING"
            and s.player.room_vnum == player.room_vnum
        ]
        added = 0
        skipped = 0
        for follower in followers:
            if follower.group is session.group and session.group is not None:
                continue
            if follower.group is not None:
                skipped += 1
                follower.send("Leave your current group before joining another.")
                continue
            members = session.group.members if session.group else [session]
            if len(members) >= groups.MAX_GROUP_SIZE:
                skipped += 1
                follower.send("That group is full.")
                continue
            if not groups.enforce_join(follower, members):
                skipped += 1
                continue
            if not session.group:
                session.group = groups.Group(session)
            session.group.members.append(follower)
            follower.group = session.group
            follower.follow_group_leader = True
            added += 1
            for member in session.group.members:
                member.send(f"&G{follower.player.name} joins the group!&x")
        if not added:
            session.send("No new eligible followers in this room to group.")
        else:
            session.send(f"&GGrouped {added} follower(s).&x")
        if skipped:
            session.send(f"{skipped} follower(s) could not join.")
        return

    if sub == "leave":
        if not session.group:
            session.send("You aren't in a group.")
            return
        group = session.group
        groups.remove_member(group, session)
        session.group = None
        session.send("You leave the group.")
        for member in group.members:
            member.send(f"&D{player.name} has left the group.&x")
        return

    if sub == "kick":
        if len(args) < 2:
            session.send("Usage: group kick <player>")
            return
        if not session.group or session.group.leader is not session:
            session.send("Only the group leader can kick members.")
            return
        query = args[1].lower()
        target = next(
            (m for m in session.group.members if m is not session and query in m.player.name.lower()),
            None,
        )
        if not target:
            session.send("No one in your group matches that name.")
            return
        group = session.group
        groups.remove_member(group, target)
        target.group = None
        target.send(f"&D{player.name} has removed you from the group.&x")
        for member in group.members:
            member.send(f"&D{target.player.name} has been removed from the group.&x")
        return

    if sub == "disband":
        if not session.group or session.group.leader is not session:
            session.send("Only the group leader can disband the group.")
            return
        group = session.group
        for member in group.members:
            member.send("&DThe group has been disbanded.&x")
        groups.disband(group)
        return

    session.send("Usage: group [all|follow [on|off]|leave|kick <player>|disband]")


def cmd_team(session, args: List[str]) -> None:
    """The new, persistent Teams system (teams.py) -- genuinely
    separate from 'group' above (see teams.py's own module docstring
    for the full distinction). 'team' alone shows the roster; 'team
    create <name>' (Chunin+ only, not on disband cooldown) forms a
    new team with the creator as leader; 'team invite <player>'
    (leader only, target can be offline) + 'team accept' joins;
    'team leave'/'team disband' (leader only) break it apart, always
    starting the 24-hour rejoin cooldown for whoever's membership
    just ended, per confirmed design."""
    player = session.player

    if not args:
        team = teams.get_team(player.team_name)
        if not team:
            session.send("You aren't on a team. Try 'team create <name>' or wait for an invite.")
            return
        lines = [f"&WTeam {team['name']}:&x"]
        for member_name in team["members"]:
            leader_tag = " &Y(Leader)&x" if member_name == team["leader"] else ""
            online_session = next((s for s in session.active_sessions() if s.player and s.player.name == member_name), None)
            status = "&Gonline&x" if online_session else "&Doffline&x"
            lines.append(f"  {member_name}{leader_tag} - {status}")
        session.send("\n".join(lines))
        return

    sub = args[0].lower()

    if sub == "create":
        if len(args) < 2:
            session.send("Usage: team create <name>")
            return
        if player.team_name:
            session.send("You're already on a team -- leave it first.")
            return
        if teams.on_disband_cooldown(player):
            remaining = teams.disband_cooldown_remaining_seconds(player)
            hours = int(remaining // 3600)
            minutes = int((remaining % 3600) // 60)
            session.send(f"You must wait {hours}h {minutes}m after leaving a team before joining or creating another.")
            return
        if not teams.can_lead_team(player):
            session.send(f"Only {teams.MIN_LEADER_RANK.title()} rank or higher can lead a team.")
            return
        team_name = " ".join(args[1:])
        error = teams.create_team(player, team_name)
        if error:
            session.send(error)
            return
        session.send(f"You form Team {team_name}, with yourself as leader.")
        return

    if sub == "invite":
        if len(args) < 2:
            session.send("Usage: team invite <player>")
            return
        team = teams.get_team(player.team_name)
        if not team:
            session.send("You aren't on a team.")
            return
        if team["leader"] != player.name:
            session.send("Only the team leader can invite new members.")
            return
        if len(team["members"]) >= teams.MAX_TEAM_SIZE:
            session.send(f"Your team is already full ({teams.MAX_TEAM_SIZE} members max).")
            return

        target_query = args[1].lower()
        target_session = next(
            (s for s in session.active_sessions() if s.player and target_query in s.player.name.lower()),
            None,
        )
        if target_session:
            target_player = target_session.player
        else:
            target_player = storage.load_player(args[1].capitalize())
        if not target_player:
            session.send("There's no player by that name.")
            return
        if target_player.team_name:
            session.send(f"{target_player.name} is already on a team.")
            return

        target_player.pending_team_invite = team["name"]
        storage.save_player(target_player)
        if target_session:
            target_session.send(f"{player.name} invites you to join Team {team['name']}. Type 'team accept' to join.")
        session.send(f"You invite {target_player.name} to join Team {team['name']}.")
        return

    if sub == "accept":
        if not player.pending_team_invite:
            session.send("You don't have a pending team invite.")
            return
        team = teams.get_team(player.pending_team_invite)
        player.pending_team_invite = None
        if not team:
            session.send("That team no longer exists.")
            return
        if player.team_name:
            session.send("You're already on a team -- leave it first.")
            return
        if teams.on_disband_cooldown(player):
            remaining = teams.disband_cooldown_remaining_seconds(player)
            hours = int(remaining // 3600)
            minutes = int((remaining % 3600) // 60)
            session.send(f"You must wait {hours}h {minutes}m after leaving a team before joining another.")
            return
        error = teams.join_team(player, team["name"])
        if error:
            session.send(error)
            return
        session.send(f"You join Team {team['name']}.")
        for other_name in team["members"]:
            if other_name == player.name:
                continue
            other_session = next((s for s in session.active_sessions() if s.player and s.player.name == other_name), None)
            if other_session:
                other_session.send(f"{player.name} has joined Team {team['name']}.")
        return

    if sub == "leave":
        if not player.team_name:
            session.send("You aren't on a team.")
            return
        team_name = player.team_name
        teams.leave_team(player)
        session.send(f"You leave Team {team_name}. You must wait 24 hours before joining or creating another team.")
        return

    if sub == "disband":
        team = teams.get_team(player.team_name)
        if not team:
            session.send("You aren't on a team.")
            return
        if team["leader"] != player.name:
            session.send("Only the team leader can disband the team.")
            return
        team_name = team["name"]
        member_names = list(team["members"])
        for member_name in member_names:
            member_session = next((s for s in session.active_sessions() if s.player and s.player.name == member_name), None)
            if member_session and member_session is not session:
                member_session.player.team_name = None
                member_session.player.team_disband_cooldown_until = time.time() + teams.DISBAND_COOLDOWN_SECONDS
                member_session.send(f"&DTeam {team_name} has been disbanded.&x")
            elif not member_session:
                offline_player = storage.load_player(member_name)
                if offline_player:
                    offline_player.team_name = None
                    offline_player.team_disband_cooldown_until = time.time() + teams.DISBAND_COOLDOWN_SECONDS
                    storage.save_player(offline_player)
        player.team_name = None
        player.team_disband_cooldown_until = time.time() + teams.DISBAND_COOLDOWN_SECONDS
        del teams.TEAMS[team_name.lower()]
        teams._save()
        session.send(f"You disband Team {team_name}. Every member must wait 24 hours before joining or creating another team.")
        return

    session.send("Usage: team [create <name>|invite <player>|accept|leave|disband]")


def cmd_trade(session, args: List[str]) -> None:
    """Player-to-player trading (trade.py) -- per direct request
    ("Trade commands"). Confirmed design: an invite/accept flow to
    start (invite/accept by both participants), same room
    required for the ENTIRE negotiation (leaving cancels it entirely,
    enforced in cmd_move), full negotiation where each side stages
    their OWN offer (items + an optional ryo amount, never touching
    the other side's offer), and a genuine safety property -- ANY
    change to either side's offer after either side has confirmed
    resets BOTH confirmations, so a trade can never complete on terms
    neither side actually agreed to at the same moment."""
    player = session.player

    if not args:
        active_trade = session.trade
        if not active_trade:
            session.send("You aren't trading with anyone. Try 'trade <player>' to propose one.")
            return
        other = active_trade.other(session)
        my_offer = active_trade.my_offer(session)
        their_offer = active_trade.their_offer(session)
        lines = [f"&WTrading with {other.player.name}:&x"]
        lines.append(f"  Your offer: {', '.join(my_offer['items']) or '(nothing)'}" + (f" + {my_offer['ryo']} ryo" if my_offer["ryo"] else ""))
        lines.append(f"  Their offer: {', '.join(their_offer['items']) or '(nothing)'}" + (f" + {their_offer['ryo']} ryo" if their_offer["ryo"] else ""))
        lines.append(f"  You: {'confirmed' if active_trade.is_confirmed(session) else 'not confirmed'}")
        lines.append(f"  {other.player.name}: {'confirmed' if active_trade.is_confirmed(other) else 'not confirmed'}")
        session.send("\n".join(lines))
        return

    sub = args[0].lower()

    if sub not in ("add", "remove", "ryo", "confirm", "cancel"):
        # 'trade <player>' -- propose or accept, matching group's own invite/accept shape.
        if session.trade and session.trade.accepted:
            session.send("You're already trading with someone. 'trade cancel' first if you want to switch.")
            return
        query = " ".join(args).lower()
        target_session = next(
            (s for s in session.active_sessions() if s is not session and s.player
             and s.player.room_vnum == player.room_vnum and query in s.player.name.lower()),
            None,
        )
        if not target_session:
            session.send("There's nobody here by that name.")
            return
        if session.trade and session.trade.other(session) is target_session and not session.trade.accepted:
            # WE were the one invited -- this is the accept.
            session.trade.accepted = True
            session.send(f"You accept {target_session.player.name}'s trade offer.")
            target_session.send(f"{player.name} accepts your trade offer.")
            return
        if target_session.trade and target_session.trade.accepted:
            session.send(f"{target_session.player.name} is already trading with someone else.")
            return
        import trade as trade_module
        trade_module.start_trade(session, target_session)
        session.send(f"You propose a trade to {target_session.player.name}. They must 'trade {player.name.lower()}' to accept.")
        target_session.send(f"{player.name} wants to trade with you. Type 'trade {player.name.lower()}' to accept, or ignore to decline.")
        return

    active_trade = session.trade
    if not active_trade:
        session.send("You aren't trading with anyone.")
        return
    other = active_trade.other(session)

    if sub != "cancel" and not active_trade.accepted:
        session.send(f"{other.player.name} hasn't accepted your trade proposal yet.")
        return

    if sub == "cancel":
        import trade as trade_module
        trade_module.cancel_trade(active_trade)
        session.send("You cancel the trade.")
        other.send(f"{player.name} cancels the trade.")
        return

    if sub == "add":
        if len(args) < 2:
            session.send("Usage: trade add <item>")
            return
        item_query = " ".join(args[1:]).lower()
        match = next((item for item in player.inventory if item_query in item.lower()), None)
        if not match:
            session.send(f"You aren't carrying anything like '{item_query}'.")
            return
        if match.endswith(" [glued]"):
            session.send("That item is glued to you and cannot be traded.")
            return
        import crafted_provenance
        if (crafted_provenance.denied(match, player, session=session)
                or crafted_provenance.denied(match, other.player, session=other)):
            session.send(crafted_provenance.DENIED)
            return
        my_offer = active_trade.my_offer(session)
        if match in my_offer["items"]:
            session.send(f"{match} is already in your offer.")
            return
        my_offer["items"].append(match)
        active_trade.reset_confirmations()
        session.send(f"You add {match} to your offer.")
        other.send(f"{player.name} adds {match} to their offer. Any previous confirmations were reset.")
        return

    if sub == "remove":
        if len(args) < 2:
            session.send("Usage: trade remove <item>")
            return
        item_query = " ".join(args[1:]).lower()
        my_offer = active_trade.my_offer(session)
        match = next((item for item in my_offer["items"] if item_query in item.lower()), None)
        if not match:
            session.send(f"'{item_query}' isn't in your offer.")
            return
        my_offer["items"].remove(match)
        active_trade.reset_confirmations()
        session.send(f"You remove {match} from your offer.")
        other.send(f"{player.name} removes {match} from their offer. Any previous confirmations were reset.")
        return

    if sub == "ryo":
        if len(args) < 2 or not args[1].isdigit():
            session.send("Usage: trade ryo <amount>")
            return
        amount = int(args[1])
        if amount > player.ryo:
            session.send(f"You don't have {amount} ryo.")
            return
        my_offer = active_trade.my_offer(session)
        my_offer["ryo"] = amount
        active_trade.reset_confirmations()
        session.send(f"You set your ryo offer to {amount}.")
        other.send(f"{player.name} sets their ryo offer to {amount}. Any previous confirmations were reset.")
        return

    if sub == "confirm":
        active_trade.set_confirmed(session, True)
        session.send("You confirm the trade.")
        other.send(f"{player.name} confirms the trade.")
        if active_trade.both_confirmed():
            import trade as trade_module
            try:
                trade_module.complete_trade(active_trade)
            except ValueError as exc:
                active_trade.reset_confirmations()
                session.send(str(exc))
                other.send("Trade blocked: a crafted item cannot be received by an alt.")
                return
            session.send("&GThe trade is complete!&x")
            other.send("&GThe trade is complete!&x")
        return


def cmd_duel(session, args: List[str]) -> None:
    """Formal 1v1 duels (duel.py + duel_arena.py) -- per direct
    request/design ("What you described but it transfers combatants
    to an 10 room arena with several biomes. When combat ends they
    are returned to the room they came from."). Confirmed design: an
    invite/accept flow (matching group/team/trade's own pattern,
    including the same accepted-flag fix already proven necessary for
    trade -- a pending, not-yet-accepted proposal must be told apart
    from an active one, since both sessions' .duel is set the instant
    a proposal is made). The instant BOTH sides have accepted, both
    combatants are teleported straight into the Arena's two starting
    rooms -- no separate "ready" step. Actually ending the duel
    happens entirely in combat.handle_player_defeat's own new duel
    branch (checked there, not here), since the confirmed design is
    that only a genuine defeat ends a duel."""
    player = session.player

    if not args:
        if session.duel and session.duel.accepted:
            other = session.duel.other(session)
            session.send(f"You are dueling {other.player.name} in the arena.")
        elif session.duel:
            session.send("You have a pending duel proposal.")
        else:
            session.send("You aren't in a duel. Try 'duel <player>' to propose one.")
        return

    if args[0].lower() == "cancel":
        if not session.duel:
            session.send("You aren't in a duel.")
            return
        other = session.duel.other(session)
        if session.duel.accepted:
            import duel as duel_module
            duel_module.end_duel(session.duel, session)
        else:
            import duel as duel_module
            duel_module.cancel_duel(session.duel)
            session.send("You cancel the duel proposal.")
            other.send(f"{player.name} cancels the duel proposal.")
        return

    if session.duel and session.duel.accepted:
        session.send("You're already dueling someone.")
        return
    query = " ".join(args).lower()
    target_session = next(
        (s for s in session.active_sessions() if s is not session and s.player
         and s.player.room_vnum == player.room_vnum and query in s.player.name.lower()),
        None,
    )
    if not target_session:
        session.send("There's nobody here by that name.")
        return

    if session.duel and session.duel.other(session) is target_session and not session.duel.accepted:
        # WE were the one invited -- this is the accept.
        import duel as duel_module
        session.duel.accepted = True
        duel_module.begin_duel(session.duel)
        session.send(f"You accept {target_session.player.name}'s duel! You're pulled into the arena.")
        target_session.send(f"{player.name} accepts your duel! You're both pulled into the arena.")
        return

    if target_session.duel and target_session.duel.accepted:
        session.send(f"{target_session.player.name} is already dueling someone else.")
        return
    import duel as duel_module
    duel_module.start_duel(session, target_session)
    session.send(f"You challenge {target_session.player.name} to a duel. They must 'duel {player.name.lower()}' to accept.")
    target_session.send(f"{player.name} challenges you to a duel! Type 'duel {player.name.lower()}' to accept, or ignore to decline.")


def cmd_chunin_exam(session, args: List[str]) -> None:
    """Enters (or re-enters) the Chunin Exam -- see chunin_exam.py's
    own docstring for the full design. Grants one random scroll type
    on first entry only; re-entering after leaving (e.g. via a
    hospital respawn from a PvP loss) does NOT re-roll or top up a
    scroll already lost, since that would undermine the entire point
    of the theft mechanic -- the exam is meant to be survived, not
    retried for free."""
    player = session.player
    if player.village_rank != "genin":
        session.send("The Chunin Exam is only open to Genin.")
        return
    if not chunin_exam.qualifies_for_exam(player):
        session.send(
            f"You aren't ready yet. The Chunin Exam requires at least level "
            f"{chunin_exam.MIN_LEVEL} and {chunin_exam.MIN_COMPLETED_MISSIONS} completed mission(s)."
        )
        return

    if player.in_chunin_exam:
        if player.room_vnum == chunin_exam.FINAL_ARENA_VNUM:
            if player.chunin_final_ready:
                session.send("&RYour final Chunin opponent is waiting. Attack your shadow to begin!&x")
            else:
                chunin_exam.show_hokage_speech(session)
            return
        session.send("You're already inside the Forest of Death -- finish the trial without leaving.")
        return

    player.in_chunin_exam = True
    starting_scroll = random.choice(chunin_exam.SCROLLS)
    player.inventory.append(starting_scroll)
    player.room_vnum = chunin_exam.ENTRANCE_VNUM
    session.send(
        f"&YYou pass through the gate into the Forest of Death.&x\n"
        f"You've been given {rarity_colored_name(starting_scroll)} -- you'll need to find "
        f"{'a Hell Scroll' if starting_scroll == chunin_exam.HEAVEN_SCROLL else 'a Heaven Scroll'} "
        f"to pass. Defeat animals and rival ninja to find the other scroll. "
        "Then reach the central tower."
    )


def cmd_leave_exam(session, args: List[str]) -> None:
    """No free exam exit: explicit confirmation forfeits every scroll."""
    player = session.player
    if not player.in_chunin_exam:
        session.send("You aren't currently taking the Chunin Exam.")
        return
    if not args or args[0].lower() not in {"confirm", "forfeit"}:
        session.send(
            "&RLeaving the Forest of Death means FAILING the Chunin Exam. "
            "You must repeat it from the beginning. To surrender, type 'leave confirm'.&x"
        )
        return
    chunin_exam.reset_exam(player)
    session.combat_target = None
    player.room_vnum = VILLAGES[player.village]["starting_room_vnum"]
    storage.save_player(player)
    session.send("&RYou forfeit the Chunin Exam, surrender both scrolls and return to your village. Your next attempt starts fresh.&x")


def cmd_submit_scrolls(session, args: List[str]) -> None:
    """Use the tower proctor to begin the sealed 1v1 at VNUM 670."""
    if chunin_exam.start_final_trial(session):
        cmd_look(session, [])


def cmd_missions(session, args: List[str]) -> None:
    player = session.player
    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    if village_rooms and player.room_vnum == village_rooms["board"]:
        all_missions = missions.missions_for_village(player.village)
        first_words = [m["title"].split()[0].lower() for m in all_missions]
        lines = ["&WMissions posted here:&x"]
        for m in all_missions:
            already_active = any(am["mission_id"] == m["mission_id"] for am in player.active_missions)
            remaining = missions.cooldown_remaining(player, m["mission_id"])
            if already_active:
                status = "already accepted -- check 'mission info' for progress"
            elif remaining > 0:
                status = f"on cooldown, ready in {missions._format_duration(remaining)}"
            else:
                first_word = m["title"].split()[0].lower()
                if first_words.count(first_word) > 1:
                    # Ambiguous with another mission here (e.g. several
                    # "Hunt the X" missions) -- suggest the rank instead,
                    # which is always unique per village.
                    status = f"type 'accept {m['rank'].lower()}' to take it"
                else:
                    status = f"type 'accept {first_word}' to take it"
            lines.append(f"  &Y{m['title']}&x ({m['rank']}): {m['description']}\n    ({status})")
        lines.append("\n&D(Request a level-appropriate Mission-tagged hunt with 'mission request <rank>'.)&x")
        session.send("\n".join(lines))
        return

    session.send(missions.mission_info(player))


def cmd_accept(session, args: List[str]) -> None:
    player = session.player
    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    if not village_rooms or player.room_vnum != village_rooms["board"]:
        session.send("There is nothing to accept here.")
        return
    available = missions.missions_for_village(player.village)
    if not args:
        if len(available) == 1:
            session.send(missions.accept_mission(player, player.village, available[0]["mission_id"]))
            return
        session.send(
            "Accept which mission? " + ", ".join(m["title"] for m in available)
        )
        return
    query = " ".join(args).lower()
    matched = next(
        (m for m in available if query in m["title"].lower() or query in m["rank"].lower()),
        None,
    )
    if not matched:
        session.send(f"No mission here matches '{' '.join(args)}'.")
        return
    session.send(missions.accept_mission(player, player.village, matched["mission_id"]))


def cmd_mission(session, args: List[str]) -> None:
    """Mission request, info and fail; enforce persistent 30-minute limits."""
    player = session.player
    before = [(e.get("mission_id"), e.get("expires_at"))
              for e in player.active_missions]
    expired = missions.expire_missions(player)
    for message in expired:
        session.send(message)
    after = [(e.get("mission_id"), e.get("expires_at"))
             for e in player.active_missions]
    if before != after:
        storage.save_player(player)
    if not args:
        session.send("Usage: mission request <d|c|b|a|s> | mission info | mission fail [rank]")
        return
    action, rest = args[0].lower(), args[1:]
    if action == "request":
        if not rest:
            session.send("Request which rank? Usage: mission request <d|c|b|a|s>")
            return
        result = missions.request_mission(player, " ".join(rest))
        session.send(result)
        if result.startswith("Mission requested:"):
            storage.save_player(player)
    elif action in ("info", "status"):
        session.send(missions.mission_info(player))
    elif action == "fail":
        result = missions.fail_mission(player, " ".join(rest))
        session.send(result)
        if result.startswith("&RMission failed:"):
            storage.save_player(player)
    else:
        session.send("Usage: mission request <d|c|b|a|s> | mission info | mission fail [rank]")


def cmd_request(session, args: List[str]) -> None:
    """'request <rank>' -- requests a dynamic C/B/A/S mission, per
    direct request ("instead of a static board you request what
    mission difficulty you want and it will select from a pool of
    mobs within your level range dependent on what you picked").
    Deliberately works from anywhere, not gated to standing at a
    village mission board -- unlike D-Rank (still 'accept' at the
    board, unchanged), the whole point of this system is moving away
    from that board-bound model. See missions.request_mission for the
    actual selection/gating logic."""
    if not args:
        session.send("Request which rank? Usage: request <c-rank|b-rank|a-rank|s-rank>")
        return
    rank = " ".join(args)
    cmd_mission(session, ["request", rank])



# --- Training / practice --------------------------------------------

STAT_TRAIN_SECONDS = 15
# A failure costs time, not a point. Higher attributes take more patience.
STAT_TRAIN_BASE_SUCCESS = 85


def _stat_training_drill(attribute: str, current: int) -> tuple:
    """Narrative inspired by practical shinobi training in Naruto."""
    if attribute == "chakra_control":
        if current < 40:
            return ("walk up a tree trunk without using your hands",
                    "Your chakra holds firm and you climb several steps higher!",
                    "Your chakra slips from the bark and you slide back down.")
        if current < 60:
            return ("balance a steady stream of chakra to walk across water",
                    "You cross the rippling surface without sinking!",
                    "Your flow falters and you splash into the water.")
        return ("shape a spinning stream of chakra inside a water balloon",
                "You sustain the spinning chakra until the balloon bursts!",
                "Your concentration slips and the spinning chakra unravels.")
    return {
        "strength": ("strike a reinforced wooden training post",
                     "Your controlled strikes drive deep marks into the wood!",
                     "Your stance buckles before the final strike."),
        "dexterity": ("dodge swinging logs while catching thrown kunai",
                      "You slip through the obstacles and catch the last kunai!",
                      "A swinging log clips your shoulder and breaks your rhythm."),
        "constitution": ("complete an exhausting weighted endurance circuit",
                         "You finish the entire circuit without collapsing!",
                         "Your breathing gives out before the last lap."),
        "intelligence": ("memorize and repeat a complex sequence of hand signs",
                         "You perform every hand sign in the correct sequence!",
                         "You lose track of a crucial hand sign."),
        "wisdom": ("hold a leaf steady on your forehead while meditating",
                   "Your mind settles and the leaf remains perfectly still!",
                   "A stray thought breaks your concentration and the leaf falls."),
        "luck": ("navigate a shifting obstacle course with unpredictable traps",
                 "You improvise perfectly through every changing obstacle!",
                 "One unexpected trap throws off your timing."),
        "perception": ("locate hidden targets while blindfolded",
                       "You sense and identify each hidden target!",
                       "You mistake a decoy for the real target."),
        "willpower": ("hold your focus against a trainer's genjutsu distractions",
                      "You maintain your resolve and break the distraction!",
                      "The illusion interrupts your concentration."),
    }[attribute]


def cmd_train(session, args: List[str]) -> None:
    """SWR-style timed stat training: physically attend a live trainer mob."""
    player = session.player
    typed = " ".join(args).strip().lower()
    attr = TRAIN_ATTRIBUTE_NAMES.get(typed, typed.replace(" ", "_"))
    if attr not in TRAINABLE_ATTRIBUTES:
        session.send("Usage: train <attribute> (str, wis, con, int, dex, luk, per, wil, cc)")
        return
    if player.training_points <= 0:
        session.send("You have no training points left.")
        return
    current = getattr(player, attr)
    if current >= config.MAX_ATTRIBUTE_VALUE:
        session.send(f"Your {attr.replace('_', ' ')} is already at its maximum ({config.MAX_ATTRIBUTE_VALUE}).")
        return
    if (getattr(session, "combat_target", None) is not None
            or getattr(session, "pvp_target", None) is not None
            or getattr(session, "pending_cast", None) is not None):
        session.send("You cannot train while fighting or casting a jutsu.")
        return
    if player.position != "standing":
        session.send("Stand up before beginning your shinobi training.")
        return
    if session.is_busy():
        session.send("You are already busy with something. Finish it before training.")
        return
    trainer = next((mob for mob in combat.mobs_in_room(player.room_vnum)
                    if mob.health > 0 and combat.is_stat_trainer(mob)), None)
    if trainer is None:
        session.send("You must find a shinobi stat trainer mob in the same room. Training cannot be done anywhere else.")
        return

    start_room = player.room_vnum
    action, success_text, failure_text = _stat_training_drill(attr, current)
    label = attr.replace("_", " ")
    session.send(f"&C{trainer.name.capitalize()} begins your {label} lesson. "
                 f"You {action}. The exercise takes {STAT_TRAIN_SECONDS} seconds.&x")
    import room_actions
    room_actions.emit(session, f"{player.name} begins a {label} exercise under {trainer.name}'s supervision.")

    def complete_training():
        # Resolve only once the actual 15 seconds have passed. A player
        # cannot leave, enter combat, or lose their trainer to finish remotely.
        if (session.player is not player or player.room_vnum != start_room
                or getattr(session, "combat_target", None) is not None
                or getattr(session, "pvp_target", None) is not None
                or getattr(session, "pending_cast", None) is not None
                or trainer not in combat.mobs_in_room(start_room)
                or trainer.health <= 0 or not combat.is_stat_trainer(trainer)):
            session.send("&YYour lesson was interrupted. No training point was spent.&x")
            return
        if player.training_points <= 0 or getattr(player, attr) >= config.MAX_ATTRIBUTE_VALUE:
            session.send("&YYou can no longer complete this stat lesson. No training point was spent.&x")
            return
        # Stat difficulty rises gradually to the existing 75-point cap.
        chance = max(50, STAT_TRAIN_BASE_SUCCESS - max(0, getattr(player, attr) - 10) // 2)
        if random.randint(1, 100) > chance:
            session.send(f"&Y{failure_text} The trainer tells you to try again. "
                         "No training point was spent.&x")
            room_actions.emit(session, f"{player.name} fails a {label} training exercise.")
            return

        before = getattr(player, attr)
        setattr(player, attr, before + 1)
        player.training_points -= 1
        session.send(f"&G{success_text} Your {label} increases to {before + 1}! "
                     f"Training points remaining: {player.training_points}.&x")
        room_actions.emit(session, f"{player.name} completes a {label} training exercise.")
        if attr == "chakra_control":
            # Preserve the already-established permanent +10 Chakra bonus.
            player.maximum_chakra += 10
            session.send(f"&CYour chakra reserves permanently increase by 10 -- "
                         f"maximum Chakra is now {player.maximum_chakra}.&x")

    session.start_timed_action(
        "stat training", STAT_TRAIN_SECONDS, complete_training,
        flavor_schedule=[(7, f"&DYou continue to {action}, following the trainer's guidance...&x")],
    )


PRACTICE_POINTS_PER_TRAINING_POINT = 5  # confirmed directly: "turn in 5 practice points for 1 training point"


def cmd_convert_practice(session, args: List[str]) -> None:
    """'convert practice' -- per direct request/confirmation (Section
    132): turns 5 unused practice points into 1 training point,
    letting a player accelerate stat training with practice points
    they aren't otherwise using. Confirmed directly: only usable
    while standing near a real teacher mob (any teacher counts, since
    this isn't tied to a specific skill's own class category, matching
    how a General Skills entry already works for anyone), and
    repeatable as many times as the player has spare practice points."""
    player = session.player
    if not any(combat.is_teacher(mob) for mob in combat.mobs_in_room(player.room_vnum)):
        session.send("You need to find a teacher to convert practice points into training.")
        return
    if player.practice_points < PRACTICE_POINTS_PER_TRAINING_POINT:
        session.send(f"You need at least {PRACTICE_POINTS_PER_TRAINING_POINT} practice points to convert (you have {player.practice_points}).")
        return
    player.practice_points -= PRACTICE_POINTS_PER_TRAINING_POINT
    player.training_points += 1
    session.send(
        f"&WThe teacher exchanges {PRACTICE_POINTS_PER_TRAINING_POINT} of your practice points for 1 training point. "
        f"You now have {player.practice_points} practice point(s) and {player.training_points} training point(s).&x"
    )


def _practice_gain(player) -> int:
    """Percentage points gained per practice attempt, scaled by
    Intelligence -- higher Int means faster proficiency growth.
    Floor of 1 so practicing is never a no-op even at very low Int."""
    return max(1, player.intelligence // 2)


def proficiency_level_name(pct: int) -> str:
    """Maps a raw percentage back to the familiar tier name for flavor
    text (score sheet, skills list) without that name being the actual
    stored value anymore."""
    if pct >= 150:
        return "signature mastered"
    if pct >= 100:
        return "mastered"
    if pct >= 80:
        return "expert"
    if pct >= 60:
        return "skilled"
    if pct >= 40:
        return "familiar"
    if pct >= 20:
        return "novice"
    return "untrained"


def proficiency_color(pct: int) -> str:
    """A genuine continuous 256-color gradient for a skill proficiency
    percentage, per direct request ("create a better prac list with
    color based on skill% used the 256 color scale not just basics").
    Smoothly interpolates through the real xterm 256-color RGB cube
    (index = 16 + 36r + 6g + b, r/g/b in 0-5) from red at 0% through
    orange and yellow to green at 100%, rather than a small, fixed set
    of threshold buckets like resource_color/proficiency_level_name
    use -- every distinct percentage from 0 to 100 gets its own
    genuinely distinct shade along the ramp, not just 6 flat blocks.

    The ramp itself: red (5,0,0) -> orange (5,2,0) -> yellow (5,5,0)
    -> green (0,5,0), moving through 3 linear segments so the color
    genuinely reads as "red early, yellow in the middle, green late"
    rather than a flat rainbow smear."""
    pct = max(0, min(100, pct))
    if pct <= 33:
        # Red -> orange: green channel ramps 0 -> 2
        r, g, b = 5, round(pct / 33 * 2), 0
    elif pct <= 66:
        # Orange -> yellow: green channel ramps 2 -> 5
        r, g, b = 5, 2 + round((pct - 33) / 33 * 3), 0
    else:
        # Yellow -> green: red channel ramps 5 -> 0
        r, g, b = 5 - round((pct - 66) / 34 * 5), 5, 0
    xterm = 16 + 36 * r + 6 * g + b
    return f"&[{xterm}]"


def _is_weapon_skill_name(skill_name: str) -> bool:
    """Whether skill_name is one of the weapon proficiencies
    (data_weapons.WEAPON_TYPES' own "skill" display names -- Kunai,
    Sword, Shuriken, Blunt Weapon, Polearm, Exotic Weapon), as
    opposed to a jutsu. Needed because "usage" means something
    genuinely different for each once past the practice cap --
    confirmed design: any attack made while a weapon type is
    equipped counts for its own skill, while a jutsu specifically
    needs to land a real hit."""
    return skill_name in {info["skill"] for info in data_weapons.WEAPON_TYPES.values()}


def cmd_practice(session, args: List[str]) -> None:
    player = session.player
    if not args:
        session.send("Practice what?")
        return
    query = " ".join(args).lower()
    match = next((s for s in player.learned_skills if query in s.lower()), None)
    if not match:
        session.send("You haven't learned that skill or jutsu.")
        return
    attack_requirement = next(
        (required_class for name, _, required_class in data_jutsu.MULTI_ATTACK_SKILLS
         if name == match), None)
    if attack_requirement and player.primary_class != attack_requirement:
        session.send(f"{match} is only available to {attack_requirement.title()} users.")
        return
    if data_passives.is_passive(match):
        session.send(f"{match} is a passive skill -- it improves automatically through combat experience, not practice.")
        return
    import signature_moves
    if match == signature_moves.selected_name(player) and player.skill_proficiencies.get(match, 0) >= 100:
        session.send(f"{match} is your signature move: raise it from 100% to 150% through successful use, not teacher practice.")
        return
    teacher = _find_matching_teacher(player.room_vnum, match)
    if not teacher:
        category = _category_for_skill(match)
        if category == "General Skills":
            session.send(f"You need to find a teacher to practice {match}.")
        else:
            session.send(f"You need to find a {category} teacher to practice {match}.")
        return
    if player.practice_points <= 0:
        session.send("You have no practice points left.")
        return
    current = player.skill_proficiencies.get(match, 0)
    practice_cap = data_jutsu.PRACTICE_CAP_PERCENT.get(match, data_jutsu.DEFAULT_PRACTICE_CAP_PERCENT)
    if current >= practice_cap:
        if practice_cap < 100:
            if match == "Handsigns":
                usage_hint = "actually performing hand signs to cast a jutsu"
            elif _is_weapon_skill_name(match):
                usage_hint = "actually attacking with it equipped, in combat"
            else:
                usage_hint = "actually landing a hit with it in combat"
            session.send(f"{match} can only be practiced up to {practice_cap}% -- {usage_hint} is the only way to raise it further.")
        else:
            session.send(f"{match} is already mastered.")
        return
    gain = _practice_gain(player)
    new_pct = min(practice_cap, current + gain)
    player.skill_proficiencies[match] = new_pct
    import skill_training
    skill_training.mark_practiced(player, match)
    experience_before = player.experience
    xp_messages = leveling.grant_experience(player, (new_pct - current) * 10)
    earned_xp = max(0, player.experience - experience_before)
    player.practice_points -= 1
    player.practice_sessions_used += 1
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} practices {match} with a teacher.")
    session.send(
        f"You practice {match} (+{new_pct - current}% from your Intelligence). "
        f"Proficiency is now {new_pct}% ({proficiency_level_name(new_pct)})."
    )
    if earned_xp:
        session.send(f"&G+{earned_xp} experience from skill improvement.&x")
    for message in xp_messages:
        session.send(message)


def cmd_signature(session, args: List[str]) -> None:
    """Pick a mastered active move; changing choice removes old overmastery."""
    import signature_moves
    player = session.player
    current = signature_moves.selected_name(player)
    if not args:
        status = (f"{current} ({player.skill_proficiencies.get(current, 0)}/150%)"
                  if current else "none")
        ready = sorted(j["display_name"] for j in data_jutsu.JUTSU.values()
                       if signature_moves.eligible(j) and j["display_name"] in player.learned_skills
                       and player.skill_proficiencies.get(j["display_name"], 0) >= 100)
        session.send(f"Signature move: {status}. The +25% damage/effect-duration bonus starts at 150%.\n"
                     f"Eligible mastered moves: {', '.join(ready) or 'none'}\n"
                     "Use 'signature <move>' to choose or 'signature clear' to remove it. "
                     "Switching returns the old move to 100%.")
        return
    query = " ".join(args).strip().lower()
    if query == "clear":
        if not current:
            session.send("You have no signature move selected.")
            return
        player.skill_proficiencies[current] = min(100, player.skill_proficiencies.get(current, 0))
        player.signature_move = ""
        session.send(f"{current} is no longer your signature move; its proficiency returns to 100%.")
        return
    eligible = [j for j in data_jutsu.JUTSU.values()
                if signature_moves.eligible(j) and j["display_name"] in player.learned_skills]
    matches = [j for j in eligible if j["display_name"].lower() == query]
    if not matches:
        matches = [j for j in eligible if query in j["display_name"].lower()]
    if len(matches) != 1:
        session.send("Choose one eligible learned move by name. " +
                     ("Matches: " + ", ".join(j["display_name"] for j in matches)
                      if matches else "Use 'signature' to see your eligible mastered moves."))
        return
    name = matches[0]["display_name"]
    if player.skill_proficiencies.get(name, 0) < 100:
        session.send(f"{name} must reach 100% proficiency before you can select it.")
        return
    if name == current:
        session.send(f"{name} is already your signature move ({player.skill_proficiencies.get(name, 0)}/150%).")
        return
    if current:
        player.skill_proficiencies[current] = min(100, player.skill_proficiencies.get(current, 0))
    player.signature_move = name
    session.send(f"{name} is now your signature move. Raise it from 100% to 150% "
                 "by successfully using it, not by teacher practice. The +25% bonus activates at 150%.")


def _skill_unlock_level(skill_name: str) -> Optional[int]:
    """The level a given entry in player.learned_skills was actually
    obtained at, per direct request ("make skills list the level that
    that jutsu is obtained before the name"). Checked across every
    real source of a level-gated skill, in order: an actual jutsu
    (data_jutsu.JUTSU, keyed by the lowercased display name), a
    weapon multi-attack skill (data_jutsu.MULTI_ATTACK_SKILLS, e.g.
    "Third Attack"), Handsigns and Examine (their own dedicated
    level constants), a weapon skill (data_weapons.WEAPON_TYPES, e.g.
    "Kunai", "Sword" -- genuinely obtainable at ANY character level
    by wielding a matching weapon, not level-gated at all, so shown
    as level 1 as a consistent, honest standard rather than left
    blank), and finally a universal starting skill
    (data_jutsu.UNIVERSAL_STARTING_SKILLS) -- granted at character
    creation with no real level gate beyond that, so shown as level 1
    for a consistent, honest display rather than left blank. Returns
    None only for something with no real "unlock level" concept at
    all (there currently isn't one, but this stays defensive)."""
    jutsu = data_jutsu.JUTSU.get(skill_name.lower().replace(":", ""))
    if jutsu:
        return jutsu["level_requirement"]
    for name, level_req, _required_class in data_jutsu.MULTI_ATTACK_SKILLS:
        if name == skill_name:
            return level_req
    import data_handsigns
    if skill_name == "Handsigns":
        return data_handsigns.HANDSIGNS_MIN_LEVEL
    if skill_name == "Examine":
        return data_jutsu.APPRAISAL_LEVEL_REQUIREMENT
    if skill_name == "Scan":
        return SCAN_LEVEL
    if skill_name == "Chakra Charge":
        return data_jutsu.CHAKRA_CHARGE_LEVEL
    import data_weapons
    if skill_name in {info["skill"] for info in data_weapons.WEAPON_TYPES.values()}:
        return 1
    if skill_name in data_jutsu.UNIVERSAL_STARTING_SKILLS:
        return 1
    return None


# Browsable jutsu catalog. All entries come from the active jutsu registry;
# class/level data is never duplicated in a hand-maintained command list.
JUTSU_CATALOG_CLASSES = ("ninjutsu", "taijutsu", "genjutsu", "bukijutsu")


def _catalog_jutsu_visible(player, key, info) -> bool:
    """Permanent character access, independent of temporary combat conditions."""
    known = info["display_name"].lower() in {name.lower() for name in player.learned_skills}
    if (info.get("secret") or info.get("scroll_only")) and not known:
        return False
    for attribute, required in (("clan", info.get("required_clan")),
                                ("village", info.get("required_village"))):
        if required and getattr(player, attribute, "").lower() != required:
            return False
    revealed = {nature for nature, shown in (
        (player.chakra_nature, player.chakra_nature_revealed),
        (player.chakra_nature_secondary, player.chakra_nature_secondary_revealed),
        (player.chakra_nature_tertiary, player.chakra_nature_tertiary_revealed),
    ) if shown and nature}
    element = info.get("element", "none")
    if element != "none" and element not in revealed:
        return False
    gate = info.get("kkg_gate")
    if gate:
        import data_kekkei_genkai
        if gate in data_kekkei_genkai.ELEMENTAL_RELEASE_NAMES:
            return data_kekkei_genkai.has_elemental_release(player, gate)
        if gate == "byakugan":
            return hyuga.eligible(player) and player.bloodline_potential >= info.get("hyuga_potential", 0)
        if gate == "mangekyo_technique":
            eye = info.get("mangekyo_roster_key", key)
            return (player.bloodline_id == "sharingan" and player.bloodline_mangekyo
                    and eye in (player.mangekyo_eye_1, player.mangekyo_eye_2)
                    and eye in player.mangekyo_eyes_used)
        if gate in {"six_paths_indra", "six_paths_ashura"}:
            import six_paths
            return six_paths.eligible(player, gate.removeprefix("six_paths_"))
        return False
    if info.get("jutsu_type") == "beast_bomb" and not player.jinchuriki_beast_key:
        return False
    return (known or player.copied_jutsu_key == key
            or info.get("class_requirement") in {player.primary_class.lower(), "general"})


def build_jutsu_catalog_lines(player, immortal: bool = False) -> List[str]:
    """Show obtainable class jutsu and abilities actually unlocked elsewhere."""
    import data_classes
    if not immortal and player.primary_class.lower() not in data_classes.CLASSES:
        return ["You do not have a recognized combat class."]
    classes = tuple(c for c in JUTSU_CATALOG_CLASSES if c in data_classes.CLASSES)

    known = set(player.learned_skills)
    shortcuts = {info["display_name"]: data_jutsu.JUTSU_SHORTCUTS[key]
                 for key, info in data_jutsu.JUTSU.items()
                 if key in data_jutsu.JUTSU_SHORTCUTS}
    sections = [(name, data_classes.CLASSES[name]["display_name"])
                for name in classes]
    sections.append(("general", "General Jutsu"))
    lines = ["&WJutsu Catalog&x &D(learned and future techniques; "
             "level indicates minimum level, not automatic access)&x"]
    for category, title in sections:
        # General moves are shared by all classes. The class registry also
        # includes scroll- and release-specific entries, not just regular
        # leveling unlocks.
        entries = sorted(
            (info for key, info in data_jutsu.JUTSU.items()
             if info.get("class_requirement") == category
             and (immortal or _catalog_jutsu_visible(player, key, info))),
            key=lambda info: (info.get("level_requirement", 1),
                              info["display_name"].casefold()),
        )
        if not entries and not immortal and category not in {player.primary_class.lower(), "general"}:
            continue
        lines.append("")
        lines.append(_prac_header(title))
        if not entries:
            lines.append("  &D(No listed techniques)&x")
            continue
        color = PRAC_CATEGORY_COLOR.get(title, "&W")
        for info in entries:
            name = info["display_name"]
            level = info.get("level_requirement", 1)
            is_known = name in known
            status = "&GLearned&x" if is_known else ("&DLocked&x" if player.level < level else "&YNot learned&x")
            conditions = []
            if info.get("scroll_only"):
                conditions.append("Scroll")
            if info.get("kkg_gate"):
                conditions.append("Release")
            if info.get("jutsu_id", "").startswith("six_paths_"):
                conditions.append("Six Paths")
            extra = f" &D[{', '.join(conditions)}]&x" if conditions else ""
            shortcut = f"  &DShort: {shortcuts[name]}&x" if name in shortcuts else ""
            lines.append(f"  &WLv {level:>3}&x  {color}{name}&x  {status}{extra}{shortcut}")
        lines.append(f"&D{len(entries)} {title.lower()} technique(s)&x")
    lines.append("")
    lines.append("&DType a listed shortcut directly. Use 'jutsu shorts' for learned shortcuts, "
                 "'skills' to see only your learned skills, "
                 "or 'help <jutsu name>' for details.&x")
    return lines


def cmd_jutsu(session, args: List[str]) -> None:
    """Show the full catalog or compact shortcuts for learned jutsu."""
    mode = args[0].lower() if len(args) == 1 else ""
    if mode not in {"all", "shorts", "shortcuts"}:
        session.send("Usage: jutsu all | jutsu shorts  (catalog or learned one-word shortcuts)")
        return
    immortal = bool(session.account and
                    session.account.staff_level in WHO_LEADER_STAFF_LEVELS)
    if mode == "all":
        lines = build_jutsu_catalog_lines(session.player, immortal=immortal)
    else:
        known = set(session.player.learned_skills)
        lines = ["&WJutsu Shortcuts&x",
                 "&DType a shortcut directly, or use per <shortcut>. "
                 "Add a target or on/off after it as usual.&x", ""]
        for key, info in sorted(data_jutsu.JUTSU.items(),
                                key=lambda item: item[1]["display_name"].casefold()):
            if info["display_name"] in known and (immortal or _catalog_jutsu_visible(session.player, key, info)):
                lines.append(f"  &C{data_jutsu.JUTSU_SHORTCUTS[key]:<9}&x {info['display_name']}")
        if len(lines) == 3:
            lines.append("You have not learned any jutsu yet.")
    output = "\n".join(lines)
    if callable(getattr(session, "send_paginated", None)):
        session.send_paginated(output)
    else:
        session.send(output)


def cmd_skills(session, args: List[str]) -> None:
    player = session.player
    if args:
        if len(args) == 1 and args[0].lower() == "all":
            cmd_jutsu(session, ["all"])
        else:
            session.send("Usage: skills [all]")
        return
    immortal = bool(session.account and session.account.staff_level in WHO_LEADER_STAFF_LEVELS)
    jutsu_by_name = {info["display_name"].lower(): (key, info)
                     for key, info in data_jutsu.JUTSU.items()}
    lines = ["Skills and jutsu:"]
    ordered_skills = sorted(
        player.learned_skills,
        key=lambda name: (_skill_unlock_level(name) is None, _skill_unlock_level(name) or 0),
    )
    for skill in ordered_skills:
        spec = jutsu_by_name.get(skill.lower())
        if spec and not immortal and not _catalog_jutsu_visible(player, *spec):
            continue
        if skill.lower() == "sharingan genjutsu":
            continue  # old saved characters may still contain the retired skill
        level = _skill_unlock_level(skill)
        prefix = f"[Level {level}] " if level is not None else ""
        color = PRAC_CATEGORY_COLOR[_category_for_skill(skill)]
        lines.append(f"  {prefix}{color}{skill}&x")
    session.send("\n".join(lines))


def cmd_examine(session, args: List[str]) -> None:
    """Inspect carried or equipped items, showing item-bound enchantments
    only in this report and improving Examine proficiency through use.
    Rarity is deliberately hidden everywhere.
    """
    player = session.player
    if not args:
        session.send("Examine what?")
        return

    query = " ".join(args).lower()
    import scroll_writing
    candidates = list(player.inventory) + list(player.equipment.values())
    match = find_indexed_item(query, candidates)
    if not match:
        # Written notes lying on the ground are readable too, without
        # letting ordinary ground-item appraisal bypass inventory rules.
        room = WORLD.get(player.room_vnum)
        found_on_ground = find_indexed_item(query, room.ground_items) if room else None
        if found_on_ground:
            ground_proto = _find_object_prototype_by_name(found_on_ground)
            if (ground_proto and ground_proto.get("scroll_message_writable")
                    and scroll_writing.inscription(found_on_ground)):
                match = found_on_ground
    if not match:
        session.send(f"You aren't carrying or wearing anything like '{query}'.")
        return

    proto = _find_object_prototype_by_name(match)
    note = (scroll_writing.inscription(match)
            if proto and proto.get("scroll_message_writable") else None)
    written_lines = []
    if note:
        written_lines = [f"&YWritten on this scroll by {note.get('author', 'Unknown')}:&x",
                         note.get("text", "")]

    if "Examine" not in player.learned_skills:
        if written_lines:
            session.send("\n".join([f"You examine {rarity_colored_name(match)}."] + written_lines))
            return
        session.send(
            f"You don't know how to examine items that closely yet -- "
            f"Examine unlocks at level {data_jutsu.APPRAISAL_LEVEL_REQUIREMENT}."
        )
        return

    import skill_training
    if skill_training.needs_first_practice(player, "Examine"):
        if written_lines:
            session.send("\n".join([f"You examine {rarity_colored_name(match)}."] + written_lines))
            return
        session.send("Practice Examine with a teacher at least once before using it.")
        return
    appraisal_pct = player.skill_proficiencies.get("Examine", 0)
    import ninja_arts

    def complete_examination():
        session.send("\n".join(lines))
        combat.grow_skill_from_usage(player, "Examine", session=session)

    lines = [f"You examine {rarity_colored_name(match)}."]
    lines.extend(written_lines)
    element = ninja_arts.element_of(match)
    art = ninja_arts.property_of(match)
    if element:
        lines.append(f"&WElemental Enchantment:&x {element.title()} chakra")
        lines.append("&DElemental benefits require a Bukijutsu wielder with that chakra nature.&x")
    elif art:
        lines.append(f"&WWeapon Enchantment:&x {art.replace('_', ' ').title()}")
    if match.casefold().endswith(" [glued]"):
        lines.append("&WBinding:&x Glued (cannot drop or trade)")
    import pill_crafting
    pill_info = pill_crafting.pill_data(match)
    if pill_info:
        lines.append(f"&WPill Level:&x {pill_info['level']}")
        if pill_info.get("resources"):
            lines.append(f"&WHealing:&x {pill_info['amount']} {', '.join(pill_info['resources'])} over {pill_info['heal_duration']} seconds")
        if pill_info.get("cures"):
            lines.append(f"&WCures:&x {', '.join(pill_info['cures'])}")

    if appraisal_pct < 40:
        lines.append("&D(Train Examine further to learn more about this item.)&x")
        complete_examination()
        return

    if proto:
        lines.append(f"&WItem Type:&x {proto.get('item_type', 'misc').capitalize()}")
        wear_loc = proto.get("wear_loc")
        if wear_loc:
            lines.append(f"&WWear Location:&x {wear_loc.replace('_', ' ').title()}")

    stat_lines = []
    if proto and proto.get("stat_bonuses"):
        for key, value in proto["stat_bonuses"].items():
            stat_lines.append(f"  {key.replace('_', ' ').title()}: {value:+d}")
    crafted_bonus = parse_crafted_hitroll_bonus(match)
    if crafted_bonus and not (proto and proto.get("stat_bonuses", {}).get("hitroll")):
        stat_lines.append(f"  Hitroll: +{crafted_bonus}")
    if stat_lines:
        lines.append("&WStat Bonuses:&x")
        lines.extend(stat_lines)

    if proto:
        import gem_inlays
        import elemental_counters
        if proto.get("gem_inlay"):
            gem = proto["gem_inlay"]
            lines.append(f"&WGem Inlay:&x {gem.title()} (permanent, 1 slot)")
            lines.append(f"&WAdded Gem Bonuses:&x Hitroll +{gem_inlays.strength(gem)}, Damageroll +{gem_inlays.strength(gem)}")
            original = proto.get("stat_bonuses", {})
            if proto.get("item_type") == "weapon":
                lines.append(
                    f"&WWeapon Total:&x Hitroll +{original.get('hitroll', 0) + gem_inlays.strength(gem)}, "
                    f"Damageroll +{original.get('damroll', 0) + gem_inlays.strength(gem)} "
                    "(original forge stats + gem)"
                )
            else:
                lines.append("&WArmor:&x Original defense and all other forged stats are unchanged.")
            element = gem_inlays.ELEMENT_GEMS.get(gem)
            if element:
                lines.append(f"&WElemental Gem:&x +{gem_inlays.ELEMENTAL_JUTSU_BONUS_PERCENT}% {element.title()} jutsu damage; "
                             f"{gem_inlays.ELEMENTAL_COUNTER_RESIST_PERCENT}% {elemental_counters.counters(element).title()} resistance")
        if proto.get("weapon_type"):
            lines.append(f"&WWeapon Type:&x {data_weapons.display_name(proto['weapon_type'])}")
        if proto.get("gem_bonuses"):
            bonuses = proto["gem_bonuses"]
            lines.append(f"&WGem Inlay Potential:&x Hitroll +{bonuses.get('hitroll', 0)}, Damageroll +{bonuses.get('damroll', 0)}")
        lines.append(f"&WCost:&x {proto.get('cost', 0):,} ryo   &WWeight:&x {proto.get('weight', 1)}")

    if appraisal_pct < 80:
        lines.append("&D(Train Examine further to see full set details.)&x")
        complete_examination()
        return

    if proto and proto.get("set_vnums"):
        required = ", ".join(str(v) for v in proto["set_vnums"])
        lines.append(
            f"&WSet Bonus:&x requires vnums {required} also worn -- "
            f"+{proto.get('set_bonus_percent', 25)}% to combat stats when complete"
        )
    elif proto:
        lines.append("&WSet Bonus:&x not part of a set")

    complete_examination()


# --- prac: categorized skill list (Sections 8-9, 12) --------------------

PRAC_CATEGORY_ORDER = ["Ninjutsu", "Taijutsu", "Genjutsu", "Bukijutsu", "KKGK", "General Skills"]


def _categorize_skill(skill_name: str) -> str:
    lname = skill_name.lower()
    for jutsu in data_jutsu.JUTSU.values():
        if jutsu["display_name"].lower() == lname:
            return "KKGK" if jutsu.get("kkg_gate") else jutsu["class_requirement"].capitalize()
    if skill_name in sword_styles.STYLES:
        return "Bukijutsu"
    if skill_name in {name for name, _, required_class in data_jutsu.MULTI_ATTACK_SKILLS
                      if required_class == "bukijutsu"}:
        return "Bukijutsu"
    if lname in {"sharingan", "mangekyo sharingan", "izanagi"}:
        return "KKGK"
    if lname == "punch":
        return "Taijutsu"
    return "General Skills"


def _skill_catalog_for_category(category: str) -> list:
    """Every skill that belongs to `category`, regardless of whether
    the player has learned it yet -- (name, level_requirement) pairs.
    The single source of truth cmd_prac uses to show the FULL catalog,
    not just what a player already knows."""
    entries = []
    if category in ("Ninjutsu", "Taijutsu", "Genjutsu", "Bukijutsu"):
        class_key = category.lower()
        for jutsu in data_jutsu.JUTSU.values():
            if jutsu["class_requirement"] == class_key and not jutsu.get("kkg_gate"):
                entries.append((jutsu["display_name"], jutsu["level_requirement"]))
        if category == "Bukijutsu":
            entries.extend((name, info["level"]) for name, info in sword_styles.STYLES.items())
            entries.extend((name, level_req)
                           for name, level_req, required_class in data_jutsu.MULTI_ATTACK_SKILLS
                           if required_class == "bukijutsu")
    elif category == "KKGK":
        # This overrides only PRAC presentation. Jutsu retain their
        # original combat class, chakra costs, and bloodline unlocks.
        for jutsu in data_jutsu.JUTSU.values():
            if jutsu.get("kkg_gate"):
                entries.append((jutsu["display_name"], jutsu["level_requirement"]))
        # The Sharingan toggle and Izanagi command are separate from
        # the JUTSU table, but old characters may track them as skills.
        entries.extend((("Sharingan", 25), ("Mangekyo Sharingan", 25), ("Izanagi", None)))
    elif category == "General Skills":
        # Weapon skills folded in here per explicit request (previously
        # their own "Weapon Skills" category). Not level-gated --
        # learned by wielding a matching weapon type, so there's no
        # meaningful "unlocks at level N" for these.
        for weapon_info in data_weapons.WEAPON_TYPES.values():
            entries.append((weapon_info["skill"], None))
        entries.append(("Strong Fist Style", 1))
        entries.append(("Examine", data_jutsu.APPRAISAL_LEVEL_REQUIREMENT))
        entries.append(("Scan", SCAN_LEVEL))
        import data_handsigns
        entries.append(("Handsigns", data_handsigns.HANDSIGNS_MIN_LEVEL))
        entries.append(("Anki", 1))  # confirmed directly: no real level requirement at all, shown as level 1 like every other level-1-effectively skill (matches how UNIVERSAL_STARTING_SKILLS is handled elsewhere)
        entries.append(("Chakra Charge", data_jutsu.CHAKRA_CHARGE_LEVEL))
        # Second Attack is universal (level 25 Bukijutsu; level 100
        # all other classes). Every later attack is Bukijutsu-only.
        for skill_name, level_req, required_class in data_jutsu.MULTI_ATTACK_SKILLS:
            if required_class is None:
                entries.append((skill_name, level_req))
        # Every real class-agnostic jutsu (class_requirement="general",
        # e.g. Track, Sealing Jutsu, Release Jutsu, Tailed Beast Bomb --
        # any class can learn these) genuinely belongs here too. Caught
        # by direct user report: "many jutsu dont show on prac list
        # every single jutsu learned by a player should be there" --
        # these 4 were never added when they were originally built,
        # so a player who'd learned any of them never saw it on 'prac'
        # at all, despite it being real.
        for jutsu in data_jutsu.JUTSU.values():
            if jutsu["class_requirement"] == "general" and not jutsu.get("kkg_gate"):
                entries.append((jutsu["display_name"], jutsu["level_requirement"]))
    return entries


def _category_for_skill(skill_name: str) -> str:
    """The PRAC_CATEGORY_ORDER category a given skill belongs to, per
    direct request ("make the skills command colored based on
    class... so genjutsu skills will be a color and so on"). Built
    directly on _skill_catalog_for_category, the existing single
    source of truth cmd_prac already uses for this exact
    classification, rather than duplicating its logic. Defaults to
    "General Skills" for anything not found in any of the 4 class
    catalogs (matches how General Skills already behaves as the
    catch-all category in cmd_prac)."""
    for category in PRAC_CATEGORY_ORDER:
        for name, _level_req in _skill_catalog_for_category(category):
            if name == skill_name:
                return category
    return "General Skills"


PRAC_CATEGORY_COLOR = {
    "Ninjutsu": "&B",
    "Taijutsu": "&R",
    "Genjutsu": "&M",
    "Bukijutsu": "&Y",
    "KKGK": "&[135]",  # unique purple for bloodline and ocular powers
    "General Skills": "&C",  # confirmed: a distinct color from the 4 class colors, changed from gray per direct request
    "General Jutsu": "&C",  # same shared-category color in the jutsu catalog
}


def _prac_header(category: str, width: int = 74) -> str:
    label = f"[ {category} ]"
    pad = max(0, width - len(label))
    left = pad // 2
    right = pad - left
    color = PRAC_CATEGORY_COLOR.get(category, "&W")
    return f"&D{'-' * left}&x{color}{label}&x&D{'-' * right}&x"


def _prac_entry(name: str, pct: int, width: int = 45, signature: bool = False) -> str:
    """A single colored skill entry, name and percentage colored by
    proficiency_color's own 256-color gradient. Padded to `width`
    against the VISIBLE text (computed before color codes are added)
    so the existing 2-column layout still lines up -- color codes are
    invisible characters that would otherwise throw off a plain
    len()-based right-justify."""
    visible = f"{name}{' [Signature]' if signature else ''}  {pct}%"
    pad = max(0, width - len(visible))
    color = proficiency_color(pct)
    return " " * pad + f"{color}{visible}&x"


def cmd_prac(session, args: List[str]) -> None:
    if args:
        cmd_practice(session, args)
        return

    player = session.player
    lines = []
    for category in PRAC_CATEGORY_ORDER:
        lines.append(_prac_header(category))
        catalog = _skill_catalog_for_category(category)
        entries = []
        for name, level_req in catalog:
            if name in player.learned_skills and (
                    category != "Bukijutsu" or player.primary_class == "bukijutsu"):
                pct = player.skill_proficiencies.get(name, 0)
                entries.append(_prac_entry(name, pct, signature=name == getattr(player, "signature_move", "")))
        for i in range(0, len(entries), 2):
            pair = entries[i:i + 2]
            row = pair[0] + "  "
            if len(pair) == 2:
                row += pair[1]
            lines.append(row)

    lines.append(f"You have {player.practice_points} practice session(s) remaining.")
    import skill_training
    if any(skill_training.needs_first_practice(player, skill) for skill in player.learned_skills):
        lines.append("&YUntrained skills must be practiced once with a teacher before use.&x")
    session.send("\n".join(lines))


def cmd_clan(session, args: List[str]) -> None:
    player = session.player
    if not args:
        current = data_clans.display_name(player.clan)
        session.send(
            f"Your clan: {current}\n"
            "Usage: clan join <name>  (choose a clan from your village)\n"
            f"Clans of your village:\n" + data_clans.clan_names_display(player.village)
        )
        return
    if args[0].lower() != "join" or len(args) < 2:
        session.send("Usage: clan join <name>")
        return
    key = " ".join(args[1:]).lower()
    village_clans = data_clans.clans_for_village(player.village)
    if key not in village_clans:
        session.send(
            f"'{' '.join(args[1:])}' is not a clan of your village. Available:\n"
            + data_clans.clan_names_display(player.village)
        )
        return
    player.clan = key
    session.send(f"You are now affiliated with the {data_clans.display_name(key)} clan.")


# --- Shops ----------------------------------------------------------------

def _own_kage_chamber(player) -> bool:
    village_rooms = content._VILLAGE_ROOMS.get(player.village)
    return bool(village_rooms) and player.room_vnum == village_rooms["kage"]


def _find_shopkeeper(room_vnum: int):
    for mob in combat.mobs_in_room(room_vnum):
        if combat.is_shopkeeper(mob):
            return mob
    return None


def _find_gambler(room_vnum: int):
    for mob in combat.mobs_in_room(room_vnum):
        if combat.is_gambler(mob):
            return mob
    return None


def _categorize_underlying_class(skill_name: str) -> str:
    if skill_name in sword_styles.STYLES or skill_name in {
            name for name, _, required_class in data_jutsu.MULTI_ATTACK_SKILLS
            if required_class == "bukijutsu"}:
        return "Bukijutsu"
    for jutsu in data_jutsu.JUTSU.values():
        if jutsu["display_name"].lower() == skill_name.lower():
            name = jutsu["class_requirement"].capitalize()
            return "General Skills" if name == "General" else name
    return "General Skills"


def _find_matching_teacher(room_vnum: int, skill_name: str):
    """The first teacher-flagged mob in the room genuinely able to
    teach `skill_name`, or None if no such teacher is present. Per
    direct confirmation: a teacher can only teach skills matching
    their own class (Ninjutsu/Taijutsu/Genjutsu/Bukijutsu); any
    teacher works for a "General Skills" entry, since those aren't
    tied to a class at all."""
    # KKGK is a list/category only, not a fifth combat class. Keep
    # existing teacher eligibility based on the jutsu's underlying
    # class_requirement so this update cannot lock out practiced eyes.
    category = _categorize_underlying_class(skill_name)
    for mob in combat.mobs_in_room(room_vnum):
        if not combat.is_teacher(mob):
            continue
        if category == "General Skills" or combat.teacher_class(mob) == category.lower():
            return mob
    return None


def cmd_list(session, args: List[str]) -> None:
    player = session.player
    if _own_kage_chamber(player):
        lines = [f"&W{kage.kage_title(player.village)} offers these village-wide perks:&x"]
        for key, info in village_perks.PERK_TYPES.items():
            lines.append(f"  {info['display_name']} ({key}) - {info['cost']} mission point(s)")
        lines.append("&D(Perks are global -- they apply to every player of your village, not just you.)&x")
        active = village_perks.active_perks_display(player.village)
        if active:
            lines.append("&GCurrently active:&x " + "; ".join(active))
        lines.append("")
        lines.append(f"&W{kage.kage_title(player.village)} also offers these legendary items:&x")
        owned_names = {item.lower() for item in list(player.inventory) + [slot for slot in player.equipment.values() if slot]}
        for key, data in legendary_items.LEGENDARY_ITEMS.items():
            proto = olc.OBJECT_TEMPLATES.get(data["vnum"])
            item_name = proto["short_desc"] if proto else data["short_desc"]
            already_owned = item_name.lower() in owned_names
            status = "&D(already owned)&x" if already_owned else f"{data['cost_mission_points']:,} mission point(s)"
            level_text = f" (level {proto['level']})" if proto and proto.get("level", 0) > 0 else ""
            lines.append(f"  {rarity_colored_name(item_name)} - {status}{level_text}")
        lines.append("&D('examine' one to see its full stats.)&x")
        session.send("\n".join(lines))
        return

    shopkeeper = _find_shopkeeper(player.room_vnum)
    if shopkeeper and shopkeeper.player_shop_owner:
        lines = [f"&W{shopkeeper.name.capitalize()} offers for sale:&x"]
        stock = playershops.stock_for_display(shopkeeper)
        priced_any = False
        for entry in stock:
            if entry["price"] is None:
                continue
            priced_any = True
            proto = playershops.stock_prototype(entry)
            level_text = f" (level {proto['level']})" if proto and proto.get("level", 0) > 0 else ""
            lines.append(f"  {rarity_colored_name(entry['item_name'])} - {entry['price']:,} ryo{level_text}")
        if not priced_any:
            lines.append("  (nothing in stock right now)")
        session.send("\n".join(lines))
        return

    if shopkeeper:
        shop_items = combat.mob_shop_items(shopkeeper)
        buys_categories = combat.mob_shop_buys_categories(shopkeeper)
        lines = [f"&W{shopkeeper.name.capitalize()} offers for sale:&x"]
        for obj_vnum in shop_items:
            obj = olc.OBJECT_TEMPLATES.get(obj_vnum)
            if obj:
                level_text = f" (level {obj['level']})" if obj.get("level", 0) > 0 else ""
                lines.append(f"  {rarity_colored_name(obj['short_desc'])} - {obj['cost']} ryo{level_text}")
        if not shop_items:
            lines.append("  (nothing in stock right now)")
        if buys_categories:
            lines.append(f"&D(Only buys {', '.join(buys_categories)} items.)&x")
        else:
            lines.append("&D(Buys any item, but at a lower price than a specialty shop.)&x")
        session.send("\n".join(lines))
        return

    shop = content.SHOPS.get(player.room_vnum)
    if not shop:
        session.send("There is nothing to list here.")
        return
    shop_info = data_shops.SHOP_TYPES[shop["type"]]
    lines = [f"&W{shop_info['display_name']} -- for sale:&x"]
    for item in shop["items"]:
        proto = _find_object_prototype_by_name(item["name"])
        level_text = f" (level {proto['level']})" if proto and proto.get("level", 0) > 0 else ""
        lines.append(f"  {rarity_colored_name(item['name'])} - {item['price']} ryo{level_text}")
    if shop["type"] == "general":
        lines.append("&D(Buys any item, but at a lower price than a specialty shop.)&x")
    else:
        categories = ", ".join(sorted(data_shops.SHOP_TYPES[shop["type"]]["allowed_sell_categories"]))
        lines.append(f"&D(Only buys {categories} items.)&x")
    session.send("\n".join(lines))


def cmd_buy(session, args: List[str]) -> None:
    player = session.player

    if args and args[0].lower() != "all" and not args[0].isdigit() and "apartment" in " ".join(args).lower():
        current_room = WORLD.get(player.room_vnum)
        if not current_room or not current_room.apartment:
            session.send("You can only buy an apartment while standing inside one that's available.")
            return
        if current_room.owner is not None:
            session.send("This apartment is already owned. Look for a vacant one.")
            return
        if player.apartment_room_vnum is not None:
            session.send("You already own an apartment. Only one per player.")
            return
        if player.ryo < config.APARTMENT_COST_RYO:
            session.send(f"An apartment costs {config.APARTMENT_COST_RYO:,} ryo -- you have {player.ryo:,}.")
            return
        player.ryo -= config.APARTMENT_COST_RYO
        current_room.owner = player.name
        player.apartment_room_vnum = current_room.vnum
        session.send(
            f"You pay {config.APARTMENT_COST_RYO:,} ryo and receive the deed to {current_room.name}. "
            f"It's yours -- type 'recall' anytime to return home."
        )
        return

    if args and args[0].lower() == "room":
        if player.apartment_room_vnum is None:
            session.send("You need to own an apartment first -- try 'buy apartment'.")
            return
        if player.room_vnum != player.apartment_room_vnum:
            session.send("New rooms must be built from your main apartment room, not from another room.")
            return
        current_room = WORLD.get(player.room_vnum)
        if not current_room or current_room.owner != player.name:
            session.send("Something's wrong with your apartment's deed -- contact a builder.")
            return
        if len(args) != 3:
            session.send(
                f"Usage: buy room <type> <direction>\n"
                f"Types: {', '.join(apartments.APARTMENT_ROOM_TYPES)}"
            )
            return
        room_type = args[1].lower()
        direction = world.normalize_direction(args[2])
        if room_type not in apartments.APARTMENT_ROOM_TYPES:
            session.send(f"'{args[1]}' isn't a room type. Choose one of: {', '.join(apartments.APARTMENT_ROOM_TYPES)}")
            return
        if not direction:
            session.send(f"'{args[2]}' isn't a direction.")
            return
        if room_type in player.apartment_expansions:
            session.send(f"You already have a {room_type} -- only one of each type.")
            return
        if direction in current_room.exits:
            session.send(f"There's already an exit to the {direction} from here.")
            return
        new_vnum = apartments.expansion_room_vnum(player.apartment_room_vnum, room_type)
        existing = WORLD.get(new_vnum)
        if existing is not None:
            # Earlier versions left disconnected placeholders after a sale.
            if existing.owner == player.name and existing.apartment_room_type == apartments.EMPTY_ROOM_TYPE:
                apartments.delete_expansion_room(player, room_type)
            else:
                session.send(f"Room VNUM {new_vnum} is already occupied. Contact a builder.")
                return
        cost = apartments.expansion_cost(len(player.apartment_expansions))
        if player.ryo < cost:
            session.send(f"A {room_type} costs {cost:,} ryo -- you have {player.ryo:,}.")
            return

        player.ryo -= cost
        new_room = world.Room(
            new_vnum, f"{player.name}'s {room_type.capitalize()}",
            apartments.ROOM_TYPE_DESCRIPTIONS[room_type],
        )
        new_room.apartment = True
        new_room.owner = player.name
        new_room.safe = True
        WORLD.add_room(new_room)
        apartments.setup_expansion_room(new_room, room_type)
        WORLD.link(current_room.vnum, direction, new_vnum)
        if room_type == "storage":
            new_room.ground_items = player.storage_room_items
        player.apartment_expansions[room_type] = {
            "direction": direction, "cost": cost, "parent_vnum": player.apartment_room_vnum,
        }
        storage.save_player(player)
        import world_autosave
        world_autosave.mark_dirty()
        session.send(
            f"You pay {cost:,} ryo and build a {room_type} to the {direction}. "
            f"{apartments.ROOM_TYPE_DESCRIPTIONS[room_type]}"
        )
        return

    if args and args[0].lower() == "shop":
        current_room = WORLD.get(player.room_vnum)
        if not current_room or not current_room.player_shop:
            session.send("You can only buy a shop while standing inside a vacant one along Main Street.")
            return
        if current_room.owner is not None:
            session.send("This shop is already claimed. Look for a vacant one.")
            return
        if player.shop_room_vnum is not None:
            session.send("You already own a shop. Only one per player.")
            return
        if player.ryo < config.PLAYER_SHOP_COST_RYO:
            session.send(f"A shop costs {config.PLAYER_SHOP_COST_RYO:,} ryo -- you have {player.ryo:,}.")
            return

        player.ryo -= config.PLAYER_SHOP_COST_RYO
        current_room.owner = player.name
        player.shop_room_vnum = current_room.vnum
        shopkeeper = combat.spawn_mob(playershops.SHOPKEEPER_TEMPLATE_VNUM, current_room.vnum)
        shopkeeper.player_shop_owner = player.name
        shopkeeper.name = f"{player.name}'s shopkeeper"
        session.send(
            f"You pay {config.PLAYER_SHOP_COST_RYO:,} ryo and claim {current_room.name}. "
            f"Give items to your shopkeeper (see 'help give') and use 'price' to set what they sell for."
        )
        return

    # Bulk purchases require an explicit item query. Property purchases,
    # mission-point rewards and perks remain one-at-a-time commands.
    if args and (args[0].lower() == "all" or
                 (args[0].isdigit() and len(args) >= 2)):
        _buy_multiple(session, args)
        return

    if _own_kage_chamber(player):
        if not args:
            session.send("Buy what? Try 'list' to see available perks and legendary items.")
            return
        query = " ".join(args).lower()

        legendary_key, legendary_data = legendary_items.find_by_query(query)
        if not legendary_key:
            legendary_key = next(
                (key for key, data in legendary_items.LEGENDARY_ITEMS.items()
                 if (proto := olc.OBJECT_TEMPLATES.get(data["vnum"]))
                 and query in proto["short_desc"].lower()), None)
            if legendary_key:
                legendary_data = legendary_items.LEGENDARY_ITEMS[legendary_key]
        if legendary_key:
            vnum = legendary_data["vnum"]
            cost = legendary_data["cost_mission_points"]
            proto = olc.OBJECT_TEMPLATES.get(vnum)
            item_name = proto["short_desc"] if proto else legendary_data["short_desc"]
            level_error = playershops.purchase_level_error(
                player, proto, item_name)
            if level_error:
                session.send(level_error)
                return
            already_owned = any(
                item.lower() == item_name.lower()
                for item in list(player.inventory) + [slot for slot in player.equipment.values() if slot]
            )
            if already_owned:
                session.send(f"You already own {rarity_colored_name(item_name)} -- there's only one to a customer.")
                return
            if player.mission_points < cost:
                session.send(f"You need {cost:,} mission point(s) for that -- you have {player.mission_points:,}.")
                return
            ok, reason = inventory.add_item(player.inventory, item_name)
            if not ok:
                session.send(inventory.full_message(reason, item_name))
                return
            player.mission_points -= cost
            session.send(
                f"You spend {cost:,} mission point(s). {kage.kage_title(player.village)} presents you with "
                f"{rarity_colored_name(item_name)}!"
            )
            return

        perk_key = next((key for key in village_perks.PERK_TYPES if query in key), None)
        if not perk_key:
            session.send("That isn't a perk or legendary item your Kage offers. Try 'list'.")
            return
        info = village_perks.PERK_TYPES[perk_key]
        if player.mission_points < info["cost"]:
            session.send(f"You need {info['cost']} mission point(s) for that -- you have {player.mission_points}.")
            return
        player.mission_points -= info["cost"]
        village_perks.purchase(player.village, perk_key)
        minutes = village_perks.duration_seconds(perk_key) // 60
        session.send(
            f"You spend {info['cost']} mission point(s). {kage.kage_title(player.village)} grants the village "
            f"&Y{info['display_name']}&x perk for {minutes} minutes!"
        )
        session.broadcast_village(
            player.village,
            f"&Y[{info['display_name']} is now active for the village for {minutes} minutes, "
            f"purchased by {player.name}!]&x",
            exclude_self=True,
        )
        return

    shopkeeper = _find_shopkeeper(player.room_vnum)
    if shopkeeper and shopkeeper.player_shop_owner:
        if not args:
            session.send("Buy what?")
            return
        ok, result, price = playershops.buy_from_shop(shopkeeper, player, " ".join(args).lower())
        if not ok:
            session.send(result)
            return
        session.send(f"You buy {rarity_colored_name(result)} for {price:,} ryo.")
        _fire_item_trigger(session, result, "get")
        return

    if shopkeeper:
        if not args:
            session.send("Buy what?")
            return
        query = " ".join(args).lower()
        obj_vnum = next(
            (v for v in combat.mob_shop_items(shopkeeper)
             if v in olc.OBJECT_TEMPLATES and query in olc.OBJECT_TEMPLATES[v]["short_desc"].lower()),
            None,
        )
        if obj_vnum is None:
            session.send(f"{shopkeeper.name.capitalize()} doesn't sell that.")
            return
        obj = olc.OBJECT_TEMPLATES[obj_vnum]
        level_error = playershops.purchase_level_error(player, obj, obj["short_desc"])
        if level_error:
            session.send(level_error)
            return
        if player.ryo < obj["cost"]:
            session.send("You can't afford that.")
            return
        import crafted_provenance
        if crafted_provenance.denied(obj["short_desc"], player, session=session):
            session.send(crafted_provenance.DENIED)
            return
        ok, reason = inventory.add_item(player.inventory, obj["short_desc"])
        if not ok:
            session.send(inventory.full_message(reason, obj["short_desc"]))
            return
        player.ryo -= obj["cost"]
        session.send(f"You buy {rarity_colored_name(obj['short_desc'])} for {obj['cost']} ryo.")
        _fire_item_trigger(session, obj["short_desc"], "get")
        return

    shop = content.SHOPS.get(player.room_vnum)
    if not shop:
        session.send("There is nothing to buy here.")
        return
    if not args:
        session.send("Buy what?")
        return
    query = " ".join(args).lower()
    match = next((item for item in shop["items"] if query in item["name"].lower()), None)
    if not match:
        session.send("They don't sell that here.")
        return
    level_error = playershops.purchase_level_error(
        player, _find_object_prototype_by_name(match["name"]), match["name"])
    if level_error:
        session.send(level_error)
        return
    if player.ryo < match["price"]:
        session.send("You can't afford that.")
        return
    import crafted_provenance
    if crafted_provenance.denied(match["name"], player, session=session):
        session.send(crafted_provenance.DENIED)
        return
    ok, reason = inventory.add_item(player.inventory, match["name"])
    if not ok:
        session.send(inventory.full_message(reason, match["name"]))
        return
    player.ryo -= match["price"]
    session.send(f"You buy {rarity_colored_name(match['name'])} for {match['price']} ryo.")
    _fire_item_trigger(session, match["name"], "get")



def _buy_multiple(session, args: List[str]) -> None:
    """Buy as many copies of a named item as possible or a fixed quantity.

    'buy all sardine' is bounded by actual stock in player shops and by
    Ryo/inventory stack limits in NPC shops. 'buy 3 sardine' buys up to 3.
    Never treat a bare 'buy all' as permission to buy the whole shop.
    """
    player = session.player
    query = " ".join(args[1:]).strip().lower()
    if not query:
        session.send("Usage: buy all <item>  |  buy <number> <item>")
        return
    unlimited = args[0].lower() == "all"
    limit = None if unlimited else int(args[0])
    if limit is not None and limit < 1:
        session.send("Enter a positive number of items to buy.")
        return
    if _own_kage_chamber(player):
        session.send("Kage rewards and village perks must be bought individually.")
        return

    shopkeeper = _find_shopkeeper(player.room_vnum)
    shop = None if shopkeeper else content.SHOPS.get(player.room_vnum)
    if not shopkeeper and not shop:
        session.send("There is nothing to buy here.")
        return

    bought = []
    total_ryo = 0
    stop_reason = None

    if shopkeeper and shopkeeper.player_shop_owner:
        # Real, individually stocked player shop items can sell out.
        stock = [
            entry for entry in playershops.stock_for_display(shopkeeper)
            if entry["price"] is not None and _item_matches(query, entry["item_name"])
        ]
        if not stock:
            session.send(f"{shopkeeper.name.capitalize()} doesn't sell that.")
            return
        count = len(stock) if unlimited else min(limit, len(stock))
        for _ in range(count):
            ok, result, price = playershops.buy_from_shop(shopkeeper, player, query)
            if not ok:
                stop_reason = result
                break
            bought.append(result)
            total_ryo += price
            _fire_item_trigger(session, result, "get")
        if not unlimited and count < limit and not stop_reason:
            stop_reason = "The shop has no more of that item in stock."

    else:
        if shopkeeper:
            obj_vnum = next((
                vnum for vnum in combat.mob_shop_items(shopkeeper)
                if vnum in olc.OBJECT_TEMPLATES
                and _item_matches(query, olc.OBJECT_TEMPLATES[vnum]["short_desc"])
            ), None)
            if obj_vnum is None:
                session.send(f"{shopkeeper.name.capitalize()} doesn't sell that.")
                return
            obj = olc.OBJECT_TEMPLATES[obj_vnum]
            name, cost, proto = obj["short_desc"], obj["cost"], obj
        else:
            entry = next((
                item for item in shop["items"]
                if _item_matches(query, item["name"])
            ), None)
            if entry is None:
                session.send("They don't sell that here.")
                return
            name, cost = entry["name"], entry["price"]
            proto = _find_object_prototype_by_name(name)

        level_error = playershops.purchase_level_error(player, proto, name)
        if level_error:
            session.send(level_error)
            return
        # NPC stores have unlimited stock, but inventory stacks hold at
        # most 2,000 copies per exact item, even when an item is free.
        count = inventory.MAX_STACK_SIZE if unlimited else min(limit, inventory.MAX_STACK_SIZE)
        for _ in range(count):
            import crafted_provenance
            if crafted_provenance.denied(name, player, session=session):
                stop_reason = crafted_provenance.DENIED
                break
            if player.ryo < cost:
                stop_reason = "You can't afford any more of that item."
                break
            ok, reason = inventory.add_item(player.inventory, name)
            if not ok:
                stop_reason = inventory.full_message(reason, name)
                break
            player.ryo -= cost
            bought.append(name)
            total_ryo += cost
            _fire_item_trigger(session, name, "get")
        if not unlimited and limit > count and not stop_reason:
            stop_reason = "Your inventory stack limit was reached."

    if not bought:
        session.send(stop_reason or "You couldn't buy any matching items.")
        return
    counts = inventory.slot_counts(bought)
    details = ", ".join(
        f"{rarity_colored_name(name)} x{quantity}"
        for name, quantity in counts.items()
    )
    message = f"You buy {len(bought)} item(s) for {total_ryo:,} ryo: {details}."
    if stop_reason:
        message += f" {stop_reason}"
    session.send(message)



def cmd_sell(session, args: List[str]) -> None:
    player = session.player

    if args and args[0].lower() == "shop":
        if player.shop_room_vnum is None:
            session.send("You don't own a shop to close.")
            return
        results = playershops.close_shop(player)
        if not results:
            session.send("You close your shop. It stood empty, so there was nothing to return.")
        else:
            floor_items = [name for name, dest in results if dest == "floor"]
            inv_items = [name for name, dest in results if dest == "inventory"]
            lines = ["You close your shop."]
            if inv_items:
                lines.append(f"Returned to your inventory: {', '.join(inv_items)}.")
            if floor_items:
                lines.append(f"No room left for these, so they're on the floor: {', '.join(floor_items)}.")
            session.send("\n".join(lines))
        return

    if args and args[0].lower() == "room":
        if player.apartment_room_vnum is None:
            session.send("You don't own an apartment.")
            return
        if len(args) != 2:
            session.send(f"Usage: sell room <type>\nTypes you own: {', '.join(player.apartment_expansions) or 'none'}")
            return
        room_type = args[1].lower()
        if room_type not in player.apartment_expansions:
            session.send(f"You don't have a {room_type} to sell.")
            return

        room_vnum = apartments.expansion_room_vnum(player.apartment_room_vnum, room_type)
        # Older apartments could have children built off a hallway/bedroom.
        # Don't orphan those rooms by selling their parent alone.
        children = [
            name for name, entry in player.apartment_expansions.items()
            if name != room_type and entry.get("parent_vnum", player.apartment_room_vnum) == room_vnum
        ]
        if children:
            session.send(f"Sell the connected room(s) first: {', '.join(children)}.")
            return
        room = WORLD.get(room_vnum)
        if room and not apartments.owns_expansion_room(player, room_type):
            session.send(f"Room VNUM {room_vnum} has been reassigned. Contact a builder.")
            return

        entry = player.apartment_expansions.pop(room_type)
        refund = apartments.refund_for_cost(entry["cost"])
        player.ryo += refund
        apartments.delete_expansion_room(player, room_type)
        if player.room_vnum == room_vnum:
            player.room_vnum = player.apartment_room_vnum
        if room_type == "storage":
            player.storage_room_items = []
        storage.save_player(player)
        import world_autosave
        world_autosave.mark_dirty()
        session.send(
            f"You tear out the {room_type}, freeing VNUM {room_vnum}, and receive {refund:,} ryo "
            f"(50% of the {entry['cost']:,} ryo it cost)."
        )
        return

    if args and args[0].lower() != "all" and not args[0].isdigit() and "apartment" in " ".join(args).lower():
        if player.apartment_room_vnum is None:
            session.send("You don't own an apartment to sell.")
            return
        room = WORLD.get(player.apartment_room_vnum)
        if room is None or room.owner != player.name:
            session.send("Your apartment deed doesn't match the main room. Contact a builder.")
            return
        total_refund = apartments.refund_for_cost(config.APARTMENT_COST_RYO)
        for entry in player.apartment_expansions.values():
            total_refund += apartments.refund_for_cost(entry["cost"])

        # Verify every registered room before making any changes: a
        # builder may have reused a VNUM, which we must never delete.
        for room_type in apartments.APARTMENT_VNUM_TYPES:
            expansion_vnum = apartments.expansion_room_vnum(player.apartment_room_vnum, room_type)
            expansion = WORLD.get(expansion_vnum)
            if expansion and not apartments.owns_expansion_room(player, room_type):
                session.send(f"Room VNUM {expansion_vnum} is no longer yours. Contact a builder.")
                return

        apartments.clear_apartment_expansions(player)
        if player.room_vnum != player.apartment_room_vnum and apartments.owns_room_at(player, player.room_vnum):
            player.room_vnum = player.apartment_room_vnum
        apartments.reset_vacant_apartment(room)
        player.apartment_room_vnum = None
        player.apartment_name = None
        player.apartment_description = None
        player.apartment_expansions = {}
        player.storage_room_items = []
        player.ryo += total_refund
        storage.save_player(player)
        import world_autosave
        world_autosave.mark_dirty()
        session.send(
            f"You sign over the deed and receive {total_refund:,} ryo (50% of what each room cost). "
            "The expansion rooms and their VNUMs are freed; the main room is now Empty apartment."
        )
        return

    if args and (args[0].lower() == "all" or
                 (args[0].isdigit() and len(args) > 1)):
        _sell_multiple(session, args)
        return

    shopkeeper = _find_shopkeeper(player.room_vnum)
    if shopkeeper:
        if not args:
            session.send("Sell what?")
            return
        query = " ".join(args).lower()
        match = find_indexed_item(query, player.inventory)
        if not match:
            session.send(f"You aren't carrying anything like '{query}'.")
            return
        if match.endswith(" [glued]"):
            session.send("That item is glued to you and cannot be sold.")
            return
        category = item_types.classify_item(match)
        buys_categories = combat.mob_shop_buys_categories(shopkeeper)
        import seasonal_events
        is_feather = match == seasonal_events.TURKEY_FEATHER
        if buys_categories and category not in buys_categories and not is_feather:
            session.send(f"{shopkeeper.name.capitalize()} doesn't buy {category} items.")
            return
        multiplier = 1.0 if buys_categories else 0.5
        dish_price = cooking.price_for_dish(match)
        base_price = dish_price if dish_price is not None else item_types.base_sell_price(match)
        price = 500 if is_feather else max(1, int(base_price * multiplier))
        player.inventory.remove(match)
        player.ryo += price
        session.send(f"You sell {match} for {price} ryo.")
        return

    shop = content.SHOPS.get(player.room_vnum)
    if not shop:
        session.send("There is nowhere to sell that here.")
        return
    if not args:
        session.send("Sell what?")
        return
    query = " ".join(args).lower()
    match = find_indexed_item(query, player.inventory)
    if not match:
        session.send(f"You aren't carrying anything like '{query}'.")
        return
    if match.endswith(" [glued]"):
        session.send("That item is glued to you and cannot be sold.")
        return

    category = item_types.classify_item(match)
    shop_type = shop["type"]
    if not data_shops.can_sell_here(shop_type, category):
        shop_info = data_shops.SHOP_TYPES[shop_type]
        session.send(f"{shop_info['display_name']} doesn't buy {category} items.")
        return

    dish_price = cooking.price_for_dish(match)
    base_price = dish_price if dish_price is not None else item_types.base_sell_price(match)
    price = max(1, int(base_price * data_shops.sell_multiplier(shop_type)))
    player.inventory.remove(match)
    player.ryo += price
    session.send(f"You sell {match} for {price} ryo.")



def _sell_multiple(session, args: List[str]) -> None:
    """Sell every matching inventory item, or up to an exact quantity.

    Syntax: sell all <item> | sell <count> <item>.
    The item query is mandatory, preventing accidental inventory-wide sales.
    Equipped items are not in the inventory list and cannot be selected.
    """
    player = session.player
    query = " ".join(args[1:]).strip().lower()
    if not query:
        session.send("Usage: sell all <item>  |  sell <number> <item>")
        return
    unlimited = args[0].lower() == "all"
    quantity = None if unlimited else int(args[0])
    if quantity is not None and quantity < 1:
        session.send("Enter a positive number of items to sell.")
        return

    shopkeeper = _find_shopkeeper(player.room_vnum)
    shop = None if shopkeeper else content.SHOPS.get(player.room_vnum)
    if not shopkeeper and not shop:
        session.send("There is nowhere to sell that here.")
        return

    # Record real inventory indices: multiple copies have identical strings,
    # and carried container contents are indexed by their inventory position.
    candidates = [
        (i, item) for i, item in enumerate(player.inventory)
        if _item_matches(query, item)
    ]
    selected = candidates if unlimited else candidates[:quantity]
    if not selected:
        session.send(f"You aren't carrying anything like '{query}'.")
        return

    import seasonal_events
    sold = []
    total_ryo = 0
    skipped = 0
    rejected_category = None
    buys_categories = combat.mob_shop_buys_categories(shopkeeper) if shopkeeper else None

    # Descending order keeps the original indices of pending candidates valid.
    for index, item in reversed(selected):
        if item.endswith(" [glued]") or player.backpack_contents.get(str(index)):
            skipped += 1
            continue
        category = item_types.classify_item(item)
        is_feather = item == seasonal_events.TURKEY_FEATHER
        if shopkeeper:
            if buys_categories and category not in buys_categories and not is_feather:
                rejected_category = category
                skipped += 1
                continue
            multiplier = 1.0 if buys_categories else 0.5
        else:
            shop_type = shop["type"]
            if not data_shops.can_sell_here(shop_type, category):
                rejected_category = category
                skipped += 1
                continue
            multiplier = data_shops.sell_multiplier(shop_type)

        dish_price = cooking.price_for_dish(item)
        base_price = dish_price if dish_price is not None else item_types.base_sell_price(item)
        price = 500 if shopkeeper and is_feather else max(1, int(base_price * multiplier))
        del player.inventory[index]
        # An empty container may be sold, but do not orphan the contents
        # mapping of a different backpack positioned later in inventory.
        shifted = {}
        for raw_position, contents in player.backpack_contents.items():
            position = int(raw_position)
            if position != index:
                shifted[str(position - 1 if position > index else position)] = contents
        player.backpack_contents = shifted
        sold.append(item)
        total_ryo += price

    if not sold:
        if rejected_category is not None:
            if shopkeeper:
                session.send(f"{shopkeeper.name.capitalize()} doesn't buy {rejected_category} items.")
            else:
                display_name = data_shops.SHOP_TYPES[shop["type"]]["display_name"]
                session.send(f"{display_name} doesn't buy {rejected_category} items.")
        else:
            session.send("Those items are protected or contain stored items and cannot be sold.")
        return

    player.ryo += total_ryo
    counts = inventory.slot_counts(sold)
    details = ", ".join(f"{name} x{count}" for name, count in counts.items())
    message = f"You sell {len(sold)} item(s) for {total_ryo:,} ryo: {details}."
    if skipped:
        message += f" {skipped} matching item(s) could not be sold."
    session.send(message)


CHOU_HAN_CHOICES = {"chou": "chou", "even": "chou", "han": "han", "odd": "han"}
CHOU_HAN_PAYOUT_MULTIPLIER = 3  # a win pays back 3x the wager (net gain = 2x)


GAMBLE_DELAY_SECONDS = 60.0


def cmd_gamble(session, args: List[str]) -> None:
    """Chou-han (even/odd): the dealer rolls two dice; bet on whether
    the sum is even (chou) or odd (han). Requires sitting down at the
    table (position == 'resting' -- our existing 'rest' position is
    also how the game narrates it: 'You sit down and rest'). Takes
    GAMBLE_DELAY_SECONDS (~1 minute) to resolve, with flavor messages
    along the way, rather than resolving instantly -- the wager is
    deducted up front (so it can't be spent elsewhere mid-roll), and
    the actual result only lands once the delay is up."""
    player = session.player
    dealer = _find_gambler(player.room_vnum)
    if not dealer:
        session.send("There is no dealer here to gamble with.")
        return
    if session.is_busy():
        session.send("You're already busy with something.")
        return
    if player.position != "resting":
        session.send(f"You need to sit down at the table first (try 'rest') before {dealer.name} will deal you in.")
        return
    if len(args) != 2:
        session.send("Usage: gamble <chou|han|even|odd> <wager>")
        return
    choice_word, wager_text = args[0].lower(), args[1]
    if choice_word not in CHOU_HAN_CHOICES:
        session.send("Call 'chou' (even) or 'han' (odd).")
        return
    if not wager_text.isdigit() or int(wager_text) <= 0:
        session.send("Wager must be a positive number of ryo.")
        return
    wager = int(wager_text)
    if wager > player.ryo:
        session.send("You can't wager more ryo than you have.")
        return

    choice = CHOU_HAN_CHOICES[choice_word]
    player.ryo -= wager

    def resolve() -> None:
        die1, die2 = random.randint(1, 6), random.randint(1, 6)
        total = die1 + die2
        outcome = "chou" if total % 2 == 0 else "han"

        session.send(
            f"{dealer.name.capitalize()} lifts the cup -- {die1} and {die2} -- {total} ({outcome})."
        )
        if choice == outcome:
            winnings = wager * CHOU_HAN_PAYOUT_MULTIPLIER
            player.ryo += winnings
            session.send(f"&GYou called {choice_word} correctly! {dealer.name.capitalize()} pays you {winnings} ryo.&x")
        else:
            session.send(f"&R{dealer.name.capitalize()} sweeps your {wager} ryo off the table.&x")

    session.send(f"You place your wager. {dealer.name.capitalize()} begins rattling the dice cup...")
    flavor = [
        (20.0, f"{dealer.name.capitalize()} shakes the cup with a steady, rhythmic clatter..."),
        (40.0, "The dice tumble and knock against the sides of the cup..."),
    ]
    session.start_timed_action("gambling", GAMBLE_DELAY_SECONDS, resolve, flavor_schedule=flavor)


SLOTS_DELAY_SECONDS = 15.0


def cmd_slots(session, args: List[str]) -> None:
    """Slot machine gambling (slots.py) -- four wager tiers (1/25/100/
    1,000 ryo), each with its own progressive jackpot that grows from
    every pull. Same location requirement as chou-han: needs a
    gambler-flagged mob in the room, but no sitting required (a
    standing machine, not a table game). Takes SLOTS_DELAY_SECONDS to
    resolve rather than being instant, same treatment as every other
    gambling/job action -- the wager is deducted up front (so it can't
    be spent elsewhere mid-pull), and the reels/payout only land once
    the delay is up (session.start_timed_action)."""
    player = session.player
    dealer = _find_gambler(player.room_vnum)
    if not dealer:
        session.send("There is no gambling machine attendant here.")
        return

    if not args:
        lines = [f"&W{dealer.name.capitalize()}'s slot machines:&x"]
        for tier in slots.TIERS:
            jackpot = slots.get_jackpot(tier)
            lines.append(f"  &Y{tier:,} ryo&x pull -- current jackpot: &O{jackpot:,} ryo&x")
        lines.append("Usage: slots <tier>")
        session.send("\n".join(lines))
        return

    if session.is_busy():
        session.send("You're already busy with something.")
        return
    if not args[0].isdigit() or int(args[0]) not in slots.TIERS:
        session.send(f"That's not a valid tier. Choose one of: {', '.join(str(t) for t in slots.TIERS)}.")
        return
    tier = int(args[0])
    if player.ryo < tier:
        session.send(f"You need {tier:,} ryo to pull this machine -- you have {player.ryo:,}.")
        return

    player.ryo -= tier

    def resolve() -> None:
        result = slots.pull(tier, tier)
        session.send(f"&D[ {slots.display_reels(result['reels'])} &D]&x")

        if result["outcome"] == "jackpot":
            player.ryo += result["payout"]
            session.send(f"&r*** JACKPOT! *** {dealer.name.capitalize()} pays out {result['payout']:,} ryo!&x")
        elif result["outcome"] == "three":
            player.ryo += result["payout"]
            session.send(f"&GThree {slots.SYMBOL_DISPLAY[result['symbol']]}&G! You win {result['payout']:,} ryo.&x")
        elif result["outcome"] == "two":
            player.ryo += result["payout"]
            session.send(f"&YTwo of a kind. You win {result['payout']:,} ryo.&x")
        else:
            session.send(f"&DNo match. {dealer.name.capitalize()} keeps your {tier:,} ryo.&x")

    session.send(f"You pull the lever on {dealer.name}'s machine. The reels start spinning...")
    session.start_timed_action("slots", SLOTS_DELAY_SECONDS, resolve)


ROULETTE_DELAY_SECONDS = 30.0


def cmd_roulette(session, args: List[str]) -> None:
    """Roulette (roulette.py) -- wagered in MISSION POINTS, not ryo,
    since it's meant to feel like the higher-stakes table game of the
    three gambling mechanics. Same gambler-mob location requirement as
    slots/chou-han, no sitting required. 'roulette number <0-36>
    <wager>' for a 36x straight-up bet, or 'roulette
    <red|black|odd|even|low|high> <wager>' for a 2x even-money bet.
    Takes ROULETTE_DELAY_SECONDS to resolve rather than being instant,
    same treatment as slots/chou-han -- the wager is deducted up
    front, and the wheel's result only lands once the delay is up."""
    player = session.player
    dealer = _find_gambler(player.room_vnum)
    if not dealer:
        session.send("There is no roulette dealer here.")
        return

    if not args:
        session.send(
            "Usage: roulette number <0-36> <wager>\n"
            "       roulette <red|black|odd|even|low|high> <wager>\n"
            "Wagers are in MISSION POINTS, not ryo. Straight numbers pay 36x; "
            "red/black/odd/even/low/high pay 2x."
        )
        return

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    bet_type = args[0].lower()
    if bet_type == "number":
        if len(args) != 3 or not args[1].isdigit() or not (0 <= int(args[1]) <= 36) or not args[2].isdigit():
            session.send("Usage: roulette number <0-36> <wager>")
            return
        bet_value = int(args[1])
        wager_text = args[2]
    elif bet_type in roulette.OUTSIDE_BET_TYPES:
        if len(args) != 2 or not args[1].isdigit():
            session.send(f"Usage: roulette {bet_type} <wager>")
            return
        bet_value = None
        wager_text = args[1]
    else:
        session.send(
            f"'{bet_type}' isn't a valid bet. Choose 'number' or one of: "
            + ", ".join(sorted(roulette.OUTSIDE_BET_TYPES))
        )
        return

    wager = int(wager_text)
    if wager <= 0:
        session.send("Wager must be a positive number of mission points.")
        return
    if wager > player.mission_points:
        session.send(f"You only have {player.mission_points} mission points -- you can't wager {wager}.")
        return

    player.mission_points -= wager

    def resolve() -> None:
        result = roulette.spin()
        session.send(f"{dealer.name.capitalize()} spins the wheel... it lands on {roulette.colored_number(result)}.")

        payout = roulette.resolve_bet(bet_type, bet_value, wager, result)
        if payout > 0:
            player.mission_points += payout
            session.send(f"&GYou win {payout:,} mission points!&x")
        else:
            session.send(f"&DThe house takes your {wager:,} mission points.&x")

    session.send(f"You place your bet. {dealer.name.capitalize()} spins up the wheel...")
    session.start_timed_action("roulette", ROULETTE_DELAY_SECONDS, resolve)


def _award_job_action_xp(session, job: str, amount: int) -> None:
    """Report real XP earned from a successful job action, not total XP.

    The central job ledger still owns level-up/stat rewards. Report only
    the increase it actually accepted (0 at the job cap), so action
    failures, denied inventory deliveries and maxed jobs don't lie.
    """
    # Apply the already-active village/global EXP perk to jobs, too.
    # Resolve it when an activity finishes, not when a timer begins.
    # Staff global and Kage village perks already replace rather than stack.
    multiplier = village_perks.xp_multiplier(session.player.village)
    earned_xp = int(amount * multiplier) if amount > 0 else amount
    before = jobs.get_job_xp(session.player, job)
    level_messages = jobs.add_job_xp(session.player, job, earned_xp)
    gained = jobs.get_job_xp(session.player, job) - before
    if gained > 0:
        perk_note = f" &Y(x{multiplier:g} EXP perk)&x" if multiplier != 1.0 else ""
        session.send(f"&G+{gained:,} {job.capitalize()} XP&x{perk_note}")
    for message in level_messages:
        session.send(message)


FISHING_DELAY_SECONDS = 6.0


def _use_held_job_tool(session, held_tool: str) -> bool:
    """Spend one use when a delayed job attempt actually resolves.

    A switched or removed tool cancels the attempt. The tool breaks on
    its final use, after which the current attempt still finishes.
    """
    player = session.player
    if player.equipment.get("tool") != held_tool:
        session.send("You stopped holding the tool before finishing the job.")
        return False
    remaining, _total = tool_durability.uses_left(held_tool)
    if remaining <= 0:
        session.send("That tool is broken.")
        return False
    updated = tool_durability.spend_use(held_tool)
    if updated is None:
        _apply_equipment_stat_bonuses(player, held_tool, sign=-1)
        del player.equipment["tool"]
        session.send(f"&R{tool_durability.base_name(held_tool)} breaks after its final use!&x")
    else:
        player.equipment["tool"] = updated
        if remaining <= 11 or remaining in {101, 51, 26}:
            session.send(f"&YYour tool has {remaining - 1} uses left.&x")
    return True


def cmd_fish(session, args: List[str]) -> None:
    """Fishing (fishing.py) -- the first job on jobs.py's generic
    leveling framework, entirely separate from ninja level/experience.
    Needs a fishing rod actually HELD (via 'hold <rod>', in the 'tool'
    equipment slot -- merely carrying one in inventory isn't enough,
    per explicit request) and a water biome (rset biome
    ocean/river/lake/swamp); the rod's tier gates both what's reachable
    at all and shifts the odds toward rarer fish, alongside the
    player's own Fishing job level. Takes FISHING_DELAY_SECONDS to
    resolve rather than being instant -- preconditions (rod held,
    right biome, rod usable at the player's level) are still checked
    immediately, but the actual catch only resolves once the delay is
    up (session.start_timed_action, resolved from the pulse loop)."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    held_tool = player.equipment.get("tool", "")
    rod_name = strip_crafted_suffix(held_tool)
    if rod_name.lower() not in fishing.RODS:
        session.send("You need to hold a fishing rod to do that (see 'help hold').")
        return

    room = world.WORLD.get(player.room_vnum)
    if not room or not fishing.can_fish_here(room.biome):
        session.send("There's nowhere to fish here -- you need to be near water.")
        return

    job_level = jobs.get_job_level(player, "fishing")

    required = fishing.rod_required_level(rod_name.lower())
    if required > job_level:
        session.send(
            f"{held_tool} requires Fishing level {required} to use -- you're only level {job_level}."
        )
        return

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if not _use_held_job_tool(session, held_tool):
            return
        catch = fishing.attempt_catch(job_level, rod_name.lower())
        if catch["failed"]:
            session.send("You feel a tug, but come up with nothing. The fish got away.")
            return
        proto = _find_object_prototype_by_name(catch["name"])
        display_name = proto["short_desc"] if proto else catch["name"]

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You caught {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("You release it back into the water.")
            _award_job_action_xp(session, "fishing", catch["xp"])
            return

        session.send(f"You caught {rarity_colored_name(display_name)}!")
        _award_job_action_xp(session, "fishing", catch["xp"])

    session.send("You cast your line and wait...")
    session.start_timed_action("fishing", FISHING_DELAY_SECONDS, resolve)


def cmd_mine(session, args: List[str]) -> None:
    """Mining (mining.py) -- the second job on jobs.py's framework,
    structured identically to cmd_fish, including the same delay
    treatment: preconditions check immediately, but the actual find
    only resolves after FISHING_DELAY_SECONDS via the timed-action
    mechanism, not instantly. Needs a pickaxe actually HELD (via 'hold
    <pickaxe>', in the 'tool' equipment slot -- merely carrying one in
    inventory isn't enough, matching the same fix applied to fishing
    rods) and a mountain biome; the pickaxe's tier gates both what's
    reachable and shifts the odds toward rarer finds, alongside the
    player's own Mining job level."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    held_tool = player.equipment.get("tool", "")
    tool_name = strip_crafted_suffix(held_tool)
    if tool_name.lower() not in mining.PICKAXES:
        session.send("You need to hold a pickaxe to do that (see 'help hold').")
        return

    room = world.WORLD.get(player.room_vnum)
    if not room or not mining.can_mine_here(room.biome):
        session.send("There's nowhere to mine here -- you need to be somewhere rocky.")
        return

    job_level = jobs.get_job_level(player, "mining")

    required = mining.tool_required_level(tool_name.lower())
    if required > job_level:
        session.send(
            f"{held_tool} requires Mining level {required} to use -- you're only level {job_level}."
        )
        return

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if not _use_held_job_tool(session, held_tool):
            return
        find = mining.attempt_mine(job_level, tool_name.lower())
        if find["failed"]:
            session.send("Your pickaxe glances off the rock. Nothing comes loose.")
            return
        proto = _find_object_prototype_by_name(find["name"])
        display_name = proto["short_desc"] if proto else find["name"]

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You dig up {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("You leave it in the rock.")
            return

        session.send(f"You mine {rarity_colored_name(display_name)}!")
        _award_job_action_xp(session, "mining", find["xp"])

        bonus = gems.roll_bonus_gem()
        if bonus:
            gem_name, gem_rarity = bonus
            gem_proto = _find_object_prototype_by_name(gem_name)
            gem_display = gem_proto["short_desc"] if gem_proto else gem_name
            ok2, reason2 = inventory.add_item(player.inventory, gem_display)
            if ok2:
                session.send(
                    f"&YSomething catches your eye in the rubble -- you find "
                    f"{rarity_colored_name(gem_display)}!&x"
                )
            else:
                session.send(
                    f"&YSomething catches your eye in the rubble -- "
                    f"{rarity_colored_name(gem_display)}, but you have nowhere to put it!&x"
                )
                session.send(inventory.full_message(reason2, gem_display))

    session.send("You swing your pickaxe at the rock face...")
    session.start_timed_action("mining", FISHING_DELAY_SECONDS, resolve)


def cmd_smelt(session, args: List[str]) -> None:
    """Smelting (mining.py) -- converts a raw ore (an iron ore/a steel
    ore/a chakra steel ore) into the ingot every downstream crafting
    recipe in the game already depends on by exact name. Gated by
    Mining level (matching the ore's own implicit tier), costs 1-2
    stamina like every other job action, and takes a real delay to
    resolve -- but always succeeds once level and material checks
    pass, since the randomness already happened at the mining step
    that produced the ore in the first place. No location or tool
    requirement, unlike the gathering jobs -- smelting works
    anywhere."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    if not args:
        session.send("Usage: smelt <ore>")
        return

    query = " ".join(args).lower()
    ore_name = next(
        (item for item in player.inventory
         if _item_matches(query, item) and item.lower() in mining.SMELTING_RECIPES),
        None,
    )
    if not ore_name:
        session.send("You don't have that ore to smelt.")
        return

    job_level = jobs.get_job_level(player, "mining")
    required = mining.smelt_required_level(ore_name.lower())
    if required > job_level:
        session.send(
            f"Smelting {ore_name} requires Mining level {required} -- you're only level {job_level}."
        )
        return

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if ore_name not in player.inventory:
            session.send(f"You no longer have {ore_name} to smelt.")
            return
        player.inventory.remove(ore_name)

        ingot_name = mining.smelt_ore(ore_name.lower())
        proto = _find_object_prototype_by_name(ingot_name)
        display_name = proto["short_desc"] if proto else ingot_name

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You smelt {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("It cools into a useless slag heap and crumbles away.")
            return

        session.send(f"You smelt {ore_name} into {rarity_colored_name(display_name)}!")

    session.send(f"You stoke the forge and begin smelting {ore_name}...")
    session.start_timed_action("mining", FISHING_DELAY_SECONDS, resolve)


def cmd_chop(session, args: List[str]) -> None:
    """Lumberjacking (lumberjack.py) -- the third job on jobs.py's
    framework, structured identically to cmd_fish/cmd_mine, including
    the same delay treatment (FISHING_DELAY_SECONDS via the timed-
    action mechanism, not instant). Needs an axe actually HELD (via
    'hold <axe>', in the 'tool' equipment slot -- merely carrying one
    in inventory isn't enough, matching the same fix applied to
    fishing rods and pickaxes) and a forest biome; the axe's tier
    gates both what's reachable and shifts the odds toward rarer
    finds, alongside the player's own Lumberjack job level."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    held_tool = player.equipment.get("tool", "")
    tool_name = strip_crafted_suffix(held_tool)
    if tool_name.lower() not in lumberjack.AXES:
        session.send("You need to hold an axe to do that (see 'help hold').")
        return

    room = world.WORLD.get(player.room_vnum)
    if not room or not lumberjack.can_chop_here(room.biome):
        session.send("There's nothing to chop here -- you need to be somewhere wooded.")
        return

    job_level = jobs.get_job_level(player, "lumberjack")

    required = lumberjack.tool_required_level(tool_name.lower())
    if required > job_level:
        session.send(
            f"{held_tool} requires Lumberjack level {required} to use -- you're only level {job_level}."
        )
        return

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if not _use_held_job_tool(session, held_tool):
            return
        find = lumberjack.attempt_chop(job_level, tool_name.lower())
        if find["failed"]:
            session.send("Your axe bites into bark, but nothing worth taking comes free.")
            return
        proto = _find_object_prototype_by_name(find["name"])
        display_name = proto["short_desc"] if proto else find["name"]

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You cut free {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("You leave it where it fell.")
            return

        session.send(f"You chop free {rarity_colored_name(display_name)}!")
        _award_job_action_xp(session, "lumberjack", find["xp"])

    session.send("You swing your axe at the trunk...")
    session.start_timed_action("lumberjack", FISHING_DELAY_SECONDS, resolve)


COOK_DELAY_SECONDS = 6.0


def cmd_farm(session, args: List[str]) -> None:
    """Farming (farming.py) -- a new gathering job on jobs.py's
    framework, structured identically to cmd_fish/cmd_mine/cmd_chop.
    Needs a hoe actually HELD and a "plains" biome. Farming level
    unlocks crops; gathering can still fail."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    held_tool = player.equipment.get("tool", "")
    tool_name = strip_crafted_suffix(held_tool)
    if tool_name.lower() not in farming.HOES:
        session.send("You need to hold a hoe to do that (see 'help hold').")
        return

    room = world.WORLD.get(player.room_vnum)
    if not room or not farming.can_farm_here(room.biome):
        session.send("There's nowhere to farm here -- you need open farmland.")
        return

    job_level = jobs.get_job_level(player, "farming")

    required = farming.tool_required_level(tool_name.lower())
    if required > job_level:
        session.send(
            f"{held_tool} requires Farming level {required} to use -- you're only level {job_level}."
        )
        return

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if not _use_held_job_tool(session, held_tool):
            return
        find = farming.attempt_farm(job_level, tool_name.lower())
        if find["failed"]:
            session.send("You till the soil, but come up with nothing usable.")
            return
        proto = _find_object_prototype_by_name(find["name"])
        display_name = proto["short_desc"] if proto else find["name"]

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You harvest {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("You leave it in the field.")
            return

        session.send(f"You harvest {rarity_colored_name(display_name)}!")
        _award_job_action_xp(session, "farming", find["xp"])

    session.send("You till the soil and tend the crops...")
    session.start_timed_action("farming", FISHING_DELAY_SECONDS, resolve)


def cmd_cook(session, args: List[str]) -> None:
    """Cooking (cooking.py) -- reworked per the same explicit request
    as fishing/mining/lumberjack/farming's own reworks: needs one of 6
    tiered cooking pots actually HELD (same requirement as fishing
    rods/pickaxes/axes/hoes), or standing in your own apartment
    kitchen (which needs no pot at all -- treated as the lowest,
    Copper tier for quality odds, since there's no specific pot item
    to gate there). A raw fish (from Fishing) is named as the argument
    -- no biome/location requirement otherwise, unlike the gathering
    jobs, since cooking works anywhere. Takes COOK_DELAY_SECONDS to
    resolve, with a real chance to burn the dish entirely; on success,
    the resulting dish's quality tier is shown as a suffix (e.g.
    "(Rare)"), same pattern crafting.py uses for a crafted item's stat
    bonus suffix -- and, per the rework, the pot's own tier shifts the
    odds toward better quality the same tier-distance way a rod/
    pickaxe/axe/hoe shifts catch rarity, so only the top pot gives a
    real shot at a Legendary dish. The ingredient is consumed either
    way (burned or not) -- re-checked at resolution time in case it
    was spent elsewhere during the delay, same pattern crafting.py
    uses for its own materials."""
    player = session.player

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    room = world.WORLD.get(player.room_vnum)
    in_own_kitchen = room and room.apartment_room_type == "kitchen" and room.owner == player.name
    held_tool = player.equipment.get("tool", "")
    stripped_tool = strip_crafted_suffix(held_tool)
    pot_name = stripped_tool if stripped_tool.lower() in cooking.POTS else None
    if pot_name is None and not in_own_kitchen:
        session.send("You need to hold a cooking pot to do that (see 'help hold').")
        return

    if not args:
        session.send("Usage: cook <fish>")
        return

    query = " ".join(args).lower()
    ingredient_name = next(
        (item for item in player.inventory
         if _item_matches(query, item) and item.lower() in cooking.INGREDIENTS),
        None,
    )
    if not ingredient_name:
        session.send("You don't have that ingredient to cook.")
        return

    job_level = jobs.get_job_level(player, "cooking")

    if pot_name is not None:
        required = cooking.pot_required_level(pot_name)
        if required > job_level:
            session.send(
                f"{held_tool} requires Cooking level {required} to use -- you're only level {job_level}."
            )
            return
    effective_pot = pot_name if pot_name is not None else "a copper cooking pot"

    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if ingredient_name not in player.inventory:
            session.send(f"You no longer have {ingredient_name} to cook.")
            return
        if pot_name is not None and not _use_held_job_tool(session, held_tool):
            return
        player.inventory.remove(ingredient_name)

        result = cooking.attempt_cook(job_level, ingredient_name.lower(), effective_pot)
        if result["burned"]:
            session.send(f"You burn {ingredient_name} to a crisp! It's ruined.")
            return

        display_name = result["name"]

        ok, reason = inventory.add_item(player.inventory, display_name)
        if not ok:
            session.send(f"You cook {rarity_colored_name(display_name)}, but had nowhere to put it!")
            session.send(inventory.full_message(reason, display_name))
            session.send("You eat it yourself on the spot rather than waste it.")
            return

        session.send(f"You cook {rarity_colored_name(display_name)}!")
        _award_job_action_xp(session, "cooking", result["xp"])

    session.send(f"You start cooking {ingredient_name}...")
    session.start_timed_action("cooking", COOK_DELAY_SECONDS, resolve)


def cmd_gemcut(session, args: List[str]) -> None:
    """Cut any of the ten rare mining gems using a held Copper Chisel."""
    player = session.player
    if session.is_busy():
        session.send("You're already busy with something.")
        return
    held_tool = player.equipment.get("tool", "")
    if strip_crafted_suffix(held_tool).lower() not in gemcutter.CHISELS:
        session.send("You need to hold a copper chisel to cut gems.")
        return
    if not args:
        session.send("Usage: gemcut <gem>  (quartz, jade, amber, garnet, amethyst, topaz, sapphire, emerald, ruby, diamond)")
        return
    raw_gems = [item for item in player.inventory if item.lower() in gemcutter.RECIPES]
    raw_gem = find_indexed_item(" ".join(args).lower(), raw_gems)
    if not raw_gem:
        session.send("You aren't carrying a cuttable gem by that name.")
        return
    result_name, required_level, xp = gemcutter.RECIPES[raw_gem.lower()]
    job_level = jobs.get_job_level(player, "gemcutter")
    if job_level < required_level:
        session.send(f"Cutting {raw_gem} requires Gemcutter level {required_level} (yours: {job_level}).")
        return
    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if raw_gem not in player.inventory:
            session.send(f"You no longer have {raw_gem} to cut.")
            return
        if not _use_held_job_tool(session, held_tool):
            return
        player.inventory.remove(raw_gem)
        ok, reason = inventory.add_item(player.inventory, result_name)
        if not ok:
            player.inventory.append(raw_gem)
            session.send(inventory.full_message(reason, result_name))
            session.send(f"You keep {raw_gem} for another attempt.")
            return
        gem_proto = _find_object_prototype_by_name(result_name)
        bonuses = gem_proto.get("gem_bonuses", {}) if gem_proto else {}
        session.send(
            f"You cut {raw_gem} into {result_name}! "
            f"Its {gem_proto.get('rarity', 'common') if gem_proto else 'common'} quality stores "
            f"Hitroll +{bonuses.get('hitroll', 0)} and Damageroll +{bonuses.get('damroll', 0)} "
            "for a permanent forge or inlay upgrade."
        )
        _award_job_action_xp(session, "gemcutter", xp)

    session.send(f"You carefully start cutting {raw_gem}...")
    session.start_timed_action("gemcutting", COOK_DELAY_SECONDS, resolve)


def cmd_inlay(session, args: List[str]) -> None:
    """Place one cut gem into a uniquely forged weapon or armor, no name suffix."""
    import gem_inlays
    import elemental_counters
    import world_autosave
    player = session.player
    words = " ".join(args)
    item_query, separator, gem_query = words.partition(" with ")
    if not separator or not item_query.strip() or not gem_query.strip():
        session.send("Usage: inlay <forged item> with <cut gem>")
        return
    if session.is_busy():
        session.send("You're already busy with something.")
        return
    held_tool = player.equipment.get("tool", "")
    if strip_crafted_suffix(held_tool).casefold() not in gemcutter.CHISELS:
        session.send("Hold a Copper Chisel to inlay a cut gem.")
        return
    forged = find_indexed_item(item_query.casefold(), player.inventory)
    gem_name = gem_inlays.available_cut_gem(player, gem_query)
    proto = gem_inlays.forged_prototype(forged) if forged else None
    if not proto:
        session.send("That must be a uniquely named forged weapon or armor in your inventory.")
        return
    if proto.get("gem_inlay"):
        session.send("This item already has a permanent gemstone inlay.")
        return
    if not gem_name:
        session.send("You must carry the selected Cut Gem.")
        return
    gem_key = gem_inlays.gem_from_cut_item(gem_name)
    required_level = min(level for output, level, _xp in gemcutter.RECIPES.values()
                         if output.casefold() == gem_name.casefold())
    if jobs.get_job_level(player, "gemcutter") < required_level:
        session.send(f"Inlaying {gem_name} requires Gemcutter level {required_level}.")
        return
    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve() -> None:
        if (forged not in player.inventory or gem_name not in player.inventory
                or gem_inlays.forged_prototype(forged) is not proto
                or proto.get("gem_inlay")):
            session.send("Your items changed; the gem inlay was cancelled.")
            return
        if not _use_held_job_tool(session, held_tool):
            return
        proto["gem_inlay"] = gem_key
        player.inventory.remove(gem_name)
        world_autosave.mark_dirty()
        storage.save_player(player)
        element = gem_inlays.ELEMENT_GEMS.get(gem_key)
        detail = (f" +{gem_inlays.ELEMENTAL_JUTSU_BONUS_PERCENT}% {element} jutsu and "
                  f"{gem_inlays.ELEMENTAL_COUNTER_RESIST_PERCENT}% "
                  f"{elemental_counters.counters(element)} resistance"
                  if element else "")
        session.send(f"&GYou securely inlay {gem_name} into {forged}. "
                     "Its original stats are preserved; EXAMINE it for the added bonuses.&x")

    session.send(f"You begin setting {gem_name} into {forged}...")
    session.start_timed_action("gem inlay", COOK_DELAY_SECONDS, resolve)




CRAFT_DELAY_SECONDS = 20.0


_NEXT_CRAFTED_ITEM_VNUM = None  # lazily initialized on first real craft, see _allocate_crafted_item_vnum


def _allocate_crafted_item_vnum() -> int:
    """A genuinely unique, real, persistent vnum for a newly crafted
    item -- starting at 500000 (confirmed genuinely free via a direct
    scan of every real vnum already in use), incrementing by 1 each
    real craft. Lazily scans for the highest already-used vnum in this
    dedicated range on first use, so it correctly resumes past
    whatever's already registered rather than always restarting at
    500000 (e.g. after a server restart where earlier crafted items
    were already saved into OBJECT_TEMPLATES via world-save/reload)."""
    global _NEXT_CRAFTED_ITEM_VNUM
    if _NEXT_CRAFTED_ITEM_VNUM is None:
        existing = [v for v in olc.OBJECT_TEMPLATES if v >= 500000]
        _NEXT_CRAFTED_ITEM_VNUM = (max(existing) + 1) if existing else 500000
    vnum = _NEXT_CRAFTED_ITEM_VNUM
    _NEXT_CRAFTED_ITEM_VNUM += 1
    return vnum


def _craft_gathering_tool(session, args: List[str]) -> None:
    """Blacksmith Bukijutsu crafts one job tool from exactly two materials.

    Syntax: craft tool <rod|axe|pickaxe> <iron|steel|chakra>.
    Materials are only spent after the delayed action succeeds, and a
    failed inventory-add returns both consumed resources to the player.
    """
    import data_crafting
    player = session.player
    if player.primary_class != "bukijutsu" or player.level < 25:
        session.send("Crafted job tools require a Bukijutsu blacksmith of ninja level 25+.")
        return
    if len(args) != 2 or (args[0], args[1]) not in data_crafting.TOOL_NAMES:
        session.send("Usage: craft tool <rod|axe|pickaxe> <iron|steel|chakra>")
        return
    kind, tier = args
    recipe = data_crafting.TOOL_RECIPES[tier]
    result = data_crafting.job_tool_name(kind, tier)
    materials = (recipe["wood"], recipe["ingot"])
    if session.is_busy():
        session.send("You're already busy with something.")
        return

    def have_materials():
        return all(any(item.casefold() == expected.casefold() for item in player.inventory)
                   for expected in materials)

    if not have_materials():
        session.send(f"You need {materials[0]} and {materials[1]} to craft {result}.")
        return
    if not jobs.try_deduct_action_stamina(player):
        session.send("You don't have enough stamina.")
        return

    def resolve():
        if player.primary_class != "bukijutsu" or player.level < 25:
            session.send("You no longer meet the Bukijutsu blacksmith requirement.")
            return
        if not have_materials():
            session.send("The two materials are no longer in your inventory. Crafting fails.")
            return
        taken = []
        for expected in materials:
            item = next(x for x in player.inventory if x.casefold() == expected.casefold())
            player.inventory.remove(item)
            taken.append(item)
        ok, reason = inventory.add_item(player.inventory, result)
        if not ok:
            player.inventory.extend(taken)
            session.send(inventory.full_message(reason, result))
            return
        session.send(f"&GYou forge {result} from {materials[0]} and {materials[1]}! "
                     f"({recipe['uses']} uses.)&x")
        storage.save_player(player)

    session.send(f"You begin forging {result} from {materials[0]} and {materials[1]}...")
    session.start_timed_action("crafting", CRAFT_DELAY_SECONDS, resolve)


def cmd_craft(session, args: List[str]) -> None:
    """'craft weapon <type> <name>' / 'craft armor <slot> <name>' --
    the real Bukijutsu crafting skill (Section 133), per direct
    request/confirmation, replacing the old crafting.py recipe
    framework entirely (it shipped with zero real recipes and was
    never refilled after an earlier revamp). Combines exactly 2 real
    materials (data_crafting.MATERIALS) into a brand-new, genuinely
    unique item the player names themselves -- their own combined
    stat_value applies as both +hitroll and +damroll for a weapon, or
    -armor_class for armor (confirmed directly, matching the game's
    own existing real equipment-bonus mechanism, commands.
    equipped_weapon_hitroll_bonus/damroll_bonus/armor_class_bonus).
    Unlocked at Bukijutsu level 25+ OR any class at level 70+
    (data_crafting.can_craft, confirmed as 2 separate real paths)."""
    import data_crafting

    player = session.player
    if args and args[0].lower() in ("tool", "rod", "axe", "pickaxe"):
        kind = args[0].lower()
        selection = ([w.lower() for w in args[1:]] if kind == "tool" else
                     [kind] + [w.lower() for w in args[1:]])
        _craft_gathering_tool(session, selection)
        return
    if args and args[0].lower() == "pill":
        import pill_crafting
        if player.primary_class != "bukijutsu" or player.level < pill_crafting.MIN_CRAFTER_LEVEL:
            session.send(f"Pill crafting is Bukijutsu-only and unlocks at level {pill_crafting.MIN_CRAFTER_LEVEL}.")
            return
        if len(args) != 3 or args[1].lower() not in ("antidote", "medicine") or not args[2].isdigit():
            session.send("Usage: craft pill antidote <level>  |  craft pill medicine <level>")
            return
        chosen_level = int(args[2])
        if not 1 <= chosen_level <= min(player.level, 100):
            session.send(f"Choose a pill level from 1 to your current level ({player.level}).")
            return
        herb = next((item for item in player.inventory if item.lower() == pill_crafting.HERB_NAME.lower()), None)
        if herb is None:
            session.send("You need Medicinal Herbs to craft a pill.")
            return
        if session.is_busy():
            session.send("You're already busy with something.")
            return
        kind = "Antidote" if args[1].lower() == "antidote" else "Medicinal"
        result = pill_crafting.encode_pill(kind, chosen_level)
        if not jobs.try_deduct_action_stamina(player):
            session.send("You don't have enough stamina.")
            return

        def finish_pill() -> None:
            if player.primary_class != "bukijutsu" or player.level < max(pill_crafting.MIN_CRAFTER_LEVEL, chosen_level):
                session.send("You no longer qualify to finish this pill.")
                return
            available = next((item for item in player.inventory if item.lower() == pill_crafting.HERB_NAME.lower()), None)
            if available is None:
                session.send("You no longer have Medicinal Herbs. The pill is not made.")
                return
            player.inventory.remove(available)
            ok, reason = inventory.add_item(player.inventory, result)
            if not ok:
                player.inventory.append(available)
                session.send(inventory.full_message(reason, result))
                return
            session.send(f"&WYou craft {result} from Medicinal Herbs!&x")

        session.send(f"You begin crafting {result} from Medicinal Herbs...")
        session.start_timed_action("crafting", CRAFT_DELAY_SECONDS, finish_pill)
        return

    if not data_crafting.can_craft(player):
        session.send(
            f"You need to be a Bukijutsu user of level {data_crafting.CRAFTING_BUKIJUTSU_MIN_LEVEL}+, "
            f"or any class at level {data_crafting.CRAFTING_GENERAL_MIN_LEVEL}+, to craft."
        )
        return

    if len(args) < 3 or args[0].lower() not in ("weapon", "armor"):
        session.send("Usage: craft tool <rod|axe|pickaxe> <iron|steel|chakra> | craft weapon <type> <name> | craft armor <slot> <name> | craft pill <antidote|medicine> <level>")
        return

    kind = args[0].lower()
    if kind == "weapon":
        if args[1].lower() not in data_weapons.WEAPON_TYPES:
            session.send(f"That's not a real weapon type. Choose from: {', '.join(sorted(data_weapons.WEAPON_TYPES))}.")
            return
        sub_type = args[1].lower()
    else:
        if args[1].lower() not in olc.ARMOR_WEAR_LOCATIONS:
            session.send(f"That's not a real armor slot. Choose from: {', '.join(sorted(olc.ARMOR_WEAR_LOCATIONS))}.")
            return
        sub_type = args[1].lower()

    item_name = " ".join(args[2:])
    if not item_name:
        session.send("You need to give your crafted item a name.")
        return

    if session.is_busy():
        session.send("You're already busy with something.")
        return

    def on_metal(response: str) -> None:
        if response.strip().casefold() == "cancel":
            session.send("You set your tools aside.")
            return
        import gem_inlays
        metal_choice, _, gem_choice = response.strip().casefold().partition(" with ")
        metal = data_crafting.equipment_metal_material(metal_choice)
        if metal is None:
            session.send("Choose iron, steel or chakra steel (or cancel).")
            return
        if player.primary_class != "bukijutsu" and metal != "iron ingot":
            session.send("Only Bukijutsu masters can craft Steel and Chakra Steel equipment.")
            return

        selected_gem = None
        gem_key = None
        if gem_choice.strip():
            selected_gem = gem_inlays.available_cut_gem(player, gem_choice.strip())
            if not selected_gem:
                session.send("You don't carry that cut gem. Use iron/steel/chakra steel with <gem>.")
                return
            gem_key = gem_inlays.gem_from_cut_item(selected_gem)
            required_gem_level = min(level for output, level, _xp in gemcutter.RECIPES.values()
                                     if output.casefold() == selected_gem.casefold())
            if jobs.get_job_level(player, "gemcutter") < required_gem_level:
                session.send(f"That gem requires Gemcutter level {required_gem_level} to inlay.")
                return
        # Item names are saved as strings. Reject duplicate object names so
        # gemstone inlays cannot accidentally change another player's gear.
        if any(p.get("short_desc", "").casefold() == item_name.casefold()
               for p in olc.OBJECT_TEMPLATES.values()):
            session.send("That item name is already in use. Choose a unique forged-item name.")
            return

        def ingots():
            return [item for item in player.inventory
                    if data_crafting.find_material(item.casefold()) == metal]

        if len(ingots()) < 2:
            session.send(f"Forging requires two {metal}s, no wood.")
            return
        if not jobs.try_deduct_action_stamina(player):
            session.send("You don't have enough stamina.")
            return

        def resolve():
            material_items = ingots()
            if len(material_items) < 2:
                session.send("You no longer have two matching metal ingots. The craft fails.")
                return
            if selected_gem and selected_gem not in player.inventory:
                session.send("You no longer carry the selected cut gem.")
                return
            if any(p.get("short_desc", "").casefold() == item_name.casefold()
                   for p in olc.OBJECT_TEMPLATES.values()):
                session.send("That name was already taken; the forge is cancelled.")
                return
            stat_value = data_crafting.combined_stat_value(metal, metal)
            vnum = _allocate_crafted_item_vnum()
            proto = dict(olc.DEFAULT_OBJECT_FIELDS)
            proto["keywords"] = item_name.lower().split()
            proto["short_desc"] = item_name
            proto["long_desc"] = f"{item_name} lies here."
            proto["description"] = (f"A crafted {kind} named {item_name}, "
                                    f"forged from {metal} and {metal}.")
            proto["craft_materials"] = [metal, metal]
            import crafted_provenance
            crafted_provenance.stamp(proto, session)
            if kind == "weapon":
                proto["item_type"] = "weapon"
                proto["weapon_type"] = sub_type
                proto["wear_loc"] = "wielded"
                proto["stat_bonuses"] = {"hitroll": stat_value, "damroll": stat_value}
            else:
                proto["item_type"] = "armor"
                proto["wear_loc"] = sub_type
                proto["stat_bonuses"] = {"armor_class": -stat_value}

            if gem_key:
                proto["gem_inlay"] = gem_key

            # Do not consume ingredients unless the resulting item fits.
            # Revert the new prototype if the inventory is at capacity.
            ok, reason = inventory.add_item(player.inventory, item_name)
            if not ok:
                session.send(inventory.full_message(reason, item_name))
                return
            for item in material_items[:2]:
                player.inventory.remove(item)
            if selected_gem:
                player.inventory.remove(selected_gem)
            olc.OBJECT_TEMPLATES[vnum] = proto
            inlay_note = f" with a Cut {gem_key.title()} inlay" if gem_key else ""
            session.send(f"&WYou craft {rarity_colored_name(item_name)} from two {metal}s{inlay_note}!&x")
            import world_autosave
            world_autosave.mark_dirty()

        session.send(f"You start forging {item_name} with two {metal}s"
                     + (f" and {selected_gem}" if selected_gem else "") + "...")
        session.start_timed_action("crafting", CRAFT_DELAY_SECONDS, resolve)

    session.enter_single_line(
        "Choose metal: iron, steel or chakra steel. Optional: iron with ruby (or cancel)".format(kind=kind),
        on_metal)



def cmd_give(session, args: List[str]) -> None:
    """Gives an item from inventory to another player in the same
    room, OR to the player's own shopkeeper mob (Section 75 player
    shops) if no matching player is found -- adding it to that shop's
    stock, unpriced until 'price' sets what it sells for. The main
    other use case: trading crafting materials (fishing.CRAFTING_RECIPES)
    that have no gathering job to produce them yet -- a player who has
    one can hand it to someone crafting a rod."""
    import currency_piles
    if currency_piles.is_give_command(args):
        currency_piles.give(session, args)
        return
    player = session.player
    if len(args) < 2:
        session.send("Usage: give <item> <player name> | give <amount> ryo <player>")
        return

    target_query = args[-1].lower()
    target_session = next(
        (
            s for s in session.active_sessions()
            if s is not session and s.player and s.player.room_vnum == player.room_vnum
            and target_query in s.player.name.lower()
        ),
        None,
    )

    item_query = " ".join(args[:-1]).lower()

    if not target_session:
        shopkeeper = next(
            (m for m in combat.mobs_in_room(player.room_vnum)
             if m.player_shop_owner == player.name and target_query in m.name.lower()),
            None,
        )
        if shopkeeper:
            if len(player.shop_stock) >= config.PLAYER_SHOP_MAX_ITEMS:
                session.send(f"Your shop is full -- it can only hold {config.PLAYER_SHOP_MAX_ITEMS} items at once.")
                return
            match = find_indexed_item(item_query, player.inventory)
            if not match:
                session.send("You aren't carrying that.")
                return
            if match.endswith(" [glued]"):
                session.send("That item is glued to you and cannot be given away.")
                return
            import crafted_provenance
            if crafted_provenance.denied(match, player, session=session):
                session.send(crafted_provenance.DENIED)
                return
            player.inventory.remove(match)
            player.shop_stock.append({"item_name": match, "price": None,
                                      "item_vnum": playershops.item_vnum_for_stock(match)})
            session.send(
                f"You give {rarity_colored_name(match)} to your shopkeeper. "
                f"Use 'price {match.split()[-1]} <amount>' to set what it sells for."
            )
            return
        # NPC give_prog: hand an item to a real mob with a matching
        # give trigger. Player-shop stock transfers above stay unchanged.
        scripted_mob = next(
            (m for m in combat.mobs_in_room(player.room_vnum)
             if target_query in m.name.lower()
             and any(p.get("trigger") == "give"
                     for p in combat.MOB_TEMPLATES.get(m.template_vnum, {}).get("mob_programs", ()))),
            None,
        )
        if scripted_mob:
            match = find_indexed_item(item_query, player.inventory)
            if not match:
                session.send("You aren't carrying that.")
                return
            if match.endswith(" [glued]"):
                session.send("That item is glued to you and cannot be given away.")
                return
            prototype = _find_object_prototype_by_name(match)
            obj_vnum = next((v for v, template in olc.OBJECT_TEMPLATES.items()
                             if template is prototype), 0)
            player.inventory.remove(match)
            session.send(f"You give {rarity_colored_name(match)} to {scripted_mob.name}.")
            old_vnum = getattr(session, "_mudprog_object_vnum", 0)
            old_name = getattr(session, "_mudprog_object_name", "")
            session._mudprog_object_vnum = obj_vnum
            session._mudprog_object_name = match
            try:
                template = combat.MOB_TEMPLATES.get(scripted_mob.template_vnum, {})
                programs.fire_programs(session, template.get("mob_programs", ()),
                                       "give", speaker_name=scripted_mob.name.capitalize(), mob=scripted_mob)
            finally:
                session._mudprog_object_vnum = old_vnum
                session._mudprog_object_name = old_name
            return
        session.send("There's no one here by that name.")
        return

    match = find_indexed_item(item_query, player.inventory)
    if not match:
        session.send("You aren't carrying that.")
        return
    if match.endswith(" [glued]"):
        session.send("That item is glued to you and cannot be given away.")
        return

    import crafted_provenance
    if (crafted_provenance.denied(match, player, session=session)
            or crafted_provenance.denied(match, target_session.player, session=target_session)):
        session.send(crafted_provenance.DENIED)
        return
    ok, reason = inventory.add_item(target_session.player.inventory, match)
    if not ok:
        session.send(f"{target_session.player.name} has no room for that.")
        return
    player.inventory.remove(match)
    session.send(f"You give {rarity_colored_name(match)} to {target_session.player.name}.")
    target_session.send(f"{player.name} gives you {rarity_colored_name(match)}.")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} gives {match} to {target_session.player.name}.", exclude=(target_session,))


def cmd_price(session, args: List[str]) -> None:
    """Sets the sell price for an item already given to the player's
    own shopkeeper (Section 75 player shops). Applies to every
    matching, currently-unpriced entry in shop_stock at once -- if
    several of the same item were given before any of them had a
    price, one 'price' call sets them all rather than requiring one
    call per instance."""
    player = session.player
    if player.shop_room_vnum is None:
        session.send("You don't own a shop.")
        return
    if len(args) < 2 or not args[-1].isdigit():
        session.send("Usage: price <item> <amount>")
        return

    amount = int(args[-1])
    if amount <= 0:
        session.send("Price must be a positive amount.")
        return
    item_query = " ".join(args[:-1]).lower()

    matches = [entry for entry in player.shop_stock
               if entry["price"] is None and _item_matches(item_query, playershops.stock_item_name(entry))]
    if not matches:
        matches = [entry for entry in player.shop_stock if _item_matches(item_query, playershops.stock_item_name(entry))]
    if not matches:
        session.send("You don't have that in your shop's stock.")
        return

    for entry in matches:
        entry["price"] = amount
    session.send(f"You set the price of {playershops.stock_item_name(matches[0])} to {amount:,} ryo.")


def cmd_shop(session, args: List[str]) -> None:
    """Renames/redescribes the player's own shop (only while standing
    inside it, matching 'apartment name'/'apartment desc'), or with no
    arguments shows its current stock and prices."""
    player = session.player
    if player.shop_room_vnum is None:
        session.send("You don't own a shop.")
        return

    if not args:
        if not player.shop_stock:
            session.send("Your shop's stock is empty.")
            return
        lines = ["&WYour shop's stock:&x"]
        for entry in player.shop_stock:
            price_str = f"{entry['price']:,} ryo" if entry["price"] is not None else "no price set"
            lines.append(f"  {rarity_colored_name(playershops.stock_item_name(entry))} - {price_str}")
        session.send("\n".join(lines))
        return

    if player.room_vnum != player.shop_room_vnum:
        session.send("You have to be standing inside your own shop to rename or redescribe it.")
        return

    subcommand = args[0].lower()
    room = WORLD.get(player.shop_room_vnum)
    if subcommand == "name" and len(args) > 1:
        new_name = " ".join(args[1:])
        player.shop_name = new_name
        if room:
            room.name = new_name
        session.send(f"Your shop is now named '{new_name}'.")
        return
    if subcommand in ("desc", "description") and len(args) > 1:
        new_desc = " ".join(args[1:])
        player.shop_description = new_desc
        if room:
            room.description = new_desc
        session.send("Your shop's description has been updated.")
        return

    session.send("Usage: shop name <text> | shop desc <text> | shop (with no arguments to see stock)")




def cmd_bribe(session, args: List[str]) -> None:
    """Offer real ryo to a mob with a bribe-trigger program."""
    if len(args) < 2 or not args[0].isdigit():
        session.send("Usage: bribe <ryo amount> <mob name>")
        return
    amount = int(args[0])
    if not 1 <= amount <= 1000000:
        session.send("Offer between 1 and 1,000,000 ryo.")
        return
    query = " ".join(args[1:]).lower().strip()
    player = session.player
    mob = next(
        (m for m in combat.mobs_in_room(player.room_vnum)
         if query in m.name.lower()
         and any(p.get("trigger") == "bribe"
                 for p in combat.MOB_TEMPLATES.get(m.template_vnum, {}).get("mob_programs", ()))),
        None,
    )
    if not mob:
        session.send("No NPC here accepts a bribe by that name.")
        return
    if player.ryo < amount:
        session.send("You don't have enough ryo.")
        return
    player.ryo -= amount
    old = getattr(session, "_mudprog_bribe", 0)
    session._mudprog_bribe = amount
    try:
        session.send(f"You offer {amount:,} ryo to {mob.name}.")
        template = combat.MOB_TEMPLATES.get(mob.template_vnum, {})
        programs.fire_programs(session, template.get("mob_programs", ()),
                               "bribe", speaker_name=mob.name.capitalize(), mob=mob)
    finally:
        session._mudprog_bribe = old

def cmd_drop(session, args: List[str]) -> None:
    """Drops one item, or everything, onto the ground in the current
    room -- 'drop <item>' for one, 'drop all' (or the literal command
    'drop.all', registered as its own alias) for everything at once.
    Dropped items land in Room.ground_items and can be picked back up
    with 'get', not just discarded -- a drop mechanic with no way to
    retrieve what you dropped would be a dead end, not a feature."""
    import currency_piles
    if currency_piles.is_drop_command(args):
        currency_piles.drop(session, args)
        return
    player = session.player
    room = WORLD.get(player.room_vnum)
    if any(item.endswith(" [glued]") for item in player.inventory) and (not args or args[0].lower() == "all"):
        session.send("Remove your glued items before dropping everything.")
        return

    if not args or args[0].lower() == "all":
        if not player.inventory:
            session.send("You aren't carrying anything.")
            return
        dropped = list(player.inventory)
        player.inventory.clear()
        room.ground_items.extend(dropped)
        counts = inventory.slot_counts(dropped)
        summary = ", ".join(
            f"{name} (x{count})" if count > 1 else name for name, count in counts.items()
        )
        session.send(f"You drop everything you were carrying: {summary}.")
        import room_actions
        room_actions.bulk_items(session, len(dropped), "drops", dropped[0] if len(dropped) == 1 else None)
        return

    query = " ".join(args).lower()
    match = find_indexed_item(query, player.inventory)
    if not match:
        session.send("You aren't carrying that.")
        return
    if match.endswith(" [glued]"):
        session.send("That item is glued to you and cannot be dropped.")
        return

    player.inventory.remove(match)
    room.ground_items.append(match)
    session.send(f"You drop {rarity_colored_name(match)}.")
    import room_actions
    room_actions.bulk_items(session, 1, "drops", match)


def cmd_get(session, args: List[str]) -> None:
    """Picks up one item lying on the ground in the current room
    (dropped via 'drop'), subject to the same inventory stacking caps
    as everything else (inventory.py). Per direct confirmation
    (Section 158): 'get <item> from <backpack>' instead takes an item
    OUT of a real backpack container and into ordinary inventory --
    detected by a literal ' from ' in the args, matching the
    confirmed real command syntax exactly."""
    player = session.player
    if not args:
        session.send("Get what?")
        return

    full_query = " ".join(args).lower()
    if " from " in full_query:
        item_query, _, backpack_query = full_query.partition(" from ")
        _get_from_backpack(session, item_query.strip(), backpack_query.strip())
        return

    import currency_piles
    if currency_piles.is_get_command(full_query):
        currency_piles.pickup(session, full_query)
        return

    room = WORLD.get(player.room_vnum)

    # "get all" picks up every portable object on the floor, while
    # "get all sardine" limits the pickup to matching ground items.
    # Ryo remains a separate currency pile and occupies no inventory slot.
    if full_query == "all" or full_query.startswith("all "):
        keyword = full_query[4:].strip() if full_query != "all" else ""
        candidates = [
            item for item in list(room.ground_items)
            if not keyword or _item_matches(keyword, item)
        ]
        picked = []
        fixed = 0
        full = 0
        denied_count = 0
        import crafted_provenance
        for item in candidates:
            if _has_no_take_flag(item):
                fixed += 1
                continue
            if crafted_provenance.denied(item, player, session=session):
                denied_count += 1
                continue
            ok, _reason = inventory.add_item(player.inventory, item)
            if not ok:
                full += 1
                continue
            room.ground_items.remove(item)
            picked.append(item)

        has_ryo = full_query == "all" and bool(getattr(room, "ground_ryo", []))
        if picked:
            counts = inventory.slot_counts(picked)
            details = ", ".join(
                f"{rarity_colored_name(name)} x{count}"
                for name, count in counts.items()
            )
            session.send(f"You pick up {len(picked)} item(s): {details}.")
            import room_actions
            room_actions.bulk_items(session, len(picked), "picks up", picked[0] if len(picked) == 1 else None)
        if has_ryo:
            currency_piles.pickup(session, "all ryo")
        if not picked and not has_ryo:
            session.send("There is nothing here you can pick up.")
        if full or fixed or denied_count:
            session.send(
                f"Left behind: {full} item(s) due to inventory limits, "
                f"{fixed} fixed decoration(s), {denied_count} alt-locked crafted item(s)."
            )
        return

    query = full_query
    match = find_indexed_item(query, room.ground_items)
    if not match:
        import room_jutsu_objects
        jutsu_object = room_jutsu_objects.find(room, query)
        if jutsu_object:
            session.send(f"{jutsu_object.name} is a lingering jutsu effect; you cannot pick it up.")
            return
        session.send("You don't see that here.")
        return
    if _has_no_take_flag(match):
        session.send(f"{rarity_colored_name(match)} won't budge -- it's fixed in place.")
        return
    import crafted_provenance
    if crafted_provenance.denied(match, player, session=session):
        session.send(crafted_provenance.DENIED)
        return

    ok, reason = inventory.add_item(player.inventory, match)
    if not ok:
        session.send(inventory.full_message(reason, match))
        return
    room.ground_items.remove(match)
    session.send(f"You pick up {rarity_colored_name(match)}.")
    import room_actions
    room_actions.bulk_items(session, 1, "picks up", match)


def _find_backpack_position(player, backpack_query: str):
    """Per direct confirmation (Section 158): resolves which real,
    specific backpack a query refers to -- by its own real, current
    position in player.inventory (raw position tracking, a confirmed,
    accepted design). Returns (position, item_name) or (None, None) if
    no real container item matches. A "container" here means any real
    item whose own oset prototype has a genuine container_capacity > 0
    -- confirmed directly this should work for ANY item set up this
    way, not just a fixed, hardcoded "backpack" item."""
    index, keyword = inventory.parse_indexed_query(backpack_query)
    candidates_with_positions = []
    for position, item_name in enumerate(player.inventory):
        if not _item_matches(keyword, item_name):
            continue
        proto = _find_object_prototype_by_name(item_name)
        if proto and proto.get("container_capacity", 0) > 0:
            candidates_with_positions.append((position, item_name))
    if index > len(candidates_with_positions) or index < 1:
        return None, None
    return candidates_with_positions[index - 1]


def cmd_put(session, args: List[str]) -> None:
    """'put <item> in <backpack>' -- per direct confirmation (Section
    158): moves an item from ordinary inventory INTO a real container
    item's own separate contents, which don't count against the
    normal 20-slot inventory cap at all. The backpack itself is
    resolved by its own real, current inventory position (see
    _find_backpack_position) -- raw position tracking, a confirmed,
    accepted design."""
    player = session.player
    full_query = " ".join(args).lower()
    if " in " not in full_query:
        session.send("Usage: put <item> in <backpack>")
        return

    item_query, _, backpack_query = full_query.partition(" in ")
    item_query, backpack_query = item_query.strip(), backpack_query.strip()

    position, backpack_name = _find_backpack_position(player, backpack_query)
    if position is None:
        session.send("You aren't carrying a container by that name.")
        return

    item_index, item_keyword = inventory.parse_indexed_query(item_query)
    item_matches = [i for i, name in enumerate(player.inventory) if _item_matches(item_keyword, name)]
    if item_index > len(item_matches) or item_index < 1:
        session.send("You aren't carrying that.")
        return
    item_position = item_matches[item_index - 1]
    match = player.inventory[item_position]
    if match.endswith(" [glued]"):
        session.send("That item is glued to you and cannot be stored.")
        return
    if item_position == position:
        session.send("You can't put a container inside itself.")
        return

    proto = _find_object_prototype_by_name(backpack_name)
    capacity = proto.get("container_capacity", 0) if proto else 0
    contents = player.backpack_contents.setdefault(str(position), [])
    if len(contents) >= capacity:
        session.send(f"{rarity_colored_name(backpack_name)} is full.")
        return

    del player.inventory[item_position]
    # If the item removed came BEFORE the backpack in the list, every
    # later real position (including the backpack's own) just shifted
    # down by one -- re-key backpack_contents to the correct, new
    # position, or this backpack's own contents would silently point
    # at the wrong real slot from here on.
    if item_position < position:
        new_position = position - 1
        if str(position) in player.backpack_contents:
            player.backpack_contents[str(new_position)] = player.backpack_contents.pop(str(position))
        position = new_position
    contents = player.backpack_contents.setdefault(str(position), [])
    contents.append(match)
    session.send(f"You put {rarity_colored_name(match)} in {rarity_colored_name(backpack_name)}.")


def _get_from_backpack(session, item_query: str, backpack_query: str) -> None:
    """The real 'get <item> from <backpack>' branch of cmd_get -- see
    cmd_get's own docstring above."""
    player = session.player
    position, backpack_name = _find_backpack_position(player, backpack_query)
    if position is None:
        session.send("You aren't carrying a container by that name.")
        return

    contents = player.backpack_contents.get(str(position), [])
    item_index, item_keyword = inventory.parse_indexed_query(item_query)
    item_matches = [i for i, name in enumerate(contents) if _item_matches(item_keyword, name)]
    if item_index > len(item_matches) or item_index < 1:
        session.send(f"{rarity_colored_name(backpack_name)} doesn't have that.")
        return
    contents_position = item_matches[item_index - 1]
    match = contents[contents_position]
    import crafted_provenance
    if crafted_provenance.denied(match, player, session=session):
        session.send(crafted_provenance.DENIED)
        return

    ok, reason = inventory.add_item(player.inventory, match)
    if not ok:
        session.send(inventory.full_message(reason, match))
        return
    del contents[contents_position]
    session.send(f"You get {rarity_colored_name(match)} from {rarity_colored_name(backpack_name)}.")
    import room_actions
    room_actions.emit(session, f"{getattr(player, 'name', 'Someone')} takes {match} from {backpack_name}.")


def _item_matches(query: str, item_name: str) -> bool:
    """Word-level match: every word in `query` must appear somewhere in
    `item_name`, not necessarily contiguously. Fixes a real bug found
    while adding crafted item names with a stat-bonus suffix: a plain
    `query in item_name` substring check fails for a query that skips a
    middle word -- 'iron rod' is not a contiguous substring of 'an iron
    fishing rod', even though it's an obviously intended match. Used
    everywhere an item is looked up by a player-typed partial name."""
    item_lower = item_name.lower()
    return all(word in item_lower for word in query.lower().split())


def find_indexed_item(query: str, items):
    """Per direct confirmation (Section 158): "a real general
    N.keyword targeting convention...usable anywhere a name is
    currently typed to target an item." Replaces the extremely
    common real pattern "next((item for item in <list> if
    _item_matches(query, item)), None)" -- a real "N." prefix (e.g.
    "2.kunai") returns the Nth match (1-indexed) in `items`, in the
    order given; a bare query with no real "N." prefix still means
    "the first match", exactly matching every existing caller's
    prior behavior. Returns None if there's no match at that index."""
    index, keyword = inventory.parse_indexed_query(query)
    matches = [item for item in items if _item_matches(keyword, item)]
    if index > len(matches) or index < 1:
        return None
    return matches[index - 1]


def _find_object_prototype_by_name(item_name: str):
    """Reverse lookup: player inventory is plain name strings, not
    linked to a vnum, so to find which oset prototype a carried item
    corresponds to (for scroll_jutsu, etc.) we match on short_desc --
    same substring-match convention used everywhere else in this file."""
    import technique_names
    import scroll_writing
    query = technique_names.scroll_name(scroll_writing.plain_name(item_name)).lower()
    for proto in olc.OBJECT_TEMPLATES.values():
        if query == proto["short_desc"].lower():
            return proto
    for proto in olc.OBJECT_TEMPLATES.values():
        if query in proto["short_desc"].lower() or proto["short_desc"].lower() in query:
            return proto
    return None


def _find_object_vnum_by_name(item_name: str):
    """Same reverse lookup as _find_object_prototype_by_name, but
    returns the vnum itself (needed to check set_vnums membership)."""
    query = item_name.lower()
    for vnum, proto in olc.OBJECT_TEMPLATES.items():
        if query in proto["short_desc"].lower() or proto["short_desc"].lower() in query:
            return vnum
    return None


def _staff_vnum_suffix(session, item_name: str = None, mob=None) -> str:
    """Per direct user feedback ("imms need to see object vnums and
    mobs not just rooms") -- staff_show_vnums previously only affected
    the room header (see cmd_look). Returns " [vnum N]" for a staff
    member with that config on, or "" otherwise (non-staff, staff with
    it off, or -- for an item -- no matching prototype found at all).
    Exactly one of item_name/mob should be passed."""
    player = session.player
    is_staff = session.account is not None and session.account.staff_level != "player"
    if not is_staff or not player.staff_show_vnums:
        return ""
    if mob is not None:
        return f" &D[vnum {mob.template_vnum}]&x"
    vnum = _find_object_vnum_by_name(item_name)
    return f" &D[vnum {vnum}]&x" if vnum is not None else ""

def equipped_set_bonus_percent(player) -> int:  # player: Player or combat.Mob -- both share the same real .equipment shape
    """Sum of set_bonus_percent, once per DISTINCT completed set, not
    once per piece -- a 3-piece set worth 25% gives +25% total when all
    three are worn, not +75%. Multiple pieces of the same set all
    resolve to the same set (identified by the full group of vnums:
    each piece's own vnum plus its declared set_vnums), so they're only
    counted once; wearing a second, unrelated completed set would add
    its own bonus on top. An item with no set_vnums (the vast majority)
    contributes nothing. Applied to derived combat stats -- see
    derived_stats.py."""
    equipped_vnums = set()
    resolved = []
    for item_name in player.equipment.values():
        vnum = _find_object_vnum_by_name(item_name)
        if vnum is not None:
            equipped_vnums.add(vnum)
            resolved.append(vnum)

    completed_sets = {}  # frozenset of the set's full vnum group -> bonus_percent
    for vnum in resolved:
        proto = olc.OBJECT_TEMPLATES.get(vnum)
        if not proto or not proto.get("set_vnums"):
            continue
        required = {int(v) for v in proto["set_vnums"]}
        full_group = frozenset(required | {vnum})
        if required.issubset(equipped_vnums):
            completed_sets[full_group] = proto.get("set_bonus_percent", 25)
    return sum(completed_sets.values())


def _fire_item_trigger(session, item_name: str, trigger: str) -> None:
    """Fires an item's programs matching `trigger` (wear or get). Looks
    up the item's prototype via the same reverse short_desc match used
    for rarity/scrolls/set bonuses."""
    proto = _find_object_prototype_by_name(item_name)
    if proto and proto.get("item_programs"):
        programs.fire_programs(session, proto["item_programs"], trigger, speaker_name=proto["short_desc"])


CRAFT_BONUS_PATTERN = re.compile(r"\(\+(\d+) ([\w ]+)\)$")


def strip_crafted_suffix(item_name: str) -> str:
    """The base item name with any craft_stat_bonus_suffix stripped
    off (e.g. 'An Iron Fishing Rod (+3 Hitroll)' -> 'An Iron Fishing
    Rod'). Needed anywhere a crafted item's name is looked up against
    a plain, unsuffixed name-keyed dict (fishing.RODS, mining.PICKAXES,
    lumberjack.AXES, farming.HOES, cooking.POTS) -- those dicts only
    know the plain recipe output name and have no reason to know
    about every possible bonus suffix a crafted instance might carry,
    so a suffixed name would otherwise never match at all."""
    return re.sub(r" \(\+\d+ [A-Za-z ]+\)$", "", tool_durability.base_name(item_name))


def craft_stat_bonus_suffix(bonus: int, stat: str = "hitroll") -> str:
    """Bakes a crafted item's stat bonus into its own name text, since
    inventory items are plain strings in this project rather than
    per-instance objects with their own stat fields -- e.g. 'An Iron
    Fishing Rod (+3 Hitroll)'. `stat` names WHICH stat (a recipe's own
    "stat" field -- crafting.py -- so a future crafting job can use a
    different one, e.g. "armor_class" for smithed gear, rendered as
    "Armor Class"). Empty string for a zero bonus, so a plain
    (unenchanted) craft doesn't grow an empty '(+0 Hitroll)' tag."""
    return f" (+{bonus} {stat.replace('_', ' ').title()})" if bonus > 0 else ""


def parse_crafted_bonus(item_name: str, stat_key: str) -> int:
    """The other direction of craft_stat_bonus_suffix -- extracts a
    crafted item's own stat bonus back out of its display name (e.g.
    'An Iron Fishing Rod (+3 Hitroll)' -> 3 for stat_key='hitroll').
    Returns 0 if no matching suffix is present. This is what makes a
    crafted weapon/armor's bonus actually DO something in combat,
    rather than being purely cosmetic text on the item name -- see
    equipped_weapon_hitroll_bonus/equipped_armor_class_bonus below,
    which use this to feed real combat calculations."""
    stat_display = re.escape(stat_key.replace("_", " ").title())
    match = re.search(rf"\(\+(\d+) {stat_display}\)", item_name)
    return int(match.group(1)) if match else 0


def equipped_weapon_hitroll_bonus(player) -> int:  # player: Player or combat.Mob
    """Total hitroll granted by worn gear, not only the wielded weapon.

    Kage legendary masks, cloaks and rings have always declared bonuses
    on stat_bonuses, but the legacy code only honored weapon prototypes.
    Weapon craft suffixes remain supported. Resolve dynamically so even
    existing equipped items benefit immediately without editing saves.
    """
    total = 0
    for slot, name in player.equipment.items():
        if not name:
            continue
        proto = _find_object_prototype_by_name(name)
        if proto:
            total += proto.get("stat_bonuses", {}).get("hitroll", 0)
        if slot == "wielded":
            total += parse_crafted_bonus(name, "hitroll")
    import gem_inlays
    return total + gem_inlays.equipment_flat_bonus(player)


def equipped_weapon_damroll_bonus(player) -> int:  # player: Player or combat.Mob
    """Total damage-roll bonuses across all worn equipment.

    Armor/jewelry Kage rewards declare these stat bonuses; they must
    count in combat as well as weapon prototype bonuses.
    """
    import gem_inlays
    return sum(
        (proto.get("stat_bonuses", {}).get("damroll", 0) if proto else 0)
        for name in player.equipment.values() if name
        for proto in [_find_object_prototype_by_name(name)]
    ) + gem_inlays.equipment_flat_bonus(player)


def equipped_armor_class_bonus(player) -> int:  # player: Player or combat.Mob
    """Armor protection in points, subtracted from actual lower-is-better AC.

    Old Kage items express protection as -armor_class (a lower AC).
    Most other items/headbands express protection as a +N bonus which
    the caller subtracts from AC. Normalize *both* conventions to a
    positive protection value, so -10 and +10 both grant 10 AC points.
    Crafted '(+N Armor Class)' name-suffix bonuses remain supported.
    """
    total = 0
    for slot, item_name in player.equipment.items():
        if slot == "wielded" or not item_name:
            continue
        proto = _find_object_prototype_by_name(item_name)
        prototype_bonus = proto.get("stat_bonuses", {}).get("armor_class", 0) if proto else 0
        total += abs(prototype_bonus) + parse_crafted_bonus(item_name, "armor_class")
    return total


def reduce_weapon_damage(defender, weapon_type: str, damage: int) -> int:
    """Apply each worn armor piece's resistance to the incoming weapon type.

    Multiplying the remaining fractions lets armor stack without simple
    addition exceeding 100%. AC still handles the chance to be hit.
    """
    if not weapon_type or weapon_type not in data_weapons.WEAPON_TYPES or damage <= 0:
        return damage
    remaining, divisor = damage, 1
    for slot, item_name in defender.equipment.items():
        if slot not in olc.ARMOR_WEAR_LOCATIONS or not item_name:
            continue
        proto = _find_object_prototype_by_name(item_name)
        percent = proto.get("weapon_resistances", {}).get(weapon_type, 0) if proto else 0
        if percent:
            remaining *= 100 - max(0, min(100, percent))
            divisor *= 100
    return remaining // divisor


def equipped_weapon_type_damage_bonus(player) -> int:  # player: Player or combat.Mob
    """The wielded item's set base damage, or the weapon type default."""
    wielded = player.equipment.get("wielded", "")
    if not wielded:
        return 0
    proto = _find_object_prototype_by_name(wielded)
    if proto:
        return data_weapons.item_base_damage(proto)
    weapon_type = data_weapons.weapon_type_for_item(wielded)
    return data_weapons.weapon_damage_bonus(weapon_type) if weapon_type else 0


def parse_crafted_stat_bonus(item_name: str, stat: str = "hitroll") -> int:
    """The inverse of craft_stat_bonus_suffix() -- reads the bonus for
    `stat` back out of an item's name text. 0 if the item has no such
    suffix, or its suffix names a different stat."""
    match = CRAFT_BONUS_PATTERN.search(item_name)
    if not match:
        return 0
    amount, matched_stat = match.groups()
    expected_stat_text = stat.replace("_", " ").title()
    if matched_stat != expected_stat_text:
        return 0
    return int(amount)


def parse_crafted_hitroll_bonus(item_name: str) -> int:
    """Thin alias of parse_crafted_stat_bonus for the hitroll case --
    kept since it's the only stat actually wired to matter anywhere
    today (the score sheet's Hit Roll)."""
    return parse_crafted_stat_bonus(item_name, "hitroll")


def rarity_colored_name(item_name: str) -> str:
    """The single shared function for showing an item's name, used
    wherever an item name is shown to a player: inventory, equipment,
    shop listings, buy/wield confirmations, ground items, and so on.
    Per direct confirmation (Section 149): "remove all tags of items
    from common all the way to legendary..just hide them for now or
    they only show when you examine the item" -- this now returns
    the plain, uncolored name everywhere. The real, tagged/colored
    display (a bracketed rarity tag cycling through that tier's own
    colors, e.g. "[Legendary] a legendary blade") still exists, but
    only in cmd_examine's own dedicated view -- see
    _examine_rarity_colored_name below."""
    import lightsabers
    import ninja_arts
    clean_name = ninja_arts.base_item(item_name)
    themed = legendary_items.styled_name(clean_name)
    return themed if themed is not None else lightsabers.display_name(clean_name)


def _examine_rarity_colored_name(item_name: str) -> str:
    """Plain-name compatibility alias; Examine no longer displays rarity."""
    return rarity_colored_name(item_name)


_CHAKRA_PAPER_REACTIONS = {
    "fire": "curls up and bursts into ash in your hand",
    "water": "goes damp and limp, water beading across its surface",
    "wind": "splits cleanly down the middle",
    "earth": "crumbles into fine dust",
    "lightning": "wrinkles and puckers all over",
}


CHAKRA_NATURE_MIN_LEVEL = 10
CHAKRA_NATURE_SECONDARY_MIN_LEVEL = data_kekkei_genkai.ELEMENTAL_RELEASE_REVEAL_LEVEL
CHAKRA_NATURE_TERTIARY_MIN_LEVEL = 100


def cmd_channel(session, args: List[str]) -> None:
    """Consume paper to reveal the first nature at 10 or third at 100.

    The distinct second nature is chosen at level 25 in a protected
    Kage chamber; channeling a second paper consumes the sheet before
    opening the choice. Existing revealed second natures remain valid.
    """
    player = session.player
    if not args:
        session.send("Channel what?")
        return
    query = " ".join(args).lower()
    match = find_indexed_item(query, player.inventory)
    if not match:
        session.send(f"You aren't carrying anything like '{query}'.")
        return

    proto = _find_object_prototype_by_name(match)
    if not proto or "chakra paper" not in match.lower():
        session.send(f"You can't channel chakra into {match}.")
        return

    if player.chakra_nature_tertiary_revealed:
        session.send(
            f"You channel a thread of your own chakra into {match}, but nothing happens -- "
            f"you've already learned everything about your own chakra nature that there is to know."
        )
        return

    revealing_tertiary = player.chakra_nature_secondary_revealed
    revealing_secondary = player.chakra_nature_revealed and not revealing_tertiary
    min_level = (CHAKRA_NATURE_TERTIARY_MIN_LEVEL if revealing_tertiary else
                 CHAKRA_NATURE_SECONDARY_MIN_LEVEL if revealing_secondary else CHAKRA_NATURE_MIN_LEVEL)

    if player.level < min_level:
        session.send(
            f"You channel a thread of your own chakra into {match}, but nothing happens -- "
            f"your own chakra is still too raw and unrefined to reveal anything yet. "
            f"(Requires level {min_level}; you are level {player.level}.)"
        )
        return

    if revealing_secondary:
        import element_choice
        if not element_choice.start_with_paper(session, match):
            session.send("Your village's Kage chamber is unavailable. Contact an administrator.")
        return

    player.inventory.remove(match)

    if revealing_tertiary:
        player.chakra_nature_tertiary = biomes.roll_tertiary_chakra_nature(
            player.chakra_nature, player.chakra_nature_secondary)
        player.chakra_nature_tertiary_revealed = True
        import data_kekkei_genkai
        data_kekkei_genkai.sync_elemental_release(player)
        nature = player.chakra_nature_tertiary
        reaction = _CHAKRA_PAPER_REACTIONS.get(nature, "reacts, but nothing seems to happen")
        release = player.elemental_release_id
        session.send(
            f"You channel a thread of your own chakra into {match}...\n"
            f"The paper {reaction}!\n"
            f"&WYour third chakra nature is {nature.capitalize()}.&x"
            + (f"\n&YYour natures form {data_kekkei_genkai.ELEMENTAL_RELEASE_NAMES[release]}!&x" if release else "")
        )
        return

    if player.chakra_nature is None:
        # A character created before chakra nature existed at all --
        # confirmed design: roll one right now, on the spot, using the
        # exact same mechanism chargen itself uses, rather than
        # crashing (nature.capitalize() on a None) or defaulting to a
        # fixed element for everyone in this situation.
        player.chakra_nature = biomes.roll_chakra_nature()
    nature = player.chakra_nature
    reaction = _CHAKRA_PAPER_REACTIONS.get(nature, "reacts, but nothing seems to happen")
    player.chakra_nature_revealed = True
    session.send(
        f"You channel a thread of your own chakra into {match}...\n"
        f"The paper {reaction}!\n"
        f"&WYour chakra nature is {nature.capitalize()}.&x"
    )


def cmd_write(session, args: List[str]) -> None:
    """Use the room-description-style editor on one real scroll instance."""
    player = session.player
    if not args:
        session.send("Usage: write <info scroll> (for example: write info scroll)")
        return
    item_query = " ".join(args).lower()
    match = find_indexed_item(item_query, player.inventory)
    if match is None:
        session.send("You must be carrying the scroll you want to write on.")
        return
    proto = _find_object_prototype_by_name(match)
    if (not proto or proto.get("item_type") != "scroll"
            or not proto.get("scroll_message_writable")
            or proto.get("scroll_jutsu")):
        session.send("You can only write on an Info Scroll, not a jutsu-learning scroll.")
        return

    import scroll_writing
    old_note = scroll_writing.inscription(match)

    def save_message(text: str) -> None:
        # A pending trade/staff action might have removed the scroll while
        # its author was editing. Never create a message on a lost item.
        if match not in player.inventory:
            session.send("You no longer have that scroll. Nothing was written.")
            return
        try:
            new_name = scroll_writing.write(match, text, player.name)
        except ValueError as error:
            session.send(str(error))
            return
        slot = player.inventory.index(match)
        player.inventory[slot] = new_name
        storage.save_player(player)
        session.send("Your words are written on this scroll. "
                     "Another player can read them with 'examine <scroll>'.")

    session.enter_editor(
        save_message,
        initial_text=old_note.get("text", "") if old_note else "",
        header="Write your message on the scroll. You may use multiple lines.",
    )


def cmd_read(session, args: List[str]) -> None:
    """Learn a jutsu from a scroll (item_type 'scroll' with a
    scroll_jutsu set via oset) -- an alternate way to obtain a jutsu
    beyond the universal starting kit. The scroll is consumed on a
    successful read; a blank (not yet inscribed) scroll or one teaching
    something already known is not consumed."""
    player = session.player
    if not args:
        session.send("Read what?")
        return
    query = " ".join(args).lower()
    match = find_indexed_item(query, player.inventory)
    if not match:
        session.send(f"You aren't carrying anything like '{query}'.")
        return

    proto = _find_object_prototype_by_name(match)
    if not proto or proto.get("item_type") != "scroll":
        session.send(f"You can't read {match}.")
        return
    if proto.get("scroll_message_writable"):
        session.send("That's an Info Scroll. Use 'examine <scroll>' to view its message "
                     "or 'write <scroll>' to leave one. It doesn't teach jutsu.")
        return

    jutsu_key = proto.get("scroll_jutsu", "")
    import technique_names
    if jutsu_key == technique_names.OLD_KEY:
        jutsu_key = technique_names.NEW_KEY
    if not jutsu_key or jutsu_key not in data_jutsu.JUTSU:
        session.send(f"{match} hasn't been inscribed with a technique yet.")
        return


    jutsu = data_jutsu.JUTSU[jutsu_key]
    display = jutsu["display_name"]
    if jutsu.get("jutsu_type") == "reaper_seal":
        import reaper_seal
        if not reaper_seal.eligible(player):
            session.send("The inscriptions resist your understanding.")
            return
    if display in player.learned_skills:
        session.send(f"You already know {display}.")
        return

    if jutsu_key == "advanced tracking" and player.level < 20:
        session.send("You must be level 20 to study the Advanced Tracking Scroll.")
        return

    player.learned_skills.append(display)
    player.skill_proficiencies[display] = leveling.initial_proficiency(player)
    import skill_training
    skill_training.grant_without_practice(player, display)
    player.inventory.remove(match)
    if jutsu_key == "reaper death seal":
        reverse = data_jutsu.JUTSU["reverse reaper seal"]["display_name"]
        if reverse not in player.learned_skills:
            player.learned_skills.append(reverse)
            player.skill_proficiencies[reverse] = leveling.initial_proficiency(player)
            skill_training.grant_without_practice(player, reverse)
        storage.save_player(player)
    # Scroll grants persist immediately even if the server restarts before
    # its next normal autosave (especially important for rare scrolls).
    storage.save_player(player)
    session.send(f"You study {match} carefully... you have learned &Y{display}&x!")


def cmd_eat(session, args: List[str]) -> None:
    # Take an inventory snapshot: a failed eat is never a room action.
    before = list(session.player.inventory)
    query = " ".join(args)
    import halloween_event
    import seasonal_events
    if halloween_event.consume_candy(session, query):
        pass
    elif seasonal_events.eat_july_fourth_food(session, query):
        pass
    elif seasonal_events.eat_turkey(session, query):
        pass
    else:
        consumables.consume(session, "eat", query)
    import room_actions
    room_actions.consumed(session, before, "eats")


def cmd_drink(session, args: List[str]) -> None:
    before = list(session.player.inventory)
    consumables.consume(session, "drink", " ".join(args))
    import room_actions
    room_actions.consumed(session, before, "drinks")


def cmd_use(session, args: List[str]) -> None:
    import lightsabers
    if lightsabers.use(session, " ".join(args)):
        return
    import seasonal_events
    if seasonal_events.use_fireworks(session, " ".join(args)):
        return
    if seasonal_events.use_holiday_item(session, " ".join(args)):
        return
    before = list(session.player.inventory)
    consumables.consume(session, "use", " ".join(args))
    import room_actions
    room_actions.consumed(session, before, "uses")


# --- Corpses / looting ---------------------------------------------------

def cmd_loot(session, args: List[str]) -> None:
    player = session.player
    query = " ".join(args) if args else None
    corpse = corpses.find_corpse(player.room_vnum, query)
    if not corpse:
        session.send("There is nothing here to loot.")
        return
    if corpse.is_empty():
        session.send(f"{corpse.name.capitalize()} has already been picked clean.")
        return

    ryo_taken = corpses.loot_ryo(player, corpse)
    if ryo_taken:
        session.send(f"You loot {ryo_taken} ryo from {corpse.name}.")
    items_taken = corpses.loot_gear(player, corpse, session=session)
    for item in items_taken:
        session.send(f"You loot {item} from {corpse.name}.")
    if corpse.items:
        session.send(f"&D(Your inventory is full -- some items are still on {corpse.name}.)&x")


def _has_no_sac_flag(item_name: str) -> bool:
    """True if item_name's own prototype carries the no_sac extra_flag
    -- checked by cmd_sacrifice for both a single named item and 'sac
    all', so a staff member can protect a special/quest item from
    being destroyed this way (oset <vnum> extra_flags no_sac)."""
    proto = _find_object_prototype_by_name(item_name)
    return proto is not None and "no_sac" in proto.get("extra_flags", [])


def _has_no_take_flag(item_name: str) -> bool:
    """True if item_name's own prototype carries the no_take
    extra_flag -- checked by cmd_get, per direct request ("make an
    item flag that doesnt allow players to pick the item up...this
    would be used for cosmetic stuff like furniture or signs and
    plants in the room"). Meant for room decoration placed via 'oset
    load <vnum>' or a registered item spawn point (spawnpoint.py) --
    both already write straight into room.ground_items, so a no_take
    item behaves exactly like any other ground item in every other
    way (visible on 'look', listed among the room's items) except
    that 'get' specifically refuses it."""
    proto = _find_object_prototype_by_name(item_name)
    return proto is not None and "no_take" in proto.get("extra_flags", [])


def cmd_sacrifice(session, args: List[str]) -> None:
    """Destroys a corpse (unchanged, see corpses.py) OR an item lying
    on the ground in the current room, in exchange for a small ryo
    reward -- meant as a way to dispose of anything you can't
    otherwise sell (no shop around, or no shop buys that category),
    not as a substitute for 'sell': an item's own reward is
    deliberately half of what selling it would give
    (item_types.base_sell_price), floored at 1 ryo so a real item
    never sacrifices for literally nothing, same reasoning as the
    existing sell-price floor. Corpses are checked first, matching the
    original behavior exactly; ground items are checked as a fallback
    when no corpse matches. Confirmed design: an item still in your
    OWN inventory is never sacrificeable through this command at all
    -- drop it first (or it must already be on the ground).

    'sacrifice all' (per explicit request) sacrifices everything
    currently in the ROOM instead -- every corpse and every ground
    item, all at once, for their combined ryo reward. This was already
    ground-items-only before this change, so it's completely
    unaffected.

    Per explicit request, items can carry a no_sac extra_flag (set via
    'oset <vnum> extra_flags no_sac') to protect specific special
    items from being sacrificed at all -- checked here for both a
    single named item and 'sacrifice all'. Corpses are unaffected by
    no_sac -- it's an item-prototype flag, and a corpse isn't a
    prototype-backed item."""
    player = session.player

    if args and args[0].lower() == "all":
        room = world.WORLD.get(player.room_vnum)
        sacrificed_count = 0
        skipped_count = 0
        before_ryo = player.ryo

        for corpse in list(corpses.corpses_in_room(player.room_vnum)):
            corpses.sacrifice(player, corpse)
            sacrificed_count += 1

        if room:
            remaining_ground = []
            for item in list(room.ground_items):
                if _has_no_sac_flag(item):
                    remaining_ground.append(item)
                    skipped_count += 1
                    continue
                reward = max(1, item_types.base_sell_price(item) // 2)
                player.ryo += reward
                sacrificed_count += 1
            room.ground_items = remaining_ground

        if sacrificed_count == 0:
            if skipped_count:
                session.send("Everything here is protected from sacrifice.")
            else:
                session.send("There is nothing here to sacrifice.")
            return

        ryo_gained = player.ryo - before_ryo
        msg = f"You sacrifice {sacrificed_count} thing(s) here and receive {ryo_gained} ryo."
        if skipped_count:
            msg += f" ({skipped_count} protected item(s) left untouched.)"
        session.send(msg)
        return

    query = " ".join(args) if args else None
    corpse = corpses.find_corpse(player.room_vnum, query)
    if corpse:
        corpse_name = corpse.name
        forfeited_ryo, forfeited_items = corpses.sacrifice(player, corpse)
        msg = f"You sacrifice {corpse_name} and receive {corpses.SACRIFICE_RYO_REWARD} ryo."
        if forfeited_ryo or forfeited_items:
            parts = []
            if forfeited_ryo:
                parts.append(f"{forfeited_ryo} ryo")
            if forfeited_items:
                parts.append(f"{len(forfeited_items)} item(s)")
            msg += f" ({' and '.join(parts)} still on it were forfeited.)"
        session.send(msg)
        return

    if not args:
        session.send("There is nothing here to sacrifice.")
        return

    room = world.WORLD.get(player.room_vnum)
    item_query = " ".join(args).lower()
    match = find_indexed_item(item_query, room.ground_items) if room else None
    if not match:
        session.send("There is nothing here to sacrifice.")
        return
    if _has_no_sac_flag(match):
        session.send(f"{rarity_colored_name(match)} is too special to sacrifice.")
        return

    reward = max(1, item_types.base_sell_price(match) // 2)
    room.ground_items.remove(match)
    player.ryo += reward
    session.send(f"You sacrifice {rarity_colored_name(match)} and receive {reward} ryo.")


def cmd_purge(session, args: List[str]) -> None:
    """Immortal utility (classic ROM/DIKU command, per explicit
    request): deletes every mob, ground item, and corpse in the
    current room at once -- a cleanup tool for staff, not a
    player-facing command. Mobs removed this way still respawn
    normally later if they're a respawning template
    (combat.remove_mob's own behavior, unchanged) -- purge clears the
    room right now, it doesn't permanently depopulate it. Takes no
    argument -- always targets the room the immortal is currently
    standing in, matching 'rset'/'oset'/'mset's own "current room"
    convention rather than requiring a vnum."""
    if not olc._require_builder(session):
        return

    player = session.player
    room = world.WORLD.get(player.room_vnum)

    mob_count = 0
    for mob in list(combat.mobs_in_room(player.room_vnum)):
        combat.remove_mob(mob)
        mob_count += 1

    corpse_count = 0
    for corpse in list(corpses.corpses_in_room(player.room_vnum)):
        corpses.remove_corpse(corpse)
        corpse_count += 1

    item_count = 0
    if room:
        item_count = len(room.ground_items)
        room.ground_items = []

    session.send(
        f"You purge the room: {mob_count} mob(s), {item_count} item(s), "
        f"and {corpse_count} corpse(s) destroyed in a flash of light."
    )


# --- Player preference config ----------------------------------------------

CONFIG_OPTIONS = {
    "auto_loot_ryo": "Automatically loot ryo from corpses you defeat",
    "auto_loot_gear": "Automatically loot items from corpses you defeat",
    "auto_sac_corpse": "Automatically sacrifice each corpse for 1 ryo (forfeiting anything left un-looted on it)",
    "tips": "Show a periodic tip-of-the-day (every 30 minutes)",
}


def cmd_config(session, args: List[str]) -> None:
    player = session.player
    if not args:
        lines = ["&WYour settings:&x"]
        for key, description in CONFIG_OPTIONS.items():
            state = "&Gon&x" if getattr(player, key) else "&Doff&x"
            lines.append(f"  {key:16s} [{state}]  {description}")
        lines.append("Usage: config <name> on|off")
        session.send("\n".join(lines))
        return

    if len(args) != 2 or args[0].lower() not in CONFIG_OPTIONS or args[1].lower() not in ("on", "off"):
        session.send("Usage: config <" + "|".join(CONFIG_OPTIONS.keys()) + "> on|off")
        return

    key = args[0].lower()
    value = args[1].lower() == "on"
    _save_personal_config(session, key, value)


STAFF_CONFIG_OPTIONS = {
    "staff_show_vnums": "Show room vnum/flags in the room header (off gives you a player's-eye view)",
    "staff_notify_reports": "Get a live ping when a player submits a bug report ('report')",
    "staff_notify_ideas": "Get a live ping when a player submits an idea ('idea')",
}


def _save_personal_config(session, key: str, value: bool) -> None:
    """Commit an allowed config toggle immediately, including before logout.

    If the save fails, don't pretend the new preference will survive a
    reconnect. Revert the live setting and show the reason instead.
    """
    player = session.player
    previous = getattr(player, key)
    setattr(player, key, value)
    try:
        storage.save_player(player)
    except OSError as exc:
        setattr(player, key, previous)
        session.send(f"&RUnable to save {key}; its previous value was kept: {exc}&x")
        return
    session.send(f"{key} is now {'on' if value else 'off'} (saved).")


def cmd_colorscheme(session, args: List[str]) -> None:
    """Administrator-only live GLOBAL room colors; auto-saved immediately."""
    if not session.account or session.account.staff_level not in ("administrator", "implementor"):
        session.send("Only administrators and Implementors can change the global room colors.")
        return

    usage = (
        "Usage: colorscheme [show|preview|reset]\\n"
        "       colorscheme name <0-255>\\n"
        "       colorscheme desc <0-255>\\n"
        "       colorscheme exits <0-255>\\n"
        "       colorscheme set <name> <desc> <exits>\\n"
        "Changes take effect instantly and auto-save through crashes and reboots."
    )
    synonyms = {
        "name": "name", "title": "name", "roomname": "name",
        "desc": "desc", "description": "desc", "roomdesc": "desc",
        "exits": "exits", "exit": "exits",
    }
    action = args[0].lower() if args else "show"
    if action in ("show", "preview") and len(args) == 1 or not args:
        pass
    elif action == "reset" and len(args) == 1:
        try:
            ui_palette.reset()
        except OSError as exc:
            session.send(f"&RColor scheme save failed; previous colors remain active: {exc}&x")
            return
        session.send("&GRoom colors reset to Ember & Sand with classic green exits; saved immediately.&x")
    elif action in synonyms and len(args) == 2:
        part = synonyms[action]
        number = _scheme_number(args[1])
        if number is None:
            session.send(usage)
            return
        try:
            ui_palette.set_color(part, number)
        except OSError as exc:
            session.send(f"&RColor scheme save failed; previous colors remain active: {exc}&x")
            return
        session.send(f"&GGlobal {part} color changed to &[{number}]sample&x "
                     f"(&[{number}]) and saved immediately.")
    elif action == "set" and len(args) == 4:
        numbers = [_scheme_number(word) for word in args[1:]]
        if any(value is None for value in numbers):
            session.send(usage)
            return
        try:
            ui_palette.save(dict(zip(("name", "desc", "exits"), numbers)))
        except OSError as exc:
            session.send(f"&RColor scheme save failed; previous colors remain active: {exc}&x")
            return
        session.send("&GAll three global colors changed and saved immediately.&x")
    else:
        session.send(usage)
        return

    palette = ui_palette.current()
    exit_color = ui_palette.EXIT_COLOR
    session.send(
        "&WCurrent GLOBAL room colors (auto-saved):&x\\n"
        f"  Name:        {ui_palette.ROOM_TITLE}Sample Name&x  [{palette['name']}]\\n"
        f"  Description: {ui_palette.ROOM_DESCRIPTION}Sample room text.&x  [{palette['desc']}]\\n"
        f"  Exits:       {exit_color}North East&x  "
        f"[{palette['exits'] if palette['exits'] is not None else 'default &G'}]"
    )
    # Show the actual room using the new colors right away; no movement
    # or world/area rebuild is required.
    cmd_look(session, [])


def _scheme_number(token: str):
    """Accept decimal 0..255, or the familiar &[208] MUD color syntax."""
    token = token.strip()
    if token.startswith("&[") and token.endswith("]"):
        token = token[2:-1]
    if not token.isascii() or not token.isdigit():
        return None
    number = int(token) if len(token) <= 3 else -1
    return number if 0 <= number <= 255 else None


def cmd_staffconfig(session, args: List[str]) -> None:
    """Staff's own, separate config set (STAFF_CONFIG_OPTIONS) --
    distinct from the regular player config command above, per direct
    user request ("staff should have there own configs")."""
    if not olc._require_builder(session):
        return
    player = session.player
    if not args:
        lines = ["&WYour staff settings:&x"]
        for key, description in STAFF_CONFIG_OPTIONS.items():
            state = "&Gon&x" if getattr(player, key) else "&Doff&x"
            lines.append(f"  {key:20s} [{state}]  {description}")
        lines.append("Usage: staffconfig <name> on|off")
        session.send("\n".join(lines))
        return

    if len(args) != 2 or args[0].lower() not in STAFF_CONFIG_OPTIONS or args[1].lower() not in ("on", "off"):
        session.send("Usage: staffconfig <" + "|".join(STAFF_CONFIG_OPTIONS.keys()) + "> on|off")
        return

    key = args[0].lower()
    value = args[1].lower() == "on"
    _save_personal_config(session, key, value)


def _resource_row(label1, color1, cur1, max1, label2="", color2="", cur2=0, max2=0, width=40):
    left_plain = f" {label1}: {cur1} / {max1}"
    pad = " " * max(1, width - len(left_plain))
    left = f" {color1}{label1}: {cur1} / {max1}&x{pad}"
    if not label2:
        return left
    return left + f"{color2}{label2}: {cur2} / {max2}&x"


def _row(label1, val1, label2="", val2="", width=40):
    """Two-column row helper: pads on the PLAIN text length (before color
    codes are added) so columns still line up once colors.render() swaps
    &-codes for invisible ANSI escapes."""
    left_plain = f" {label1}: {val1}"
    pad = " " * max(1, width - len(left_plain))
    left = f" &W{label1}:&x &C{val1}&x{pad}"
    if not label2:
        return left
    return left + f"&W{label2}:&x &C{val2}&x"


def _section(title: str, width: int = 78) -> str:
    return f"&W{'-' * width}&x\n&C{title.center(width)}&x\n&W{'-' * width}&x"


def _format_playtime(total_seconds: float) -> str:
    total_minutes = int(total_seconds // 60)
    hours, minutes = divmod(total_minutes, 60)
    if hours and minutes:
        return f"{hours} hour(s) {minutes} minute(s)"
    if hours:
        return f"{hours} hour(s)"
    return f"{minutes} minute(s)"


def _format_active_effects(effects: dict) -> str:
    """One-line, comma-joined display of every active status effect
    with its remaining duration, same format score's own sheet
    already used before this was extracted -- shared so 'score' and
    the new 'aff' command (see cmd_aff below) can't drift apart."""
    if not effects:
        return "&Gnone&x"
    effect_strs = []
    for name, data in effects.items():
        display = status_effects.EFFECT_DEFS.get(name, {}).get("display_name", name.title())
        if status_effects.EFFECT_DEFS.get(name, {}).get("toggled"):
            effect_strs.append(f"&R{display}&x (&GON&x)")
        else:
            effect_strs.append(f"&R{display}&x (&C{data['duration']}&x pulse(s) left)")
    return ", ".join(effect_strs)


def _score_plain_length(text: str) -> int:
    """Visible terminal width excluding NindoMUD's colour markup."""
    return len(re.sub(r"&(?:\[\d+\]|.)", "", str(text)))


def _score_fields(*fields, width: int = 78) -> List[str]:
    """Adaptive 1–3 column score rows; preserve complete long values.

    Every cell pads by its visible rather than escape-coded length. If a
    value doesn't fit its column, it gets a full-width line of its own.
    """
    count = len(fields)
    col_widths = [width // count] * count
    for i in range(width % count):
        col_widths[i] += 1
    cells = []
    for field in fields:
        label, value = field[:2]
        color = field[2] if len(field) > 2 else "&C"
        plain = f" {label}: {value}"
        styled = f" &W{label}:&x {color}{value}&x"
        cells.append((plain, styled))
    if any(_score_plain_length(plain) > col_widths[i] for i, (plain, _) in enumerate(cells)):
        # No truncation of custom clan names, long player names, etc.
        return [styled for _, styled in cells]
    return ["".join(styled + " " * (col_widths[i] - _score_plain_length(plain))
                    for i, (plain, styled) in enumerate(cells)).rstrip()]


def _score_section(name: str, width: int = 78) -> str:
    """One line per section instead of a three-line separator block."""
    title = f"[ {name} ] "
    return f"&C{title}&W{'-' * max(0, width - len(title))}&x"


def _score_meter(value: int, maximum: int) -> str:
    """Tiny 5-tick resource bar. Numeric totals always remain visible."""
    fraction = max(0.0, min(1.0, value / maximum)) if maximum > 0 else 0.0
    filled = min(5, max(0, round(fraction * 5)))
    return f"{value}/{maximum} [{'#' * filled}{'.' * (5-filled)}]"


def build_score_lines(p, fighting_name: str, target_staff_level: Optional[str] = None) -> List[str]:
    """Compact, colour-coordinated score, shared by SCORE and player MSTAT.

    Keep the original full set of facts, progression and visibility rules;
    only the presentation changes. Terminal-safe 78-column layout works
    on classic MUD clients without Unicode box-drawing characters.
    """
    width = 78
    rank_cap = leveling.rank_level_cap(p)
    next_xp = leveling.xp_for_next_level(p.level) if p.level < rank_cap else p.experience
    set_bonus = equipped_set_bonus_percent(p)
    stats = derived_stats.compute_all(p, set_bonus)
    tool_item = p.equipment.get("tool")
    if tool_item:
        stats["hit_roll"] += parse_crafted_hitroll_bonus(tool_item)
    stats["hit_roll"] += equipped_weapon_hitroll_bonus(p)
    stats["damage_roll"] += equipped_weapon_damroll_bonus(p)
    stats["armor_class"] -= equipped_armor_class_bonus(p)
    village_full_name = VILLAGES[p.village]["village_name"]

    title = f"{config.MUD_NAME.upper()} CHARACTER SCORE"
    lines = [
        f"&W{'=' * width}&x",
        f"&C{title.center(width)}&x",
        _score_section("SHINOBI PROFILE", width),
    ]
    if target_staff_level and target_staff_level != "player":
        lines.append(f" &M[{target_staff_level.title()}]&x")
    lines += _score_fields(("Name", p.name), ("Village", village_full_name))
    lines += _score_fields(("Rank", p.village_rank.title(), "&Y"),
                           ("Clan", data_clans.display_name(p.clan)),
                           ("Class", p.primary_class.capitalize()))
    lines += _score_fields(("Level", p.level), ("Experience", p.experience),
                           ("Next Level", next_xp))
    lines += _score_fields(("Rank Level Cap", rank_cap),
                           ("Advancement", "Promotion required" if p.level >= rank_cap and rank_cap < leveling.MAX_LEVEL else "Open"))
    lines += _score_fields(("Ryo", p.ryo, "&Y"), ("Age", p.age),
                           ("Play Time", _format_playtime(p.total_play_seconds)))
    lines += _score_fields(("Sex", data_appearance.sex_display(p.sex)),
                           ("Skin Tone", data_appearance.skin_tone_display(p.skin_tone)))
    lines += _score_fields(("Hair Color", data_appearance.hair_color_display(p.hair_color)),
                           ("Eye Color", data_appearance.eye_color_display(p.eye_color)))
    lines += _score_fields(("Build", data_appearance.build_display(p.build)),
                           ("Personality", data_appearance.personality_trait_display(p.personality_trait)))
    if p.reincarnation:
        import reincarnation
        lines += _score_fields(("Reincarnation", reincarnation.display_name(p)),
                               ("Birth Lineage", p.reincarnation_birth_clan.title()))
    nature_fields = []
    if p.chakra_nature_revealed:
        nature_fields.append(("Chakra Nature", p.chakra_nature.capitalize()))
    if p.chakra_nature_secondary_revealed:
        nature_fields.append(("Secondary Nature", p.chakra_nature_secondary.capitalize()))
    if p.chakra_nature_tertiary_revealed:
        nature_fields.append(("Third Nature", p.chakra_nature_tertiary.capitalize()))
    if nature_fields:
        lines += _score_fields(*nature_fields)
    if p.elemental_release_id:
        import data_kekkei_genkai
        lines += _score_fields(("Elemental Release", data_kekkei_genkai.ELEMENTAL_RELEASE_NAMES[p.elemental_release_id]))

    lines.append(_score_section("COMBAT INFORMATION", width))
    lines += _score_fields(
        ("Health", _score_meter(p.health, p.maximum_health), colors.resource_color(p.health, p.maximum_health)),
        ("Chakra", _score_meter(p.chakra, p.maximum_chakra), colors.resource_color(p.chakra, p.maximum_chakra)),
        ("Stamina", _score_meter(p.stamina, p.maximum_stamina), colors.resource_color(p.stamina, p.maximum_stamina)))
    signed = lambda n: f"{n:+d}"
    lines += _score_fields(("Armor Class", stats["armor_class"]),
                           ("Hit Roll", signed(stats["hit_roll"])),
                           ("Damage Roll", signed(stats["damage_roll"])))
    lines += _score_fields(("Dodge Chance", f"{stats['dodge_chance']}%"),
                           ("Critical Chance", f"{stats['critical_chance']}%"),
                           ("Initiative", signed(stats["initiative"])))
    lines += _score_fields(("Position", p.position.title()), ("Fighting", fighting_name))
    lines += _score_fields(("Player Kills", p.player_kills), ("Player Deaths", p.player_deaths))
    if set_bonus:
        lines.append(f" &YArmor set bonus active: +{set_bonus}% to the stats above&x")

    lines.append(_score_section("ATTRIBUTES", width))
    lines += _score_fields(("Strength", p.strength), ("Wisdom", p.wisdom),
                           ("Intelligence", p.intelligence))
    lines += _score_fields(("Constitution", p.constitution), ("Dexterity", p.dexterity),
                           ("Luck", p.luck))
    lines += _score_fields(("Perception", p.perception), ("Willpower", p.willpower),
                           ("Chakra Control", p.chakra_control))
    lines += _score_fields(("Practice Points", p.practice_points),
                           ("Training Points", p.training_points))

    lines.append(_score_section("MISSION INFO", width))
    lines.append(" &WActive effects:&x " + _format_active_effects(p.active_status_effects))
    if p.taijutsu_stance:
        lines.append(f" &YTaijutsu stance: {data_jutsu.JUTSU[p.taijutsu_stance]['display_name']}&x")
    if p.active_missions:
        mission_strs = []
        for entry in p.active_missions:
            m = missions._find_mission(entry["mission_id"])
            if m:
                mission_strs.append(f"&Y{m['title']}&x (&C{entry['progress']}/{m['target_count']}&x)")
        lines.append(" &WActive missions:&x " + "; ".join(mission_strs))
    else:
        lines.append(" &WActive missions:&x &Dnone&x")
    rank_counts = missions.completed_counts_by_rank(p)
    total_completed = sum(rank_counts.values())
    if total_completed:
        rank_str = "  ".join(f"&W{rank}:&x &C{count}&x" for rank, count in rank_counts.items() if count > 0)
        lines.append(f" &WMissions completed:&x &C{total_completed}&x total -- {rank_str}")
    else:
        lines.append(" &WMissions completed:&x &C0&x")
    rep = p.village_reputation.get(p.village, 0)
    rep_color = "&G" if rep > 0 else ("&R" if rep < 0 else "&W")
    lines.append(f" &WReputation with {village_full_name}:&x {rep_color}{rep}&x")
    lines.append(f"&W{'=' * width}&x")
    return lines


def cmd_score(session, args: List[str]) -> None:
    p = session.player
    fighting = session.combat_target.name if session.combat_target else "Nobody"
    target_staff_level = session.account.staff_level if session.account else None
    lines = build_score_lines(p, fighting, target_staff_level)
    session.send("\n".join(lines))


def cmd_level(session, args: List[str]) -> None:
    """Compact level and experience report using score's exact XP values."""
    p = session.player
    cap = leveling.rank_level_cap(p)
    capped = p.level >= cap
    next_xp = leveling.xp_for_next_level(p.level) if not capped else p.experience
    xp_needed = max(0, next_xp - p.experience) if not capped else 0
    lines = [
        _row("Level", p.level, "Experience", p.experience),
        _row("Next Level", next_xp, "XP Needed", xp_needed),
        _row("Ninja Rank", p.village_rank.title(), "Rank Cap", cap),
    ]
    if capped and cap < leveling.MAX_LEVEL:
        lines.append(" &YPromotion required to gain more levels.&x")
    session.send("\n".join(lines))


def cmd_uptime(session, args: List[str]) -> None:
    """Show how long the active Nindo_mud server has run since boot."""
    import server_uptime
    session.send(f"&CNindo_mud uptime:&x {server_uptime.format_uptime()}")


def build_jobs_lines(p, width: int = 78) -> List[str]:
    """Every registered job (jobs.JOB_NAMES), shown even at level 1/0
    xp -- a player who has never fished still sees Fishing listed, not
    an empty page, matching the request to show every job "even if
    they have zero levels." Reuses the score sheet's own _section/_row
    helpers so this reads as a companion sheet, not a different style
    bolted on next to it."""
    lines = [
        "&W" + "=" * width + "&x",
        f"&C{'JOB LEVELS'.center(width)}&x",
        "&W" + "=" * width + "&x",
        "",
        _section("JOBS"),
        "",
    ]
    for job in jobs.JOB_NAMES:
        if job in jobs.HIDDEN_JOBS:
            continue
        level = jobs.get_job_level(p, job)
        xp = jobs.get_job_xp(p, job)
        next_xp = jobs.job_xp_for_level(level + 1) if level < jobs.MAX_JOB_LEVEL else xp
        lines.append(_row(f"{job.capitalize()} Level", level, f"{job.capitalize()} XP", f"{xp}/{next_xp}"))
    lines += ["", "&W" + "=" * width + "&x"]
    return lines


def cmd_jobs(session, args: List[str]) -> None:
    session.send("\n".join(build_jobs_lines(session.player)))


def cmd_prompt(session, args: List[str]) -> None:
    player = session.player
    if not args:
        session.send(f"Current prompt format: {player.prompt_string or PRESETS['default']}")
        return
    arg = args[0].lower()
    if arg == "help":
        session.send(
            "Usage: prompt <preset|off|default|custom format>\n"
            "Presets: " + ", ".join(PRESETS.keys()) + "\n"
            "Tokens: %h %H %c %C %s %S %x %X %q %r %m %l %v %k %p %e"
        )
        return
    if arg == "off":
        player.prompt_string = "off"
        session.send("Prompt disabled.")
        return
    if arg in PRESETS:
        player.prompt_string = PRESETS[arg]
        session.send(f"Prompt set to the '{arg}' preset.")
        return
    player.prompt_string = " ".join(args)
    session.send("Prompt format updated.")


def cmd_password(session, args: List[str]) -> None:
    if len(args) != 2:
        session.send("Usage: password <old password> <new password>")
        return
    old_pw, new_pw = args
    account = session.account
    if not security.verify_password(old_pw, account.salt_hex, account.hash_hex):
        session.send("Your old password was incorrect.")
        return
    ok, reason = security.validate_new_password(
        new_pw, session.player.name,
        previous_hash=tuple(account.previous_hash) if account.previous_hash else None,
    )
    if not ok:
        session.send(reason)
        return
    account.previous_hash = [account.salt_hex, account.hash_hex]
    account.salt_hex, account.hash_hex = security.hash_password(new_pw)
    account.forced_reset = False
    storage.save_account(account)
    session.send("Password changed.")


def cmd_delete(session, args: List[str]) -> None:
    """Permanently delete only the authenticated player's character."""
    if len(args) != 2:
        session.send("Usage: delete <password> <password>")
        return
    first, second = args
    if first != second:
        session.send("Passwords do not match. Character deletion cancelled.")
        return
    account, player = session.account, session.player
    if not account or not player or account.name.lower() != player.account_name.lower():
        session.send("Could not verify the current character. Deletion cancelled.")
        return
    if not security.verify_password(first, account.salt_hex, account.hash_hex):
        session.send("Incorrect password. Character deletion cancelled.")
        return
    if account.staff_level != "player":
        session.send("Staff accounts cannot be deleted with this command.")
        return
    # Close active duels, group membership, scouting clones and other
    # transient world references before erasing persisted account data.
    name = player.name
    session.send(f"&R{name} has been permanently deleted. Goodbye.&x")
    session.request_close()
    storage.delete_character(name, account.name)



def cmd_quit(session, args: List[str]) -> None:
    storage.save_player(session.player)
    import shinobi_notices
    session.send(shinobi_notices.farewell(session.player.name))
    session.request_close()


def cmd_save(session, args: List[str]) -> None:
    if args and args[0].lower() == "world":
        cmd_save_world(session, args[1:])
        return
    storage.save_player(session.player)
    session.send("Saved.")


def cmd_save_world(session, args: List[str]) -> None:
    """'save world' -- Implementor-only, per direct request ("how do
    we make it so when you package up the newest version it does not
    effect area files ever again so i can start 'building' the mud").
    Writes a full snapshot of every room/mob/item CURRENTLY live in
    memory to disk (world_persistence.save_world -- see that module's
    own docstring for the full-snapshot format and saved-data precedence.
    Normal builder edits now also save silently and automatically). From this point on, EVERY future server
    restart -- whether from a crash, a reboot, or deploying a newly
    packaged version of the code -- loads this exact saved state back
    in, on top of whatever content.py itself would otherwise build,
    rather than losing anything built or edited since the code was
    last written. Gated to implementor, matching 'reboot's own
    precedent -- this is a genuinely high-impact command, not an
    ordinary builder-level edit, since it permanently determines what
    every future restart loads from here on. Dispatched from cmd_save
    itself ("save world") rather than a separate top-level command,
    since "save" was already a registered single-word verb that would
    otherwise silently swallow the "world" argument and just re-save
    the player's own character instead."""
    if not session.account or session.account.staff_level != "implementor":
        session.send("You don't have access to that.")
        return

    import world_persistence
    counts = world_persistence.save_world()
    session.send(
        f"World saved: {counts['rooms']} room(s), {counts['mobs']} mob(s), {counts['items']} item(s). "
        f"This exact state will be restored on every future restart from here on."
    )


def _reboot_process() -> None:
    """The actual process replacement -- split out from cmd_reboot so
    a test can monkeypatch just this piece and verify the save/warn
    logic ran correctly beforehand, without actually terminating the
    test process. Re-execs the exact same command line in place
    (os.execv), which restarts the server whether or not it's running
    under an external supervisor like systemd -- unlike just exiting,
    which only comes back on its own if something like systemd's
    Restart=on-failure is watching for it."""
    import os
    import sys
    script = os.path.abspath(sys.argv[0])
    os.execv(sys.executable, [sys.executable, script] + sys.argv[1:])


def _reboot_preflight() -> str:
    """Import the installed source in a fresh interpreter before going offline.

    This catches missing modules and syntax/import errors from an incomplete
    extraction while the existing server is still accepting connections.
    """
    import os
    import subprocess
    import sys
    script = os.path.abspath(sys.argv[0])
    if not os.path.isfile(script):
        return f"Launcher not found: {script}"
    source_dir = os.path.dirname(script)
    if os.path.basename(script) in ("main.py", "Nindo_mud"):
        check_command = [sys.executable, script, "--preflight"]
    else:
        # A wrapper or test runner may not implement --preflight; still
        # check imports from the installed source directory.
        imports = ("import sys; sys.path.insert(0, sys.argv[1]); "
                   "import main, session, combat, commands, help_system, "
                   "jutsu_colors, mangekyo_discovery")
        check_command = [sys.executable, "-c", imports, source_dir]
    try:
        result = subprocess.run(check_command,
                                cwd=source_dir, capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return str(exc)
    if result.returncode:
        return (result.stderr or result.stdout or "Unknown startup error").strip()[-1800:]
    return ""


def cmd_reboot(session, args: List[str]) -> None:
    """Implementor-only: saves every connected player, warns everyone,
    then saves the world before restarting the whole server process in place. Restricted to the
    single highest staff tier given the severity -- this affects every
    connected player, not just the one running the command."""
    if not session.account or session.account.staff_level != "implementor":
        session.send("You don't have access to that.")
        return

    error = _reboot_preflight()
    if error:
        session.send(f"&RReboot cancelled: the installed files failed the startup check. The server is still online.\n{error}&x")
        return

    # Save world before warning players or beginning process replacement.
    # If the disk is unavailable, do not reboot and lose builder edits.
    import world_persistence
    try:
        world_persistence.save_world()
    except Exception as exc:
        session.send(f"&RReboot cancelled: could not save the world ({exc}). The server is still online.&x")
        return

    from session import ACTIVE_SESSIONS
    for other in list(ACTIVE_SESSIONS):
        other.send("&R*** The MUD is rebooting now -- please reconnect in a few seconds. ***&x")
        if other.player:
            storage.save_player(other.player)

    _reboot_process()


def cmd_makeimm(session, args: List[str]) -> None:
    """Promote an existing account to the entry-level immortal rank."""
    if (not session.account or session.account.staff_level != "implementor"
            or session.account.name.lower() != config.ADMIN_NAME):
        session.send("You don't have access to that.")
        return
    if len(args) != 1 or not args[0].isascii() or not args[0].isalpha() or not (2 <= len(args[0]) <= 20):
        session.send("Usage: makeimm <account>")
        return
    account = storage.load_account(args[0])
    if account is None:
        session.send("That account does not exist.")
        return
    if account.staff_level != "player":
        session.send(f"{account.name} is already staff ({account.staff_level}).")
        return
    account.staff_level = "helper"
    storage.save_account(account)
    from session import ACTIVE_SESSIONS
    for other in list(ACTIVE_SESSIONS):
        if other.account and other.account.name.lower() == account.name.lower():
            other.account.staff_level = "helper"
            if other.player:
                other.player._immortal_skill_mastery = True
                if hasattr(other.player, "learned_skills"):
                    import leveling
                    leveling.grant_immortal_jutsu(other.player)
                    storage.save_player(other.player)
            other.send("Your account has been promoted to immortal (Helper). Your jutsu are ready to use.")
    session.send(f"{account.name} is now an immortal (Helper). The account change is saved.")


def cmd_promoteimm(session, args: List[str]) -> None:
    """Raise an existing immortal to Builder, Area Leader, or Administrator."""
    if (not session.account or session.account.staff_level != "implementor"
            or session.account.name.lower() != config.ADMIN_NAME):
        session.send("You don't have access to that.")
        return
    usage = "Usage: promoteimm <account> <builder|area leader|administrator>"
    if len(args) < 2 or not args[0].isascii() or not args[0].isalpha() or not (2 <= len(args[0]) <= 20):
        session.send(usage)
        return
    rank = " ".join(args[1:]).lower()
    if rank not in ("builder", "area leader", "administrator"):
        session.send(usage)
        return
    account = storage.load_account(args[0])
    if account is None:
        session.send("That account does not exist.")
        return
    if account.staff_level == "player":
        session.send(f"{account.name} is not an immortal yet. Use makeimm {account.name} first.")
        return
    if account.staff_level not in config.STAFF_LEVELS or config.STAFF_LEVELS.index(rank) <= config.STAFF_LEVELS.index(account.staff_level):
        session.send(f"{account.name} is already {account.staff_level}; choose a higher rank.")
        return
    account.staff_level = rank
    storage.save_account(account)
    from session import ACTIVE_SESSIONS
    for other in list(ACTIVE_SESSIONS):
        if other.account and other.account.name.lower() == account.name.lower():
            other.account.staff_level = rank
            other.send(f"Your immortal rank is now {rank.title()}.")
    session.send(f"{account.name} is now {rank.title()}. The account change is saved.")


def cmd_changes(session, args: List[str]) -> None:
    import changelog
    lines = ["&WChangelog (newest first):&x"]
    for version, summary in reversed(changelog.CHANGELOG):
        lines.append(f"  &C{version}&x - {summary}")
    session.send_paginated("\n".join(lines))


def _format_leaderboard_value(category: str, value: int) -> str:
    if category == "playtime":
        hours, minutes = divmod(int(value) // 60, 60)
        return f"{hours}h {minutes}m"
    return f"{value:,}"


def cmd_leaderboard(session, args: List[str]) -> None:
    import leaderboards

    if not args:
        lines = ["&WLeaderboard categories:&x"]
        for key, (display_name, _) in leaderboards.CATEGORIES.items():
            lines.append(f"  &C{key}&x - {display_name}")
        lines.append("Usage: leaderboard <category>")
        session.send("\n".join(lines))
        return

    category = args[0].lower()
    if category not in leaderboards.CATEGORIES:
        session.send(
            f"'{category}' isn't a leaderboard category. Valid: "
            + ", ".join(sorted(leaderboards.CATEGORIES.keys()))
        )
        return

    display_name, _ = leaderboards.CATEGORIES[category]
    entries = leaderboards.top(category)
    lines = [f"&W=== {display_name} ===&x"]
    if not entries:
        lines.append("  Nobody has any record here yet.")
    else:
        for rank, (name, value) in enumerate(entries, start=1):
            lines.append(f"  &Y{rank:>2}.&x {name.ljust(16)} {_format_leaderboard_value(category, value)}")
    session.send("\n".join(lines))


def cmd_bingobook(session, args: List[str]) -> None:
    """The Bingo Book -- lists every posted bounty, grouped by village,
    showing whether the viewing player has already claimed each one.
    Open to any player; posting/removing entries is a staff-only
    'bounty' command below."""
    import bounties

    player = session.player
    all_entries = bounties.all_bounties()
    if not all_entries:
        session.send("&DThe Bingo Book is empty. No bounties have been posted.&x")
        return

    lines = ["&r=== THE BINGO BOOK ===&x"]
    for village in sorted(bounties.VILLAGE_ID_RANGES.keys()):
        village_entries = {
            bid: e for bid, e in all_entries.items() if e["village"] == village
        }
        if not village_entries:
            continue
        village_full_name = VILLAGES.get(village, {}).get("village_name", village.title())
        lines.append(f"&W-- {village_full_name} --&x")
        for bid in sorted(village_entries.keys(), key=int):
            entry = village_entries[bid]
            if bounties.target_type_of(entry) == "player":
                target_name = f"{entry['target_player']} &D(player)&x"
                if entry.get("posted_by"):
                    target_name += f" &D-- posted by {entry['posted_by']}&x"
            else:
                mob_proto = combat.MOB_TEMPLATES.get(entry["mob_vnum"])
                target_name = mob_proto["short_desc"] if mob_proto else f"(vnum {entry['mob_vnum']}, missing)"
            claimed_tag = " &G[CLAIMED]&x" if player.name in entry["claimed_by"] else ""
            reward_bits = []
            if entry["reward_ryo"]:
                reward_bits.append(f"{entry['reward_ryo']:,} ryo")
            if entry["reward_mission_points"]:
                reward_bits.append(f"{entry['reward_mission_points']} mission point(s)")
            reward_text = " + ".join(reward_bits) if reward_bits else "no reward set"
            lines.append(f"  &Y#{bid}&x {target_name} -- {entry['description']} ({reward_text}){claimed_tag}")
    session.send("\n".join(lines))


def cmd_bounty(session, args: List[str]) -> None:
    """Staff-only: post or remove a Bingo Book bounty on a mob
    prototype or a player. IDs are auto-assigned within the target
    village's fixed block (bounties.VILLAGE_ID_RANGES) -- the mob's
    own village theme, or the target player's own village. Unlike the
    player-facing 'place bounty' command, this requires no payment and
    isn't subject to the same-village restriction."""
    if not olc._require_builder(session):
        return
    import bounties

    usage = (
        "Usage: bounty create mob <mob vnum> <village> <reward_ryo> <reward_mission_points> <description...>\n"
        "       bounty create player <name> <reward_ryo> <reward_mission_points> <description...>\n"
        "       bounty remove <id>\n"
        f"Villages: {', '.join(sorted(bounties.VILLAGE_ID_RANGES.keys()))}"
    )
    if not args or args[0].lower() not in ("create", "remove"):
        session.send(usage)
        return

    sub = args[0].lower()
    if sub == "remove":
        if len(args) != 2 or not args[1].isdigit():
            session.send("Usage: bounty remove <id>")
            return
        if bounties.remove_bounty(int(args[1])):
            session.send(f"Bounty #{args[1]} removed from the Bingo Book.")
        else:
            session.send(f"No bounty #{args[1]} exists.")
        return

    # create
    if len(args) < 2 or args[1].lower() not in ("mob", "player"):
        session.send(usage)
        return
    target_kind = args[1].lower()

    if target_kind == "mob":
        if len(args) < 7 or not args[2].isdigit() or not args[4].isdigit() or not args[5].isdigit():
            session.send(usage)
            return
        mob_vnum, village, reward_ryo, reward_mp = int(args[2]), args[3].lower(), int(args[4]), int(args[5])
        description = " ".join(args[6:])

        if mob_vnum not in combat.MOB_TEMPLATES:
            session.send(f"No mobile prototype {mob_vnum} exists.")
            return
        if village not in bounties.VILLAGE_ID_RANGES:
            session.send(f"'{village}' isn't a valid village. Choose one of: {', '.join(sorted(bounties.VILLAGE_ID_RANGES.keys()))}")
            return

        bounty_id = bounties.create_bounty("mob", mob_vnum, village, reward_ryo, reward_mp, description)
        if bounty_id is None:
            session.send(f"'{village}'s Bingo Book block is completely full -- no ID available.")
            return
        session.send(f"Bounty #{bounty_id} posted on {combat.MOB_TEMPLATES[mob_vnum]['short_desc']}.")
        return

    # create player
    if len(args) < 6 or not args[3].isdigit() or not args[4].isdigit():
        session.send(usage)
        return
    target_name, reward_ryo, reward_mp = args[2].capitalize(), int(args[3]), int(args[4])
    description = " ".join(args[5:])

    if not storage.player_exists(target_name):
        session.send(f"No character named '{target_name}' exists.")
        return
    target_player = storage.load_player(target_name)
    village = target_player.village

    bounty_id = bounties.create_bounty("player", target_name, village, reward_ryo, reward_mp, description)
    if bounty_id is None:
        session.send(f"'{village}'s Bingo Book block is completely full -- no ID available.")
        return
    session.send(f"Bounty #{bounty_id} posted on {target_name}.")


def cmd_territory(session, args: List[str]) -> None:
    """Shows every capture point (any room flagged CapturePoint --
    see 'rset flags CapturePoint'), its owner and garrison, the
    current war window status, and your own village's treasury."""
    import territory
    import world

    player = session.player
    points = territory.all_capture_point_vnums()

    window = territory.war_window_status()
    if window["active"]:
        remaining = int(window["ends_at"] - time.time())
        window_text = f"&r*** WAR WINDOW ACTIVE *** &x({remaining // 60}m {remaining % 60}s remaining)"
    elif window["starts_at"]:
        until = int(window["starts_at"] - time.time())
        hours, minutes = until // 3600, (until % 3600) // 60
        window_text = f"&YNext war window in ~{hours}h {minutes}m.&x"
    else:
        window_text = "&DNo war window scheduled yet.&x"

    lines = [window_text, f"&WYour village treasury:&x {territory.treasury_balance(player.village):,} ryo", ""]

    if not points:
        lines.append("No capture points exist yet.")
    else:
        lines.append("&WCapture points:&x")
        for vnum in points:
            room = world.WORLD.get(vnum)
            room_name = room.name if room else f"room {vnum}"
            point = territory.point_state(vnum)
            owner_text = point["owner"].capitalize() if point["owner"] else "&Dunclaimed&x"
            income = territory.point_income(vnum)
            garrison_text = f"{len(point['garrison'])}/{territory.MAX_GARRISON_PER_POINT} garrisoned"
            contest_text = ""
            if point["contested_by"]:
                remaining = int(territory.HOLD_DURATION_SECONDS - (time.time() - point["hold_started_at"]))
                contest_text = f" &r-- being captured by {point['contested_by'].capitalize()} ({remaining}s left)&x"
            lines.append(
                f"  {room_name} (vnum {vnum}) -- owner: {owner_text}, {garrison_text}, "
                f"{income} ryo/tick{contest_text}"
            )
    session.send("\n".join(lines))


def cmd_garrison(session, args: List[str]) -> None:
    """'garrison buy <tier>' -- stations a new defense mob at the
    capture point you're standing in, funded by your village's shared
    treasury. Requires being that village's Kage (the official
    village leader, since this spends communal funds, not your own --
    see 'help setkage') and standing at a point your own village
    currently owns."""
    import territory

    player = session.player
    if player.village_rank != "kage":
        session.send("Only your village's Kage can spend the village treasury on defenses.")
        return
    if not args or args[0].lower() != "buy" or len(args) != 2:
        session.send(f"Usage: garrison buy <tier>\nTiers: {', '.join(territory.GARRISON_TIER_ORDER)}")
        return

    tier = args[1].lower()
    error = territory.buy_garrison(player.village, player.room_vnum, tier)
    if error:
        session.send(error)
        return

    tier_info = territory.GARRISON_TIERS[tier]
    session.send(
        f"You pay {tier_info['cost']:,} ryo from the village treasury. "
        f"A {tier_info['display_name']} takes up position to defend this point."
    )
    session.broadcast_room(f"{player.name} summons a {tier_info['display_name']} to defend this point!", exclude_self=True)


def cmd_trap(session, args: List[str]) -> None:
    """'trap buy <type>' -- places a trap in the room you're standing
    in, funded by your village's shared treasury. Requires being that
    village's Kage (same reasoning as 'garrison buy') and standing
    within 1-2 rooms of a capture point your own village currently
    owns -- traps guard the approach, not the point itself."""
    import territory

    player = session.player
    if player.village_rank != "kage":
        session.send("Only your village's Kage can spend the village treasury on defenses.")
        return
    if not args or args[0].lower() != "buy" or len(args) != 2:
        session.send(f"Usage: trap buy <type>\nTypes: {', '.join(territory.TRAP_TYPES.keys())}")
        return

    trap_type = args[1].lower()
    error = territory.buy_trap(player.village, player.room_vnum, trap_type)
    if error:
        session.send(error)
        return

    trap_info = territory.TRAP_TYPES[trap_type]
    session.send(f"You pay {trap_info['cost']:,} ryo from the village treasury. A {trap_info['display_name']} is set here.")


def cmd_report(session, args: List[str]) -> None:
    """'report <message>' -- logs a bug report to a running text file
    (data/bug_reports/reports.txt) that staff can read directly,
    outside the game. Open to any player, anywhere, anytime -- no
    location or rank gating, since a bug report should be as
    frictionless to file as possible."""
    message = " ".join(args).strip()
    if not message:
        session.send("Usage: report <what went wrong>")
        return

    player = session.player
    storage.append_bug_report(player.name, player.village, player.room_vnum, message)
    session.send("Thanks -- your report has been logged for staff to review.")

    for s in session.active_sessions():
        if (s is not session and s.player and s.account and s.account.staff_level != "player"
                and s.player.staff_notify_reports):
            s.send(f"&Y*** Bug report from {player.name}: {message}&x")
            s.send_prompt()


def cmd_idea(session, args: List[str]) -> None:
    """'idea <suggestion>' -- logs a player suggestion to a running
    text file (data/ideas/ideas.txt) that staff can read directly,
    outside the game. Genuinely a copy of cmd_report's own structure,
    per direct request ("like the buigs command create a copy of it
    just make it ideas command so players can submit ideas") -- open
    to any player, anywhere, anytime, no location or rank gating,
    same reasoning as bug reports: as frictionless to file as
    possible. Uses its own, genuinely SEPARATE live-notify toggle
    (player.staff_notify_ideas) from bug reports, per direct
    confirmation, so staff can turn one off without the other."""
    message = " ".join(args).strip()
    if not message:
        session.send("Usage: idea <your suggestion>")
        return

    player = session.player
    storage.append_idea(player.name, player.village, player.room_vnum, message)
    session.send("Thanks -- your idea has been logged for staff to review.")

    for s in session.active_sessions():
        if (s is not session and s.player and s.account and s.account.staff_level != "player"
                and s.player.staff_notify_ideas):
            s.send(f"&Y*** Idea from {player.name}: {message}&x")
            s.send_prompt()


def cmd_bank(session, args: List[str]) -> None:
    """'bank' shows your balance from anywhere. 'bank deposit <n>' /
    'bank withdraw <n>' require standing at a mob flagged "Banker" --
    a small amount of interest (see bank.py) is applied lazily
    whenever you interact with your balance in any way, including just
    checking it."""
    import bank

    player = session.player

    if not args:
        bank.apply_interest(player)
        session.send(
            f"&WOn hand:&x {player.ryo:,} ryo\n"
            f"&WBanked:&x {player.bank_balance:,} ryo"
        )
        return

    sub = args[0].lower()
    if sub not in ("deposit", "withdraw") or len(args) != 2 or not args[1].isdigit():
        session.send("Usage: bank\n       bank deposit <amount>\n       bank withdraw <amount>")
        return

    room_mobs = combat.mobs_in_room(player.room_vnum)
    has_banker = any(
        "Banker" in combat.MOB_TEMPLATES.get(mob.template_vnum, {}).get("act_flags", [])
        for mob in room_mobs
    )
    if not has_banker:
        session.send("There's no banker here to do that.")
        return

    amount = int(args[1])
    if sub == "deposit":
        error = bank.deposit(player, amount)
        if error:
            session.send(error)
            return
        session.send(f"You deposit {amount:,} ryo. Banked: {player.bank_balance:,} ryo.")
    else:
        error = bank.withdraw(player, amount)
        if error:
            session.send(error)
            return
        session.send(f"You withdraw {amount:,} ryo. Banked: {player.bank_balance:,} ryo.")


def cmd_lottery(session, args: List[str]) -> None:
    """View the daily jackpot or purchase a four-digit ticket."""
    import datetime
    import lottery
    state = lottery.draw_due(session.active_sessions())
    if len(args) == 2 and args[0].lower() == "buy":
        error = lottery.buy(session.player, args[1], session.active_sessions())
        if error:
            session.send(error)
        else:
            ticket = next(t for t in lottery.load()["tickets"] if t["player"].casefold() == session.player.name.casefold())
            session.send(f"Lottery ticket {ticket['number']} purchased for {lottery.TICKET_PRICE:,} ryo. "
                         f"Current jackpot: {lottery.load()['jackpot']:,} ryo.")
        return
    if args:
        session.send("Usage: lottery  |  lottery buy <four digits|random>")
        return
    date = datetime.datetime.fromtimestamp(state["next_draw"], datetime.timezone.utc)
    mine = [t["number"] for t in state["tickets"] if t["player"] == session.player.name]
    last = state.get("last_draw")
    session.send(f"Jackpot: {state['jackpot']:,} ryo. Tickets: {lottery.TICKET_PRICE:,} ryo each.\n"
                 f"Next draw: {date:%Y-%m-%d %H:%M} UTC. Buy one ticket with 'lottery buy 0042' or 'lottery buy random'.\n"
                 f"Your tickets: {', '.join(mine) if mine else 'none'}.\n"
                 f"Last draw: {last['number'] if last else 'none yet'}.")


def cmd_place(session, args: List[str]) -> None:
    """'place bounty <player> <reward_ryo> <reward_mission_points>
    <description...>' -- posts a player bounty to the Bingo Book, in
    person at a mob flagged "BountyOffice" (see act_flags). Unlike the
    staff-only 'bounty create', this requires the poster to pay the
    full reward up front (deducted immediately, refused if they can't
    afford it -- otherwise this would be a free way to spam bounties),
    and enforces a hard failsafe, per explicit request: a bounty can
    never be placed on a fellow villager -- bounties are for rival-
    village ninja, not internal betrayal."""
    player = session.player
    usage = "Usage: place bounty <player name> <reward_ryo> <reward_mission_points> <description...>"
    if len(args) < 2 or args[0].lower() != "bounty":
        session.send(usage)
        return

    room = world.WORLD.get(player.room_vnum)
    room_mobs = combat.MOBS_BY_ROOM.get(player.room_vnum, [])
    has_bounty_office = any(
        "BountyOffice" in combat.MOB_TEMPLATES.get(mob.template_vnum, {}).get("act_flags", [])
        for mob in room_mobs
    )
    if not has_bounty_office:
        session.send("There's no Bingo Book office here to place a bounty at.")
        return

    if len(args) < 5 or not args[2].isdigit() or not args[3].isdigit():
        session.send(usage)
        return
    target_name = args[1].capitalize()
    reward_ryo, reward_mp = int(args[2]), int(args[3])
    description = " ".join(args[4:])

    if reward_ryo <= 0 and reward_mp <= 0:
        session.send("The reward has to be at least 1 ryo or 1 mission point.")
        return
    if target_name == player.name:
        session.send("You can't place a bounty on yourself.")
        return
    if not storage.player_exists(target_name):
        session.send(f"No character named '{target_name}' exists.")
        return

    import bounties
    target_player = storage.load_player(target_name)
    if target_player.village == player.village:
        session.send(
            f"You can't place a bounty on a fellow {VILLAGES[player.village]['village_name']} ninja."
        )
        return

    if player.ryo < reward_ryo:
        session.send(f"You need {reward_ryo:,} ryo to fund that reward -- you have {player.ryo:,}.")
        return
    if player.mission_points < reward_mp:
        session.send(f"You need {reward_mp} mission point(s) to fund that reward -- you have {player.mission_points}.")
        return

    player.ryo -= reward_ryo
    player.mission_points -= reward_mp

    bounty_id = bounties.create_bounty(
        "player", target_name, target_player.village, reward_ryo, reward_mp, description, posted_by=player.name
    )
    if bounty_id is None:
        # Refund -- the block being completely full is a genuine, if
        # unlikely, failure after payment was already taken.
        player.ryo += reward_ryo
        player.mission_points += reward_mp
        session.send(f"'{target_player.village}'s Bingo Book block is completely full -- no ID available.")
        return

    session.send(
        f"&r*** BOUNTY POSTED (#{bounty_id}) ***&x\n"
        f"You place a bounty on {target_name} for {description}. "
        f"Reward: {reward_ryo:,} ryo and {reward_mp} mission point(s)."
    )


def cmd_commands(session, args: List[str]) -> None:
    """Lists every registered command verb -- player and staff/immortal
    alike, in one combined list -- three columns wide. Movement
    (north/south/etc. and their n/s/e/w/u/d shorthand) is handled
    outside the COMMANDS dict, so it's called out separately."""
    names = sorted(set(COMMANDS.keys()))
    import lightsabers
    import seasonal_events
    if not seasonal_events.may_fourth_active() and not lightsabers.owns_saber(session.player):
        names = [name for name in names if name not in lightsabers.COMMAND_NAMES]
    col_width = max(len(name) for name in names) + 2
    per_column = (len(names) + 2) // 3  # split into 3 roughly-even columns
    columns = [names[i:i + per_column] for i in range(0, len(names), per_column)]

    lines = ["&WMovement:&x north/south/east/west/up/down/northeast/northwest/southeast/southwest "
             "(n/s/e/w/u/d/ne/nw/se/sw)", "", "&WCommands:&x"]
    for row in range(max(len(col) for col in columns)):
        parts = []
        for col in columns:
            if row < len(col):
                parts.append(col[row].ljust(col_width))
        lines.append("  " + "".join(parts).rstrip())
    session.send("\n".join(lines))


import lightsabers
import reincarnation
import six_paths

from network_bans import cmd_ip, cmd_ban
import immortal_practice

COMMANDS = {
    "setallprac": immortal_practice.command,
    "ip": cmd_ip,
    "ban": cmd_ban,
    "reincarnation": reincarnation.command,
    "sixpaths": six_paths.command,
    "lightsaber": lightsabers.command,
    "activate": lightsabers.activate, "deactivate": lightsabers.deactivate,
    "insert": lightsabers.insert_gem,
    "imms": cmd_imms, "immortal": cmd_imms, "immortals": cmd_imms,
    "sage": sage_mode.command,
    "susanoo": __import__("susanoo").command,
    "set": __import__("susanoo").command_set,
    "swordstyle": sword_styles.command,
    "sstyle": sword_styles.command,
    "style": sword_styles.command,
    "summon": sage_mode.summon_command,
    "order": sage_mode.order_command,
    "teach": __import__("player_teaching").command,
    "sealconsent": __import__("whirlpool_fuinjutsu").contract_consent,
    "restore": cmd_restore, "respawn": cmd_respawn,
    "vperk": cmd_vperk, "villageperk": cmd_vperk,
    "emotes": cmd_emotes, "emojis": cmd_emotes,
    "look": cmd_look, "l": cmd_look,
    "scan": cmd_scan,
    "say": cmd_say,
    "ooc": cmd_ooc,
    "title": __import__("ooc_titles").command,
    "chatlog": cmd_chatlog,
    "village": cmd_village_chat, "vchat": cmd_village_chat, "vc": cmd_village_chat,
    "ask": cmd_ask,
    "who": cmd_who,
    "whois": cmd_whois,
    "sharingan": cmd_sharingan, "shar": cmd_sharingan,
    "byakugan": hyuga.cmd_byakugan, "hyuga": hyuga.cmd_hyuga,
    "jinchuriki": cmd_jinchuriki, "mastery": cmd_jinchuriki,
    "beastmode": cmd_tailed_beast_mode,
    "bijuu": __import__("bijuu_chakra").command,
    "izanagi": cmd_izanagi,
    "guess": cmd_guess,
    "stab": cmd_stab,
    "impale": cmd_impale,
    "burn": cmd_burn,
    "crush": cmd_crush,
    "unmake": cmd_unmake,
    "aff": cmd_aff,
    "afk": cmd_afk,
    "recall": cmd_recall,
    "teleport": __import__("halloween_event").command_teleport,
    "trickortreat": __import__("halloween_event").command_trickortreat,
    "clone": __import__("clone_control").cmd_clone,
    "anki": cmd_anki,
    "charge": cmd_charge,
    "goto": cmd_goto,
    "transfer": cmd_transfer,
    "force": cmd_force,
    "spy": __import__("immortal_spy").command,
    "return": cmd_return,
    "apartment": cmd_apartment,
    "description": cmd_description,
    "biography": cmd_biography, "bio": cmd_biography,
    "inventory": cmd_inventory, "i": cmd_inventory,
    "equipment": cmd_equipment, "eq": cmd_equipment,
    "wear": cmd_wear,
    "wield": cmd_wield,
    "hold": cmd_hold,
    "remove": cmd_remove,
    "attack": cmd_attack, "kill": cmd_attack,
    "consider": cmd_consider,
    "weather": cmd_weather,
    "flee": cmd_flee,
    "yes": cmd_finish_downed_yes,
    "release": cmd_release,
    "unleash": cmd_unleash,
    "unseal": __import__("immortal_unseal").command,
    "no": cmd_finish_downed_no,
    "auction": cmd_auction,
    "price": cmd_price,
    "shop": cmd_shop,
    "wimpy": cmd_wimpy,
    "perform": cmd_perform,
    "per": cmd_perform,
    "mission": cmd_mission,
    "missions": cmd_missions,
    "exam": cmd_chunin_exam,
    "submit": cmd_submit_scrolls,
    "leave": cmd_leave_exam,
    "accept": cmd_accept,
    "request": cmd_request,
    "train": cmd_train,
    "convert": cmd_convert_practice,
    "practice": cmd_practice,
    "prac": cmd_prac,
    "signature": cmd_signature,
    "rest": cmd_rest,
    "sleep": cmd_sleep,
    "stand": cmd_stand, "wake": cmd_stand,
    "skills": cmd_skills,
    "jutsu": cmd_jutsu,
    "examine": cmd_examine,
    "write": cmd_write,
    "clan": cmd_clan,
    "list": cmd_list,
    "sell": cmd_sell,
    "gamble": cmd_gamble, "chouhan": cmd_gamble,
    "slots": cmd_slots,
    "roulette": cmd_roulette,
    "fish": cmd_fish,
    "mine": cmd_mine,
    "smelt": cmd_smelt,
    "pullweeds": cmd_pullweeds,
    "deliver": cmd_deliver,
    "chop": cmd_chop,
    "cook": cmd_cook,
    "farm": cmd_farm,
    "gemcut": cmd_gemcut,
    "inlay": cmd_inlay,
    "craft": cmd_craft,
    "give": cmd_give,
    "bribe": cmd_bribe,
    "drop": cmd_drop,
    "open": cmd_open,
    "close": cmd_close,
    "lock": cmd_lock,
    "unlock": cmd_unlock,
    "drop.all": lambda session, args: cmd_drop(session, ["all"]),
    "get": cmd_get,
    "put": cmd_put,
    "read": cmd_read, "study": cmd_read,
    "channel": cmd_channel,
    "buy": cmd_buy,
    "eat": cmd_eat,
    "drink": cmd_drink,
    "use": cmd_use,
    "loot": cmd_loot,
    "sacrifice": cmd_sacrifice, "sac": cmd_sacrifice,
    "purge": cmd_purge,
    "config": cmd_config,
    "score": cmd_score, "sc": cmd_score,
    "level": cmd_level,
    "uptime": cmd_uptime,
    "jobs": cmd_jobs,
    "wizinvis": staff_invisibility.command,
    "group": cmd_group,
    "follow": cmd_follow,
    "unfollow": lambda session, args: cmd_follow(session, ["off"]),
    "team": cmd_team,
    "trade": cmd_trade,
    "duel": cmd_duel,
    "prompt": cmd_prompt,
    "password": cmd_password,
    "delete": cmd_delete,
    "help": help_system.cmd_help,
    "hedit": help_system.cmd_hedit,
    "quit": cmd_quit,
    "save": cmd_save,
    "reboot": cmd_reboot,
    "makeimm": cmd_makeimm,
    "promoteimm": cmd_promoteimm,
    "commands": cmd_commands,
    "changes": cmd_changes,
    "leaderboard": cmd_leaderboard, "leaderboards": cmd_leaderboard, "top": cmd_leaderboard,
    "bingobook": cmd_bingobook, "bounty": cmd_bounty, "place": cmd_place,
    "territory": cmd_territory, "war": cmd_territory, "garrison": cmd_garrison,
    "bank": cmd_bank, "gold": cmd_bank,
    "lottery": cmd_lottery,
    "trap": cmd_trap,
    "reload": cmd_reload,
    "spawnpoint": cmd_spawnpoint,
    "staffconfig": cmd_staffconfig,
    "colorscheme": cmd_colorscheme, "roomscheme": cmd_colorscheme,
    "report": cmd_report,
    "idea": cmd_idea,
    "rset": olc.cmd_rset,
    "redit": olc.cmd_rset,  # classic ROM naming alias for the same room editor, per direct request
    "rcreate": olc.cmd_rcreate,
    "rfind": olc.cmd_rfind,
    "rlist": olc.cmd_rlist,
    "area": olc.cmd_area,
    "aset": olc.cmd_aset,
    "astat": olc.cmd_astat,
    "mset": olc.cmd_mset,
    "mobscale": __import__("mob_balance").cmd_mobscale,
    "mpedit": olc.cmd_mpedit,
    "mpstat": olc.cmd_mpstat,
    "mpset": olc.cmd_mpset,
    "rpedit": olc.cmd_rpedit,
    "rpstat": olc.cmd_rpstat,
    "opedit": olc.cmd_opedit,
    "opstat": olc.cmd_opstat,
    "mcreate": olc.cmd_mcreate,
    "mcopy": olc.cmd_mcopy,
    "minvoke": olc.cmd_minvoke,
    "mfind": olc.cmd_mfind,
    "mlist": olc.cmd_mlist,
    "silence": olc.cmd_silence,
    "unsilence": olc.cmd_unsilence,
    "jail": olc.cmd_jail,
    "unjail": olc.cmd_unjail,
    "levelup": olc.cmd_levelup,
    "oset": olc.cmd_oset,
    "ocreate": olc.cmd_ocreate,
    "ocopy": olc.cmd_ocopy,
    "oinvoke": olc.cmd_oinvoke,
    "ofind": olc.cmd_ofind,
    "olist": olc.cmd_olist,
    "mstat": olc.cmd_mstat,
    "bloodstat": olc.cmd_bloodstat,
    "bloodset": olc.cmd_bloodset,
    "awaken": olc.cmd_awaken,
    "setkage": olc.cmd_setkage,
    "award": olc.cmd_award,
    "addtip": olc.cmd_addtip,
    "remtip": olc.cmd_remtip,
    "vnum": olc.cmd_vnum,
    "ostat": olc.cmd_ostat,
    "rstat": olc.cmd_rstat,
}


# Reserve full command names, every command prefix, and all movement aliases.
# The explicit shortcut map must stay stable when new commands/jutsu are added.
from jutsu_shortcuts import validate_shortcuts
_shortcut_reserved_words = set(COMMANDS) | set(world.DIRECTION_ALIASES) | set(world.OPPOSITE_DIRECTION)
validate_shortcuts(data_jutsu.JUTSU, data_jutsu.JUTSU_ALIASES,
                   {word[:length] for word in _shortcut_reserved_words
                    for length in range(1, len(word) + 1)})

# Inventory actual command registrations to ensure all command aliases and
# public techniques have an individual searchable in-game help page.
import help_audit as _help_audit
_help_audit.populate(help_system.DEFAULT_HELP_ENTRIES, COMMANDS)
