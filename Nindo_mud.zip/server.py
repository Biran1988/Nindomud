"""
Asyncio TCP server. Wires each incoming connection to a Session, and runs
the pulse loop that drives automatic combat, mob respawns, and natural
regeneration.
"""

import asyncio
import socket

import config
import consumables
import storage
import country_geo
import network_bans
from session import ACTIVE_SESSIONS, Session

PULSE_SECONDS = 1.0  # ROM-style short pulse -- drives every periodic system's own elapsed-time counter below.
COMBAT_ROUND_SECONDS = 2.5  # a combat round used to fire every single pulse (1s) -- slowed per explicit request ("a little slower, each round is very fast").


def _enable_tcp_keepalive(writer: asyncio.StreamWriter) -> None:
    """Without this, a genuinely abrupt disconnect (linkdead -- no
    clean TCP close) is invisible to the connection loop below:
    reader.readline() just hangs forever waiting for data that will
    never arrive, so the session is never cleaned up on its own unless
    the same player reconnects (see Session._enter_world's kick-the-
    stale-session check). Enabling keepalive makes the OS actively
    probe an idle connection and eventually raise an error if it's
    truly dead, bounding how long a linkdead session can linger even
    if the player never comes back. Linux-specific tuning (TCP_KEEPIDLE
    etc.) is guarded since it isn't available on all platforms; the
    base SO_KEEPALIVE still applies everywhere."""
    try:
        sock = writer.get_extra_info("socket")
        if sock is None:
            return
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        if hasattr(socket, "TCP_KEEPIDLE"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 60)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 15)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 4)
    except OSError:
        pass  # best-effort -- never let keepalive setup crash a connection


async def handle_connection(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    def send_raw(text: str) -> None:
        try:
            writer.write(text.encode("utf-8", errors="ignore"))
        except Exception:
            pass

    def close_callback() -> None:
        try:
            writer.close()
        except Exception:
            pass

    peer = writer.get_extra_info("peername")
    try:
        ip = str(country_geo.address(peer[0]))
        country = country_geo.lookup(ip)
        denied = network_bans.blocked(ip, country)
    except (OSError, ValueError, KeyError, TypeError, IndexError):
        # Unknown peer or a damaged policy must never bypass access controls.
        send_raw("Connection access checks unavailable. Please try again later.\r\n")
        writer.close()
        await writer.wait_closed()
        return
    if denied:
        send_raw(network_bans.DENIED_MESSAGE)
        writer.close()
        await writer.wait_closed()
        return
    session = Session(send_raw, close_callback, connection_ip=ip,
                      connection_port=peer[1], connection_country=country)
    _enable_tcp_keepalive(writer)

    try:
        while True:
            data = await reader.readline()
            if not data:
                break
            line = data.decode("utf-8", errors="ignore")
            session.handle_line(line)
            if session.state.name == "CLOSED":
                break
    except (ConnectionResetError, asyncio.IncompleteReadError):
        pass
    finally:
        # A lost socket is not a quit: preserve the player in a protected
        # link-dead state. Explicit quit has already marked it CLOSED.
        if session.state.name == "PLAYING":
            session.begin_disconnect_grace()
        elif session.state.name != "CLOSED":
            session.request_close()
        try:
            writer.close()
        except Exception:
            pass


def tick_idle_upkeep(session) -> None:
    """Apply silent maintenance without repainting an otherwise idle prompt."""
    import ninja_arts
    import regen
    import sage_mode

    visible = False
    for message in regen.tick_sharingan_idle(session.player):
        session.send(message)
        visible = True
    if session.player.sage_active_contract:
        visible = sage_mode.idle_upkeep(session) or visible
    if session.player.six_paths_active:
        import six_paths
        visible = six_paths.idle_upkeep(session) or visible
    if session.player.samurai_sabre_active:
        visible = ninja_arts.tick_samurai_sabre(session) or visible
    if visible:
        session.send_prompt()


async def pulse_loop() -> None:
    """Drives automatic combat rounds, mob respawns, natural regen,
    corpse decay, and periodic autosave."""
    import combat
    import corpses
    import programs
    import smaug_progs
    import regen
    import storage
    import weather
    import auction
    import areas
    import territory
    import tips
    import upkeep_reports
    from session import ACTIVE_SESSIONS, State

    elapsed_since_regen = 0.0
    elapsed_since_idle_upkeep = 0.0
    elapsed_since_autosave = 0.0
    elapsed_since_weather = 0.0
    elapsed_since_time_of_day = 0.0
    elapsed_since_territory_income = 0.0
    elapsed_since_combat = 0.0
    elapsed_since_tips = 0.0
    tips_rotation_index = 0
    elapsed_since_area_reset = 0.0
    elapsed_since_seasonal = 0.0

    def _broadcast_all(message: str) -> None:
        for s in ACTIVE_SESSIONS:
            if s.state == State.PLAYING:
                s.send(message)
                s.send_prompt()

    while True:
        await asyncio.sleep(PULSE_SECONDS)

        # The expiration clock runs even when nobody else is connected.
        # Only after 15 full minutes do we perform the real logout,
        # releasing group slots and sending the global departure notice.
        from session import expire_linkdead_sessions
        expire_linkdead_sessions()

        elapsed_since_regen += PULSE_SECONDS
        elapsed_since_idle_upkeep += PULSE_SECONDS
        elapsed_since_autosave += PULSE_SECONDS
        elapsed_since_weather += PULSE_SECONDS
        elapsed_since_time_of_day += PULSE_SECONDS
        elapsed_since_territory_income += PULSE_SECONDS
        elapsed_since_combat += PULSE_SECONDS
        elapsed_since_tips += PULSE_SECONDS
        elapsed_since_area_reset += PULSE_SECONDS

        combat.process_respawns()
        import halloween_event
        halloween_event.process_fast_respawns()
        # Other holiday populations only need minute-level calendar checks.
        elapsed_since_seasonal += PULSE_SECONDS
        if elapsed_since_seasonal >= 60:
            elapsed_since_seasonal = 0.0
            import seasonal_events
            seasonal_events.sync_visitors()
        import lottery
        lottery.draw_due(ACTIVE_SESSIONS)
        corpses.process_decay()
        auction.process_expired_auctions()
        combat.process_wander()
        combat.process_scavengers()
        import mob_aggression
        mob_aggression.process_aggression()
        smaug_progs.process_delayed()
        import tailed_beasts
        import world as world_module
        import session as session_module
        tailed_beasts.process_tailed_beasts(combat, world_module, session_module)
        tailed_beasts.process_rampages(combat, session_module)
        import mangekyo
        mangekyo.process_amaterasu_room_fires(combat, world_module)
        mangekyo.process_amaterasu_player_burns(combat, session_module)
        mangekyo.process_kamui_pocket_dimensions(combat, world_module, session_module)
        mangekyo.process_kekkei_no_me(combat, world_module, session_module)
        import izanami_loops
        izanami_loops.process(ACTIVE_SESSIONS)
        import hidden_mist
        hidden_mist.process_rooms(ACTIVE_SESSIONS)
        import whirlpool_fuinjutsu
        whirlpool_fuinjutsu.process_barriers(sessions=ACTIVE_SESSIONS)
        programs.process_random_triggers()
        territory.ensure_war_window_scheduled(_broadcast_all)
        territory.tick_captures(_broadcast_all)

        if elapsed_since_territory_income >= territory.INCOME_TICK_SECONDS:
            elapsed_since_territory_income = 0.0
            territory.tick_income()

        if elapsed_since_weather >= weather.WEATHER_CHANGE_INTERVAL_SECONDS:
            elapsed_since_weather = 0.0
            weather.tick_weather()

        if elapsed_since_time_of_day >= weather.DAY_NIGHT_INTERVAL_SECONDS:
            elapsed_since_time_of_day = 0.0
            weather.tick_time_of_day()

        # Status effects tick down every pulse for everyone, independent of
        # combat state -- this used to only happen inside resolve_pulse()
        # (i.e. only while actively fighting), which left effects frozen
        # outside combat or after the fight that applied them ended.
        combat.tick_all_mob_effects(list(ACTIVE_SESSIONS))
        combat.tick_pending_casts()
        for session in list(ACTIVE_SESSIONS):
            if session.state == State.PLAYING:
                import element_choice
                element_choice.begin(session)
                combat.tick_effects_pulse(session)
                import bijuu_chakra
                bijuu_chakra.tick(session)
                # Shadow Clone upkeep, per direct follow-up request
                # ("Clones can be summoned before combat and persist
                # until unsigned or chakra runs out") -- same
                # always-ticks-regardless-of-combat-state reasoning
                # as tick_effects_pulse just above.
                for message in combat.tick_shadow_clone_upkeep(session.player):
                    session.send(message)
                import tracking
                tracking.tick_tracking(session)
                for message in upkeep_reports.due(session.player):
                    session.send(message)
                    session.send_prompt()

        if elapsed_since_combat >= COMBAT_ROUND_SECONDS:
            elapsed_since_combat = 0.0
            for session in list(ACTIVE_SESSIONS):
                if session.state == State.PLAYING and session.combat_target is not None:
                    combat.resolve_pulse(session)
                    session.send_prompt()
                if session.state == State.PLAYING and session.pvp_target is not None:
                    combat.resolve_pvp_pulse(session)
                    session.send_prompt()
                if session.state == State.PLAYING:
                    combat.tick_summon_upkeep(session)
                    combat.tick_ordered_summon(session)

        for session in list(ACTIVE_SESSIONS):
            if session.state == State.PLAYING and session.chakra_charge is not None:
                import commands
                commands.process_chakra_charge(session)
            if session.state == State.PLAYING and session.pending_action is not None:
                session.process_pending_action()
            if session.state == State.PLAYING:
                session.player.total_play_seconds += PULSE_SECONDS
                restored = consumables.tick_medical_healing(session.player)
                for message in consumables.medical_healing_report(session.player, restored):
                    session.send(message)
                    session.send_prompt()

        if elapsed_since_regen >= config.REGEN_INTERVAL_SECONDS:
            elapsed_since_regen -= config.REGEN_INTERVAL_SECONDS
            for session in list(ACTIVE_SESSIONS):
                if session.state == State.PLAYING and session.combat_target is None and session.pvp_target is None:
                    messages = regen.tick_player(session.player)
                    if messages:
                        for message in messages:
                            session.send(message)
                        session.send_prompt()

        if elapsed_since_idle_upkeep >= config.IDLE_SHARINGAN_UPKEEP_INTERVAL_SECONDS:
            elapsed_since_idle_upkeep -= config.IDLE_SHARINGAN_UPKEEP_INTERVAL_SECONDS
            for session in list(ACTIVE_SESSIONS):
                if session.state == State.PLAYING and session.combat_target is None and session.pvp_target is None:
                    tick_idle_upkeep(session)

        if elapsed_since_autosave >= config.AUTOSAVE_INTERVAL_SECONDS:
            elapsed_since_autosave = 0.0
            for session in list(ACTIVE_SESSIONS):
                if session.state == State.PLAYING:
                    storage.save_player(session.player)

        if elapsed_since_tips >= tips.TIPS_INTERVAL_SECONDS:
            elapsed_since_tips = 0.0
            tip_text, tips_rotation_index = tips.next_tip(tips_rotation_index)
            if tip_text is not None:
                for session in list(ACTIVE_SESSIONS):
                    if session.state == State.PLAYING and session.player.tips:
                        session.send(f"&C[Tip]&x {tip_text}")
                        session.send_prompt()

        if elapsed_since_area_reset >= areas.AREA_RESET_INTERVAL_SECONDS:
            elapsed_since_area_reset = 0.0
            areas.perform_all_area_resets()


async def run_server(host: str = config.HOST, port: int = config.PORT) -> None:
    storage.ensure_dirs()
    network_bans.initialize()
    server = await asyncio.start_server(handle_connection, host, port)
    import server_uptime
    server_uptime.start()  # a fresh clock per reboot or new server process
    asyncio.create_task(pulse_loop())
    addr = server.sockets[0].getsockname()
    print(f"{config.MUD_NAME} MUD listening on {addr[0]}:{addr[1]}")
    async with server:
        await server.serve_forever()
