"""
Combat engine (Section 16) + defeat/hospital flow (Sections 22-26).

Pulse model: normal attacks are automatic and resolved once per pulse
by `resolve_pulse()` (called from server.py's pulse_loop). Jutsu are
player-issued commands that resolve immediately when typed (subject to
their own cooldown), matching "players enter commands between combat
pulses" from the brief.

Mobs are plain in-memory instances (not persisted) spawned from
MOB_TEMPLATES -- `mset spawn` creates more of them at
runtime the same way.
"""

"""
Combat engine (Section 16) + defeat/hospital flow (Sections 22-26).

Pulse model: normal attacks are automatic and resolved once per pulse
by `resolve_pulse()` (called from server.py's pulse_loop). Jutsu are
player-issued commands that resolve immediately when typed (subject to
their own cooldown), matching "players enter commands between combat
pulses" from the brief.

Mob prototypes carry the full SMAUG-style stat block (see `mstat` in
olc.py) -- hit_dice/damage_dice are the SOURCE OF TRUTH for a mob's
health and attack damage, rolled per-instance at spawn (hit points) or
per-attack (damage), so two instances of the same template aren't
identical. Fields like armor_class/hit_roll/damage_roll/act_flags are
stored and displayed but not yet wired deeper into hit-chance math --
only the player side of that (derived_stats.py) is actually rolled
against right now; see olc.py's module docstring for the honest list of
what's cosmetic vs functional.

Mobs are plain in-memory instances (not persisted) spawned from
MOB_TEMPLATES -- `mset spawn` creates more of them at runtime the same
way.
"""

import jutsu_colors
import general_skills
import itertools
import random
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import config
import data_jutsu
import sword_styles
import jutsu_balance
import eight_gates
import hyuga
import data_mangekyo
import data_passives
import data_weapons
import damage_messages
import derived_stats
import world
import dice
import inventory
import leveling
import mob_balance
import status_effects
import signature_moves
import ninja_arts
import teams
import pvp_organizations
from data_villages import VILLAGES
from models import Player

_id_counter = itertools.count(1)

# Universal level limit for killable, holiday/event-spawned enemies. Events
# explicitly mark their killable prototypes with EVENT_KILLABLE_TAG, allowing
# ordinary world mobs and noncombat holiday vendors to retain their levels.
MAX_KILLABLE_EVENT_MOB_LEVEL = 50
EVENT_KILLABLE_TAG = "_event_killable"

# Sensible SMAUG-ish defaults for any prototype field not explicitly set.
DEFAULT_MOB_FIELDS = {
    "keywords": [], "short_desc": "", "long_desc": "", "description": "",
    "level": 1, "sex": "Neutral",
    "alignment": 0, "position": "Standing", "default_position": "Standing",
    "attributes": {"str": 13, "int": 13, "wis": 13, "dex": 13, "con": 13, "cha": 13, "luck": 13},
    # A builder's own real, fixed combat class (Taijutsu/Ninjutsu/
    # Genjutsu/Bukijutsu), per direct confirmation (Section 147
    # follow-up: "mset class genjutsu/ninjutsu ect"). None (the real
    # default) means a level-10+ mob rolls a random ninja class at
    # spawn; level 1-9 remain unclassed. Builders can fix any mob's
    # class explicitly instead.
    "primary_class": None,
    "hit_dice": "1d1+20", "mana": 100, "move": 100,
    "armor_class": 0, "hit_roll": 0, "damage_roll": 0, "damage_dice": "1d4+0", "attacks": 1,
    "act_flags": ["Npc"], "affected_by": [], "attack_verbs": ["hit"], "defenses": [],
    "resistant": [], "immune": [], "susceptible": [],
    "body_parts": ["head", "arms", "legs", "torso"],
    "gold": 0, "special_function": "None", "speaks": ["common"], "speaking": ["common"],
    "mob_programs": [],
    # Hostile targeting config: flags decide which category attacks;
    # these prototype fields name the specific village/clan.
    "aggro_village": "", "aggro_clan": "",
    # Gameplay-critical fields combat.py actually resolves against:
    "experience_reward": 0, "ryo_reward": 0, "loot_items": [], "respawns": True,
    "enabled": True,  # immortal-only toggle -- disabled prototypes refuse to spawn
    "auto_balance": True,  # shared HP/damage standard; disable per mob for scripted bosses
    # Shopkeeper fields -- a builder places a shopkeeper anywhere by
    # setting "shopkeeper" true; players can't attack them, and they sell
    # whatever object prototypes are added to "shop_items" at that
    # object's own oset-set "cost". "shop_buys_categories" optionally
    # restricts what item_types categories they'll buy FROM a player (empty
    # = buys anything, at half value; non-empty = only those categories,
    # full value -- a shopkeeper can hold more than one, e.g. both
    # "weapon" and "armor", to act as a combined weapon/blacksmith keeper).
    "shopkeeper": False, "shop_items": [], "shop_buys_categories": [],
    "shop_type": "general",  # optional named specialty; custom buys list overrides
    "shop_open_hour": -1, "shop_close_hour": -1,  # -1 = always open (legacy)
    "gate_room_vnum": None, "gate_direction": "",  # explicit guarded door
    "gate_open_hour": 6, "gate_close_hour": 18,
    # Gambler/dealer flag -- a builder places a chou-han dealer anywhere
    # the same way (mset <vnum> gambler on). Like shopkeepers, gamblers
    # can't be attacked. See commands.cmd_gamble.
    "gambler": False,
    # Teacher field -- independent of shopkeeper/gambler (a mob can be
    # any combination of the three, or none). Holds the CLASS this mob
    # teaches directly ("ninjutsu"/"taijutsu"/"genjutsu"/"bukijutsu"),
    # per direct request/confirmation (Section 110: "lets change up the
    # prac system so skills cant be learned anywhere in game they must
    # goto a mob with a flag of teacheer" -> confirmed a teacher can
    # only teach skills matching their own class, confirmed the field
    # itself holds the class name directly rather than a separate
    # on/off + class-field pair). "" (falsy, same as the old False)
    # means "not a teacher at all". Like shopkeepers and gamblers,
    # teachers can't be attacked. See commands.cmd_practice's own
    # teacher-presence gate.
    "teacher": "",
    "summon_family": "",
}


@dataclass
class Mob:
    def __setattr__(self, name, value):
        # Immortal is a true invulnerability flag, not simply a large HP pool.
        # Guard the health assignment itself so AoE, traps, lingering fire,
        # summons and other damage paths cannot accidentally kill protected NPCs.
        if name == "health" and "max_health" in self.__dict__:
            template_vnum = self.__dict__.get("template_vnum")
            flags = (MOB_TEMPLATES.get(template_vnum) or {}).get("act_flags", ())
            if (template_vnum == 6 or any(flag in flags for flag in
                    ("Immortal", "SummonElder", "Trainer"))):
                value = max(1, self.__dict__["max_health"])
        object.__setattr__(self, name, value)

    instance_id: int
    template_vnum: int
    name: str
    level: int
    health: int
    max_health: int
    room_vnum: int
    experience_reward: int
    ryo_reward: int
    damage_dice: str = "1d4+0"
    attacks: int = 1
    armor_class: int = 0
    hit_roll: int = 0
    respawns: bool = True
    loot_items: List[str] = field(default_factory=list)
    # Scavenged items are held only by this live mob instance. They are
    # intentionally absent from prototypes and vanish on reboot or death.
    scavenged_items: List[str] = field(default_factory=list)
    active_status_effects: Dict[str, dict] = field(default_factory=dict)
    mangekyo_amaterasu_caster: Optional[str] = None
    kamui_return_room_vnum: Optional[int] = None
    # Mob stats/class parity (Section 86, per direct request: "give
    # mobs all that stats and classes that players do") -- scoped
    # down through real numeric chakra/stamina pools, a primary class,
    # and a chakra nature. Level-10+ mobs now cast suitable class jutsu
    # in normal combat using these same real resources.
    # Needed so the elemental status effects Drained (chakra loss) and
    # Off Balance (stamina loss) have something real to act on when
    # inflicted on a mob, not just players. See
    # mob_chakra_for_level/mob_stamina_for_level below for the actual
    # level-scaled formula (mirrors the player's own exact growth
    # rate) and spawn_mob for where these get set on a freshly
    # spawned instance.
    chakra: int = 0
    maximum_chakra: int = 0
    stamina: int = 0
    maximum_stamina: int = 0
    primary_class: Optional[str] = None
    # Per-instance NPC casting; prevents several players fighting one NPC
    # from provoking a jutsu on every session's combat pulse.
    jutsu_cooldowns: Dict[str, float] = field(default_factory=dict)
    next_jutsu_at: float = 0.0
    # Real attribute fields (Section 147, per direct request: "mopbs
    # must be able to wear gear too" -> confirmed full parity, not
    # just cosmetic). Baseline 10, same as a fresh player. strength/
    # dexterity/luck genuinely drive derived_stats.py's own real
    # formulas for mob combat now (see derive_mob_combat_attributes
    # and combat.py's own real hit/damage/dodge/crit resolution).
    # constitution/intelligence/wisdom are confirmed, deliberate
    # placeholders -- no real mechanical effect yet, matching how
    # Perception/Willpower already sit inert on players.
    strength: int = 10
    dexterity: int = 10
    intelligence: int = 10
    wisdom: int = 10
    luck: int = 10
    constitution: int = 10
    # A real, per-instance equipment dict (slot -> item name),
    # matching Player.equipment's own established shape exactly --
    # per-INSTANCE rather than per-template, since 'force <mob> wear'
    # equips one specific spawned mob, not every future copy of it.
    equipment: Dict[str, str] = field(default_factory=dict)
    chakra_nature: Optional[str] = None
    # Player shops (Section 75) -- which player this specific spawned
    # instance belongs to, if any. Per-INSTANCE, not per-template,
    # since every player shop reuses the same generic Shopkeeper
    # template but each has a different owner and stock.
    player_shop_owner: Optional[str] = None
    # Shadow Clone Jutsu (Section 78, per direct follow-up requests) --
    # which player this clone belongs to, if any. A real, independently
    # attackable Mob instance (not an abstract counter, per confirmed
    # design), using a per-CASTER template (see
    # _shadow_clone_template_vnum) so the clone's name/description
    # genuinely match that specific player, not a shared generic one.
    shadow_clone_owner: Optional[str] = None
    clone_element: str = "none"
    # Summoning contracts (Section 118, per direct request/
    # confirmation) -- which player this summon belongs to, if any,
    # and which real tier (data_summons.CONTRACT_TIERS, e.g.
    # "toad_3") it was summoned as. Mirrors shadow_clone_owner's own
    # established pattern exactly: a real, independently-attackable
    # Mob instance, not an abstract counter. summon_tier_key lets
    # combat resolve this specific summon's own unique mechanic (see
    # data_summons.tier_by_key) without needing to re-derive it from
    # the owner's current level, which could have changed since it
    # was actually summoned.
    summon_owner: Optional[str] = None
    summon_tier_key: Optional[str] = None
    summon_order: str = "follow"
    summon_attack_target_id: int = 0
    stomach_target_instance_id: int = 0
    # The Toad Stomach's own trap mechanic (Section 118, "trap"
    # tier mechanic) -- once applied to a mob, a real, meaningfully
    # large to-hit penalty against the player for the rest of that
    # fight. summon_trap_applied guards against re-applying (and
    # re-narrating) the same trap every single round.
    summon_trap_applied: bool = False
    summon_trap_to_hit_penalty: int = 0
    # Tailed Beasts (Section 127, per direct request/confirmation) --
    # which of the 9 real beasts (data_tailed_beasts.TAILED_BEASTS)
    # this specific live Mob instance is, or None for every ordinary
    # mob. tailed_beast_despawn_at is the real, absolute timestamp
    # this beast vanishes on its own if not sealed or killed by then
    # -- confirmed directly: a genuine 2 real hours from release.
    tailed_beast_key: Optional[str] = None
    tailed_beast_despawn_at: float = 0.0
    # The real "awaiting sealing" window (Section 127 continued, per
    # direct confirmation): once a beast reaches 0 HP, it's kept
    # alive/present here rather than being removed immediately --
    # this is the real, absolute timestamp it dies normally if nobody
    # casts the Sealing Jutsu on it in time. 0.0 means not currently
    # downed at all (either full health, or already resolved one way
    # or the other).
    tailed_beast_downed_until: float = 0.0
    # One real movement clock and independently seeded RNG for THIS
    # living instance, never a prototype/room/area/shared-pulse clock.
    # The initial deadline is scheduled immediately by spawn_mob().
    # Zero is retained for older/directly constructed test mobs.
    next_wander_at: float = 0.0
    wander_rng: random.Random = field(default_factory=random.Random,
                                      repr=False, compare=False)


MOB_TEMPLATES: Dict[int, dict] = {}          # template_vnum -> full prototype dict
MOBS_BY_ROOM: Dict[int, List[Mob]] = {}       # room_vnum -> [Mob, ...]


def default_template(vnum: int, name: str = "a nondescript mob") -> dict:
    """A blank-ish prototype with every field defaulted -- what `mset
    create <vnum>` starts from, before individual `mset` field edits."""
    t = {k: (list(v) if isinstance(v, list) else dict(v) if isinstance(v, dict) else v)
         for k, v in DEFAULT_MOB_FIELDS.items()}
    t["short_desc"] = name
    t["long_desc"] = f"{name.capitalize()} is here."
    t["keywords"] = name.split()
    return t


def register_template(vnum: int, name: str, level: int, max_health: int,
                       min_damage: int, max_damage: int,
                       experience_reward: int, ryo_reward: int,
                       loot_items: Optional[List[str]] = None) -> None:
    """Backward-compatible simple registration (used by content.py) --
    builds equivalent hit_dice/damage_dice strings so the mob still gets
    a full SMAUG-style prototype under the hood, visible via `mstat`."""
    t = default_template(vnum, name)
    t["level"] = level
    t["hit_dice"] = f"1d1+{max(0, max_health - 1)}"  # deterministic: 1d1 always rolls 1, so bonus = max_health - 1
    span = max(1, max_damage - min_damage + 1)
    t["damage_dice"] = f"1d{span}+{min_damage - 1}"  # rolls into [min_damage, max_damage]
    t["experience_reward"] = experience_reward
    t["ryo_reward"] = ryo_reward
    t["gold"] = ryo_reward
    t["loot_items"] = list(loot_items or [])
    MOB_TEMPLATES[vnum] = t


def mob_chakra_for_level(level: int) -> int:
    """Mirrors the player's own exact chakra growth (leveling.py:
    75 base at level 1, +CHAKRA_PER_LEVEL per level after) so a mob's
    resource pool feels consistent with a player at the same level."""
    import leveling
    return 75 + leveling.CHAKRA_PER_LEVEL * max(0, level - 1)


def mob_stamina_for_level(level: int) -> int:
    """Mirrors the player's own exact stamina growth (leveling.py:
    100 base at level 1, +STAMINA_PER_LEVEL per level after)."""
    import leveling
    return 100 + leveling.STAMINA_PER_LEVEL * max(0, level - 1)


def derive_mob_combat_attributes(hit_roll: int, damage_dice: str) -> tuple:
    """Per direct confirmation (Section 147): converts an EXISTING
    mob template's own real, hand-tuned flat combat values into the
    real attribute values that now drive mob combat math (see
    derived_stats.py's own real formulas, which every mob's combat
    resolution now goes through, matching a player's exact same
    math). Returns a real (strength, dexterity) tuple -- luck stays
    at the confirmed baseline of 10, since no existing mob field maps
    to it.

    dexterity = hit_roll + 10 (the real inverse of derived_stats.
    hit_roll's own dexterity - 10 formula) -- confirmed directly to
    take priority; armor_class is then whatever THIS SAME dexterity
    produces via derived_stats.armor_class, even where that changes
    an existing mob's own armor_class from what it is today.

    strength = 10 + dice.average(damage_dice) -- confirmed directly
    that the resulting damage_roll bonus stacks ON TOP of the
    existing damage_dice roll (not replacing it), a real, accepted
    damage increase across every existing mob as a deliberate side
    effect of this change."""
    import dice
    dexterity = hit_roll + 10
    strength = 10 + dice.average(damage_dice)
    return strength, dexterity


TRAINING_DUMMY_VNUM = 6
TRAINING_DUMMY_HEALTH = 1_000_000


def is_training_dummy(mob: Mob) -> bool:
    return mob.template_vnum == TRAINING_DUMMY_VNUM


def spawn_mob(template_vnum: int, room_vnum: int) -> Optional[Mob]:
    t = MOB_TEMPLATES[template_vnum]
    if not t.get("enabled", True) and template_vnum != TRAINING_DUMMY_VNUM:
        return None
    # A runtime safeguard even if a holiday template gets edited above 50.
    level = (min(t["level"], MAX_KILLABLE_EVENT_MOB_LEVEL)
             if template_vnum != TRAINING_DUMMY_VNUM and t.get(EVENT_KILLABLE_TAG)
             else t["level"])
    # Guard the nine canonical bijuu VNUMs even if a saved or builder-edited
    # template accidentally re-enables auto_balance. Their hand-tuned health
    # and attack dice must never be replaced by ordinary mobscale settings.
    import tailed_beasts
    is_tailed_beast = (tailed_beasts.BEAST_TEMPLATE_VNUM_BASE <= template_vnum
                       < tailed_beasts.BEAST_TEMPLATE_VNUM_BASE + 9)
    # Preserve deliberately scripted event encounters; ordinary mobs get
    # identical baseline HP and expected damage for the same level.
    auto_balance = (template_vnum != TRAINING_DUMMY_VNUM and not is_tailed_beast
                    and t.get("auto_balance", True)
                    and not t.get("_custom_boss_balance"))
    max_hp = (TRAINING_DUMMY_HEALTH if template_vnum == TRAINING_DUMMY_VNUM
              else mob_balance.hp_for_level(level) if auto_balance
              else max(1, dice.roll(t["hit_dice"])))
    effective_damage_dice = ("0d1+0" if template_vnum == TRAINING_DUMMY_VNUM
                             else mob_balance.damage_dice_for_level(level) if auto_balance
                             else t["damage_dice"])
    max_chakra = mob_chakra_for_level(level)
    max_stamina = mob_stamina_for_level(level)
    import data_classes
    import biomes
    derived_strength, derived_dexterity = derive_mob_combat_attributes(t.get("hit_roll", 0), effective_damage_dice)
    mob = Mob(
        instance_id=next(_id_counter), template_vnum=template_vnum,
        name=t.get("short_desc") or f"mob {template_vnum}",
        level=level, health=max_hp, max_health=max_hp, room_vnum=room_vnum,
        experience_reward=(0 if template_vnum == TRAINING_DUMMY_VNUM else t["experience_reward"]),
        ryo_reward=(0 if template_vnum == TRAINING_DUMMY_VNUM else t["ryo_reward"]),
        damage_dice=effective_damage_dice,
        attacks=(1 if template_vnum == TRAINING_DUMMY_VNUM else max(1, t.get("attacks", 1))),
        armor_class=t.get("armor_class", 0), hit_roll=t.get("hit_roll", 0),
        respawns=t.get("respawns", True), loot_items=list(t.get("loot_items", [])),
        chakra=max_chakra, maximum_chakra=max_chakra,
        stamina=max_stamina, maximum_stamina=max_stamina,
        # Below level 10, preserve the old no-class default; these mobs
        # cannot cast. Combat mobs at 10+ without a builder-assigned class
        # roll one of the four normal ninja classes on spawn.
        primary_class=(None if template_vnum == TRAINING_DUMMY_VNUM
                       else t.get("primary_class") if t.get("primary_class") in data_classes.CLASSES
                       else random.choice(tuple(data_classes.CLASSES)) if level >= 10
                       else None),
        chakra_nature=biomes.roll_chakra_nature(),
        strength=derived_strength, dexterity=derived_dexterity,
    )
    # Persistent roadside weapon loadout: apply on every fresh spawn,
    # including post-death respawns, rather than only on first install.
    if t.get("roadside_weapon"):
        mob.equipment["wielded"] = t["roadside_weapon"]
    MOBS_BY_ROOM.setdefault(room_vnum, []).append(mob)
    if is_wandering(mob) and not mob.tailed_beast_key:
        # Startup/area resets may spawn dozens of instances during one
        # server pulse. Give each its own clock NOW, with room-local
        # staggering, rather than starting a shared 2-minute waiting
        # window on the first global movement sweep.
        _schedule_next_wander(mob, time.time(), initial=True)
    return mob


def mobs_in_room(room_vnum: int) -> List[Mob]:
    return MOBS_BY_ROOM.get(room_vnum, [])


# Shopkeeper fields are looked up live from the mob's TEMPLATE, not
# cached on the Mob instance -- so a builder's `mset` edit (adding an
# item, changing shop_buys_categories, flipping the shopkeeper flag)
# takes effect immediately on already-placed instances, with no need
# to respawn them.
def is_shopkeeper(mob: Mob) -> bool:
    if is_training_dummy(mob):
        return False
    t = MOB_TEMPLATES.get(mob.template_vnum)
    return bool(t and t.get("shopkeeper", False))


def mob_shop_items(mob: Mob) -> List[int]:
    t = MOB_TEMPLATES.get(mob.template_vnum)
    return list(t.get("shop_items", [])) if t else []


def mob_shop_buys_categories(mob: Mob) -> List[str]:
    t = MOB_TEMPLATES.get(mob.template_vnum)
    if not t:
        return []
    # Preserve preexisting manually configured specialty categories.
    explicit = list(t.get("shop_buys_categories", []))
    if explicit:
        return explicit
    import data_shops
    shop_type = t.get("shop_type", "general")
    spec = data_shops.SHOP_TYPES.get(shop_type, data_shops.SHOP_TYPES["general"])
    allowed = spec["allowed_sell_categories"]
    return sorted(allowed) if allowed is not None else []


# Gambler/dealer is its own independent flag -- unrelated to the
# shopkeeper system above (a mob can be a gambler, a shopkeeper, both,
# or neither). Looked up live from the template for the same reason as
# the shopkeeper fields: a builder's mset edit takes effect immediately
# on an already-placed mob, no respawn needed.
def is_gambler(mob: Mob) -> bool:
    if is_training_dummy(mob):
        return False
    t = MOB_TEMPLATES.get(mob.template_vnum)
    return bool(t and t.get("gambler", False))


# Teacher is its own independent flag -- see the DEFAULT_MOB_FIELDS
# comment for scope (flag only for now; actual teaching interaction is
# a future addition). Looked up live from the template for the same
# reason as shopkeeper/gambler.
def is_teacher(mob: Mob) -> bool:
    if is_training_dummy(mob):
        return False
    t = MOB_TEMPLATES.get(mob.template_vnum)
    return bool(t and t.get("teacher", ""))


def is_stat_trainer(mob: Mob) -> bool:
    """SWR-style attribute instructor. Separate from class skill teachers."""
    template = MOB_TEMPLATES.get(mob.template_vnum)
    return bool(template and "Trainer" in template.get("act_flags", []))


def teacher_class(mob: Mob) -> str:
    """The class this mob teaches ("ninjutsu"/"taijutsu"/"genjutsu"/
    "bukijutsu"), per direct confirmation (Section 110: a teacher can
    only teach skills matching their own class). Returns "" if the
    mob isn't a teacher at all -- callers should check is_teacher(mob)
    first, or just treat an empty string as "no match" directly."""
    t = MOB_TEMPLATES.get(mob.template_vnum)
    return (t or {}).get("teacher", "")


def is_immortal_mob(mob: Mob) -> bool:
    """Per direct request/confirmation (Section 150): "add an
    immortal mob flag" -- a mob carrying the real Immortal act flag
    genuinely cannot be attacked at all (plain attack or jutsu-
    based), matching the exact real "protected and cannot be
    attacked" refusal already used for shopkeepers/gamblers/
    teachers. Looked up live from the template, same as every other
    act-flag check here, so a builder's mset edit takes effect
    immediately on an already-placed mob."""
    if is_training_dummy(mob):
        return False  # immortal health, not the attack-blocking Immortal flag
    t = MOB_TEMPLATES.get(mob.template_vnum)
    if not t:
        return False
    return any(flag in t.get("act_flags", []) for flag in ("Immortal", "SummonElder", "Trainer"))


def is_wandering(mob: Mob) -> bool:
    if is_training_dummy(mob):
        return False
    t = MOB_TEMPLATES.get(mob.template_vnum)
    if not t:
        return False
    act_flags = t.get("act_flags", [])
    if "Sentinel" in act_flags:
        return False  # a hard override, matching Sentinel's own documented meaning -- see olc.VALID_MOB_ACT_FLAGS
    return "Wander" in act_flags


def _mob_is_being_fought(mob: Mob) -> bool:
    import session as session_module  # local import -- avoids a circular dependency at module load
    return any(s.combat_target is mob for s in session_module.ACTIVE_SESSIONS)


def _broadcast_to_room(room_vnum: int, text: str, *, exclude_session=None) -> None:
    """Broadcast mob movement to room observers, optionally excluding its pilot.

    A player controlling an elemental clone already gets direct movement
    feedback and a room description; showing both room broadcasts to the
    pilot caused a redundant three-message movement sequence.
    """
    import session as session_module
    import clone_control
    for s in session_module.ACTIVE_SESSIONS:
        if s is not exclude_session and s.player:
            if clone_control.view_room(s) == room_vnum:
                s.send(text)


WANDER_MIN_SECONDS = 120.0  # Each mob's normal interval: 2–4 real minutes
WANDER_MAX_SECONDS = 240.0
WANDER_FIRST_MIN_SECONDS = WANDER_MIN_SECONDS  # Preserve 2–4 minute first-move balance
WANDER_SPACING_SECONDS = 9.0   # Separate nearby mobs' actual departures


def _schedule_next_wander(mob: Mob, now: float, *, initial: bool = False,
                          retry: bool = False) -> None:
    """Set this instance's own deadline without a shared mob/room timer.

    On a mass spawn, independently seeded mob RNGs spread first moves
    across the same 2–4 minute interval rather than creating a wave.
    Stagger due times within one room
    to keep those mobs from leaving as one group. Timers stay attached
    to the mob, even when it walks to another room.
    """
    rng = mob.wander_rng
    if retry:
        deadline = now + rng.uniform(WANDER_SPACING_SECONDS, 2 * WANDER_SPACING_SECONDS)
    elif initial:
        deadline = now + rng.uniform(WANDER_FIRST_MIN_SECONDS, WANDER_MAX_SECONDS)
    else:
        deadline = now + rng.uniform(WANDER_MIN_SECONDS, WANDER_MAX_SECONDS)

    # A sorted pass guarantees a minimum gap from already-scheduled
    # neighbors even if hundreds of mobs share the same starting room.
    neighbors = sorted(other.next_wander_at
                       for other in MOBS_BY_ROOM.get(mob.room_vnum, ())
                       if other is not mob and is_wandering(other)
                       and other.health > 0 and other.next_wander_at > now)
    for other_due in neighbors:
        if abs(deadline - other_due) < WANDER_SPACING_SECONDS:
            deadline = other_due + WANDER_SPACING_SECONDS + rng.uniform(0.01, 1.0)
    mob.next_wander_at = deadline


def process_wander() -> None:
    """Process each living Wander mob's *own* deadline once per server pulse.

    Never move a group merely because a room/area reset or global tick
    occurred. The server pulse only checks individual deadlines. A
    frozen snapshot stops mobs walking into a later-scanned room and
    being visited a second time in the same pulse. Only one successful
    departure per origin room per pulse is allowed, so synchronized old
    deadlines cannot create an entire troop marching in lockstep.
    """
    now = time.time()
    seen = set()
    mobs = []
    for room_mobs in list(MOBS_BY_ROOM.values()):
        for mob in list(room_mobs):
            if mob.instance_id not in seen:
                seen.add(mob.instance_id)
                mobs.append(mob)

    moved_from_rooms = set()
    for mob in mobs:
        if mob.health <= 0 or mob.tailed_beast_key or not is_wandering(mob):
            continue
        if mob.next_wander_at <= 0.0:
            _schedule_next_wander(mob, now, initial=True)
            continue
        if now < mob.next_wander_at:
            continue

        # Older code/save or builder commands may leave two due dates
        # identical. Defer ONLY this individual mob, not the whole room.
        if mob.room_vnum in moved_from_rooms:
            _schedule_next_wander(mob, now, retry=True)
            continue

        if _mob_is_being_fought(mob) or toad_stomach_target(mob):
            _schedule_next_wander(mob, now)
            continue
        room = world.WORLD.get(mob.room_vnum)
        if not room or not room.exits:
            _schedule_next_wander(mob, now)
            continue
        candidates = [
            (direction, dest) for direction, dest in room.exits.items()
            if world.WORLD.get(dest) and world.WORLD.get(dest).enabled
            and not world.WORLD.get(dest).apartment
            and "no_wander" not in world.WORLD.get(dest).flags
            and (not MOB_TEMPLATES.get(mob.template_vnum, {}).get("roadside_patrol_vnums")
                 or dest in MOB_TEMPLATES[mob.template_vnum]["roadside_patrol_vnums"])
            and (not MOB_TEMPLATES.get(mob.template_vnum, {}).get("roadside_camp")
                 or not world.WORLD.get(dest).safe)
        ]
        if not candidates:
            _schedule_next_wander(mob, now)
            continue

        direction, destination = mob.wander_rng.choice(candidates)
        origin = mob.room_vnum
        _broadcast_to_room(origin, f"{mob.name.capitalize()} leaves {direction}.")
        MOBS_BY_ROOM[origin].remove(mob)
        mob.room_vnum = destination
        MOBS_BY_ROOM.setdefault(destination, []).append(mob)
        _broadcast_to_room(destination, f"{mob.name.capitalize()} arrives from the {world.OPPOSITE_DIRECTION.get(direction, direction)}.")
        moved_from_rooms.add(origin)
        _schedule_next_wander(mob, now)
        import programs
        programs.fire_mob_entry(mob)


def process_scavengers() -> None:
    """Let flagged live mobs clear ordinary ground items once per pulse.

    The collected strings live only on the mob instance; no prototype or
    player save contains them, so a restart discards them. Private apartment
    rooms and fixed no_take decorations are excluded.
    """
    import commands  # local import avoids the command/combat import cycle

    for room_vnum, mobs in list(MOBS_BY_ROOM.items()):
        room = world.WORLD.get(room_vnum)
        if not room or room.apartment or not room.ground_items:
            continue
        for mob in list(mobs):
            if mob.health <= 0 or "Scavenger" not in MOB_TEMPLATES.get(mob.template_vnum, {}).get("act_flags", []):
                continue
            for item in list(room.ground_items):
                if commands._has_no_take_flag(item):
                    continue
                room.ground_items.remove(item)
                mob.scavenged_items.append(item)
            # The first scavenger collects every eligible item in this room.
            break


def find_mob(room_vnum: int, query: str) -> Optional[Mob]:
    """Per direct confirmation (Section 158): a real "N.keyword" prefix
    (e.g. "2.bandit") targets the Nth mob in the room matching
    "bandit", 1-indexed -- the same general disambiguation convention
    now used everywhere a name can be typed to target something. A
    bare query with no real "N." prefix still means "the first
    match", exactly as before."""
    index, keyword = inventory.parse_indexed_query(query)
    keyword = keyword.lower()
    matches = [mob for mob in mobs_in_room(room_vnum) if keyword in mob.name.lower()]
    if index > len(matches):
        return None
    return matches[index - 1] if matches else None


def remove_mob(mob: Mob) -> None:
    mob.mangekyo_amaterasu_caster = None
    if is_shadow_clone(mob):
        import clone_control
        clone_control.notify_clone_removed(mob, "disperses")
    room_mobs = MOBS_BY_ROOM.get(mob.room_vnum, [])
    if mob in room_mobs:
        room_mobs.remove(mob)
    if mob.respawns:
        # A mob ALSO covered by a real spawn point (Section 102) skips the
        # normal timer-based respawn entirely -- the spawn point's own
        # independent area-reset sweep is the single, sole mechanism
        # responsible for bringing it back in that case. Without this
        # check, a genuine double-spawn was caught by direct testing:
        # both mechanisms independently restoring the exact same mob,
        # completely uncoordinated with each other.
        import spawn_points
        already_covered = any(
            p["kind"] == "mob" and p["vnum"] == mob.template_vnum and p["room_vnum"] == mob.room_vnum
            for p in spawn_points.list_spawn_points(mob.room_vnum)
        )
        if not already_covered:
            # A fresh instance becomes available after config.MOB_RESPAWN_SECONDS,
            # tracked by the pulse loop via _respawn_queue.
            _respawn_queue.append((time.time() + config.MOB_RESPAWN_SECONDS, mob.template_vnum, mob.room_vnum))


_respawn_queue: List[tuple] = []


def process_respawns() -> None:
    now = time.time()
    ready = [r for r in _respawn_queue if r[0] <= now]
    for r in ready:
        _respawn_queue.remove(r)
        spawn_mob(r[1], r[2])


# --- Damage / attack resolution ------------------------------------------

def _player_attack_damage(player: Player) -> int:
    base = random.randint(3, 7)
    dmg = base + player.strength // 4
    import commands as commands_module
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    dmg += derived_stats.damage_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "damage_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player))
    dmg += commands_module.equipped_weapon_type_damage_bonus(player)
    dmg += commands_module.equipped_weapon_damroll_bonus(player)
    for skill, pct in player.skill_proficiencies.items():
        if data_passives.is_passive(skill):
            dmg = int(dmg * data_passives.damage_multiplier(skill, pct))
    import village_perks
    dmg = int(dmg * village_perks.damage_multiplier(player.village))
    import sage_mode
    import susanoo
    return eight_gates.physical_damage(player, susanoo.outgoing_damage(
        player, sage_mode.outgoing(
            player, status_effects.reduce_outgoing_damage(player.active_status_effects, dmg),
            weapon=bool(player.equipment.get("wielded")))))


def _mob_attack_damage(mob: Mob) -> int:
    if is_training_dummy(mob):
        return 0
    import commands as commands_module
    base = dice.roll(mob.damage_dice)
    strength_bonus = derived_stats.damage_roll(mob)
    equipment_bonus = commands_module.equipped_weapon_damroll_bonus(mob) + commands_module.equipped_weapon_type_damage_bonus(mob)
    return status_effects.reduce_outgoing_damage(mob.active_status_effects, max(0, base + strength_bonus + equipment_bonus))


def start_attack(session, mob: Mob) -> None:
    if is_immortal_mob(mob):
        session.combat_target = None
        session.send(f"{mob.name.capitalize()} is protected and cannot be attacked.")
        return
    import general_skills
    general_skills.break_camouflage(session)
    session.combat_target = mob
    session.player.recently_defeated_timer = 0.0
    import groups
    groups.assist_group_attack(session, mob)


def jutsu_resource_shortfall(player: Player, jutsu: dict, jutsu_key: str) -> str | None:
    """Match actual live casting prices for hand-sign prechecks and utility."""
    copied = player.copied_jutsu_key == jutsu_key
    chakra_cost = jutsu_balance.cast_cost(
        player, jutsu, "chakra",
        base_override=player.copied_jutsu_cost if copied else None)
    stamina_cost = jutsu_balance.cast_cost(player, jutsu, "stamina")
    if player.chakra < chakra_cost:
        return "You don't have enough chakra."
    if player.stamina < stamina_cost:
        return "You don't have enough stamina."
    return None

class PendingCast:
    """A hand-sign casting delay in progress, per direct request/
    design ("lets put a lag time before doing jutsu while your
    casting so mastery of handsigns will lowere that lag time").
    is_pvp distinguishes a mob-target cast from a PvP one, since they
    resolve through 2 genuinely different functions
    (use_jutsu/use_jutsu_on_player) with different signatures.
    start_combat_on_resolve is True only when this cast was the thing
    that STARTED the fight (the player wasn't already fighting
    anything) -- confirmed design ("it will not initiate combat until
    the jutsu itself has landed damage or a failed attempt"): combat
    doesn't actually begin (session.combat_target/pvp_target get set,
    which is what turns on the automatic per-pulse attack) until this
    cast resolves, hit or miss, not the moment it's begun."""

    def __init__(self, jutsu_key: str, target, is_pvp: bool, remaining_seconds: float, start_combat_on_resolve: bool = False):
        self.jutsu_key = jutsu_key
        self.target = target
        self.is_pvp = is_pvp
        self.remaining_seconds = remaining_seconds
        self.start_combat_on_resolve = start_combat_on_resolve


def begin_pending_cast(session, jutsu_key: str, target, is_pvp: bool, start_combat_on_resolve: bool = False) -> None:
    """Starts the casting delay for jutsu_key, per confirmed design:
    only Ninjutsu/Genjutsu jutsu use hand signs at all
    (data_handsigns.has_handsigns) -- everything else (Taijutsu,
    Bukijutsu) resolves with NO delay at all, exactly as it already
    did before this feature existed. The delay itself is based on the
    caster's own current Handsigns proficiency (0 if they don't know
    Handsigns at all yet, e.g. below level 20 -- confirmed design:
    Handsigns is UNIVERSAL at level 20, so anyone casting one of
    these before that point gets the full, slowest delay).

    Confirmed design: the hand-sign sequence is broadcast to
    EVERYONE in the room as it's performed, not just the caster --
    deliberate groundwork for a future counter-jutsu system, not
    built yet ("this will play into counter jutsu later because a
    player can see their opponents handsigns").

    start_combat_on_resolve: per a later direct report ("it will not
    initiate combat until the jutsu itself has landed damage or a
    failed attempt"), a cast that STARTS a fight (the player wasn't
    already fighting anything) does not set combat_target/pvp_target
    here -- that only happens once the cast actually resolves, hit
    or miss (see tick_pending_casts), so no automatic per-pulse
    attack can fire during the delay window at all."""
    import data_handsigns
    jutsu = data_jutsu.JUTSU[jutsu_key]
    player = session.player
    mastery = player.skill_proficiencies.get("Handsigns", 0)
    delay = data_handsigns.casting_delay_seconds(mastery)
    if (getattr(player, "chokkan_active", False)
            and "Chokkan" in player.learned_skills
            and random.randint(1, 100) <= player.skill_proficiencies.get("Chokkan", 0)):
        delay *= 0.5
        grow_skill_from_usage(player, "Chokkan", session=session)
    signs = data_handsigns.sequence_for(jutsu_key)

    session.pending_cast = PendingCast(jutsu_key, target, is_pvp, delay, start_combat_on_resolve)
    session.send(f"&WYou begin forming hand signs: {' -> '.join(signs)}...&x")
    import room_actions
    room_actions.emit(session, f"&W{player.name} forms hand signs: {' -> '.join(signs)}...&x")


def _check_jutsu_collisions() -> None:
    """A genuine pre-pass, run once per pulse BEFORE any individual
    PendingCast resolves, per direct request/confirmation (Section
    97: "A counter jutsu should be an opposing element only" +
    "finishes within 1 second of the other" + "Both jutsu are
    cancelled -- neither deals its normal damage/effect to the
    intended target, only the room effect happens"). Finds every
    mutual PvP pair -- A's pending cast targets B AND B's pending
    cast targets A, both genuinely still in the same room -- whose
    delays will finish within elemental_counters.COLLISION_WINDOW_
    SECONDS of each other and whose jutsu are of OPPOSING elements
    (per the confirmed 5-way cycle, not just any two elements). If
    found, both casts are cancelled outright -- neither ever reaches
    the normal resolution path in tick_pending_casts -- and the
    pair's own themed collision message is sent to the room, plus a
    real, temporary room-description addition (world.Room.
    temp_description_text/temp_description_until)."""
    import elemental_counters
    import time as time_module
    from session import ACTIVE_SESSIONS

    candidates = []
    for session in ACTIVE_SESSIONS:
        cast = session.pending_cast
        if cast is None or session.state.name != "PLAYING" or not cast.is_pvp:
            continue
        jutsu = data_jutsu.JUTSU.get(cast.jutsu_key)
        if not jutsu or jutsu.get("element", "none") == "none":
            continue
        candidates.append(session)

    already_collided = set()
    for session in candidates:
        if session in already_collided:
            continue
        cast = session.pending_cast
        target_session = cast.target
        if target_session not in candidates or target_session in already_collided:
            continue
        if not pvp_organizations.allowed_sessions(session, target_session):
            continue
        other_cast = target_session.pending_cast
        # Mutual: the target's own pending cast must be aimed back at THIS caster.
        if other_cast.target is not session:
            continue
        if session.player.room_vnum != target_session.player.room_vnum:
            continue
        if abs(cast.remaining_seconds - other_cast.remaining_seconds) > elemental_counters.COLLISION_WINDOW_SECONDS:
            continue

        my_element = data_jutsu.JUTSU[cast.jutsu_key]["element"]
        their_element = data_jutsu.JUTSU[other_cast.jutsu_key]["element"]
        if not (elemental_counters.is_counter(my_element, their_element)
                or elemental_counters.is_counter(their_element, my_element)):
            continue

        # Genuine collision -- cancel BOTH casts outright first (the
        # overpower path below, if it applies, re-resolves the winning
        # side's own jutsu for real afterward).
        already_collided.add(session)
        already_collided.add(target_session)
        session.pending_cast = None
        target_session.pending_cast = None

        if elemental_counters.is_counter(my_element, their_element):
            elemental_winner_session, elemental_loser_session = session, target_session
            elemental_winner_cast, elemental_loser_cast = cast, other_cast
        else:
            elemental_winner_session, elemental_loser_session = target_session, session
            elemental_winner_cast, elemental_loser_cast = other_cast, cast
        winner, loser = elemental_winner_session.player.name, elemental_loser_session.player.name

        # Overpower check (Section 98): only the elementally-favored side can
        # ever overpower -- its own combined power score must clear the
        # OPPOSING side's by OVERPOWER_THRESHOLD or more.
        winner_mastery = elemental_winner_session.player.skill_proficiencies.get(
            data_jutsu.JUTSU[elemental_winner_cast.jutsu_key]["display_name"], 0)
        loser_mastery = elemental_loser_session.player.skill_proficiencies.get(
            data_jutsu.JUTSU[elemental_loser_cast.jutsu_key]["display_name"], 0)
        winner_score = elemental_counters.power_score(elemental_winner_session.player.level, winner_mastery)
        loser_score = elemental_counters.power_score(elemental_loser_session.player.level, loser_mastery)
        overpowered = (winner_score - loser_score) >= elemental_counters.OVERPOWER_THRESHOLD

        effect = elemental_counters.collision_effect(my_element, their_element)
        message = effect["message"].format(winner=winner, loser=loser)
        if overpowered:
            message += f" &D({winner}'s superior skill lets it punch through, landing with reduced force.)&x"

        room = world.WORLD.get(session.player.room_vnum)
        if room:
            room.temp_description_text = effect["room_text"]
            room.temp_description_until = time_module.time() + elemental_counters.TEMP_DESCRIPTION_DURATION_SECONDS
            for other in ACTIVE_SESSIONS:
                if other.state.name == "PLAYING" and other.player and other.player.room_vnum == room.vnum:
                    other.send(message)

        if overpowered:
            other_target_session = elemental_loser_session
            if (
                other_target_session.state.name == "PLAYING"
                and other_target_session.player
                and other_target_session.player.room_vnum == elemental_winner_session.player.room_vnum
                and other_target_session.player.health > 0
            ):
                use_jutsu_on_player(
                    elemental_winner_session, elemental_winner_cast.jutsu_key, other_target_session,
                    damage_multiplier=elemental_counters.OVERPOWER_DAMAGE_MULTIPLIER,
                )


def resolve_illusion_walk_cast(session, target_session, grow_handsigns: bool = True) -> None:
    """The real, actual effect of an Illusion Walk cast landing --
    shared by both the normal delayed-cast path (tick_pending_casts,
    grow_handsigns=True since real hand signs were formed) and the
    instant-cast path via the Silent Genjutsu passive (Section 122,
    grow_handsigns=False since no hand signs were genuinely formed at
    all with that passive active). See tracking's own docstring/
    commands.py's own cmd_use_jutsu for the full confirmed design."""
    player = session.player
    if not pvp_organizations.check(session, target_session):
        return
    if (
        target_session.state.name != "PLAYING"
        or not target_session.player
        or target_session.player.room_vnum != player.room_vnum
        or target_session.player.health <= 0
    ):
        session.send("&DYour target is no longer there!&x")
        return
    import data_kekkei_genkai
    if status_effects.willpower_resists(target_session.player):
        session.send(f"&C{target_session.player.name}'s Willpower rejects Illusion Walk!&x")
        target_session.send("&CYour trained Willpower sees through the false path!&x")
        if grow_handsigns:
            grow_skill_from_usage(player, "Handsigns", session=session)
        return
    if data_kekkei_genkai.sharingan_genjutsu_resistant(target_session.player):
        session.send(f"&Y{target_session.player.name}'s eyes see through your illusion completely!&x")
        target_session.send(f"&Y{player.name} tries to trap you in a genjutsu, but your Sharingan sees through it!&x")
        if grow_handsigns:
            grow_skill_from_usage(player, "Handsigns", session=session)
        return
    proficiency = player.skill_proficiencies.get("Illusion Walk", 0)
    if proficiency >= 90:
        illusion_range = 3
    elif proficiency >= 50:
        illusion_range = 2
    else:
        illusion_range = 1
    target_session.player.illusion_walk_caster = player.name
    target_session.player.illusion_walk_real_room_vnum = target_session.player.room_vnum
    target_session.player.illusion_walk_range = illusion_range
    target_session.player.illusion_walk_steps_taken = 0
    session.send(f"&YYou trap {target_session.player.name} in an illusion of endless walking!&x")
    target_session.send(f"&R{player.name}'s eyes lock with yours -- something feels wrong.&x")
    if grow_handsigns:
        grow_skill_from_usage(player, "Handsigns", session=session)


def resolve_amaterasu_cast(session, target_session, grow_handsigns: bool = True) -> None:
    """The real, actual effect of an Amaterasu cast landing (Section
    140) -- shared by both the normal delayed-cast path
    (tick_pending_casts, grow_handsigns=True) and the instant-cast
    path via the Silent Genjutsu passive (grow_handsigns=False),
    matching resolve_illusion_walk_cast's own exact established
    pattern. Deals 250 initial damage to a player (before defenses),
    permanently ignites the target, and separately sets their room on
    fire for five minutes (everyone in it except the caster)."""
    player = session.player
    if not pvp_organizations.check(session, target_session):
        return
    if (
        target_session.state.name != "PLAYING"
        or not target_session.player
        or target_session.player.room_vnum != player.room_vnum
        or target_session.player.health <= 0
    ):
        jutsu_colors.send(session, "&DYour target is no longer there!&x")
        return
    # First enter normal combat; rejected attacks must not apply flames.
    if not engage_damage_attack(session, target_session.player, target_session):
        return
    import data_mangekyo
    # Immortals are immune to attached black flames. Other players are
    # protected from endless burns by a real-time five-minute deadline.
    immortal_target = is_immortal_immune_to_defeat(target_session)
    target_session.player.mangekyo_amaterasu_burning = not immortal_target
    target_session.player.mangekyo_amaterasu_caster = None if immortal_target else player.name
    target_session.player.mangekyo_amaterasu_expires_at = (
        0.0 if immortal_target else time.time() + data_mangekyo.AMATERASU_PLAYER_BURN_DURATION_SECONDS
    )
    import mangekyo_discovery
    mangekyo_discovery.record_use(player, "amaterasu")
    room = world.WORLD.get(target_session.player.room_vnum)
    if room is not None:
        room.amaterasu_fire_caster = player.name
        room.amaterasu_fire_expires_at = time.time() + data_mangekyo.AMATERASU_ROOM_FIRE_DURATION_SECONDS
    # Same immediate strike as the mob casting path. Defenses reduce
    # the initial impact; attached flames last until the target dies.
    import sage_mode
    damage = status_effects.reduce_incoming_damage(
        target_session.player.active_status_effects, data_mangekyo.AMATERASU_INITIAL_DAMAGE)
    damage = sage_mode.incoming(target_session.player, damage)
    target_session.player.health -= damage
    jutsu_colors.send(session, f"&RAmaterasu engulfs {target_session.player.name} for {damage_messages.describe_damage(damage)} initial damage! The black flames burn until death.&x")
    jutsu_colors.send(target_session, f"&R{player.name}'s Amaterasu engulfs you for {damage_messages.describe_damage(damage)} initial damage! The black flames burn until death.&x")
    if grow_handsigns:
        grow_skill_from_usage(player, "Handsigns", session=session)
    if target_session.player.health <= 0:
        if try_trigger_izanagi(target_session):
            pass
        elif is_immortal_immune_to_defeat(target_session):
            clamp_immortal_health(target_session)
        else:
            handle_pvp_defeat(winner_session=session, loser_session=target_session)
    # The wall-clock deadline persists across logging out and rebooting.
    import storage
    storage.save_player(target_session.player)


def resolve_kamui_limb_removal_cast(session, target_session) -> None:
    """The real, actual effect of Kamui: Limb Removal landing (Section
    140), after its own genuinely long, custom real delay (see
    begin_kamui_limb_removal_cast) -- a real, one-time burst of high
    damage (data_mangekyo.KAMUI_LIMB_REMOVAL_DAMAGE), confirmed
    directly to NOT be a lingering effect, just a single, massive
    hit if the long cast actually completes."""
    player = session.player
    if not pvp_organizations.check(session, target_session):
        return
    if (
        target_session.state.name != "PLAYING"
        or not target_session.player
        or target_session.player.room_vnum != player.room_vnum
        or target_session.player.health <= 0
    ):
        jutsu_colors.send(session, "&DYour target is no longer there!&x")
        return
    import data_mangekyo
    import random
    if not engage_damage_attack(session, target_session.player, target_session):
        return
    dmg = random.randint(*data_mangekyo.KAMUI_LIMB_REMOVAL_DAMAGE)
    dmg = status_effects.reduce_incoming_damage(target_session.player.active_status_effects, dmg)
    target_session.player.health -= dmg
    import mangekyo_discovery
    mangekyo_discovery.record_use(player, "kamui limb removal")
    jutsu_colors.send(session, f"&RYour blade tears through space itself, severing {target_session.player.name}'s limb for {damage_messages.describe_damage(dmg)} damage!&x")
    jutsu_colors.send(target_session, f"&R{player.name}'s Kamui rips your limb away in an instant of pure agony -- {damage_messages.describe_damage(dmg)} damage!&x")
    if target_session.player.health <= 0:
        if try_trigger_izanagi(target_session):
            pass
        elif is_immortal_immune_to_defeat(target_session):
            clamp_immortal_health(target_session)
        else:
            handle_pvp_defeat(winner_session=session, loser_session=target_session)


def resolve_izanami_cast(session, target_session, grow_handsigns: bool = True) -> None:
    """The real, actual effect of an Izanami cast landing (Section
    140) -- traps the target in place, genuinely immune to attack
    (confirmed directly), with a real, fixed random number from 1-25
    set ONCE right here and never changed again. The caster is
    completely free to act normally elsewhere while it's running
    (confirmed directly -- not tied up or restricted in any way), so
    this deliberately does nothing at all to the caster's own state."""
    player = session.player
    if not pvp_organizations.check(session, target_session):
        return
    if (
        target_session.state.name != "PLAYING"
        or not target_session.player
        or target_session.player.room_vnum != player.room_vnum
        or target_session.player.health <= 0
    ):
        jutsu_colors.send(session, "&DYour target is no longer there!&x")
        return
    if target_session.player.izanami_trapped:
        jutsu_colors.send(session, "&RThat player is already trapped in Izanami.&x")
        return
    import data_mangekyo
    import random
    import izanami_loops
    secret_number = random.randint(
        data_mangekyo.IZANAMI_NUMBER_MIN, data_mangekyo.IZANAMI_NUMBER_MAX
    )
    izanami_loops.start(session, target_session, secret_number)
    import mangekyo_discovery
    mangekyo_discovery.record_use(player, "izanami")
    jutsu_colors.send(session, f"&R{target_session.player.name} is pulled into a recursive loop of your own making.&x")
    jutsu_colors.send(target_session,
        f"&RTime folds in on itself -- you're trapped, reliving the same moment over and over. "
        f"Guess the number ({data_mangekyo.IZANAMI_NUMBER_MIN}-{data_mangekyo.IZANAMI_NUMBER_MAX}) to break free: 'guess <number>'. "
        "You get ONE guess per 15-second loop. Wrong answers deal Health damage!&x"
    )
    if grow_handsigns:
        grow_skill_from_usage(player, "Handsigns", session=session)


def resolve_kekkei_no_me_cast(session, grow_handsigns: bool = True) -> None:
    """The real, actual effect of a Kekkei no Me cast landing (Section
    140) -- a genuinely no-target, self-cast jutsu (unlike every other
    Mangekyo technique built so far). Transforms the caster's own
    CURRENT room in place (confirmed directly -- no one moves
    anywhere) into their own real, active chakra-nature element,
    lasting a real 90 seconds. If the caster has no real chakra
    nature at all yet, refuses cleanly rather than transforming into
    a nonexistent element."""
    player = session.player
    if not player.chakra_nature:
        jutsu_colors.send(session, "&DYour own chakra nature hasn't awakened yet -- there's nothing to draw on.&x")
        return
    room = world.WORLD.get(player.room_vnum)
    if room is None:
        jutsu_colors.send(session, "&DSomething's wrong with this room -- contact a builder.&x")
        return
    import data_mangekyo
    room.kekkei_no_me_caster = player.name
    room.kekkei_no_me_element = player.chakra_nature
    room.kekkei_no_me_expires_at = time.time() + data_mangekyo.KEKKEI_NO_ME_DURATION_SECONDS
    import mangekyo_discovery
    mangekyo_discovery.record_use(player, "kekkei no me")
    jutsu_colors.send(session, f"&RThe room itself bends to your will, awash in your own {player.chakra_nature} nature.&x")
    for s in session.active_sessions():
        if s is not session and s.player and s.player.room_vnum == player.room_vnum:
            s.send(f"&R{player.name}'s domain consumes the room -- {player.chakra_nature} chakra saturates the air, draining you!&x")
    if grow_handsigns:
        grow_skill_from_usage(player, "Handsigns", session=session)


def resolve_tsukuyomi_cast(session, target_session, grow_handsigns: bool = True) -> None:
    """The real, actual effect of a Tsukuyomi cast landing (Section
    140) -- moves BOTH the caster and target into a shared, real
    torture room in one action (mangekyo.open_tsukuyomi), unlike
    Kamui's target-first 2-step entry. A real, hidden random number from 5-10
    is rolled inside open_tsukuyomi itself, setting how many of the
    caster's own actions the technique lasts."""
    player = session.player
    if not pvp_organizations.check(session, target_session):
        return
    if (
        target_session.state.name != "PLAYING"
        or not target_session.player
        or target_session.player.room_vnum != player.room_vnum
        or target_session.player.health <= 0
    ):
        jutsu_colors.send(session, "&DYour target is no longer there!&x")
        return
    import mangekyo
    import world as world_module
    mangekyo.open_tsukuyomi(session, target_session, world_module)
    import mangekyo_discovery
    mangekyo_discovery.record_use(player, "tsukuyomi")
    jutsu_colors.send(session, f"&RYour world dissolves into crimson -- you and {target_session.player.name} are pulled into Tsukuyomi.&x")
    jutsu_colors.send(target_session, f"&R{player.name}'s eyes consume your reality -- you're trapped in Tsukuyomi, frozen and defenseless.&x")
    if grow_handsigns:
        grow_skill_from_usage(player, "Handsigns", session=session)


def tick_pending_casts() -> None:
    """Counts down every in-progress PendingCast by one pulse, and
    resolves any that have finished by actually calling the real
    use_jutsu/use_jutsu_on_player at that point -- confirmed design,
    the jutsu genuinely doesn't happen until the delay elapses, not
    just a delayed message. If the target is no longer valid (a mob
    already dead/gone, a PvP target who's disconnected or left the
    room) by the time the delay finishes, the cast simply fizzles
    with no resource refund.

    A genuine counter-jutsu collision (Section 97, see
    _check_jutsu_collisions) is checked BEFORE any individual cast
    below gets a chance to resolve this same pulse -- a collided cast
    has already had its own session.pending_cast cleared to None by
    that point, so it's silently skipped here, exactly like any other
    already-resolved cast would be."""
    _check_jutsu_collisions()
    from session import ACTIVE_SESSIONS
    for session in ACTIVE_SESSIONS:
        cast = session.pending_cast
        if cast is None or session.state.name != "PLAYING":
            continue
        cast.remaining_seconds -= 1.0
        if cast.remaining_seconds > 0:
            continue
        jutsu = data_jutsu.JUTSU.get(cast.jutsu_key)
        if jutsu and jutsu.get("kkg_gate") and not _can_use_jutsu(session.player, jutsu, cast.jutsu_key):
            session.pending_cast = None
            session.send("&RYour Sharingan is no longer active -- the Mangekyo technique fades before it takes hold.&x"
                         if jutsu.get("kkg_gate") == "mangekyo_technique" else
                         "&RYour Six Paths mode fades before the technique takes hold.&x"
                         if jutsu.get("kkg_gate", "").startswith("six_paths_") else
                         "&RYour elemental release fades before the technique takes hold.&x")
            continue

        session.pending_cast = None
        player = session.player
        # Check BEFORE special Mangekyo dispatches (Tsukuyomi, Kamui,
        # Amaterasu, etc.), not just ordinary damaging jutsu below.
        # Otherwise a cast started while someone was online could still
        # strike them after their connection dropped.
        if cast.is_pvp:
            opponent = cast.target
            if (getattr(getattr(opponent, "state", None), "name", "PLAYING") != "PLAYING"
                    or not getattr(opponent, "player", None)
                    or opponent.player.room_vnum != player.room_vnum
                    or opponent.player.health <= 0):
                session.send("&DYour hand signs fade -- that shinobi is no longer an active target.&x")
                continue
        if cast.is_pvp and not pvp_organizations.check(session, cast.target):
            session.send("&DYour hostile jutsu dissolves before reaching a protected shinobi.&x")
            continue
        if cast.is_pvp and getattr(cast.target, "player", None):
            import hidden_mist
            if hidden_mist.obscures(player, cast.target.player) or general_skills.concealed_from(player, cast.target.player):
                session.send("&CThe hidden mist swallows your target before your jutsu can land.&x")
                continue
        if cast.jutsu_key == "hidden mist jutsu":
            import hidden_mist
            if hidden_mist.cast(session):
                grow_skill_from_usage(player, "Handsigns", session=session)
            continue
        if (cast.jutsu_key in ("amaterasu", "tsukuyomi", "izanami", "kamui limb removal")
                and not cast.is_pvp):
            import mangekyo_mobs
            mangekyo_mobs.resolve(session, cast.jutsu_key, cast.target)
            continue
        if data_jutsu.JUTSU.get(cast.jutsu_key, {}).get("jutsu_type") in ("disguise", "item_illusion", "item_decoy", "chisei", "room_sleep"):
            import genjutsu
            genjutsu.resolve_cast(session, cast.jutsu_key, cast.target)
            grow_skill_from_usage(player, "Handsigns", session=session)
            continue
        if cast.jutsu_key == "illusion walk":
            resolve_illusion_walk_cast(session, cast.target, grow_handsigns=True)
            continue
        if cast.jutsu_key == "tsukuyomi":
            resolve_tsukuyomi_cast(session, cast.target, grow_handsigns=True)
            continue
        if cast.jutsu_key == "amaterasu":
            resolve_amaterasu_cast(session, cast.target, grow_handsigns=True)
            continue
        if cast.jutsu_key == "kamui limb removal":
            resolve_kamui_limb_removal_cast(session, cast.target)
            continue
        if cast.jutsu_key == "izanami":
            resolve_izanami_cast(session, cast.target, grow_handsigns=True)
            continue
        if cast.jutsu_key == "kekkei no me":
            resolve_kekkei_no_me_cast(session, grow_handsigns=True)
            continue
        if cast.is_pvp:
            target_session = cast.target
            if (
                target_session.state.name != "PLAYING"
                or not target_session.player
                or target_session.player.room_vnum != player.room_vnum
                or target_session.player.health <= 0
            ):
                session.send("&DYour hand signs falter -- your target is no longer there!&x")
                continue
            jutsu = data_jutsu.JUTSU[cast.jutsu_key]
            if cast.start_combat_on_resolve and session.pvp_target is None:
                shortfall = jutsu_resource_shortfall(player, jutsu, cast.jutsu_key)
                if shortfall:
                    session.send(shortfall)
                    continue
                start_pvp_attack(session, target_session)
            use_jutsu_on_player(session, cast.jutsu_key, target_session)
        else:
            mob = cast.target
            if mob not in mobs_in_room(player.room_vnum) or mob.health <= 0:
                session.send("&DYour hand signs falter -- your target is no longer there!&x")
                continue
            if cast.start_combat_on_resolve and session.combat_target is None:
                shortfall = jutsu_resource_shortfall(player, data_jutsu.JUTSU[cast.jutsu_key], cast.jutsu_key)
                if shortfall:
                    session.send(shortfall)
                    continue
                start_attack(session, mob)
            use_jutsu(session, cast.jutsu_key, mob)
        grow_skill_from_usage(player, "Handsigns", session=session)


def tick_effects_pulse(session) -> None:
    """Tick a player's status effects and report expiries. Called once per
    server pulse for EVERY connected player regardless of combat state --
    this used to only happen inside resolve_pulse() (i.e. only while
    actively fighting), which meant an effect outside combat, or one that
    outlived the fight it was applied in, never ticked down at all.

    Applies the 3 elemental damage/drain-over-time effects (Burning,
    Drained, Off Balance) BEFORE the duration decrement below, so each
    one deals its damage/drain on every remaining round it's active,
    including its final one -- confirmed as a genuine standalone
    per-round timer, deliberately different from the existing Bleeding
    effect (which only ticks when the target is hit again in combat)."""
    player = session.player
    if player.reaper_seal_id:
        return
    import genjutsu
    genjutsu.tick_player(session)
    import general_skills
    general_skills.upkeep(session)
    if "burning" in player.active_status_effects:
        dmg = status_effects.burning_damage()
        dmg = status_effects.reduce_incoming_damage(player.active_status_effects, dmg)
        player.health = max(0, player.health - dmg)
        session.send(f"&RThe fire burns you for {damage_messages.describe_damage(dmg)} damage!&x")
    if "poisoned" in player.active_status_effects:
        dmg = status_effects.reduce_incoming_damage(player.active_status_effects, random.randint(3, 5))
        player.health = max(0, player.health - dmg)
        session.send(f"&GPoison hurts you for {damage_messages.describe_damage(dmg)} damage!&x")
    for trap in ninja_arts.TRAPS:
        state = player.active_status_effects.get(trap)
        if state and state["duration"] <= 1:
            player.active_status_effects.pop(trap)
            dmg = ninja_arts.detonate_trap(player, trap)
            session.send(f"&R{trap.title()} detonates for {damage_messages.describe_damage(dmg)} damage!&x")
    if "drained" in player.active_status_effects:
        loss = min(player.chakra, status_effects.drained_chakra_loss())
        player.chakra -= loss
        session.send(f"&CYour chakra is drained by {loss}!&x")
    if "off_balance" in player.active_status_effects:
        loss = min(player.stamina, status_effects.off_balance_stamina_loss())
        player.stamina -= loss
        session.send(f"&YBeing off balance saps {loss} stamina!&x")

    # A trained mind can break an ordinary Genjutsu after it lands,
    # including sleep/paralysis that would otherwise prevent acting.
    # Run before decrementing duration; physical status effects and
    # Mangekyo special states are not eligible.
    for name in status_effects.break_genjutsu_effects(player.active_status_effects, player):
        session.send(f"&CYour Willpower tears through the {status_effects.EFFECT_DEFS[name]['display_name']} illusion!&x")

    eight_gates.tick(session)
    expired = status_effects.tick_effects(player.active_status_effects)
    for name in expired:
        if name == "chisei" and player.chisei_chakra_bonus:
            player.maximum_chakra -= player.chisei_chakra_bonus
            player.chakra = min(player.chakra, player.maximum_chakra)
            player.chisei_chakra_bonus = 0
        session.send(f"You are no longer {status_effects.EFFECT_DEFS[name]['display_name'].lower()}.")
    if player.health <= 0:
        if not try_trigger_izanagi(session) and not is_immortal_immune_to_defeat(session):
            handle_player_defeat(session)

    hyuga.tick_upkeep(session)
    import upkeep_reports
    upkeep_reports.tick_active_toggles(session)


def tick_all_mob_effects(sessions=None) -> None:
    """Tick every spawned mob's status effects, once per pulse, regardless
    of whether anyone is currently fighting them. Also applies the 3
    elemental damage/drain-over-time effects (mirroring
    tick_effects_pulse's own player-side logic) -- now that mobs have
    real chakra/stamina fields (Section 86) for Drained/Off Balance to
    meaningfully act on, not just players."""
    for room_mobs in list(MOBS_BY_ROOM.values()):
        for mob in list(room_mobs):
            if is_immortal_mob(mob):
                # Applies immediately to an existing NPC when staff add the
                # flag; clear old hostile effects so they cannot linger.
                mob.health = mob.max_health
                mob.mangekyo_amaterasu_caster = None
                for effect in ("burning", "poisoned", "bleeding", "drained", "off_balance"):
                    mob.active_status_effects.pop(effect, None)
                for trap in ninja_arts.TRAPS:
                    mob.active_status_effects.pop(trap, None)
                continue
            # A defeated beast remains a target for Sealing Jutsu. Its own
            # lifecycle removes it after the capture window; the generic
            # dead-mob cleanup must not erase it on the next pulse.
            if mob.tailed_beast_key and mob.tailed_beast_downed_until:
                continue
            if mob.health <= 0 and mob.mangekyo_amaterasu_caster:
                mob.mangekyo_amaterasu_caster = None
            if mob.health > 0 and mob.mangekyo_amaterasu_caster:
                import data_mangekyo
                mob.health = max(0, mob.health - random.randint(*data_mangekyo.AMATERASU_PLAYER_BURN_PER_TICK))
                if mob.health <= 0:
                    mob.mangekyo_amaterasu_caster = None
            if "burning" in mob.active_status_effects:
                mob.health = max(0, mob.health - status_effects.burning_damage())
            if "poisoned" in mob.active_status_effects:
                mob.health = max(0, mob.health - random.randint(3, 5))
            if "drained" in mob.active_status_effects:
                mob.chakra = max(0, mob.chakra - status_effects.drained_chakra_loss())
            if "off_balance" in mob.active_status_effects:
                mob.stamina = max(0, mob.stamina - status_effects.off_balance_stamina_loss())
            for trap in ninja_arts.TRAPS:
                state = mob.active_status_effects.get(trap)
                if state and state["duration"] <= 1:
                    mob.active_status_effects.pop(trap)
                    dmg = ninja_arts.detonate_trap(mob, trap)
                    if sessions:
                        for owner in sessions:
                            if owner.player and owner.player.name == state["source"]:
                                owner.send(f"&R{trap.title()} detonates on {mob.name} for {damage_messages.describe_damage(dmg)} damage!&x")
                                if mob.health <= 0 and mob in room_mobs:
                                    handle_mob_defeat(owner, mob)
                                break
            status_effects.tick_effects(mob.active_status_effects)
            # A mob's casting Chakra/Stamina slowly regenerate between
            # fights, so old wandering NPCs don't become permanent
            # non-casters after fighting the first player they meet.
            if mob.health > 0 and not _mob_is_being_fought(mob):
                mob.chakra = min(mob.maximum_chakra, mob.chakra + max(1, mob.maximum_chakra // 60))
                mob.stamina = min(mob.maximum_stamina, mob.stamina + max(1, mob.maximum_stamina // 60))
            if mob.health <= 0 and sessions and mob in room_mobs:
                owner = next((s for s in sessions if s.player and
                              (s.combat_target is mob or s.player.name == mob.mangekyo_amaterasu_caster)), None)
                if owner:
                    handle_mob_defeat(owner, mob)
                else:
                    remove_mob(mob)


PASSIVE_GROWTH_CHANCE_PCT = 20  # per combat round
PASSIVE_GROWTH_AMOUNT = 1


USAGE_GROWTH_PER_HIT = 2  # matches SHADOW_CLONE_MASTERY_GAIN_PER_CAST's own established rate, for consistency


def grow_skill_from_usage(player: Player, skill_name: str, session=None) -> None:
    """Gives skill_name a CHANCE to raise its proficiency by
    USAGE_GROWTH_PER_HIT on qualifying use up to 100%, or 150% when
    the player has selected this jutsu as their signature move.
    The teacher practice cap never gates natural usage growth: even
    a weapon skill at 7% can improve by attacking in combat. Teacher
    practice remains a guaranteed way to train up to its own cap.

    Usage growth is a genuine roll, not a guarantee, per
    direct request/confirmation ("Let's make practice % much lower to
    succeed when using a skill so mastery actually means something" ->
    clarified and confirmed exactly: "Chance to gain = (100 -
    current%), so 98% mastery only has a 2% chance per use to tick up
    at all, while 10% mastery has a 90% chance"). The closer to 100%
    a skill already is, the rarer any further gain becomes -- this is
    what makes true mastery (100%) a genuinely long grind rather than
    a fixed number of guaranteed hits away, at any proficiency level.

    Confirmed design (\"Make it so every skill/jutsu can only be
    practiced up to 50% after that they must raise it via usage\"): a
    jutsu grows on a landed HIT (called from use_jutsu, right after
    damage is confirmed dealt); a weapon skill grows on ANY attack
    made while that weapon type is equipped, hit or miss (called from
    the player-attack helpers). Silently does nothing for a skill
    that isn't learned or is already at its current cap (100%, or
    150% for the selected signature) -- this is called unconditionally
    from the relevant combat paths, not gated by the caller."""
    if skill_name not in player.learned_skills:
        return
    import skill_training
    if skill_training.needs_first_practice(player, skill_name):
        return
    current = player.skill_proficiencies.get(skill_name, 0)
    import signature_moves
    cap = (signature_moves.SIGNATURE_CAP
           if signature_moves.selected_name(player) == skill_name else 100)
    if current >= cap:
        return
    if random.randint(1, 100) > (cap - current):
        return
    new_pct = min(cap, current + USAGE_GROWTH_PER_HIT)
    player.skill_proficiencies[skill_name] = new_pct
    if new_pct > current:
        xp = (new_pct - current) * 10
        experience_before = player.experience
        level_up_messages = leveling.grant_experience(player, xp)
        earned_xp = max(0, player.experience - experience_before)
        if session is not None:
            xp_note = f" +{earned_xp} experience." if earned_xp else ""
            session.send(f"&G{skill_name} improves to {new_pct}%!{xp_note}&x")
            for message in level_up_messages:
                session.send(message)
            if new_pct == signature_moves.SIGNATURE_CAP and cap == signature_moves.SIGNATURE_CAP:
                session.send(f"&Y{skill_name} has reached 150% signature mastery! "
                             "Your +25% damage or effect-duration bonus is active.&x")


def tick_passive_skill_growth(player: Player) -> list:
    """Passive skills gain proficiency automatically from being in
    combat -- never from `practice`. Called once per combat round.
    Returns messages for any skill that just grew."""
    messages = []
    for skill in player.learned_skills:
        if not data_passives.is_passive(skill):
            continue
        current = player.skill_proficiencies.get(skill, 0)
        if current >= 100:
            continue
        if random.randint(1, 100) <= PASSIVE_GROWTH_CHANCE_PCT:
            new_pct = min(100, current + PASSIVE_GROWTH_AMOUNT)
            player.skill_proficiencies[skill] = new_pct
            experience_before = player.experience
            messages.extend(leveling.grant_experience(player, (new_pct - current) * 10))
            earned_xp = max(0, player.experience - experience_before)
            if earned_xp:
                messages.append(f"&G+{earned_xp} experience from {skill} improvement.&x")
            messages.append(f"&D(Your {skill} improves through combat experience: {new_pct}%.)&x")
    return messages


SHADOW_CLONE_UPKEEP_PER_CLONE = 3.75  # 15% of the former 25; quarter-Chakra fractions carry between ticks
SHADOW_CLONE_UPKEEP_QUARTERS = 15
SHADOW_CLONE_HEALTH_PERCENT_OF_OWNER = 25  # confirmed design ("1/4 the players go") -- a clone's HP pool is a flat 25% of the CASTER's own current max health, fixed at summon time
SUMMON_HP_PER_LEVEL = 8  # flat HP per summoner level, multiplied by the tier's own base_modifier -- see combat.stat_for_summon_tier / data_summons.py's own docstring for the confirmed "level x modifier" design
SUMMON_DAMAGE_PER_LEVEL = 1.2  # flat damage per summoner level, multiplied by the tier's own base_modifier -- same formula, different flat scale, since a summon's own real per-hit damage should be meaningfully smaller than its own HP pool
TOAD_STOMACH_MOB_TO_HIT_PENALTY = 30  # a real, meaningfully large percentage-point penalty to a TRAPPED mob's own to-hit chance -- the Toad Stomach's whole point is battlefield control, not damage


def shadow_clone_count_for_mastery(mastery_pct: int) -> int:
    """How many clones Shadow Clone Jutsu actually summons, based on
    the caster's OWN mastery percent in that jutsu -- confirmed design
    ("The more mastery of this jutsu allows up to a max of 100% is 3
    clones"). An even 3-way split of the 0-100% range: under 34% is 1
    clone, 34-66% is 2, 67% and up is the full 3."""
    if mastery_pct >= 67:
        return 3
    if mastery_pct >= 34:
        return 2
    return 1


def _shadow_clone_template_vnum(player) -> int:
    """A fake, negative, per-CASTER vnum -- genuinely unique per
    player (never collides with any real, positive-vnum mob/item in
    the game), used only internally as this player's own personal
    clone template. Rebuilt fresh on every cast (see
    _register_shadow_clone_template) so a clone's look/examine text
    always reflects whatever the caster's OWN name/description
    currently is, even if it changed since an earlier clone from the
    same player was summoned."""
    return -1_000_000 - (abs(hash(player.name)) % 1_000_000)


def _register_shadow_clone_template(player) -> int:
    """(Re)builds this player's own personal shadow-clone template --
    short_desc/keywords set to the player's OWN exact name (confirmed
    design: "genuinely indistinguishable at a glance", not "<name>'s
    shadow clone"), long_desc/description mirroring the player's own
    current description text. Rebuilt on every single cast rather
    than cached, so it can never go stale if the player's own
    description changes between casts. act_flags includes "Sentinel"
    (no wander -- a clone should stay put, not roam off) plus a
    dedicated "ShadowClone" flag used only to detect/skip these mobs
    in display code that needs to treat them specially (the health-%
    room-listing suppression -- see commands.cmd_look)."""
    vnum = _shadow_clone_template_vnum(player)
    template = default_template(vnum, player.name)
    template["short_desc"] = player.name
    template["long_desc"] = f"{player.name} is here."
    template["description"] = player.description if player.description else f"{player.name} hasn't set a description."
    template["keywords"] = [player.name]
    template["level"] = player.level
    template["act_flags"] = ["Npc", "Sentinel", "ShadowClone"]
    template["experience_reward"] = 0
    template["ryo_reward"] = 0
    MOB_TEMPLATES[vnum] = template
    return vnum


def is_shadow_clone(mob) -> bool:
    """Whether a spawned Mob instance is a shadow clone, for display
    code that needs to treat these specially (see
    commands.cmd_look's room-listing health-% suppression, confirmed
    design: a clone's line in a room listing must look exactly like a
    real player's, with no health-% tag at all)."""
    return bool(mob.shadow_clone_owner)


def spawn_shadow_clones(player, count: int, element: str = "none") -> List["Mob"]:
    """Spawns `count` real, independently-attackable Mob instances in
    the CASTER's own current room, each a genuine copy of the
    caster's name/description via _register_shadow_clone_template,
    each with a fixed HP pool of SHADOW_CLONE_HEALTH_PERCENT_OF_OWNER%
    of the caster's own CURRENT max health (confirmed design -- set
    once at summon time, not tied to the caster's health changing
    afterward). Does NOT dismiss any pre-existing clones first --
    callers are expected to have already called dismiss_shadow_clones
    if replacing an earlier batch (see use_shadow_clone_jutsu)."""
    vnum = _register_shadow_clone_template(player)
    clone_hp = max(1, player.maximum_health * SHADOW_CLONE_HEALTH_PERCENT_OF_OWNER // 100)
    clones = []
    for _ in range(count):
        clone = spawn_mob(vnum, player.room_vnum)
        if clone is None:
            continue
        clone.health = clone_hp * (2 if element == "sand" else 1)
        clone.max_health = clone.health
        clone.shadow_clone_owner = player.name
        clone.clone_element = element
        # All shadow and elemental clones copy their caster's visible name.
        # The actual nature is retained internally in clone_element for
        # combat, upkeep and mastery rather than advertised in room text.
        clone.name = player.name
        clone.respawns = False  # a popped clone never comes back on its own -- only a fresh cast makes more
        clones.append(clone)
    return clones


def dismiss_shadow_clones(player) -> int:
    """Removes every currently-summoned clone belonging to this
    player from whatever room each one is actually in (a clone may
    have been left behind if the player moved rooms after summoning
    them -- confirmed design: clones persist independently, not
    bound to follow the caster around). Returns how many were
    removed. Safe to call even if the player has no clones at all
    (returns 0)."""
    removed = 0
    player._shadow_clone_upkeep_quarters = 0
    import upkeep_reports
    for skill in ("Shadow Clone Jutsu", "Raiton Kage Bunshin", "Mizu Bunshin", "Deido Bunshin", "Suna Bunshin"):
        upkeep_reports.stop_maintaining(player, skill)
    for room_vnum, room_mobs in list(MOBS_BY_ROOM.items()):
        still_here = []
        removed_here = 0
        for mob in room_mobs:
            if mob.shadow_clone_owner == player.name:
                import clone_control
                clone_control.notify_clone_removed(mob, "disperses")
                removed_here += 1
            else:
                still_here.append(mob)
        if removed_here:
            MOBS_BY_ROOM[room_vnum] = still_here
            removed += removed_here
    return removed


def active_shadow_clones(player) -> List["Mob"]:
    """Every currently-live clone belonging to this player, across
    every room (a clone doesn't follow the caster if they move away
    from it -- see dismiss_shadow_clones' own note). Used for the
    per-round upkeep tick and the caster's own combat-round attack
    loop, both of which need the real, live set rather than a cached
    count that could go stale the moment a clone is popped by someone
    else's attack."""
    return [
        mob for room_mobs in MOBS_BY_ROOM.values() for mob in room_mobs
        if mob.shadow_clone_owner == player.name
    ]


def _summon_template_vnum(tier_key: str) -> int:
    """A fake, negative, per-TIER vnum -- genuinely distinct from the
    shadow clone range (-1,000,000 to -2,000,000, see
    _shadow_clone_template_vnum) so the two can never collide.
    Per-tier rather than per-caster (unlike a shadow clone), since
    every player's own Gamabunta should look identical -- a fixed
    offset from a large negative base, keyed only by the tier's own
    stable string key."""
    return -3_000_000 - (abs(hash(tier_key)) % 1_000_000)


def _register_summon_template(tier: dict) -> int:
    """(Re)builds the real mob template for one specific summon tier
    (see data_summons.CONTRACT_TIERS) -- short_desc/keywords/
    long_desc genuinely reflect that tier's own real display_name
    (e.g. "Gamabunta"), not the summoner's own name, since this is a
    per-tier template shared by every player who ever summons that
    same tier. act_flags includes "Sentinel" (no wander) plus a
    dedicated "Summon" flag, mirroring ShadowClone's own established
    display-suppression convention (see commands.cmd_look)."""
    vnum = _summon_template_vnum(tier["key"])
    template = default_template(vnum, tier["display_name"])
    template["short_desc"] = tier["display_name"]
    template["long_desc"] = f"{tier['display_name']} is here, ready to fight alongside its summoner."
    template["description"] = f"A real, living {tier['display_name']}, bound by summoning contract."
    template["keywords"] = tier["display_name"].lower().split()
    template["act_flags"] = ["Npc", "Sentinel", "Summon"]
    template["experience_reward"] = 0
    template["ryo_reward"] = 0
    MOB_TEMPLATES[vnum] = template
    return vnum


def stat_for_summon_tier(summoner_level: int, tier: dict, per_level: float) -> int:
    """The real, level-scaled stat formula confirmed directly
    ("the strength of the toad is at your currently level x any
    summon appropriate base modifier") -- the SUMMONER's own current
    level, times a flat per-stat scale, times that tier's own
    base_modifier (a higher-tier/rarer summon has a higher modifier,
    so two summons at the same summoner level are still genuinely
    different in real strength). Always at least 1, so a very
    low-level summoner's summon is never truly stat-less."""
    return max(1, round(summoner_level * per_level * tier["base_modifier"]))


# Runtime manifestations of the Toad Stomach are barriers, not mobs.
# Keep separate from MOBS_BY_ROOM: they do not show up as creatures, cannot
# be killed or ordered as fighters, and cease immediately without chakra.
_TOAD_STOMACH_BARRIERS = {}


def toad_stomach_target(mob):
    """Whether a living mob is currently trapped inside an active stomach."""
    return next((barrier for barrier in _TOAD_STOMACH_BARRIERS.values()
                 if barrier.room_vnum == mob.room_vnum
                 and barrier.stomach_target_instance_id == mob.instance_id), None)


def _clear_toad_stomach_effects(barrier):
    for mob in mobs_in_room(barrier.room_vnum):
        if mob.instance_id == barrier.stomach_target_instance_id:
            mob.summon_trap_applied = False
            mob.summon_trap_to_hit_penalty = 0


def dismiss_summon(player) -> int:
    """Removes this player's own currently-active summon (there is
    ever only ONE, per direct confirmation: "A real, single summon at
    a time -- summoning a new one dismisses whatever was already
    there") from whatever room it's actually in. Returns how many
    were removed (0 or 1 -- a list-based removal for genuine symmetry
    with dismiss_shadow_clones' own return shape, even though only
    one can ever exist). Safe to call with no active summon at all."""
    removed = 0
    barrier = _TOAD_STOMACH_BARRIERS.pop(player.name, None)
    if barrier is not None:
        _clear_toad_stomach_effects(barrier)
        removed += 1
    for room_vnum, room_mobs in list(MOBS_BY_ROOM.items()):
        still_here = []
        removed_here = 0
        for mob in room_mobs:
            if mob.summon_owner == player.name:
                removed_here += 1
            else:
                still_here.append(mob)
        if removed_here:
            MOBS_BY_ROOM[room_vnum] = still_here
            removed += removed_here
    return removed


def follow_owner_summon(player, from_room: int, to_room: int) -> None:
    """Summons ordered to follow move with their owner, not by teleporting
    to unrelated locations or ignoring a stay/guard/sleep command."""
    summon = active_summon(player)
    if (summon is None or getattr(summon, "is_toad_stomach_barrier", False)
            or summon.room_vnum != from_room
            or getattr(summon, "summon_order", "follow") != "follow"):
        return
    room_mobs = MOBS_BY_ROOM.get(from_room, [])
    if summon in room_mobs:
        room_mobs.remove(summon)
    summon.room_vnum = to_room
    MOBS_BY_ROOM.setdefault(to_room, []).append(summon)


def tick_ordered_summon(session) -> None:
    """An ATTACK order works even while its summoner is not attacking."""
    player = session.player
    summon = active_summon(player)
    if (not summon or summon.health <= 0 or summon.room_vnum != player.room_vnum
            or summon.summon_order != "attack" or session.combat_target):
        return
    target = next((m for m in mobs_in_room(summon.room_vnum)
                   if m.instance_id == summon.summon_attack_target_id
                   and m.health > 0), None)
    if target is None:
        summon.summon_order = "guard"
        summon.summon_attack_target_id = 0
        return
    _summon_attack_mob_once(session, player, summon, target)
    if target.health <= 0:
        handle_mob_defeat(session, target)


def tick_summon_upkeep(session) -> None:
    """Toad stomach barriers persist for paid chakra, never a timer."""
    player = session.player
    summon = active_summon(player)
    if not summon:
        return
    import data_summons
    tier = data_summons.tier_by_key(summon.summon_tier_key)
    if not tier or tier.get("mechanic") != "trap":
        return
    upkeep = max(6, player.level // 12)
    if player.chakra < upkeep:
        dismiss_summon(player)
        session.send("&RYour Toad Stomach barrier collapses as its chakra upkeep runs out!&x")
        return
    player.chakra -= upkeep
    if summon.stomach_target_instance_id:
        target = next((mob for mob in mobs_in_room(summon.room_vnum)
                       if mob.instance_id == summon.stomach_target_instance_id and mob.health > 0), None)
        if target is None:
            dismiss_summon(player)
            session.send("&YThe Toad Stomach releases its vanished target and folds away.&x")
            return
        if not target.summon_trap_applied:
            target.summon_trap_applied = True
            target.summon_trap_to_hit_penalty = TOAD_STOMACH_MOB_TO_HIT_PENALTY
            session.send(f"&RThe Toad Stomach seals every exit around {target.name}!&x")
        if not engage_damage_attack(session, target):
            return
        damage = max(2, target.max_health // 25)
        target.health -= damage
        session.send(f"&RThe living stomach devours {target.name} for {damage} damage!&x")
        if target.health <= 0:
            handle_mob_defeat(session, target)
            dismiss_summon(player)


def reset_summon_round_state(player) -> None:
    """Clears the per-fight summon flags (Section 118) -- Manda's own
    flee-lock and Enma's own weapon buff -- the instant a real PvE
    fight actually ends, whichever way it ends (the mob died, the
    player was defeated, the mob was left behind, or the mob was
    somehow already gone). Called from every genuine "PvE fight has
    ended" moment, so a bind or weapon buff from one fight can never
    bleed into a completely unrelated later one. Does NOT touch the
    active summon itself (see dismiss_summon for that) -- a summon
    stays out across fights until genuinely dismissed or replaced,
    matching the same persistence Shadow Clone Jutsu's own clones
    already have."""
    player.summon_flee_locked = False
    player.summon_weapon_buff_active = False


def active_summon(player):
    """This player's own currently-active summon Mob, or None. There
    is ever only one (see dismiss_summon's own docstring), so this
    returns a single Mob (or None), not a list."""
    if player.name in _TOAD_STOMACH_BARRIERS:
        return _TOAD_STOMACH_BARRIERS[player.name]
    for room_mobs in MOBS_BY_ROOM.values():
        for mob in room_mobs:
            if mob.summon_owner == player.name:
                return mob
    return None


def spawn_summon(player, tier: dict) -> "Mob":
    """Summons a real, independently-attackable Mob instance of the
    given tier (see data_summons.CONTRACT_TIERS) into the player's
    OWN current room. Does NOT dismiss any pre-existing summon first
    -- callers are expected to have already called dismiss_summon if
    replacing an earlier one (see use_summoning_jutsu), mirroring
    spawn_shadow_clones' own established convention exactly. HP/
    damage are both derived from stat_for_summon_tier, fixed at
    summon time (not tied to the summoner's own level changing
    afterward, matching the same "set once" precedent shadow clones
    already established)."""
    hp = stat_for_summon_tier(player.level, tier, SUMMON_HP_PER_LEVEL)
    if tier.get("mechanic") == "trap":
        from types import SimpleNamespace
        barrier = SimpleNamespace(name=tier["display_name"], health=hp, max_health=hp,
                                  room_vnum=player.room_vnum, summon_owner=player.name,
                                  summon_tier_key=tier["key"], summon_order="guard",
                                  stomach_target_instance_id=0,
                                  summon_attack_target_id=0,
                                  is_toad_stomach_barrier=True)
        _TOAD_STOMACH_BARRIERS[player.name] = barrier
        return barrier
    vnum = _register_summon_template(tier)
    mob = spawn_mob(vnum, player.room_vnum)
    if mob is None:
        return None
    mob.health = hp
    mob.max_health = hp
    mob.summon_owner = player.name
    mob.summon_tier_key = tier["key"]
    mob.respawns = False  # a popped/dismissed summon never comes back on its own -- only a fresh cast makes a new one
    return mob


def tick_shadow_clone_upkeep(player) -> list:
    """Charges the CURRENTLY LIVE set of this player's clones (see
    active_shadow_clones) their per-round chakra upkeep (see
    SHADOW_CLONE_UPKEEP_PER_CLONE). Called every pulse regardless of
    combat state (confirmed design: "Clones can be summoned before
    combat and persist until unsigned or chakra runs out") -- matching
    tick_effects_pulse's own established always-ticks precedent, NOT
    gated behind resolve_pulse/combat state the way this used to be
    when clones were still an abstract counter. If the player can't
    afford the full upkeep for every currently-live clone, clones are
    dismissed one at a time (cheapest possible response to a chakra
    shortfall) until what remains is affordable, rather than an
    all-or-nothing dismissal."""
    clones = active_shadow_clones(player)
    if not clones:
        player._shadow_clone_upkeep_quarters = 0
        return []
    import upkeep_reports
    messages = []
    while clones:
        quarters = len(clones) * SHADOW_CLONE_UPKEEP_QUARTERS + getattr(player, "_shadow_clone_upkeep_quarters", 0)
        cost, remainder = divmod(quarters, 4)
        if player.chakra >= cost:
            player.chakra -= cost
            player._shadow_clone_upkeep_quarters = remainder
            messages.extend(upkeep_reports.record(player, "Shadow Clones", cost))
            clone = clones[0]
            skill = {"none": "Shadow Clone Jutsu", "lightning": "Raiton Kage Bunshin",
                     "water": "Mizu Bunshin", "earth": "Deido Bunshin",
                     "sand": "Suna Bunshin"}.get(clone.clone_element, "Shadow Clone Jutsu")
            upkeep_reports.maintain_skill(player, skill)
            return messages
        popped = clones.pop()
        import clone_control
        clone_control.notify_clone_removed(popped, "collapses when you run out of Chakra")
        room_mobs = MOBS_BY_ROOM.get(popped.room_vnum, [])
        if popped in room_mobs:
            room_mobs.remove(popped)
        if clones:
            messages.append(f"&RYou don't have enough chakra to sustain all your shadow clones -- one dispels! ({len(clones)} remaining.)&x")
        else:
            messages.append("&RYou don't have enough chakra to sustain your shadow clone -- it dispels!&x")
    messages.extend(upkeep_reports.flush(player, "Shadow Clones"))
    player._shadow_clone_upkeep_quarters = 0
    for skill in ("Shadow Clone Jutsu", "Raiton Kage Bunshin", "Mizu Bunshin", "Deido Bunshin", "Suna Bunshin"):
        upkeep_reports.stop_maintaining(player, skill)
    return messages


def tick_sharingan_upkeep(player) -> list:
    """Charges the Sharingan's per-round chakra+stamina upkeep while
    commands.cmd_sharingan has it toggled on (see that command for the
    ability itself; the actual dodge bonus is applied at the two
    dodge_chance call sites in resolve_pulse/resolve_pvp_pulse below,
    not here). Chakra cost scales down with tomoe count (commands.
    sharingan_chakra_upkeep) -- less taxing with more tomoe open, per
    direct request; stamina cost stays flat regardless of tomoe count.
    Called once per combat round, same pattern as
    tick_passive_skill_growth above. If the player can't afford the
    upkeep, it turns itself off automatically rather than draining a
    resource into the negatives. Idle upkeep is charged separately by
    regen.tick_sharingan_idle."""
    if not player.sharingan_active:
        return []
    import commands
    import upkeep_reports
    chakra_cost = commands.sharingan_chakra_upkeep(player.bloodline_tomoe)
    if player.chakra < chakra_cost or player.stamina < commands.SHARINGAN_STAMINA_UPKEEP:
        player.sharingan_active = False
        return upkeep_reports.flush(player, "Sharingan") + ["&RYour chakra and stamina give out -- your Sharingan fades back to black.&x"]
    player.chakra -= chakra_cost
    player.stamina -= commands.SHARINGAN_STAMINA_UPKEEP
    return upkeep_reports.record(player, "Sharingan", chakra_cost, commands.SHARINGAN_STAMINA_UPKEEP)


def tick_sharingan_mastery_gain(player) -> list:
    """Rolls the Sharingan's small, Talent-scaled upkeep chance to
    gain mastery (data_kekkei_genkai.tick_mastery_gain) while it's
    actively toggled on -- per explicit design confirmation, only once
    the bloodline is already formally awakened (bloodline_awakened),
    it doesn't silently accumulate before that. Called once per combat
    round, same pattern as tick_sharingan_upkeep above -- costs
    nothing and rolls nothing at all while not actively fighting.
    Silent on every round that doesn't cross a new tomoe threshold;
    only narrates the discrete, already-player-visible milestone of
    gaining a new tomoe, never a raw mastery number or percentage --
    same security posture the rest of this framework was built
    around, see data_kekkei_genkai.py's own docstring."""
    if not player.sharingan_active or not player.bloodline_awakened:
        return []
    import data_kekkei_genkai
    result = data_kekkei_genkai.tick_mastery_gain(player)
    if result["tomoe_increased"]:
        return [f"&RYour Sharingan sharpens -- you now command {result['new_tomoe']} tomoe.&x"]
    return []


def tick_automatic_bloodline_awakening(player) -> list:
    """"The first quest" -- the real, live, automatic awakening
    check, per direct request/confirmation (Section 112: "turn the
    sharingan unlock quest into something that is automatic that has
    a chance of awakening... this is the first quest not the
    second"). Called once per combat round (both PvE and PvP), same
    pattern as tick_sharingan_upkeep/tick_sharingan_mastery_gain
    above -- rolls nothing and costs nothing at all while not
    actively fighting, matching direct confirmation this should only
    ever trigger in combat.

    Applies to any of the 5 kekkei genkai, not just Sharingan (see
    data_kekkei_genkai.attempt_automatic_awakening's own docstring
    for the full eligibility/chance design). On a genuine awakening,
    the player themselves gets a real narration line, AND every
    other connected, playing session gets a genuinely global
    broadcast -- confirmed exact wording, deliberately generic so it
    never reveals WHICH of the 5 bloodlines actually awakened,
    matching the hidden-by-design posture the rest of this framework
    already has."""
    import data_kekkei_genkai
    result = data_kekkei_genkai.attempt_automatic_awakening(player)
    if not result["awakened_this_call"]:
        return []

    import session as session_module
    for s in session_module.ACTIVE_SESSIONS:
        if s.state.name == "PLAYING":
            s.send(f"&Y{player.name}'s bloodline has awakened!&x")
            s.send_prompt()
    return ["&RSomething within you stirs and awakens -- your bloodline has awakened!&x"]


def _jutsu_damage_bonus(player: Player) -> int:
    """The stat/equipment-driven bonus added ON TOP of a jutsu's own
    base damage roll (roll_jutsu_damage), per direct correction
    ("justsu damage should be based on strength and a players
    damroll + weapon damroll + weapon damage"). Mirrors the FULL
    stat/equipment contribution a regular weapon attack gets
    (_player_attack_damage) -- Strength's own direct contribution,
    the real player-level damroll (derived_stats.damage_roll, a
    genuine pre-existing Strength-based derived stat that had never
    actually been wired into ANY combat path before this turn -- now
    fixed for both regular attacks and jutsu at once, confirmed
    directly), the wielded weapon's own intrinsic damage-by-type
    bonus, and the wielded weapon's own damroll bonus. Everything
    except the base 3-7 roll (the jutsu already supplies its own base
    via roll_jutsu_damage) and passive multipliers (jutsu apply their
    own separate multiplier chain already, in use_jutsu/
    use_jutsu_on_player, not here)."""
    import commands as commands_module
    import data_personality
    import tailed_beasts
    bonus = player.strength // 4
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    bonus += derived_stats.damage_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "damage_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player))
    bonus += commands_module.equipped_weapon_type_damage_bonus(player)
    bonus += commands_module.equipped_weapon_damroll_bonus(player)
    return bonus


def _kekkei_no_me_damage_multiplier(player: Player, jutsu: dict) -> float:
    """The real, confirmed +50% damage multiplier (Section 140,
    data_mangekyo.KEKKEI_NO_ME_ELEMENT_DAMAGE_BONUS_PCT) for the
    caster's own jutsu, ONLY while standing in a room they themselves
    transformed with Kekkei no Me, AND only when the jutsu being cast
    genuinely matches that room's own element. Checked live at the
    moment of each real cast (not precomputed/cached), since the room
    could expire or the caster could leave between casts. Returns
    1.0 (no change) in every other case."""
    room = world.WORLD.get(player.room_vnum)
    if room is None or room.kekkei_no_me_caster != player.name:
        return 1.0
    if jutsu.get("element") != room.kekkei_no_me_element:
        return 1.0
    import data_mangekyo
    return 1.0 + (data_mangekyo.KEKKEI_NO_ME_ELEMENT_DAMAGE_BONUS_PCT / 100.0)



def mastered_jutsu_breakthrough_percent(player: Player, jutsu: dict) -> int:
    """Modest high-level bonus only for techniques fully mastered by actual use.

    A high character level does not confer this benefit to untrained jutsu.
    Signature techniques can exceed 100% proficiency, and still qualify.
    """
    if player.level < 100:
        return 0
    if player.skill_proficiencies.get(jutsu.get("display_name", ""), 0) < 100:
        return 0
    return 2 * (1 + min(6, (player.level - 100) // 25))


def roll_jutsu_damage(jutsu: dict) -> "tuple[int, bool]":
    """Rolls this jutsu's damage, returning (amount, was_explosive).
    Every ordinary jutsu (no "explosive_chance_pct" field at all)
    just rolls its own damage range normally, was_explosive always
    False. Explosive Tag Kunai is the one confirmed exception -- a
    SINGLE roll picks EITHER the normal damage range OR the bigger
    explosive_damage range, never both on the same throw (confirmed
    design: "A single roll picks ONE outcome")."""
    if "explosive_chance_pct" in jutsu and random.randint(1, 100) <= jutsu["explosive_chance_pct"]:
        lo, hi = jutsu["explosive_damage"]
        return random.randint(lo, hi), True
    lo, hi = jutsu["damage"]
    return random.randint(lo, hi), False


def _genjutsu_hit_bonus(player, jutsu):
    return 12 if jutsu.get("class_requirement") == "genjutsu" and "chisei" in player.active_status_effects else 0


def _mirror_illusion_damage(jutsu, target, rolled):
    """Insect Eyes makes the victim suffer their own normal attack sequence."""
    if jutsu.get("jutsu_type") != "mirror":
        return rolled
    if isinstance(target, Mob):
        return max(1, rolled + sum(_mob_attack_damage(target) for _ in range(max(1, target.attacks))))
    return max(1, rolled + sum(_player_attack_damage(target) for _ in range(1 + _roll_extra_attacks(target))))


def _genjutsu_impact(jutsu, target):
    if jutsu.get("stamina_drain"):
        target.stamina = max(0, target.stamina - jutsu["stamina_drain"])


NANAIRO_STRIKES = (
    ("fire", None), ("water", None), ("earth", None),
    ("wind", None), ("lightning", None),
    ("soul", "poisoned"), ("dark", "blinded"),
)


def _sevenfold_damage(jutsu, caster):
    """Roll each Nanairo strike separately; a missed color deals no damage.

    Its five elemental colors are part of this one Ninjutsu, rather than
    seven independently castable elemental jutsu. Matching chakra nature
    strengthens only that color; soul and dark have no nature gate.
    """
    total = 0
    landed = []
    effects = []
    for color, effect in NANAIRO_STRIKES:
        if random.randint(1, 100) > 75:
            continue
        strike = random.randint(*jutsu["damage"])
        if color in (caster.chakra_nature, caster.chakra_nature_secondary, caster.chakra_nature_tertiary):
            strike = round(strike * 1.2)
        total += strike
        landed.append(color)
        if effect and random.randint(1, 100) <= 25:
            effects.append(effect)
    return total, landed, effects


def _try_counter_kunai(session, target_session, target, attacker_name: str, jutsu_display_name: str) -> bool:
    """Whether target (a player defending against a jutsu_type
    "thrown" attack) successfully blocks it with Counter Kunai --
    confirmed design: works against ANY thrown jutsu (Throw Shuriken/
    Throw Kunai/Explosive Tag Kunai), not just kunai-specific ones;
    fully blocks (zero damage), not a reduction; consumes one of the
    DEFENDER'S OWN kunai from their inventory, same requires_item
    convention as the attacking jutsu itself. Returns False (does
    nothing at all) if the defender doesn't know Counter Kunai or
    isn't carrying a kunai right now -- this is genuinely passive, so
    a defender with no kunai on hand just takes the hit normally,
    exactly as if this ability didn't exist for them this time."""
    if "Counter Kunai" not in target.learned_skills:
        return False
    held_kunai = next((item for item in target.inventory if "kunai" in item.lower()), None)
    if not held_kunai:
        return False
    target.inventory.remove(held_kunai)
    jutsu_colors.send(session, f"&C{target.name} whips out a kunai and deflects your {jutsu_display_name} completely!&x")
    jutsu_colors.send(target_session, f"&CYou whip out a kunai and deflect {attacker_name}'s {jutsu_display_name} completely!&x")
    return True


def _sharingan_dodge_bonus(defender) -> int:
    """The Sharingan's active dodge bonus (see commands.
    cmd_sharingan/tick_sharingan_upkeep above) for whoever is about to
    be attacked -- 0 if they don't have it toggled on right now.
    Amplified at tomoe 6 (the capstone stage), per the fuller
    progression table's "major perception/combat bonus" description."""
    import commands
    if not defender.sharingan_active:
        return 0
    if defender.bloodline_tomoe >= 6:
        return commands.SHARINGAN_DODGE_BONUS_PERCENT_TOMOE_6
    return commands.SHARINGAN_DODGE_BONUS_PERCENT


GENJUTSU_MENTAL_PENALTIES = frozenset({"confused", "narakumi", "soundless", "disoriented", "haze", "ringing"})


def _accuracy_penalty_from_effects(attacker) -> int:
    """The total to-hit percentage penalty from every active status
    effect on the attacker that carries an "accuracy_penalty" field
    (narakumi, and the older "confused" effect -- defined with this
    same field for years but never actually wired into any of the
    game's to-hit calculations until now). Returns a POSITIVE number
    meant to be SUBTRACTED at the call site, matching how every other
    to_hit modifier here is a plain additive term (this one's just
    negative). Works for both a player attacker and a mob attacker --
    both carry active_status_effects in the same shape."""
    total = 0
    for name, effect_state in attacker.active_status_effects.items():
        defn = status_effects.EFFECT_DEFS.get(name, {})
        penalty = defn.get("accuracy_penalty", 0)
        if name in GENJUTSU_MENTAL_PENALTIES and "focused_mind" in attacker.active_status_effects:
            penalty //= 2
        total += penalty
    return total


def _is_action_blocked(attacker) -> bool:
    """Whether attacker's active status effects include one that
    carries blocks_action=True (stunned, genjutsu_locked, and the new
    paralyzed) -- confirmed and wired for real (Section 87), the same
    "documented but never actually checked" gap already found and
    fixed once this session for accuracy_penalty. Confirmed design:
    checked at PER-ROUND attack resolution (both a regular attack and
    a jutsu cast), not the initial attack/perform command -- an
    already-ongoing fight continues normally, individual rounds are
    what get skipped while blocked. Works for both a player and a mob
    attacker, both carry active_status_effects in the same shape.

    Also checks tsukuyomi_frozen (Section 140, per direct
    confirmation: the target is genuinely frozen in place, unable to
    act, for the whole real duration) -- a direct Player field rather
    than a generic status effect, since it's tied to a real, active
    Mangekyo technique rather than an ordinary combat status."""
    if getattr(attacker, "tsukuyomi_frozen", False):
        return True
    for name in attacker.active_status_effects:
        if status_effects.EFFECT_DEFS.get(name, {}).get("blocks_action", False):
            return True
    return False


def _sharingan_hitroll_bonus(attacker) -> int:
    """The 3-tomoe Sharingan's active hitroll bonus for whoever is
    about to attack -- 0 unless they're actively toggled on AND have
    reached at least 3 tomoe (data_kekkei_genkai.tick_mastery_gain),
    per direct design confirmation. Same shape as _sharingan_dodge_
    bonus above, just offense instead of defense. Amplified at tomoe 6
    (the capstone stage)."""
    import commands
    if not (attacker.sharingan_active and attacker.bloodline_tomoe >= 3):
        return 0
    if attacker.bloodline_tomoe >= 6:
        return commands.SHARINGAN_HITROLL_BONUS_PERCENT_TOMOE_6
    return commands.SHARINGAN_HITROLL_BONUS_PERCENT


SUMMON_WEAPON_BUFF_HITROLL_BONUS = 15
SUMMON_WEAPON_BUFF_DAMAGE_PERCENT = 20

def _summon_weapon_buff_hitroll_bonus(attacker) -> int:
    """Enma's own real "weapon_buff" mechanic (Section 118) -- a flat
    hitroll bonus for whoever currently has an active weapon-buff
    summon out, checked the same inline way _sharingan_hitroll_bonus
    already is. 0 for anyone without the flag set (see combat.
    _resolve_summon_round, the only place that ever sets it)."""
    return SUMMON_WEAPON_BUFF_HITROLL_BONUS if attacker.summon_weapon_buff_active else 0


def _summon_weapon_buff_damage_percent(attacker) -> int:
    """Enma's own real damage-side bonus, applied as a genuine
    percentage increase to the attacker's own raw damage roll --
    0 for anyone without the flag set."""
    return SUMMON_WEAPON_BUFF_DAMAGE_PERCENT if attacker.summon_weapon_buff_active else 0


def _sharingan_predict_and_reduce_damage(defender, dmg: int) -> int:
    """The 3-tomoe Sharingan's Movement Prediction perk, per direct
    design confirmation ("chance outside of dodge to block an attack
    but not dodge... when it fails it will say you weren't fast enough
    to counter" / "reduces damage by a set amount/percentage rather
    than blocking it entirely"). Callers are expected to only call
    this AFTER the normal dodge roll has already failed -- Prediction
    is a genuinely separate roll, not a second chance at the same
    dodge, and it never fully negates the attack the way a dodge does,
    only cuts its damage. Returns the (possibly reduced) damage
    unchanged if the player doesn't have Prediction available at all
    (not actively toggled, or under 3 tomoe) or the roll itself
    fails -- callers distinguish the two cases by comparing the
    returned value to the original `dmg` they passed in, same pattern
    already used elsewhere in this module rather than a separate
    boolean return. The chance itself is amplified at tomoe 6 (the
    capstone stage, "Sharingan Insight / Predictive Counter" per the
    fuller progression table) -- the damage reduction percentage
    stays the same throughout, only the odds of triggering it improve."""
    import commands
    if not (defender.sharingan_active and defender.bloodline_tomoe >= 3):
        return dmg
    chance = (
        commands.SHARINGAN_PREDICTION_CHANCE_PERCENT_TOMOE_6
        if defender.bloodline_tomoe >= 6
        else commands.SHARINGAN_PREDICTION_CHANCE_PERCENT
    )
    if random.randint(1, 100) <= chance:
        return int(dmg * (1 - commands.SHARINGAN_PREDICTION_DAMAGE_REDUCTION_PERCENT / 100))
    return dmg


def _roll_extra_attacks(player) -> int:
    """How many EXTRA attacks (beyond the guaranteed first) a player
    gets this combat round, per explicit request for Second/Third/
    Fourth/Fifth Attack (data_jutsu.MULTI_ATTACK_SKILLS). Cascading,
    not four independent rolls -- Third Attack is only even attempted
    if Second Attack's own roll already succeeded this round
    (thematically, a third swing shouldn't happen without a second one
    landing first), and so on down the chain. Each skill's own
    proficiency is its % chance of triggering -- a freshly-granted
    skill at 0% contributes nothing until trained up."""
    extra = 0
    for skill_name, level_req, required_class in data_jutsu.MULTI_ATTACK_SKILLS:
        if (skill_name not in player.learned_skills
                or (required_class and player.primary_class != required_class)
                or player.level < data_jutsu.multi_attack_required_level(player, skill_name, level_req)):
            break
        proficiency = max(0, min(100, player.skill_proficiencies.get(skill_name, 0)))
        if random.randint(1, 100) <= proficiency:
            extra += 1
        else:
            break
    return extra


def _weapon_expert_damage(player, damage):
    """The old MUD's armed-only, mastery-based 50% damage proc."""
    if (player.primary_class == "bukijutsu" and player.equipment.get("wielded")
            and "Weapon Expert" in player.learned_skills
            and random.randint(1, 100) <= player.skill_proficiencies.get("Weapon Expert", 0)):
        grow_skill_from_usage(player, "Weapon Expert")
        return max(1, int(damage * 1.5))
    return damage


def _soto_uke_blocks(defender, attacker_level):
    """Half mastery, a one-in-three follow-up, and 10 Stamina per block."""
    if (defender.primary_class != "taijutsu" or "Soto Uke" not in defender.learned_skills
            or defender.stamina < 10 or _is_action_blocked(defender)):
        return False
    chance = max(0, min(100, defender.skill_proficiencies.get("Soto Uke", 0) // 2
                         + defender.level - attacker_level))
    if random.randint(1, 100) <= chance and random.randint(1, 3) == 1:
        defender.stamina -= 10
        grow_skill_from_usage(defender, "Soto Uke")
        return True
    return False


def _offhand_attack(session, target, target_session=None):
    """One extra swing with the off-hand weapon's own properties."""
    player = session.player
    offhand = player.equipment.get("offhand")
    if (player.primary_class != "bukijutsu" or not offhand or not player.equipment.get("wielded")
            or "Dual Wield" not in player.learned_skills or player.stamina < 5
            or random.randint(1, 100) > player.skill_proficiencies.get("Dual Wield", 0)):
        return
    player.stamina -= 5
    grow_skill_from_usage(player, "Dual Wield")
    primary = player.equipment["wielded"]
    player.equipment["wielded"] = offhand
    try:
        if target_session is None:
            _player_attack_mob_once(session, player, target)
        else:
            _player_attack_target_once(session, player, target_session, target)
    finally:
        # The durability callback may have destroyed the temporarily wielded
        # off-hand blade; do not restore a broken duplicate into its real slot.
        player.equipment["offhand"] = player.equipment.get("wielded")
        player.equipment["wielded"] = primary


def _player_attack_mob_once(session, player, mob, guaranteed_hit=False) -> bool:
    """One single attack (to-hit roll through any bleeding tick) from
    player against mob -- extracted so resolve_pulse can call this
    once per attack a player has earned this round (see
    _roll_extra_attacks), rather than duplicating the whole sequence
    inline for each one. Behavior is identical to what resolve_pulse
    always did for its one guaranteed attack.

    Confirmed design (reversed from an earlier turn): automatic
    attacks fire normally during a hand-sign cast, including any
    extra attacks per round -- a character with something like third
    attack was otherwise strictly worse off casting jutsu at all,
    since every one of those extra swings was lost for the whole
    delay. The jutsu itself still lands separately once it resolves;
    this is purely about whether the ORDINARY automatic attack is
    also suppressed while it forms. _is_action_blocked (stun/
    paralysis) still correctly suppresses it -- only the pending-cast
    lockout is gone."""
    if _is_action_blocked(player):
        session.send("You are unable to act!")
        return
    import commands as commands_module
    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_hit_roll = derived_stats.hit_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "hit_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) + commands_module.equipped_weapon_hitroll_bonus(player) + _summon_weapon_buff_hitroll_bonus(player)
    mob_armor_class = derived_stats.armor_class(mob) - commands_module.equipped_armor_class_bonus(mob)
    import hidden_mist
    import sage_mode
    to_hit = derived_stats.to_hit_chance(player_hit_roll, mob_armor_class) + weather.combat_accuracy_modifier() + _sharingan_hitroll_bonus(player) + hyuga.accuracy(player) - _accuracy_penalty_from_effects(player) + hidden_mist.advantage(player, mob) + sage_mode.accuracy(player) + general_skills.focused_accuracy(player) + sword_styles.accuracy_bonus(player) + eight_gates.accuracy(player) + __import__("susanoo").accuracy_bonus(player)
    to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit))
    attack_verb = data_weapons.attack_verb_for_item(player.equipment.get("wielded", ""))
    weapon_skill = data_weapons.skill_for_item(player.equipment.get("wielded", ""))
    if weapon_skill:
        grow_skill_from_usage(player, weapon_skill, session=session)
    if not guaranteed_hit and random.randint(1, 100) > to_hit:
        session.send(f"You {attack_verb} at {mob.name} but miss!")
        import room_actions
        room_actions.emit(session, f"{player.name} {data_weapons.attack_verb_for_item_third_person(player.equipment.get('wielded', ''))} at {mob.name} but misses.")
        return
    if not engage_damage_attack(session, mob):
        return False
    dmg = _player_attack_damage(player)
    dmg = sword_styles.damage_bonus(player, dmg)
    dmg = _weapon_expert_damage(player, dmg)
    dmg = int(dmg * (100 + _summon_weapon_buff_damage_percent(player)) / 100)
    is_crit = random.randint(1, 100) <= derived_stats.critical_chance(player, set_bonus + data_personality.personality_bonus_percent(player, "critical_chance"))
    if is_crit:
        dmg = int(dmg * 1.5)
    dmg = commands_module.reduce_weapon_damage(mob, data_weapons.weapon_type_for_item(player.equipment.get("wielded", "")), dmg)
    dmg = ninja_arts.weapon_hit(player, mob, dmg, session=session)
    mob.health -= dmg
    sword_styles.successful_strike(player, session)
    if is_crit:
        session.send(f"&YCritical hit!&x You {attack_verb} {mob.name} for {damage_messages.describe_damage(dmg)} damage. {damage_messages.impact_flavor(dmg)}")
    else:
        session.send(f"You {attack_verb} {mob.name} for {damage_messages.describe_damage(dmg)} damage. {damage_messages.impact_flavor(dmg)}")
    import room_actions
    room_actions.emit(session, f"{player.name} {data_weapons.attack_verb_for_item_third_person(player.equipment.get('wielded', ''))} {mob.name} for {damage_messages.describe_damage(dmg)} damage.")
    if "bleeding" in mob.active_status_effects:
        bleed = status_effects.bleeding_damage()
        mob.health -= bleed
        session.send(f"{mob.name} bleeds for {damage_messages.describe_damage(bleed)} damage.")
    import equipment_durability
    equipment_durability.wear_weapon(session)
    return True


SHADOW_CLONE_DAMAGE_SCALE = 0.5  # a clone hits for half what the player's own attack would


def _clone_attack_mob_once(session, player, mob, clone=None) -> None:
    """One single attack from ONE shadow clone against mob -- same
    to-hit math and weapon as the player's own attack (confirmed
    design: "using the player's own stats/weapon"), but damage scaled
    down (SHADOW_CLONE_DAMAGE_SCALE) so 3 clones don't simply
    quadruple the player's own damage output. Called once per active
    clone, each round, from resolve_pulse -- see
    active_shadow_clones(player)."""
    import commands as commands_module
    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_hit_roll = derived_stats.hit_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "hit_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) + commands_module.equipped_weapon_hitroll_bonus(player)
    mob_armor_class = derived_stats.armor_class(mob) - commands_module.equipped_armor_class_bonus(mob)
    to_hit = derived_stats.to_hit_chance(player_hit_roll, mob_armor_class) + weather.combat_accuracy_modifier() + _sharingan_hitroll_bonus(player) + hyuga.accuracy(player) - _accuracy_penalty_from_effects(player)
    to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit))
    attack_verb = data_weapons.attack_verb_for_item(player.equipment.get("wielded", ""))
    element = getattr(clone, "clone_element", "none")
    clone_label = f"{element} clone" if element != "none" else "shadow clone"
    if random.randint(1, 100) > to_hit:
        session.send(f"Your {clone_label} {attack_verb}s at {mob.name} but misses!")
        return
    if not engage_damage_attack(session, mob):
        return
    dmg = int(_player_attack_damage(player) * SHADOW_CLONE_DAMAGE_SCALE)
    if element == "earth":
        dmg = round(dmg * 1.25)
    dmg = commands_module.reduce_weapon_damage(mob, data_weapons.weapon_type_for_item(player.equipment.get("wielded", "")), dmg)
    mob.health -= dmg
    session.send(f"Your {clone_label} {attack_verb}s {mob.name} for {damage_messages.describe_damage(dmg)} damage.")
    clone_effect = {"lightning": "paralyzed", "water": "drained", "sand": "entangled"}.get(element)
    if clone_effect and random.randint(1, 100) <= 20:
        status_effects.apply_effect(mob.active_status_effects, clone_effect, source=f"{element} clone", duration_override=2)
        session.send(status_effects.EFFECT_DEFS[clone_effect]["message"].format(target=mob.name))
    if "bleeding" in mob.active_status_effects:
        bleed = status_effects.bleeding_damage()
        mob.health -= bleed
        session.send(f"{mob.name} bleeds for {damage_messages.describe_damage(bleed)} damage.")


def _summon_attack_mob_once(session, player, summon, mob) -> None:
    """One single attack from a player's own active summon against
    mob -- per direct request/confirmation (Section 118), ONLY for a
    summon whose own tier mechanic is genuinely "fighter" (an
    ordinary independent combatant); every other mechanic (trap/
    bind/healer/safety_net/flee_lock/weapon_buff) is a deliberately
    DIFFERENT kind of battle role and never calls this at all. Uses
    the summon's own real, tier-scaled damage (stat_for_summon_tier),
    genuinely separate math from both the player's own attack and a
    shadow clone's scaled-down copy of it, since a summon is its own
    real creature, not an echo of the summoner."""
    import data_summons
    tier = data_summons.tier_by_key(summon.summon_tier_key)
    to_hit = 70  # a summon's own real, tier-independent base accuracy -- deliberately simple, not derived from the player's own stats
    if random.randint(1, 100) > to_hit:
        session.send(f"{summon.name} attacks {mob.name} but misses!")
        return
    if not engage_damage_attack(session, mob):
        return
    dmg = stat_for_summon_tier(player.level, tier, SUMMON_DAMAGE_PER_LEVEL)
    mob.health -= dmg
    session.send(f"{summon.name} attacks {mob.name} for {damage_messages.describe_damage(dmg)} damage.")


def _resolve_summon_round(session, player, mob) -> None:
    """The real per-round dispatcher for a player's own active summon
    (Section 118) -- checked once per combat round (PvE only for the
    round-by-round mechanics below; see handle_pvp_defeat/cmd_flee
    for the 2 mechanics that matter at a different moment instead).
    Does nothing at all if the player has no active summon.

    Per direct confirmation, every contract's own TOP tier has a
    genuinely different battle role, not just bigger numbers:
      "fighter"     -- an ordinary attack (_summon_attack_mob_once).
      "healer"      -- heals the player instead of attacking at all,
                        every round it's out (SLUG_HEAL_PERCENT-scaled
                        via the tier's own heal_percent).
      "trap"        -- Toad Stomach: restrains the MOB (a real,
                        meaningfully large to-hit PENALTY applied to
                        the mob's own attacks for the rest of this
                        fight), but never deals ongoing damage of its
                        own at all -- a pure battlefield-control role,
                        matching the request's own "could be a room
                        trap instead of an actual mob that fights
                        along with you" framing.
      "bind"        -- Manda: poisons the mob (real damage-over-time,
                        ticked here) AND hard-locks the PLAYER's own
                        flee attempts to fail for the rest of the
                        fight (checked directly in cmd_flee).
      "weapon_buff" -- Enma: never attacks independently at all --
                        applies a real hitroll/damage bonus to the
                        PLAYER's own attacks instead, refreshed each
                        round it's out.
    "safety_net" and "flee_lock" are deliberately NOT resolved here --
    their own real effect only matters at a genuinely different
    moment (an about-to-happen defeat, or the opponent's own flee
    attempt), so they're checked directly at THOSE call sites
    instead, not on this per-round PvE tick."""
    summon = active_summon(player)
    if (summon is None or summon.health <= 0 or summon.room_vnum != player.room_vnum
            or summon.summon_order in {"sleep", "stop"}):
        return
    import data_summons
    tier = data_summons.tier_by_key(summon.summon_tier_key)
    if tier is None:
        return
    mechanic = tier["mechanic"]

    if mechanic == "fighter":
        if mob.health > 0:
            _summon_attack_mob_once(session, player, summon, mob)
    elif mechanic == "healer":
        heal_percent = tier.get("heal_percent", 10)
        heal_amount = max(1, player.maximum_health * heal_percent // 100)
        healed = min(heal_amount, player.maximum_health - player.health)
        if healed > 0:
            player.health += healed
            session.send(f"{summon.name} tends to your wounds, healing you for {healed} HP.")
    elif mechanic == "trap":
        if not summon.stomach_target_instance_id:
            summon.stomach_target_instance_id = mob.instance_id
        if summon.stomach_target_instance_id == mob.instance_id:
            if not getattr(mob, "summon_trap_applied", False):
                mob.summon_trap_applied = True
                mob.summon_trap_to_hit_penalty = TOAD_STOMACH_MOB_TO_HIT_PENALTY
                session.send(f"&R{summon.name} seals every exit around {mob.name}; the stomach begins to devour its victim!&x")
            # Digestion is applied once by tick_summon_upkeep even when
            # the summoner is not in combat; never double-charge this round.
    elif mechanic == "bind":
        player.summon_flee_locked = True
        if "bleeding" not in mob.active_status_effects:
            status_effects.apply_effect(mob.active_status_effects, "bleeding", source="summon_bind")
        bleed = status_effects.bleeding_damage()
        mob.health -= bleed
        session.send(f"{summon.name} coils tight, poison seeping into {mob.name} for {damage_messages.describe_damage(bleed)} damage!")
    elif mechanic == "poison_cloud":
        poison = max(3, player.level // 6 + int(tier["base_modifier"] * 5))
        mob.health -= poison
        if "bleeding" not in mob.active_status_effects:
            status_effects.apply_effect(mob.active_status_effects, "bleeding", source="salamander_venom")
        session.send(f"&g{summon.name} surrounds {mob.name} with toxic mist, inflicting {poison} poison damage!&x")
    elif mechanic == "weapon_buff":
        player.summon_weapon_buff_active = True


def resolve_pulse(session, *, retaliate: bool = True) -> None:
    """One automatic-attack round for a session actively fighting a mob.
    Assumes tick_effects_pulse()/tick_all_mob_effects() have already run
    for this pulse (server.py's pulse_loop does this before calling here;
    tests simulating pulses should do the same)."""
    player = session.player
    if player.reaper_seal_id or player.izanami_trapped:
        session.combat_target = None
        return
    import element_choice
    if element_choice.in_choice(player):
        session.combat_target = None
        return
    mob = session.combat_target
    if mob is None:
        return
    if is_immortal_mob(mob):
        mob.health = mob.max_health
        session.combat_target = None
        reset_summon_round_state(player)
        return
    if mob.room_vnum != player.room_vnum or mob.health <= 0:
        session.combat_target = None
        reset_summon_round_state(player)
        return
    import groups
    groups.assist_group_attack(session, mob)

    # Full multiline fight programs fire while an actual player is
    # fighting this specific live NPC; chance is per script entry.
    # Existing one-action programs have no fight trigger, so they are
    # unchanged. Recheck placement because a script may teleport.
    template = MOB_TEMPLATES.get(mob.template_vnum)
    if (not is_training_dummy(mob) and template
            and any(p.get("trigger") == "fight" for p in template.get("mob_programs", ()))):
        import programs
        programs.fire_programs(session, template["mob_programs"], "fight",
                               speaker_name=mob.name.capitalize(), mob=mob)
        if mob.room_vnum != player.room_vnum or mob.health <= 0:
            session.combat_target = None
            reset_summon_round_state(player)
            return

    if player.jinchuriki_beast_key and player.rampage_until == 0.0:
        import tailed_beasts as tailed_beasts_module
        tailed_beasts_module.tick_jinchuriki_mastery(player)
        if tailed_beasts_module.check_rampage_trigger(player):
            tailed_beasts_module.trigger_rampage(player)
            session.send("&RSomething inside you SNAPS -- the beast's chakra floods your body, and you lose all control!&x")

    session.send("")  # blank line so each round doesn't blur into the last
    import sage_mode
    sage_mode.combat_pulse(session)
    ninja_arts.tick_samurai_sabre(session, combat=True)

    for message in tick_passive_skill_growth(player):
        session.send(message)
    for message in tick_sharingan_upkeep(player):
        session.send(message)
    for message in tick_sharingan_mastery_gain(player):
        session.send(message)
    for message in hyuga.combat_tick(player):
        session.send(message)
    for message in tick_automatic_bloodline_awakening(player):
        session.send(message)
    if hyuga.eligible(player):
        for new_skill in hyuga.sync(player):
            session.send(f'&CByakugan technique unlocked: {new_skill}!&x')

    # A body projecting its senses through a remote clone is helpless:
    # it cannot autoattack, cast, flee or secretly fight while scouting.
    # Its enemy still gets a normal round against the exposed body.
    if getattr(session, "controlled_clone", None) is not None:
        session.send("&DYour real body remains motionless while you pilot your elemental clone.&x")
    else:
        if _is_action_blocked(player):
            session.send("You are stunned and can't act this round!" if "stunned" in player.active_status_effects else "You cannot act this round!")
        else:
            _player_attack_mob_once(session, player, mob)
            if mob.health > 0:
                trained_extra = _roll_extra_attacks(player)
                for attack_index in range(trained_extra + sage_mode.extra_attacks(player) + eight_gates.extra_attacks(player)):
                    if mob.health <= 0:
                        break
                    if attack_index < trained_extra:
                        skill_name = data_jutsu.MULTI_ATTACK_SKILLS[attack_index][0]
                        mastered = player.skill_proficiencies.get(skill_name, 0) >= 100
                        landed = _player_attack_mob_once(session, player, mob, guaranteed_hit=mastered)
                        if landed:
                            grow_skill_from_usage(player, skill_name, session=session)
                    else:
                        _player_attack_mob_once(session, player, mob)
            if mob.health > 0:
                _offhand_attack(session, mob)
            for clone in active_shadow_clones(player):
                if mob.health <= 0:
                    break
                if clone.room_vnum == player.room_vnum:
                    _clone_attack_mob_once(session, player, mob, clone)
            _resolve_summon_round(session, player, mob)
    
    if mob.health <= 0:
        handle_mob_defeat(session, mob)
        return
    if is_training_dummy(mob):
        # The player still lands genuine hits and gains usage proficiency,
        # but the practice dummy never retaliates or casts any jutsu.
        return
    # Shared enemies retaliate once per server round even when multiple
    # grouped characters each make their normal full round of attacks.
    if not retaliate:
        return
    if _is_action_blocked(mob):
        session.send(f"{mob.name} is trapped in the illusion and cannot attack this round.")
        return
    import hidden_mist
    if hidden_mist.obscures(mob, player):
        session.send(f"&C{mob.name} searches the mist but cannot target you.&x")
        return

    # Jutsu uses the NPC's attack turn instead of stacking a free attack
    # on top of its normal melee sequence. Level 1-9 mobs never cast.
    import mob_jutsu
    if mob_jutsu.try_cast(session, mob):
        return

    import commands as commands_module
    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_armor_class = derived_stats.armor_class(player, set_bonus + data_personality.personality_bonus_percent(player, "armor_class") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) - commands_module.equipped_armor_class_bonus(player)
    mob_hit_roll = derived_stats.hit_roll(mob) + commands_module.equipped_weapon_hitroll_bonus(mob)
    mob_to_hit = derived_stats.to_hit_chance(mob_hit_roll, player_armor_class) + weather.combat_accuracy_modifier() - _accuracy_penalty_from_effects(mob)
    if mob.summon_trap_applied:
        mob_to_hit -= mob.summon_trap_to_hit_penalty
    mob_to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, mob_to_hit))
    if random.randint(1, 100) > mob_to_hit:
        session.send(f"&C{mob.name} attacks you but misses!&x")
        import room_actions
        room_actions.emit(session, f"{mob.name} attacks {player.name} but misses.")
        return

    if player.kamui_intangibility_rounds_left > 0:
        player.kamui_intangibility_rounds_left -= 1
        session.send(f"&R{mob.name}'s attack passes straight through you!&x")
        return

    if random.randint(1, 100) <= derived_stats.dodge_chance(player, set_bonus + data_personality.personality_bonus_percent(player, "dodge_chance")) + weather.night_dodge_bonus() + _sharingan_dodge_bonus(player) + hyuga.dodge(player) + eight_gates.dodge(player):
        session.send(f"&CYou dodge {mob.name}'s attack!&x")
        return

    for _ in range(mob.attacks):
        if player.health <= 0:
            break
        if _soto_uke_blocks(player, mob.level):
            session.send(f"&CYou use Soto Uke to block {mob.name}'s attack!&x")
            continue
        dmg = _mob_attack_damage(mob)
        if player.sharingan_active and player.bloodline_tomoe >= 3:
            reduced = _sharingan_predict_and_reduce_damage(player, dmg)
            if reduced < dmg:
                dmg = reduced
            else:
                session.send("&RYou weren't fast enough to counter!&x")
        dmg = commands_module.reduce_weapon_damage(player, data_weapons.weapon_type_for_item(mob.equipment.get("wielded", "")), dmg)
        import susanoo
        dmg = susanoo.incoming_damage(
            player, sage_mode.incoming(
                player, status_effects.reduce_incoming_damage(player.active_status_effects, dmg)))
        import iron_ascension
        dmg = iron_ascension.reduce_incoming(session, mob, dmg)
        player.health -= dmg
        if dmg > 0:
            import equipment_durability
            equipment_durability.wear_armor(session)
        session.send(f"{mob.name} strikes you for {damage_messages.describe_damage(dmg)} damage. {damage_messages.impact_flavor(dmg)}")
        import room_actions
        room_actions.emit(session, f"{mob.name} strikes {player.name} for {damage_messages.describe_damage(dmg)} damage.")

    if player.health <= 0:
        if try_trigger_izanagi(session):
            pass
        elif is_immortal_immune_to_defeat(session):
            clamp_immortal_health(session)
        else:
            handle_player_defeat(session)
    elif player.wimpy_percent > 0 and (player.health / player.maximum_health * 100) <= player.wimpy_percent:
        session.send(f"&Y(Your health has dropped to your wimpy threshold of {player.wimpy_percent}%!)&x")
        commands_module.cmd_flee(session, [])


def _staff_testing_mangekyo(player) -> bool:
    """Use the authenticated live account, never a mutable player field."""
    from session import ACTIVE_SESSIONS
    return any(getattr(s, "player", None) is player
               and getattr(getattr(s, "account", None), "staff_level", "player") != "player"
               for s in ACTIVE_SESSIONS)


def _can_use_jutsu(player, jutsu, jutsu_key: str = None) -> bool:
    """Whether player is allowed to cast jutsu at all right now, before
    any cooldown/resource checks. Every normal jutsu requires it to be
    in player.learned_skills (granted automatically at level-up, see
    leveling.py) -- but a jutsu carrying a "kkg_gate" key bypasses that
    entirely and checks the named Kekkei Genkai condition instead,
    since data_jutsu.py's own docstring confirms jutsu are no longer
    class-gated at all and every player already knows every normal
    jutsu regardless of class -- a kkg_gate jutsu needs its own
    distinct gate or it would be available to everyone, defeating the
    whole point of it being tomoe-locked. A jutsu the player has
    copied via the 5-tomoe Copy Jutsu perk (player.copied_jutsu_key)
    is also always usable, regardless of either check -- that's a
    one-time grant for exactly that jutsu, not a permanent unlock.

    A jutsu carrying a real "element" (Section 85, per direct
    clarification: "a person cant cast jutsu that is not theire
    element") is a genuine HARD GATE, not a bonus-if-matching
    condition -- confirmed directly after an earlier design that
    assumed off-element casting was allowed (just weaker) turned out
    to be wrong. Only castable if that element matches the player's
    OWN chakra nature, primary OR secondary (matching the same
    "either nature counts" rule already used for the reveal
    mechanism's own eligibility elsewhere) -- checked here so even a
    copied or Kekkei-Genkai-gated elemental jutsu would still need a
    real matching nature (though no jutsu combines both gates today)."""
    # Authenticate from the live session. Immortals can test every jutsu
    # regardless of nature, bloodline, level, gear, location or mastery.
    import whirlpool_fuinjutsu
    if whirlpool_fuinjutsu.blocked_jutsu(player, jutsu):
        return False
    if _staff_testing_mangekyo(player):
        return True
    if (jutsu.get("jutsu_type") == "kkgk_taijutsu_strike"
            and player.primary_class != "taijutsu"):
        return False
    if jutsu.get("jutsu_type") == "gate_strike" and not eight_gates.strike_unlocked(player, jutsu):
        return False
    if jutsu.get("jutsu_type") == "whirlpool_seal":
        return whirlpool_fuinjutsu.eligible(player) and player.level >= jutsu["level_requirement"] and jutsu["display_name"] in player.learned_skills
    if jutsu.get("jutsu_type") == "reaper_seal":
        import reaper_seal
        return (reaper_seal.eligible(player) and jutsu["display_name"] in player.learned_skills
                and not reaper_seal.imprisoned(player))
    import skill_training
    if skill_training.needs_first_practice(player, jutsu["display_name"]):
        return False
    if jutsu.get("jutsu_type") == "elemental_clone" and player.skill_proficiencies.get("Shadow Clone Jutsu", 0) < 100:
        return False
    if jutsu.get("requires_water"):
        import fishing
        room = world.WORLD.get(player.room_vnum)
        if room is None or not fishing.can_fish_here(room.biome):
            return False
    if jutsu.get("jutsu_type") == "fan_art" and "mighty fan" not in player.equipment.get("wielded", "").lower():
        return False
    if jutsu.get("required_weapon_types") and data_weapons.weapon_type_for_item(player.equipment.get("wielded", "")) not in jutsu["required_weapon_types"]:
        return False
    if jutsu.get("element", "none") != "none":
        if jutsu["element"] not in (player.chakra_nature, player.chakra_nature_secondary, player.chakra_nature_tertiary):
            return False
    gate = jutsu.get("kkg_gate")
    if gate in ("six_paths_indra", "six_paths_ashura"):
        import six_paths
        return (six_paths.eligible(player, gate.removeprefix("six_paths_"))
                and six_paths.active(player)
                and jutsu["display_name"] in player.learned_skills)
    import data_kekkei_genkai
    if gate == "byakugan":
        return hyuga.can_use(player, jutsu_key or jutsu["display_name"].lower())
    if gate in data_kekkei_genkai.ELEMENTAL_RELEASE_NAMES:
        return (_staff_testing_mangekyo(player)
                or (data_kekkei_genkai.has_elemental_release(player, gate)
                    and player.level >= jutsu["level_requirement"]))
    if gate == "mangekyo_technique":
        if _staff_testing_mangekyo(player):
            return True
        # Genuinely generic (Section 140): checks the jutsu's own real
        # "mangekyo_roster_key" (falling back to jutsu_key itself for
        # a single-jutsu technique like Amaterasu, where the 2 happen
        # to be identical) against BOTH of the player's real, rolled
        # eye techniques. Kamui is confirmed to be 3 SEPARATE real
        # jutsu sharing the one roster key "kamui" -- this lets all 3
        # gate correctly without needing 3 separate roster entries.
        roster_key = jutsu.get("mangekyo_roster_key", jutsu_key)
        return (player.bloodline_id == "sharingan" and player.bloodline_mangekyo
                and player.sharingan_active
                and roster_key in (player.mangekyo_eye_1, player.mangekyo_eye_2))
    if jutsu_key is not None and player.copied_jutsu_key == jutsu_key:
        return True
    return jutsu["display_name"].lower() in [s.lower() for s in player.learned_skills]


SHADOW_CLONE_MASTERY_GAIN_PER_CAST = 2


def use_shadow_clone_jutsu(session) -> None:
    """'shadow clone jutsu' (or 'perform shadow clone jutsu') -- no
    target needed, unlike every other jutsu, since this summons real,
    independently-attackable clone Mobs (see spawn_shadow_clones)
    rather than attacking anything. Dispatched from
    commands.cmd_use_jutsu/cmd_perform BEFORE the normal target-lookup
    logic runs (see jutsu_type == "summon" check there), since a
    summon-type jutsu has nothing to target at all. Confirmed usable
    outside combat entirely -- clones persist independently (see
    tick_shadow_clone_upkeep, ticked every server pulse regardless of
    combat state) until dismissed or their upkeep can no longer be
    afforded.

    Casting while clones are already active dismisses them first, then
    resummons fresh at whatever the current mastery's clone count is
    -- so a recast after mastery has since grown correctly raises the
    clone count to match, rather than stacking additional clones on
    top of an earlier batch."""
    player = session.player
    jutsu = data_jutsu.JUTSU["shadow clone jutsu"]
    now = time.time()

    if not _can_use_jutsu(player, jutsu, "shadow clone jutsu") or jutsu["display_name"] not in player.learned_skills:
        session.send("You don't know that jutsu.")
        return
    if status_effects.has_effect(player.active_status_effects, "silenced"):
        session.send("You are silenced and cannot use jutsu right now!")
        return

    cooldown_ready_at = player.cooldowns.get("shadow clone jutsu", 0)
    if now < cooldown_ready_at:
        jutsu_colors.send(session, f"&WShadow Clone Jutsu&x is still recovering ({cooldown_ready_at - now:.1f}s).")
        return
    chakra_cost = jutsu_balance.cast_cost(player, jutsu, "chakra")
    if player.chakra < chakra_cost:
        session.send("You don't have enough chakra.")
        return

    player.chakra -= chakra_cost
    player.cooldowns["shadow clone jutsu"] = now + jutsu["cooldown"]

    mastery = player.skill_proficiencies.get("Shadow Clone Jutsu", 0)
    new_mastery = min(100, mastery + SHADOW_CLONE_MASTERY_GAIN_PER_CAST)
    player.skill_proficiencies["Shadow Clone Jutsu"] = new_mastery
    if new_mastery > mastery:
        xp = (new_mastery - mastery) * 10
        experience_before = player.experience
        level_up_messages = leveling.grant_experience(player, xp)
        earned_xp = max(0, player.experience - experience_before)
        xp_note = f" +{earned_xp} experience." if earned_xp else ""
        session.send(f"&GShadow Clone Jutsu improves to {new_mastery}%!{xp_note}&x")
        for message in level_up_messages:
            session.send(message)

    dismiss_shadow_clones(player)
    clone_count = shadow_clone_count_for_mastery(new_mastery)
    spawn_shadow_clones(player, clone_count)

    plural = "clone" if clone_count == 1 else "clones"
    verb = "puffs" if clone_count == 1 else "puff"
    session.send(
        f"&WYou form a hand sign and shout, \"Shadow Clone Jutsu!\"&x\n"
        f"{clone_count} shadow {plural} {verb} into existence beside you, ready to fight!\n"
        f"&D(Shadow Clone Jutsu mastery: {new_mastery}%. Upkeep: {clone_count * SHADOW_CLONE_UPKEEP_PER_CLONE} chakra/round.)&x"
    )


def use_elemental_clone_jutsu(session, jutsu_key: str) -> None:
    """One elemental clone, sharing the existing live-clone cap and upkeep."""
    player = session.player
    jutsu = data_jutsu.JUTSU[jutsu_key]
    if player.skill_proficiencies.get("Shadow Clone Jutsu", 0) < 100:
        session.send("Master Shadow Clone Jutsu to 100% before creating elemental clones.")
        return
    if not _can_use_jutsu(player, jutsu, jutsu_key):
        jutsu_colors.send(session, f"You need {jutsu['element'].capitalize()} chakra nature and must know {jutsu['display_name']}.")
        return
    if _is_action_blocked(player) or getattr(session, "pending_cast", None) is not None:
        session.send("You are unable to form the clone right now.")
        return
    if status_effects.has_effect(player.active_status_effects, "silenced"):
        session.send("You are silenced and cannot use jutsu right now!")
        return
    now = time.time()
    if now < player.cooldowns.get(jutsu_key, 0):
        jutsu_colors.send(session, f"{jutsu['display_name']} is still recovering.")
        return
    cost = jutsu_balance.cast_cost(player, jutsu, "chakra")
    if player.chakra < cost:
        session.send("You don't have enough chakra.")
        return
    player.chakra -= cost
    player.cooldowns[jutsu_key] = now + jutsu["cooldown"]
    dismiss_shadow_clones(player)
    spawned = spawn_shadow_clones(player, 1, element=jutsu["clone_element"])
    if not spawned:
        player.chakra += cost
        player.cooldowns.pop(jutsu_key, None)
        session.send("There is no space to summon a clone here.")
        return
    grow_skill_from_usage(player, jutsu["display_name"], session=session)
    session.send(f"&CYou form hand signs and create {spawned[0].name}!&x (Upkeep: {SHADOW_CLONE_UPKEEP_PER_CLONE} chakra/round.)")


def use_barrier(session) -> None:
    """Level-35 general defensive buff, active for three minutes in one room."""
    player = session.player
    jutsu = data_jutsu.JUTSU["barrier"]
    if not _can_use_jutsu(player, jutsu, "barrier"):
        session.send("You don't know Barrier.")
        return
    if _is_action_blocked(player) or getattr(session, "pending_cast", None) is not None:
        session.send("You are unable to raise a barrier right now.")
        return
    if status_effects.has_effect(player.active_status_effects, "silenced"):
        session.send("You are silenced and cannot use jutsu right now!")
        return
    now = time.time()
    if now < player.cooldowns.get("barrier", 0):
        session.send("Barrier is still recovering.")
        return
    chakra_cost = jutsu_balance.cast_cost(player, jutsu, "chakra")
    if player.chakra < chakra_cost:
        session.send("You don't have enough chakra.")
        return
    player.chakra -= chakra_cost
    player.cooldowns["barrier"] = now + jutsu["cooldown"]
    duration = signature_moves.duration(player, jutsu, jutsu_balance.boosted_duration(
        player, jutsu, status_effects.EFFECT_DEFS["barrier"]["duration"], effect="barrier"))
    status_effects.apply_effect(player.active_status_effects, "barrier", source="barrier",
                                duration_override=duration)
    grow_skill_from_usage(player, "Barrier", session=session)
    session.send(f"&CA chakra barrier rises around you, negating 25% of incoming damage for {duration} seconds. It breaks if you leave the room.&x")


def use_jutsu(session, jutsu_key: str, mob: Mob, fan_direction: str = None) -> None:
    if is_immortal_mob(mob):
        session.send(f"{mob.name.capitalize()} is protected and cannot be attacked.")
        return
    player = session.player
    if player.reaper_seal_id:
        session.send("The Reaper's binding prevents that attack.")
        return
    if _is_action_blocked(player):
        jutsu_colors.send(session, "You are unable to act!")
        return
    jutsu = data_jutsu.JUTSU.get(jutsu_key)
    now = time.time()

    if jutsu is None or not _can_use_jutsu(player, jutsu, jutsu_key):
        jutsu_colors.send(session, "You don't know that jutsu.")
        return
    if jutsu.get("jutsu_type") == "ambush" and mob.health < mob.max_health:
        jutsu_colors.send(session, f"{mob.name} is hurt and alert; you cannot sneak up on them.")
        return
    if status_effects.has_effect(player.active_status_effects, "silenced"):
        jutsu_colors.send(session, "You are silenced and cannot use jutsu right now!")
        return

    cooldown_ready_at = player.cooldowns.get(jutsu_key, 0)
    import commands as commands_module
    colored_name = jutsu["display_name"]  # rendered by send_jutsu
    if now < cooldown_ready_at:
        jutsu_colors.send(session, f"{colored_name} is still recovering ({cooldown_ready_at - now:.1f}s).")
        return
    is_copied_cast = player.copied_jutsu_key == jutsu_key
    chakra_cost = jutsu_balance.cast_cost(
        player, jutsu, "chakra",
        base_override=player.copied_jutsu_cost if is_copied_cast else None)
    stamina_cost = jutsu_balance.cast_cost(player, jutsu, "stamina")
    if player.chakra < chakra_cost:
        jutsu_colors.send(session, "You don't have enough chakra.")
        return
    if player.stamina < stamina_cost:
        jutsu_colors.send(session, "You don't have enough stamina.")
        return

    if jutsu.get("requires_item"):
        held_items = [item for item in player.inventory if jutsu["requires_item"] in item.lower()]
        if len(held_items) < jutsu.get("requires_item_count", 1):
            jutsu_colors.send(session, f"You don't have a {jutsu['requires_item']} to throw. You need {jutsu.get('requires_item_count', 1)}.")
            return
    if jutsu.get("jutsu_type") == "trap" and jutsu_key in mob.active_status_effects:
        jutsu_colors.send(session, "That target already has this trap attached.")
        return

    if not engage_damage_attack(session, mob):
        return
    general_skills.break_camouflage(session)
    player.chakra -= chakra_cost
    player.stamina -= stamina_cost
    if is_copied_cast:
        player.copied_jutsu_key = None
        player.copied_jutsu_cost = 0
    player.cooldowns[jutsu_key] = now + jutsu["cooldown"]
    # Techniques that are deliberately silent do not reveal the user.
    if not (jutsu["class_requirement"] == "genjutsu"
            and commands_module.has_silent_genjutsu(player)
            and player.skill_proficiencies.get("Silent Genjutsu", 0) >= 100):
        import room_actions
        room_actions.emit(session, f"&C{player.name} performs {colored_name} against {mob.name}!&x")

    if jutsu.get("requires_item"):
        for held_item in held_items[:jutsu.get("requires_item_count", 1)]:
            player.inventory.remove(held_item)
        room = world.WORLD.get(player.room_vnum)
        if room and jutsu.get("jutsu_type") == "thrown":
            room.ground_items.extend(held_items[:jutsu.get("requires_item_count", 1)])

    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_hit_roll = derived_stats.hit_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "hit_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) + commands_module.equipped_weapon_hitroll_bonus(player)
    mob_armor_class = derived_stats.armor_class(mob) - commands_module.equipped_armor_class_bonus(mob)
    import hidden_mist
    import sage_mode
    to_hit = derived_stats.to_hit_chance(player_hit_roll, mob_armor_class) + weather.combat_accuracy_modifier() + _sharingan_hitroll_bonus(player) + hyuga.accuracy(player) - _accuracy_penalty_from_effects(player) + hidden_mist.advantage(player, mob) + sage_mode.accuracy(player) + general_skills.focused_accuracy(player)
    to_hit += _genjutsu_hit_bonus(player, jutsu) + jutsu.get("accuracy_bonus", 0)
    if jutsu.get("class_requirement") == "taijutsu":
        to_hit += eight_gates.accuracy(player)
    to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit))
    if random.randint(1, 100) > to_hit:
        jutsu_colors.send(session, f"You use {colored_name} on {mob.name}, but it misses!")
        return

    if jutsu.get("jutsu_type") == "trap":
        ninja_arts.attach_trap(mob, jutsu_key, player.name)
        grow_skill_from_usage(player, jutsu["display_name"], session=session)
        jutsu_colors.send(session, f"You attach {jutsu['display_name']} to {mob.name}. It will detonate in two rounds unless disabled.")
        return

    if jutsu.get("jutsu_type") == "sevenfold":
        dmg, landed, sevenfold_effects = _sevenfold_damage(jutsu, player)
        if not landed:
            jutsu_colors.send(session, f"All seven colors of {colored_name} fail to connect with {mob.name}!")
            return
        jutsu_colors.send(session, f"&C{len(landed)} of seven Rasengan strikes connect: {', '.join(landed)}.&x")
        was_explosive = False
    else:
        dmg, was_explosive = roll_jutsu_damage(jutsu)
        sevenfold_effects = []
    dmg = _mirror_illusion_damage(jutsu, mob, dmg)
    if jutsu.get("jutsu_type") == "kkgk_taijutsu_strike":
        # Hand-to-hand KKGK strikes resolve instantly and consume mostly
        # stamina; trade 15% of base technique power for that advantage.
        dmg = max(1, dmg * 85 // 100)
    dmg += _jutsu_damage_bonus(player)
    breakthrough_pct = mastered_jutsu_breakthrough_percent(player, jutsu)
    if breakthrough_pct:
        dmg = max(1, dmg * (100 + breakthrough_pct) // 100)
    if jutsu.get("wind_damage_bonus_pct") and "wind" in (player.chakra_nature, player.chakra_nature_secondary, player.chakra_nature_tertiary):
        dmg = max(1, dmg * (100 + jutsu["wind_damage_bonus_pct"]) // 100)
    if jutsu.get("jutsu_type") == "ambush":
        dmg = max(1, round(dmg * jutsu["ambush_multiplier"]))
    # Five top cut gems give the same +15% damage for their own element.
    # The rest of the gem's flat damage bonus already enters _jutsu_damage_bonus.
    import gem_inlays
    gem_mult = gem_inlays.elemental_jutsu_multiplier(player, jutsu.get("element", "none"))
    if gem_mult != 1.0:
        dmg = max(1, round(dmg * gem_mult))
    import village_perks
    dmg_mult = village_perks.damage_multiplier(player.village)
    if dmg_mult != 1.0:
        dmg = int(dmg * dmg_mult)
    kekkei_no_me_mult = _kekkei_no_me_damage_multiplier(player, jutsu)
    if kekkei_no_me_mult != 1.0:
        dmg = int(dmg * kekkei_no_me_mult)

    import biomes
    room = world.WORLD.get(player.room_vnum)
    biome_mult = biomes.damage_modifier(room.biome if room else "none", jutsu.get("element", "none"))
    if biome_mult != 1.0:
        dmg = int(dmg * biome_mult)

    dmg = sage_mode.outgoing(player, status_effects.reduce_outgoing_damage(player.active_status_effects, dmg), jutsu=True)
    dmg = eight_gates.physical_damage(player, dmg, jutsu)
    dmg = signature_moves.amount(player, jutsu, jutsu_balance.boosted_damage(player, jutsu, dmg))
    mob.health -= dmg
    hyuga.on_strike(session, mob, jutsu)
    _genjutsu_impact(jutsu, mob)
    grow_skill_from_usage(player, jutsu["display_name"], session=session)
    perk_note = f" &Y(x{dmg_mult:g} village perk)&x" if dmg_mult != 1.0 else ""
    if biome_mult > 1.0:
        biome_note = f" &C({room.biome} boosts {jutsu.get('element')})&x"
    elif biome_mult < 1.0:
        biome_note = f" &D({room.biome} weakens {jutsu.get('element')})&x"
    else:
        biome_note = ""
    if was_explosive:
        jutsu_colors.send(session, f"&RThe kunai detonates!&x You use {colored_name} on {mob.name} for {damage_messages.describe_damage(dmg)} explosive damage!{perk_note}{biome_note}")
    else:
        jutsu_colors.send(session, f"You use {colored_name} on {mob.name} for {damage_messages.describe_damage(dmg)} damage! {damage_messages.impact_flavor(dmg)}{perk_note}{biome_note}")

    if jutsu["effect"] and random.randint(1, 100) <= jutsu.get("effect_chance_pct", 100):
        duration = (status_effects.genjutsu_duration(jutsu["effect"])
                    if jutsu["class_requirement"] == "genjutsu"
                    else status_effects.EFFECT_DEFS[jutsu["effect"]]["duration"])
        duration = signature_moves.duration(player, jutsu, jutsu_balance.boosted_duration(
            player, jutsu, duration, effect=jutsu["effect"]))
        status_effects.apply_effect(mob.active_status_effects, jutsu["effect"], source=jutsu_key,
                                    duration_override=duration)
        jutsu_colors.send(session, status_effects.EFFECT_DEFS[jutsu["effect"]]["message"].format(target=mob.name))
    for effect in sevenfold_effects:
        duration = signature_moves.duration(player, jutsu, jutsu_balance.boosted_duration(
            player, jutsu, status_effects.EFFECT_DEFS[effect]["duration"], effect=effect))
        status_effects.apply_effect(mob.active_status_effects, effect, source=jutsu_key,
                                    duration_override=duration)
        jutsu_colors.send(session, status_effects.EFFECT_DEFS[effect]["message"].format(target=mob.name))

    if jutsu.get("jutsu_type") == "area":
        for other in list(mobs_in_room(player.room_vnum)):
            if other is mob or other.health <= 0 or is_shadow_clone(other):
                continue
            if (is_shopkeeper(other) or is_gambler(other)
                    or is_teacher(other) or is_immortal_mob(other)):
                continue
            other.health -= dmg
            jutsu_colors.send(session, f"{jutsu['display_name']} also strikes {other.name} for {damage_messages.describe_damage(dmg)} damage!")
            if other.health <= 0:
                handle_mob_defeat(session, other)

    if jutsu.get("jutsu_type") == "fan_art" and fan_direction and mob.health > 0:
        ninja_arts.fan_push(session, mob, fan_direction)

    if mob.health <= 0:
        handle_mob_defeat(session, mob)


def _is_linkdead(session) -> bool:
    """No PvP damage or effects may reach a disconnected character."""
    return getattr(getattr(session, "state", None), "name", "") == "LINKDEAD"


def use_jutsu_on_player(session, jutsu_key: str, target_session, damage_multiplier: float = 1.0, fan_direction: str = None) -> None:
    """PvP-enabled jutsu casting, per direct request ("make jutsu pvp
    enabled"). Mirrors use_jutsu's structure (gate/cooldown/resource
    checks, to-hit, damage, effect application) but against another
    player instead of a mob, layering in the full set of Sharingan
    perks a defender might have active: dodge (tomoe 1), Movement
    Prediction on a failed dodge (tomoe 3), genjutsu resistance
    shortening any incoming genjutsu-class effect's duration (tomoe 4
    -- this is the very first path in the whole game that can ever
    exercise that perk, since no jutsu could target a player before
    this function existed), and Copy Jutsu (tomoe 5, see below).

    damage_multiplier defaults to 1.0 (every ordinary cast) -- the
    ONLY caller that ever passes something else is
    _check_jutsu_collisions' own overpower path (Section 98, per
    direct confirmation: "still lands, but at reduced strength"),
    which passes elemental_counters.OVERPOWER_DAMAGE_MULTIPLIER."""
    player = session.player
    if _is_linkdead(target_session) or _is_linkdead(session):
        jutsu_colors.send(session, "That shinobi is disconnected and cannot be targeted.")
        return
    if not pvp_organizations.check(session, target_session):
        return
    room = world.WORLD.get(player.room_vnum)
    if room is not None and room.safe:
        session.send("This is a PvP-safe zone. You cannot attack other players here.")
        return
    if _is_action_blocked(player):
        jutsu_colors.send(session, "You are unable to act!")
        return
    jutsu = data_jutsu.JUTSU.get(jutsu_key)
    now = time.time()

    if jutsu is None or not _can_use_jutsu(player, jutsu, jutsu_key):
        jutsu_colors.send(session, "You don't know that jutsu.")
        return
    if status_effects.has_effect(player.active_status_effects, "silenced"):
        jutsu_colors.send(session, "You are silenced and cannot use jutsu right now!")
        return

    target = target_session.player
    if player.reaper_seal_id or target.reaper_seal_id:
        session.send("The Reaper's binding prevents that attack.")
        return
    import hidden_mist
    import general_skills
    if general_skills.concealed_from(player, target):
        jutsu_colors.send(session, "You cannot locate that camouflaged ninja.")
        return
    if hidden_mist.obscures(player, target) or general_skills.concealed_from(player, target):
        jutsu_colors.send(session, "The mist hides your target. You cannot lock onto them.")
        return
    if jutsu.get("jutsu_type") == "ambush" and target.health < target.maximum_health:
        jutsu_colors.send(session, f"{target.name} is hurt and alert; you cannot sneak up on them.")
        return
    if target.izanami_trapped:
        jutsu_colors.send(session, f"{target.name} is lost in a loop, untouched by reality -- you cannot reach them.")
        return
    cooldown_ready_at = player.cooldowns.get(jutsu_key, 0)
    import commands as commands_module
    colored_name = jutsu["display_name"]  # rendered by send_jutsu
    silent_to_target = (
        jutsu["class_requirement"] == "genjutsu"
        and commands_module.has_silent_genjutsu(player)
        and player.skill_proficiencies.get("Silent Genjutsu", 0) >= 100
    )
    if now < cooldown_ready_at:
        jutsu_colors.send(session, f"{colored_name} is still recovering ({cooldown_ready_at - now:.1f}s).")
        return
    is_copied_cast = player.copied_jutsu_key == jutsu_key
    chakra_cost = jutsu_balance.cast_cost(
        player, jutsu, "chakra",
        base_override=player.copied_jutsu_cost if is_copied_cast else None)
    stamina_cost = jutsu_balance.cast_cost(player, jutsu, "stamina")
    if player.chakra < chakra_cost:
        jutsu_colors.send(session, "You don't have enough chakra.")
        return
    if player.stamina < stamina_cost:
        jutsu_colors.send(session, "You don't have enough stamina.")
        return

    if jutsu.get("requires_item"):
        held_items = [item for item in player.inventory if jutsu["requires_item"] in item.lower()]
        if len(held_items) < jutsu.get("requires_item_count", 1):
            jutsu_colors.send(session, f"You don't have a {jutsu['requires_item']} to throw. You need {jutsu.get('requires_item_count', 1)}.")
            return
    if jutsu.get("jutsu_type") == "trap" and jutsu_key in target.active_status_effects:
        jutsu_colors.send(session, "That target already has this trap attached.")
        return

    if not engage_damage_attack(session, target, target_session):
        return
    general_skills.break_camouflage(session)
    general_skills.break_camouflage(target_session)
    caster_chakra_cost = chakra_cost  # the amount actually paid for this cast
    player.chakra -= chakra_cost
    player.stamina -= stamina_cost
    if is_copied_cast:
        player.copied_jutsu_key = None
        player.copied_jutsu_cost = 0
    player.cooldowns[jutsu_key] = now + jutsu["cooldown"]
    # Silent Genjutsu must never broadcast its caster's technique.
    if not silent_to_target:
        import room_actions
        room_actions.emit(session, f"&C{player.name} performs {colored_name} against {target.name}!&x",
                          exclude=(target_session,))

    if jutsu.get("requires_item"):
        for held_item in held_items[:jutsu.get("requires_item_count", 1)]:
            player.inventory.remove(held_item)
        room = world.WORLD.get(player.room_vnum)
        if room and jutsu.get("jutsu_type") == "thrown":
            room.ground_items.extend(held_items[:jutsu.get("requires_item_count", 1)])

    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_hit_roll = derived_stats.hit_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "hit_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) + commands_module.equipped_weapon_hitroll_bonus(player)
    target_set_bonus = commands_module.equipped_set_bonus_percent(target)
    target_armor_class = derived_stats.armor_class(target, target_set_bonus + data_personality.personality_bonus_percent(target, "armor_class") + tailed_beasts.rampage_bonus_percent(target) + tailed_beasts.mode_bonus_percent(target)) - commands_module.equipped_armor_class_bonus(target)
    import sage_mode
    to_hit = derived_stats.to_hit_chance(player_hit_roll, target_armor_class) + weather.combat_accuracy_modifier() + _sharingan_hitroll_bonus(player) + hyuga.accuracy(player) - _accuracy_penalty_from_effects(player) + _genjutsu_hit_bonus(player, jutsu) + hidden_mist.advantage(player, target) + jutsu.get("accuracy_bonus", 0) + sage_mode.accuracy(player) + general_skills.focused_accuracy(player) + (eight_gates.accuracy(player) if jutsu.get("class_requirement") == "taijutsu" else 0)
    to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit))
    if random.randint(1, 100) > to_hit:
        jutsu_colors.send(session, f"You use {colored_name} on {target.name}, but it misses!")
        if not silent_to_target:
            jutsu_colors.send(target_session, f"&C{player.name} uses {colored_name} on you, but it misses!&x")
        return

    if target.kamui_intangibility_rounds_left > 0:
        target.kamui_intangibility_rounds_left -= 1
        jutsu_colors.send(session, f"&R{colored_name} passes straight through {target.name}!&x")
        if not silent_to_target:
            jutsu_colors.send(target_session, f"&R{player.name}'s {colored_name} passes straight through you!&x")
        return

    if random.randint(1, 100) <= max(0, derived_stats.dodge_chance(target, target_set_bonus + data_personality.personality_bonus_percent(target, "dodge_chance")) + weather.night_dodge_bonus() + _sharingan_dodge_bonus(target) + hyuga.dodge(target) + eight_gates.dodge(target) - hidden_mist.advantage(player, target)):
        jutsu_colors.send(session, f"&C{target.name} dodges your {colored_name}!&x")
        if not silent_to_target:
            jutsu_colors.send(target_session, f"&CYou dodge {player.name}'s {colored_name}!&x")
        return

    if jutsu.get("jutsu_type") == "thrown" and _try_counter_kunai(session, target_session, target, player.name, jutsu["display_name"]):
        return

    if jutsu.get("jutsu_type") == "trap":
        ninja_arts.attach_trap(target, jutsu_key, player.name)
        grow_skill_from_usage(player, jutsu["display_name"], session=session)
        jutsu_colors.send(session, f"You attach {jutsu['display_name']} to {target.name}. It will detonate in two rounds unless disabled.")
        jutsu_colors.send(target_session, f"&R{player.name} attaches {jutsu['display_name']} to you! Use Trap Disabling before it detonates.&x")
        return

    if jutsu.get("jutsu_type") == "sevenfold":
        dmg, landed, sevenfold_effects = _sevenfold_damage(jutsu, player)
        if not landed:
            jutsu_colors.send(session, f"All seven colors of {colored_name} fail to connect with {target.name}!")
            jutsu_colors.send(target_session, "The rainbow of chakra passes around you without a hit.")
            return
        jutsu_colors.send(session, f"&C{len(landed)} of seven Rasengan strikes connect: {', '.join(landed)}.&x")
        was_explosive = False
    else:
        dmg, was_explosive = roll_jutsu_damage(jutsu)
        sevenfold_effects = []
    dmg = _mirror_illusion_damage(jutsu, target, dmg)
    if jutsu.get("jutsu_type") == "kkgk_taijutsu_strike":
        dmg = max(1, dmg * 85 // 100)
    dmg += _jutsu_damage_bonus(player)
    breakthrough_pct = mastered_jutsu_breakthrough_percent(player, jutsu)
    if breakthrough_pct:
        dmg = max(1, dmg * (100 + breakthrough_pct) // 100)
    if jutsu.get("wind_damage_bonus_pct") and "wind" in (player.chakra_nature, player.chakra_nature_secondary, player.chakra_nature_tertiary):
        dmg = max(1, dmg * (100 + jutsu["wind_damage_bonus_pct"]) // 100)
    if jutsu.get("jutsu_type") == "ambush":
        dmg = max(1, round(dmg * jutsu["ambush_multiplier"]))
    # Five top cut gems give the same +15% damage for their own element.
    # The rest of the gem's flat damage bonus already enters _jutsu_damage_bonus.
    import gem_inlays
    gem_mult = gem_inlays.elemental_jutsu_multiplier(player, jutsu.get("element", "none"))
    if gem_mult != 1.0:
        dmg = max(1, round(dmg * gem_mult))
    import village_perks
    dmg_mult = village_perks.damage_multiplier(player.village)
    if dmg_mult != 1.0:
        dmg = int(dmg * dmg_mult)
    kekkei_no_me_mult = _kekkei_no_me_damage_multiplier(player, jutsu)
    if kekkei_no_me_mult != 1.0:
        dmg = int(dmg * kekkei_no_me_mult)
    if damage_multiplier != 1.0:
        dmg = max(1, int(dmg * damage_multiplier))

    import biomes
    room = world.WORLD.get(player.room_vnum)
    biome_mult = biomes.damage_modifier(room.biome if room else "none", jutsu.get("element", "none"))
    if biome_mult != 1.0:
        dmg = int(dmg * biome_mult)

    if target.sharingan_active and target.bloodline_tomoe >= 3:
        reduced = _sharingan_predict_and_reduce_damage(target, dmg)
        if reduced < dmg:
            dmg = reduced
        elif not silent_to_target:
            jutsu_colors.send(target_session, "&RYou weren't fast enough to counter!&x")

    dmg = status_effects.reduce_outgoing_damage(player.active_status_effects, dmg)
    dmg = sage_mode.outgoing(player, dmg, jutsu=True)
    dmg = eight_gates.physical_damage(player, dmg, jutsu)
    dmg = signature_moves.amount(player, jutsu, jutsu_balance.boosted_damage(player, jutsu, dmg))
    dmg = sage_mode.incoming(target, status_effects.reduce_incoming_damage(target.active_status_effects, dmg))
    # A fire inlay resists water, earth resists lightning, etc.
    dmg = gem_inlays.reduce_counter_damage(target, jutsu.get("element", "none"), dmg)
    target.health -= dmg
    hyuga.on_strike(session, target, jutsu)
    _genjutsu_impact(jutsu, target)
    grow_skill_from_usage(player, jutsu["display_name"], session=session)
    perk_note = f" &Y(x{dmg_mult:g} village perk)&x" if dmg_mult != 1.0 else ""
    if biome_mult > 1.0:
        biome_note = f" &C({room.biome} boosts {jutsu.get('element')})&x"
    elif biome_mult < 1.0:
        biome_note = f" &D({room.biome} weakens {jutsu.get('element')})&x"
    else:
        biome_note = ""
    if was_explosive:
        jutsu_colors.send(session, f"&RThe kunai detonates!&x You use {colored_name} on {target.name} for {damage_messages.describe_damage(dmg)} explosive damage!{perk_note}{biome_note}")
        if silent_to_target:
            jutsu_colors.send(target_session, f"&RYou feel a sudden, sharp pain -- {damage_messages.describe_damage(dmg)} damage!&x")
        else:
            jutsu_colors.send(target_session, f"&RThe kunai detonates!&x {player.name} uses {colored_name} on you for {damage_messages.describe_damage(dmg)} explosive damage!{perk_note}{biome_note}")
    else:
        jutsu_colors.send(session, f"You use {colored_name} on {target.name} for {damage_messages.describe_damage(dmg)} damage! {damage_messages.impact_flavor(dmg)}{perk_note}{biome_note}")
        if silent_to_target:
            jutsu_colors.send(target_session, f"&RSomething washes over you -- {damage_messages.describe_damage(dmg)} damage!&x")
        else:
            jutsu_colors.send(target_session, f"{player.name} uses {colored_name} on you for {damage_messages.describe_damage(dmg)} damage!{perk_note}{biome_note}")

    if jutsu["effect"] and random.randint(1, 100) <= jutsu.get("effect_chance_pct", 100):
        import data_kekkei_genkai
        resisted_by_will = (jutsu["class_requirement"] == "genjutsu"
                            and status_effects.willpower_resists(target))
        if resisted_by_will:
            jutsu_colors.send(target_session, "&CYour Willpower fights off the incoming Genjutsu!&x")
            jutsu_colors.send(session, f"&C{target.name} resists your Genjutsu through sheer Willpower.&x")
        else:
            effect_duration = (status_effects.genjutsu_duration(jutsu["effect"])
                               if jutsu["class_requirement"] == "genjutsu"
                               else status_effects.EFFECT_DEFS[jutsu["effect"]]["duration"])
            if jutsu["class_requirement"] == "genjutsu" and data_kekkei_genkai.sharingan_genjutsu_resistant(target):
                effect_duration = data_kekkei_genkai.reduced_genjutsu_duration(effect_duration)
            if jutsu["class_requirement"] == "genjutsu":
                import general_skills
                effect_duration = general_skills.focused_duration(target, effect_duration)
            effect_duration = signature_moves.duration(player, jutsu, jutsu_balance.boosted_duration(
                player, jutsu, effect_duration, is_pvp=True, effect=jutsu["effect"]))
            status_effects.apply_effect(target.active_status_effects, jutsu["effect"], source=jutsu_key,
                                             duration_override=effect_duration, genjutsu=jutsu["class_requirement"] == "genjutsu")
            jutsu_colors.send(target_session, status_effects.EFFECT_DEFS[jutsu["effect"]]["message"].format(target="You"))
            jutsu_colors.send(session, status_effects.EFFECT_DEFS[jutsu["effect"]]["message"].format(target=target.name))
    for effect in sevenfold_effects:
        duration = signature_moves.duration(player, jutsu, jutsu_balance.boosted_duration(
            player, jutsu, status_effects.EFFECT_DEFS[effect]["duration"], is_pvp=True, effect=effect))
        status_effects.apply_effect(target.active_status_effects, effect, source=jutsu_key,
                                    duration_override=duration)
        jutsu_colors.send(target_session, status_effects.EFFECT_DEFS[effect]["message"].format(target="You"))
        jutsu_colors.send(session, status_effects.EFFECT_DEFS[effect]["message"].format(target=target.name))

    if jutsu.get("jutsu_type") == "fan_art" and fan_direction and target.health > 0:
        ninja_arts.fan_push(session, target, fan_direction, target_session)

    # 5-tomoe Copy Jutsu, per exact direct design confirmation
    # ("sharingan copy has a chance to copy the other users jutsu when
    # toggled on but has a cost of double the other users chakra to
    # copy"). Rolled on the DEFENDER's side -- being cast AT is what
    # gives the Sharingan something to read and copy. Cost is fixed at
    # copy time to double what the ORIGINAL caster (player, not
    # target) paid, so it can never drift if the source jutsu's own
    # cost changes later, and is explicitly NOT the target's own
    # normal cost for that jutsu.
    if target.sharingan_active and target.bloodline_tomoe >= 5 and target.health > 0:
        if random.randint(1, 100) <= commands_module.SHARINGAN_COPY_JUTSU_CHANCE_PERCENT:
            target.copied_jutsu_key = jutsu_key
            target.copied_jutsu_cost = caster_chakra_cost * 2
            jutsu_colors.send(target_session,
                f"&RYour Sharingan copies {colored_name}! You can now cast it once "
                f"for &Y{target.copied_jutsu_cost}&R chakra.&x"
            )

    if target.health <= 0:
        if try_trigger_izanagi(target_session):
            pass
        elif is_immortal_immune_to_defeat(target_session):
            clamp_immortal_health(target_session)
        else:
            handle_pvp_defeat(winner_session=session, loser_session=target_session)


# --- Defeat handling -------------------------------------------------

def _experience_reward(player: Player, mob: Mob) -> int:
    """Calculated reward for this player's level against this mob.

    Prototype ``experience_reward`` values are retained only for old saved
    world compatibility; rewards now come entirely from mob/player levels.
    """
    import leveling
    return leveling.mob_kill_experience(player.level, mob.level)


def handle_mob_defeat(session, mob: Mob) -> None:
    if is_immortal_mob(mob):
        # Protect even against effects and scripts that call defeat directly.
        # No corpse, rewards, rank/quest credit or despawn are produced.
        mob.health = mob.max_health
        if getattr(session, "combat_target", None) is mob:
            session.combat_target = None
        return
    if is_training_dummy(mob):
        mob.health = mob.max_health
        return  # never corpse, drop, XP, bounty, or despawn
    player = session.player
    # Target-bound Amaterasu dies with its mob. This also prevents
    # lingering damage from restarting a Tailed Beast's sealing window.
    mob.mangekyo_amaterasu_caster = None
    # Chunin mirror opponents are exam encounters, never farmable mobs.
    if getattr(mob, "chunin_exam_owner", ""):
        import chunin_exam
        if chunin_exam.finish_final_match(session, mob):
            return
        remove_mob(mob)
        session.combat_target = None
        return
    if is_shadow_clone(mob):
        # A defeated shadow clone bypasses XP/ryo/bounty/corpse/mob-
        # program logic entirely -- genuinely zero reward through
        # every path, per confirmed design ("Shadow clones poof
        # without a corpse"). This also sidesteps a real edge case a
        # corpse would otherwise hit: a player with the (non-default)
        # auto-sacrifice-corpse preference on would still net a flat
        # +1 ryo from that separate mechanism even with the clone's
        # own ryo_reward correctly at 0.
        session.send(f"&Y{mob.name} dispels in a puff of smoke!&x")
        import clone_control
        clone_control.notify_clone_removed(mob, "is defeated in combat")
        room_mobs = MOBS_BY_ROOM.get(mob.room_vnum, [])
        if mob in room_mobs:
            room_mobs.remove(mob)
        session.combat_target = None
        reset_summon_round_state(player)
        return

    if getattr(mob, "tailed_beast_key", None):
        mob.health = 0
        session.combat_target = None
        reset_summon_round_state(player)
        # Multiple attackers or lingering damage can report this defeat
        # again. Never turn it into an ordinary death or restart its timer.
        if mob.tailed_beast_downed_until:
            return
        mob.tailed_beast_downed_until = time.time() + 60.0  # confirmed directly: a real 1-minute window
        session.send(
            f"&R{mob.name} collapses, defeated -- but still breathes. Someone must seal it now, or it will die!&x"
        )
        _broadcast_to_room(mob.room_vnum, f"&R{mob.name} collapses, gravely wounded -- it must be sealed quickly!&x")
        return

    import corpses
    import leveling  # local import to avoid circular dependency at module load
    import village_perks

    player.npc_kills += 1
    session.send(f"&GYou have defeated {mob.name}!&x")
    session.send(f"&r{mob.name.capitalize()} is DEAD!&x")
    import iron_ascension
    iron_ascension.defeated(session, mob)

    t = MOB_TEMPLATES.get(mob.template_vnum)
    if t and t.get("mob_programs"):
        import programs
        programs.fire_programs(session, t["mob_programs"], "death", speaker_name=mob.name.capitalize(), mob=mob)

    import bounties
    bounty_id, bounty_entry = bounties.find_bounty_for_mob(mob.template_vnum)
    if bounty_id is not None and bounties.claim_bounty(bounty_id, player.name):
        player.ryo += bounty_entry["reward_ryo"]
        player.mission_points += bounty_entry["reward_mission_points"]
        player.mission_points_earned_total += bounty_entry["reward_mission_points"]
        session.send(
            f"&r*** BINGO BOOK BOUNTY CLAIMED (#{bounty_id}) ***&x\n"
            f"&Y{bounty_entry['reward_ryo']:,} ryo and {bounty_entry['reward_mission_points']} "
            f"mission point(s) added to your account.&x"
        )

    ryo_mult = village_perks.ryo_multiplier(player.village)
    corpse_ryo = int(mob.ryo_reward * ryo_mult) if ryo_mult != 1.0 else mob.ryo_reward
    import seasonal_events
    corpse = corpses.spawn_corpse(mob.name, mob.room_vnum, corpse_ryo, seasonal_events.mob_loot(mob))
    if not corpse.is_empty():
        session.send(f"{mob.name.capitalize()} leaves behind a corpse." + (f" &Y(x{ryo_mult:g} ryo village perk)&x" if ryo_mult != 1.0 else ""))

    if player.auto_loot_ryo and corpse.ryo > 0:
        taken = corpses.loot_ryo(player, corpse)
        session.send(f"You automatically loot {taken} ryo from the corpse.")
    if player.auto_loot_gear and corpse.items:
        taken = corpses.loot_gear(player, corpse, session=session)
        for item in taken:
            session.send(f"You automatically loot {item} from the corpse.")
    if player.auto_sac_corpse:
        forfeited_ryo, forfeited_items = corpses.sacrifice(player, corpse)
        msg = f"The corpse crumbles to dust, yielding {corpses.SACRIFICE_RYO_REWARD} ryo."
        if forfeited_ryo or forfeited_items:
            parts = []
            if forfeited_ryo:
                parts.append(f"{forfeited_ryo} ryo")
            if forfeited_items:
                parts.append(f"{len(forfeited_items)} item(s)")
            msg += f" ({' and '.join(parts)} left on it were forfeited.)"
        session.send(msg)

    session.combat_target = None
    reset_summon_round_state(player)
    seasonal_events.turkey_defeated(mob)
    import halloween_event
    halloween_event.mob_defeated(mob)
    remove_mob(mob)

    if session.group and len(session.group.members) > 1:
        import groups
        qualifying = [
            m for m in session.group.members
            if m.player and m.player.room_vnum == mob.room_vnum and m.player.health > 0
            and getattr(getattr(m, "state", None), "name", "PLAYING") == "PLAYING"
            and groups.xp_eligible(session, m)
        ]
        # Rank drift or stale sessions must never permit a >20-level
        # shared-XP party. A disqualified member simply gets no shared XP.
        if qualifying and (max(m.player.level for m in qualifying)
                           - min(m.player.level for m in qualifying)) > groups.GROUP_XP_LEVEL_RANGE:
            qualifying = [session]
        if session not in qualifying:
            qualifying = [session]
    else:
        qualifying = [session]

    if len(qualifying) > 1:
        for member_a in qualifying:
            for member_b in qualifying:
                if member_a is member_b:
                    continue
                counts = member_a.player.combat_partner_counts
                counts[member_b.player.name] = counts.get(member_b.player.name, 0) + 1

    for member_session in qualifying:
        member_player = member_session.player
        member_base_xp = _experience_reward(member_player, mob)
        share = member_base_xp // len(qualifying) if qualifying else 0
        member_multiplier = village_perks.xp_multiplier(member_player.village)
        member_xp = int(share * member_multiplier)
        if member_player.holiday_xp_boost_until > time.time():
            member_xp = int(member_xp * 1.10)
        team_bonus_applied = member_player.team_name and any(
            other.player and other is not member_session and other.player.team_name == member_player.team_name
            for other in qualifying
        )
        if team_bonus_applied:
            member_xp = int(member_xp * (1 + teams.TEAM_XP_BONUS_PCT / 100))
        loyal_bonus_applied = member_player.personality_trait == "loyal" and len(qualifying) > 1
        if loyal_bonus_applied:
            import data_personality
            member_xp = int(member_xp * (1 + data_personality.LOYAL_GROUP_XP_BONUS_PCT / 100))
        if not member_xp:
            continue
        perk_suffix = f" &Y(x{member_multiplier:g} village perk)&x" if member_multiplier != 1.0 else ""
        team_suffix = f" &C(+{teams.TEAM_XP_BONUS_PCT}% team bonus)&x" if team_bonus_applied else ""
        loyal_suffix = f" &C(+{data_personality.LOYAL_GROUP_XP_BONUS_PCT}% loyal bonus)&x" if loyal_bonus_applied else ""
        holiday_suffix = " &M(+10% candy perk)&x" if member_player.holiday_xp_boost_until > time.time() else ""
        experience_before = member_player.experience
        xp_messages = leveling.grant_experience(member_player, member_xp)
        earned_xp = max(0, member_player.experience - experience_before)
        if earned_xp:
            if member_session is session:
                session.send(f"You gain {earned_xp} experience.{perk_suffix}{team_suffix}{loyal_suffix}{holiday_suffix}")
            else:
                member_session.send(f"You gain {earned_xp} experience from the group's kill.{perk_suffix}{team_suffix}{loyal_suffix}{holiday_suffix}")
        for line in xp_messages:
            member_session.send(line)
        import element_choice
        element_choice.begin(member_session)

    import missions  # local import to avoid circular dependency
    for line in missions.on_mob_defeated(player, mob.template_vnum):
        session.send(line)


def try_trigger_izanagi(session) -> bool:
    """Whether Izanagi (Section 140, if rolled and actively toggled
    on) genuinely saves this session's own player from a real defeat
    right now. Per direct confirmation: a deliberate stance the
    player activated themselves in advance (session.player.
    izanagi_active), NOT automatic -- but once active, the very next
    time HP would hit 0 while it's on, it's instead restored to FULL
    HP and the stance is consumed, with a real, once-per-real-day
    cooldown starting from that moment. Checked BEFORE even
    is_immortal_immune_to_defeat at every real defeat-check site,
    since a player's own genuine, deliberate choice should take
    priority over a staff-only safety net that isn't a real choice at
    all. Returns True if it fired (caller should skip the normal
    defeat flow entirely, same contract as the immortal check)."""
    player = session.player
    if not player.izanagi_active or not (player.sharingan_active or _staff_testing_mangekyo(player)):
        return False
    player.izanagi_active = False
    player.health = player.maximum_health
    player.izanagi_cooldown_until = time.time() + data_mangekyo.IZANAGI_COOLDOWN_SECONDS
    session.send("&RFate itself refuses to claim you -- Izanagi tears you back from the brink, whole again.&x")
    return True


def is_immortal_immune_to_defeat(session) -> bool:
    """Whether this session's own real account is staff (builder or
    higher) -- per direct request/confirmation (Section 128):
    "Immortals can't die they stop at 1 hp." Same real bar already
    used for doors/goto/transfer (session.account.staff_level !=
    "player"). If True, callers are expected to clamp player.health
    to 1 and skip calling handle_player_defeat entirely, rather than
    letting a real defeat (hospital respawn, XP/ryo loss, bounty
    claims, etc.) ever actually happen to a staff member."""
    return getattr(getattr(session, "account", None), "staff_level", "player") != "player"


def clamp_immortal_health(session) -> None:
    """If this session's own real account is staff, clamps their
    health to a real minimum of 1 whenever it would otherwise be 0 or
    below -- the actual real mechanism behind "stop at 1 hp." Callers
    check is_immortal_immune_to_defeat's own return value themselves
    to decide whether to skip handle_player_defeat; this function
    only handles the real health-clamping half of it, so a caller
    that already knows a player is staff can call this directly
    without a redundant second check."""
    if session.player.health <= 0:
        session.player.health = 1


def handle_player_defeat(session) -> None:
    player = session.player
    if player.reaper_seal_id:
        player.health = max(1, player.health)
        return
    eight_gates.end(player, forced=True)
    import genjutsu
    genjutsu.clear_chisei(player)
    import hidden_mist
    if hidden_mist.owned_room(player):
        hidden_mist.dismiss(session)
    import six_paths
    six_paths.stop(session, "Your Six Paths power fades as you fall.")

    if session.duel is not None and session.duel.accepted:
        # A duel ends ONLY on a genuine defeat (confirmed design, no
        # yield/concede) -- and confirmed to carry NO penalties at
        # all, unlike a normal PvP defeat. end_duel handles the
        # return-to-origin-room trip and the partial heal for BOTH
        # combatants; nothing below this branch should ever run for
        # a duel loss.
        import duel as duel_module
        # A real duel defeat also puts out any attached Amaterasu.
        if player.mangekyo_amaterasu_burning:
            import mangekyo
            mangekyo.clear_amaterasu_target_burn(player)
            session.send("&DAmaterasu's black flames fade as you fall.&x")
        duel_module.end_duel(session.duel, session)
        return

    summon = active_summon(player)
    if summon is not None and summon.health > 0:
        import data_summons
        tier = data_summons.tier_by_key(summon.summon_tier_key)
        if tier and tier["mechanic"] == "safety_net":
            heal_percent = tier.get("heal_percent", 20)
            heal_amount = max(1, player.maximum_health * heal_percent // 100)
            player.health = min(player.maximum_health, heal_amount)
            session.send(
                f"&Y{summon.name} shields you from the killing blow at the last instant, "
                f"then dissolves back into the summoning realm, its own strength spent!&x"
            )
            dismiss_summon(player)
            return

    # Losing the final exam resets scrolls and the opponent before hospital.
    if player.in_chunin_exam:
        import chunin_exam
        chunin_exam.reset_exam(player)
        session.send("&RYou have failed the Chunin Exam. Your Heaven/Earth scrolls are forfeited. You must begin again.&x")

    # The attached black flames burn only while the target is alive.
    # On an actual defeat they go out before hospital recovery; the
    # independent room fire still runs out its own five-minute timer.
    flames_extinguished = player.mangekyo_amaterasu_burning
    if flames_extinguished:
        import mangekyo
        mangekyo.clear_amaterasu_target_burn(player)
        session.send("&DAmaterasu's black flames fade as you fall.&x")
    session.send("&RYour vision darkens as you collapse.&x")

    import leveling
    if player.level < leveling.MAX_LEVEL:
        loss = int(player.experience * 0.01)
        min_xp_for_level = leveling.cumulative_xp_for_level(player.level)
        new_xp = max(min_xp_for_level, player.experience - loss)
        actual_loss = player.experience - new_xp
        player.experience = new_xp
        if actual_loss:
            session.send(f"You lose {actual_loss} experience points.")
    else:
        session.send(f"You are level {leveling.MAX_LEVEL} and do not lose any experience.")

    ryo_loss = int(player.ryo * 0.05)
    player.ryo -= ryo_loss
    if ryo_loss:
        session.send(f"You lose {ryo_loss} ryo.")

    village = VILLAGES[player.village]
    player.room_vnum = village["hospital_room_vnum"]
    player.health = int(player.maximum_health * 0.25)
    player.chakra = int(player.maximum_chakra * 0.25)
    player.stamina = int(player.maximum_stamina * 0.25)
    status_effects.apply_effect(player.active_status_effects, "recently defeated", source="defeat")

    session.combat_target = None
    reset_summon_round_state(player)
    session.send(f"Village medics recover you and transport you to the {village['village_short_name']} Village Hospital.")
    if flames_extinguished:
        import storage
        storage.save_player(player)  # persist post-respawn state and cleared flames together


# --- PvP combat -------------------------------------------------------
#
# Deliberately parallel to the mob-combat path above rather than
# integrated into it -- session.pvp_target is a separate attribute from
# session.combat_target (Mob-only), so none of the extensively-tested
# mob-combat internals above needed to change at all. Blocked entirely
# in PvP-safe rooms (Room.safe -- see world.py/content.py for which
# rooms default to safe); checked both when an attack is initiated and
# every pulse afterward, so walking into a safe room mid-fight ends it.

def start_pvp_attack(session, target_session) -> None:
    """Mutual aggro -- both sessions start attacking each other, mirroring
    how mob combat is a two-sided exchange each pulse."""
    if (_is_linkdead(session) or _is_linkdead(target_session)):
        return False
    if not pvp_organizations.check(session, target_session):
        return False
    room = world.WORLD.get(session.player.room_vnum)
    if room is not None and room.safe:
        session.send("This is a PvP-safe zone. You cannot attack other players here.")
        return False
    import general_skills
    if general_skills.concealed_from(session.player, target_session.player):
        return False
    general_skills.break_camouflage(session)
    general_skills.break_camouflage(target_session)
    session.pvp_target = target_session
    target_session.pvp_target = session
    return True


def engage_damage_attack(session, victim, victim_session=None) -> bool:
    """Engage the real victim before any hostile direct damage or effect.

    Safe zones, disconnected players, protected NPCs and absent targets
    remain untouchable. Delayed status ticks do not chase fleeing targets.
    """
    player = getattr(session, "player", None)
    if player is None or victim is None or player.health <= 0:
        return False
    if victim_session is not None:
        if (victim_session is session
                or getattr(victim_session, "player", None) is not victim
                or _is_linkdead(session) or _is_linkdead(victim_session)
                or victim.health <= 0 or victim.room_vnum != player.room_vnum
                or getattr(victim, "izanami_trapped", False)):
            return False
        if not pvp_organizations.check(session, victim_session):
            return False
        room = world.WORLD.get(player.room_vnum)
        if room is not None and room.safe:
            session.send("This is a PvP-safe zone. You cannot attack other players here.")
            return False
        if getattr(session, "pvp_target", None) is not victim_session:
            start_pvp_attack(session, victim_session)
        return getattr(session, "pvp_target", None) is victim_session
    if (victim.health <= 0 or victim.room_vnum != player.room_vnum
            or is_immortal_mob(victim) or is_shopkeeper(victim)
            or is_gambler(victim) or is_teacher(victim)):
        session.send(f"{victim.name.capitalize()} is protected or cannot be reached.")
        return False
    if getattr(session, "combat_target", None) is not victim:
        start_attack(session, victim)
    return getattr(session, "combat_target", None) is victim


def _player_attack_target_once(session, player, target_session, target, guaranteed_hit=False) -> bool:
    """One single PvP attack (to-hit roll through the damage/miss/dodge
    messages to both sides) from player against target -- extracted so
    resolve_pvp_pulse can call this once per attack a player has
    earned this round (see _roll_extra_attacks), rather than
    duplicating the whole sequence inline for each one. Behavior is
    identical to what resolve_pvp_pulse always did for its one
    guaranteed attack; the defeat/wimpy check that used to live
    inline here now happens once in resolve_pvp_pulse itself, after
    every attack this round, not inside each individual swing.

    Confirmed design (reversed from an earlier turn): automatic
    attacks fire normally during a hand-sign cast, matching
    _player_attack_mob_once's own identical reversal -- see that
    function's docstring for the full reasoning."""
    if _is_linkdead(session) or _is_linkdead(target_session):
        return
    if _is_action_blocked(player):
        session.send("You are unable to act!")
        return
    import hidden_mist
    if hidden_mist.obscures(player, target) or general_skills.concealed_from(player, target):
        session.send("&CYou cannot find your target in the hidden mist.&x")
        return
    import commands as commands_module
    import weather
    import data_personality
    import tailed_beasts
    set_bonus = commands_module.equipped_set_bonus_percent(player)
    player_hit_roll = derived_stats.hit_roll(player, set_bonus + data_personality.personality_bonus_percent(player, "hit_roll") + tailed_beasts.rampage_bonus_percent(player) + tailed_beasts.mode_bonus_percent(player)) + commands_module.equipped_weapon_hitroll_bonus(player) + _summon_weapon_buff_hitroll_bonus(player)
    target_set_bonus = commands_module.equipped_set_bonus_percent(target)
    target_armor_class = derived_stats.armor_class(target, target_set_bonus + data_personality.personality_bonus_percent(target, "armor_class") + tailed_beasts.rampage_bonus_percent(target) + tailed_beasts.mode_bonus_percent(target)) - commands_module.equipped_armor_class_bonus(target)
    import sage_mode
    to_hit = derived_stats.to_hit_chance(player_hit_roll, target_armor_class) + weather.combat_accuracy_modifier() + _sharingan_hitroll_bonus(player) + hyuga.accuracy(player) - _accuracy_penalty_from_effects(player) + hidden_mist.advantage(player, target) + sage_mode.accuracy(player) + general_skills.focused_accuracy(player) + sword_styles.accuracy_bonus(player) + eight_gates.accuracy(player) + __import__("susanoo").accuracy_bonus(player)
    to_hit = max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit))
    attacker_wielded = player.equipment.get("wielded", "")
    attack_verb = data_weapons.attack_verb_for_item(attacker_wielded)
    weapon_skill = data_weapons.skill_for_item(attacker_wielded)
    if weapon_skill:
        grow_skill_from_usage(player, weapon_skill, session=session)
    if not guaranteed_hit and random.randint(1, 100) > to_hit:
        session.send(f"You {attack_verb} at {target.name} but miss!")
        target_session.send(f"&C{player.name} attacks you but misses!&x")
        return

    if not engage_damage_attack(session, target, target_session):
        return False
    dmg = _player_attack_damage(player)
    dmg = sword_styles.damage_bonus(player, dmg)
    dmg = _weapon_expert_damage(player, dmg)
    dmg = int(dmg * (100 + _summon_weapon_buff_damage_percent(player)) / 100)
    is_crit = random.randint(1, 100) <= derived_stats.critical_chance(player, set_bonus + data_personality.personality_bonus_percent(player, "critical_chance"))
    if is_crit:
        dmg = int(dmg * 1.5)

    if target.kamui_intangibility_rounds_left > 0:
        target.kamui_intangibility_rounds_left -= 1
        session.send(f"&RYour attack passes straight through {target.name}!&x")
        target_session.send(f"&R{player.name}'s attack passes straight through you!&x")
        return

    if not guaranteed_hit and random.randint(1, 100) <= max(0, derived_stats.dodge_chance(target, target_set_bonus + data_personality.personality_bonus_percent(target, "dodge_chance")) + weather.night_dodge_bonus() + _sharingan_dodge_bonus(target) + hyuga.dodge(target) + eight_gates.dodge(target) - hidden_mist.advantage(player, target)):
        session.send(f"&C{target.name} dodges your attack!&x")
        target_session.send(f"&CYou dodge {player.name}'s attack!&x")
        return

    if not guaranteed_hit and _soto_uke_blocks(target, player.level):
        session.send(f"&C{target.name} blocks your attack with Soto Uke!&x")
        target_session.send(f"&CYou use Soto Uke to block {player.name}'s attack!&x")
        return

    if target.sharingan_active and target.bloodline_tomoe >= 3:
        reduced = _sharingan_predict_and_reduce_damage(target, dmg)
        if reduced < dmg:
            dmg = reduced
        else:
            target_session.send("&RYou weren't fast enough to counter!&x")

    dmg = commands_module.reduce_weapon_damage(target, data_weapons.weapon_type_for_item(attacker_wielded), dmg)
    dmg = ninja_arts.weapon_hit(player, target, dmg, session=session, target_session=target_session)
    import susanoo
    dmg = susanoo.incoming_damage(
        target, sage_mode.incoming(
            target, status_effects.reduce_incoming_damage(target.active_status_effects, dmg)))
    target.health -= dmg
    sword_styles.successful_strike(player, session)
    if is_crit:
        session.send(f"&YCritical hit!&x You {attack_verb} {target.name} for {damage_messages.describe_damage(dmg)} damage. {damage_messages.impact_flavor(dmg)}")
    else:
        session.send(f"You {attack_verb} {target.name} for {damage_messages.describe_damage(dmg)} damage. {damage_messages.impact_flavor(dmg)}")
    target_session.send(f"{player.name} {data_weapons.attack_verb_for_item_third_person(attacker_wielded)} you for {damage_messages.describe_damage(dmg)} damage.")
    import room_actions
    room_actions.emit(session, f"{player.name} {data_weapons.attack_verb_for_item_third_person(attacker_wielded)} {target.name} for {damage_messages.describe_damage(dmg)} damage.", exclude=(target_session,))
    import equipment_durability
    equipment_durability.wear_weapon(session)
    if dmg > 0:
        equipment_durability.wear_armor(target_session)
    return True


def _clone_attack_target_once(session, player, target_session, target, clone) -> None:
    if _is_linkdead(session) or _is_linkdead(target_session):
        return
    """A live clone assists in PvP under the same safety and defense rules."""
    import hidden_mist
    if hidden_mist.obscures(player, target) or general_skills.concealed_from(player, target):
        return
    import commands as commands_module
    import weather
    element = clone.clone_element
    label = f"{element} clone" if element != "none" else "shadow clone"
    to_hit = derived_stats.to_hit_chance(
        derived_stats.hit_roll(player),
        derived_stats.armor_class(target) - commands_module.equipped_armor_class_bonus(target),
    ) + weather.combat_accuracy_modifier() - _accuracy_penalty_from_effects(player)
    if random.randint(1, 100) > max(derived_stats.TO_HIT_MIN_PCT, min(derived_stats.TO_HIT_MAX_PCT, to_hit)):
        session.send(f"Your {label} attacks {target.name} but misses!")
        return
    if target.kamui_intangibility_rounds_left > 0:
        target.kamui_intangibility_rounds_left -= 1
        return
    if random.randint(1, 100) <= derived_stats.dodge_chance(target) + weather.night_dodge_bonus() + _sharingan_dodge_bonus(target) + hyuga.dodge(target) + eight_gates.dodge(target):
        target_session.send(f"&CYou dodge {player.name}'s {label}!&x")
        return
    if not engage_damage_attack(session, target, target_session):
        return
    damage = int(_player_attack_damage(player) * SHADOW_CLONE_DAMAGE_SCALE * (1.25 if element == "earth" else 1))
    damage = commands_module.reduce_weapon_damage(target, data_weapons.weapon_type_for_item(player.equipment.get("wielded", "")), damage)
    damage = status_effects.reduce_incoming_damage(target.active_status_effects, damage)
    target.health -= damage
    session.send(f"Your {label} strikes {target.name} for {damage_messages.describe_damage(damage)} damage.")
    target_session.send(f"{player.name}'s {label} strikes you for {damage_messages.describe_damage(damage)} damage.")
    clone_effect = {"lightning": "paralyzed", "water": "drained", "sand": "entangled"}.get(element)
    if clone_effect and random.randint(1, 100) <= 20:
        status_effects.apply_effect(target.active_status_effects, clone_effect, source=f"{element} clone", duration_override=2)
        target_session.send(status_effects.EFFECT_DEFS[clone_effect]["message"].format(target="you"))


def _resolve_ninken_flee_lock(session, player, target_session, target) -> None:
    """The Ninken pack's own real, PvP-only mechanic (Section 118) --
    a hard flee-lock against the SUMMONER's own chosen opponent,
    specifically. Reuses the same summon_flee_locked field Manda's
    own "bind" mechanic already uses (see combat._resolve_summon_
    round and commands.cmd_flee's own check), but sets it on the
    TARGET here, not the summoner -- confirmed directly this
    mechanic only makes sense in real PvP, unlike the other 5, which
    all fire during ordinary PvE combat instead."""
    summon = active_summon(player)
    if summon is None or summon.health <= 0:
        return
    import data_summons
    tier = data_summons.tier_by_key(summon.summon_tier_key)
    if tier and tier["mechanic"] == "flee_lock":
        if not target.summon_flee_locked:
            target.summon_flee_locked = True
            session.send(f"&Y{summon.name} circles {target.name}, cutting off any chance of escape!&x")
            target_session.send(f"&R{summon.name} circles you -- you won't be able to flee this fight!&x")


def resolve_pvp_pulse(session) -> None:
    """One automatic-attack round for a session's ongoing PvP fight, if
    any. Assumes tick_effects_pulse() has already run for this pulse,
    same as resolve_pulse()."""
    player = session.player
    target_session = session.pvp_target
    if target_session is None:
        return
    if not pvp_organizations.allowed_sessions(session, target_session):
        session.pvp_target = None
        if target_session.pvp_target is session:
            target_session.pvp_target = None
        session.send("&DYour PvP fight ends because the organizations are no longer eligible.&x")
        return
    if player.izanami_trapped or (getattr(target_session, "player", None)
                                   and target_session.player.izanami_trapped):
        session.pvp_target = None
        if target_session.pvp_target is session:
            target_session.pvp_target = None
        return
    if _is_linkdead(session) or _is_linkdead(target_session):
        session.pvp_target = None
        if target_session.pvp_target is session:
            target_session.pvp_target = None
        return
    import element_choice
    if element_choice.in_choice(player) or element_choice.in_choice(target_session.player):
        session.pvp_target = None
        target_session.pvp_target = None
        return
    target = target_session.player
    if player.reaper_seal_id or (target and target.reaper_seal_id):
        session.pvp_target = target_session.pvp_target = None
        return
    if (
        target is None
        or target.room_vnum != player.room_vnum
        or target.health <= 0
        or player.health <= 0
    ):
        session.pvp_target = None
        target_session.pvp_target = None
        reset_summon_round_state(player)
        reset_summon_round_state(target)
        return

    room = world.WORLD.get(player.room_vnum)
    if room and room.safe:
        session.send("&DThe safety of this area causes you to stand down.&x")
        target_session.send(f"&D{player.name} stands down -- this area is PvP-safe.&x")
        session.pvp_target = None
        target_session.pvp_target = None
        reset_summon_round_state(player)
        reset_summon_round_state(target)
        return
    if target.izanami_trapped:
        return

    if getattr(session, "controlled_clone", None) is not None:
        # The original body cannot defend or strike while its user is
        # remotely controlling an elemental scout. Incoming PvP rounds
        # from other players still resolve normally on their sessions.
        session.send("&DYour body cannot attack while your senses inhabit your clone.&x")
        return

    if player.jinchuriki_beast_key and player.rampage_until == 0.0:
        import tailed_beasts as tailed_beasts_module
        tailed_beasts_module.tick_jinchuriki_mastery(player)
        if tailed_beasts_module.check_rampage_trigger(player):
            tailed_beasts_module.trigger_rampage(player)
            session.send("&RSomething inside you SNAPS -- the beast's chakra floods your body, and you lose all control!&x")

    session.send("")
    import sage_mode
    sage_mode.combat_pulse(session)
    ninja_arts.tick_samurai_sabre(session, combat=True)
    if _is_action_blocked(player):
        session.send("You are stunned and can't act this round!" if "stunned" in player.active_status_effects else "You cannot act this round!")
        return

    import commands as commands_module
    for message in tick_passive_skill_growth(player):
        session.send(message)
    for message in tick_sharingan_upkeep(player):
        session.send(message)
    for message in tick_sharingan_mastery_gain(player):
        session.send(message)
    for message in hyuga.combat_tick(player):
        session.send(message)
    for message in tick_automatic_bloodline_awakening(player):
        session.send(message)
    if hyuga.eligible(player):
        for new_skill in hyuga.sync(player):
            session.send(f'&CByakugan technique unlocked: {new_skill}!&x')
    import hidden_mist
    if hidden_mist.obscures(player, target) or general_skills.concealed_from(player, target):
        session.send("&CYou search the mist but cannot target your opponent.&x")
        return
    _resolve_ninken_flee_lock(session, player, target_session, target)

    _player_attack_target_once(session, player, target_session, target)
    if target.health > 0:
        trained_extra = _roll_extra_attacks(player)
        for attack_index in range(trained_extra + sage_mode.extra_attacks(player) + eight_gates.extra_attacks(player)):
            if target.health <= 0:
                break
            if attack_index < trained_extra:
                skill_name = data_jutsu.MULTI_ATTACK_SKILLS[attack_index][0]
                mastered = player.skill_proficiencies.get(skill_name, 0) >= 100
                landed = _player_attack_target_once(session, player, target_session, target, guaranteed_hit=mastered)
                if landed:
                    grow_skill_from_usage(player, skill_name, session=session)
            else:
                _player_attack_target_once(session, player, target_session, target)
    if target.health > 0:
        _offhand_attack(session, target, target_session)
    for clone in active_shadow_clones(player):
        if target.health <= 0:
            break
        if clone.room_vnum == player.room_vnum:
            _clone_attack_target_once(session, player, target_session, target, clone)

    if target.health <= 0:
        if try_trigger_izanagi(target_session):
            pass
        elif is_immortal_immune_to_defeat(target_session):
            clamp_immortal_health(target_session)
        else:
            handle_pvp_defeat(winner_session=session, loser_session=target_session)
    elif target.wimpy_percent > 0 and (target.health / target.maximum_health * 100) <= target.wimpy_percent:
        target_session.send(
            f"&Y(Your health has dropped to your wimpy threshold of {target.wimpy_percent}%!)&x"
        )
        commands_module.cmd_flee(target_session, [])


def handle_pvp_defeat(winner_session, loser_session, skip_mangekyo_check: bool = False) -> None:
    winner = winner_session.player
    loser = loser_session.player

    if not skip_mangekyo_check:
        import data_kekkei_genkai
        if data_kekkei_genkai.eligible_for_mangekyo_betrayal(winner, loser):
            loser.health = 1
            loser.downed_by = winner.name
            winner_session.pvp_target = None
            loser_session.pvp_target = None
            reset_summon_round_state(winner)
            reset_summon_round_state(loser)
            winner_session.send(
                f"&RYou stand over {loser.name}, utterly defeated at your feet.&x\n"
                f"&YSomething stirs within you -- a choice, and a cost. Finish them for the power you seek? "
                f"Type 'yes' to end their life, or 'no' to let them live.&x"
            )
            loser_session.send(
                f"&R{winner.name} stands over you, victorious. You are utterly at their mercy...&x"
            )
            return

    winner.player_kills += 1
    loser.player_deaths += 1

    winner_session.send(f"&GYou have defeated {loser.name} in combat!&x")
    winner_session.send(f"&r{loser.name} is DEAD!&x")

    import bounties
    bounty_id, bounty_entry = bounties.find_bounty_for_player(loser.name)
    if bounty_id is not None and bounties.claim_bounty(bounty_id, winner.name):
        winner.ryo += bounty_entry["reward_ryo"]
        winner.mission_points += bounty_entry["reward_mission_points"]
        winner.mission_points_earned_total += bounty_entry["reward_mission_points"]
        winner_session.send(
            f"&r*** BINGO BOOK BOUNTY CLAIMED (#{bounty_id}) ***&x\n"
            f"&Y{bounty_entry['reward_ryo']:,} ryo and {bounty_entry['reward_mission_points']} "
            f"mission point(s) added to your account.&x"
        )

    import chunin_exam
    stolen = chunin_exam.steal_scroll_on_pvp_defeat(winner, loser)
    if stolen:
        winner_session.send(f"&YYou snatch {stolen} from {loser.name}!&x")
        loser_session.send(f"&r{winner.name} takes your {stolen}!&x")

    winner_session.pvp_target = None
    loser_session.pvp_target = None
    reset_summon_round_state(winner)
    reset_summon_round_state(loser)

    handle_player_defeat(loser_session)  # reuses the existing XP/ryo loss + hospital respawn
