"""Mob targets and owner-controlled Amaterasu for Mangekyo techniques."""

import random
import time

import combat
import data_jutsu
import data_mangekyo
import damage_messages
import jutsu_colors
import mangekyo
import mangekyo_discovery
import status_effects
import world

TARGETED = {"amaterasu", "tsukuyomi", "izanami", "kamui pocket dimension", "kamui limb removal"}
DELAYED = {"amaterasu", "tsukuyomi", "izanami", "kamui limb removal"}


def cast(session, key, mob):
    """Start a Mangekyo cast against an attackable mob in this room."""
    player = session.player
    jutsu = data_jutsu.JUTSU[key]
    if not combat._can_use_jutsu(player, jutsu, key):
        jutsu_colors.send(session, "You haven't learned that skill or jutsu.")
        return
    if combat.is_shopkeeper(mob) or combat.is_gambler(mob) or combat.is_teacher(mob) or combat.is_immortal_mob(mob):
        jutsu_colors.send(session, f"{mob.name.capitalize()} is protected and cannot be attacked.")
        return
    if session.pending_cast is not None:
        jutsu_colors.send(session, "You're already forming hand signs for another jutsu!")
        return
    import jutsu_balance
    chakra_cost = jutsu_balance.cast_cost(player, jutsu, "chakra")
    stamina_cost = jutsu_balance.cast_cost(player, jutsu, "stamina")
    if player.chakra < chakra_cost or player.stamina < stamina_cost:
        jutsu_colors.send(session, "You don't have enough Chakra or Stamina.")
        return
    now = time.time()
    if now < player.cooldowns.get(key, 0):
        jutsu_colors.send(session, f"{jutsu['display_name']} is still recovering.")
        return
    if key == "kamui pocket dimension":
        try:
            mangekyo.open_mob_pocket_dimension(session, mob, world)
        except ValueError as exc:
            jutsu_colors.send(session, str(exc))
            return
    player.chakra -= chakra_cost
    player.stamina -= stamina_cost
    player.cooldowns[key] = now + jutsu["cooldown"]
    if key == "kamui pocket dimension":
        mangekyo_discovery.record_use(player, key)
        jutsu_colors.send(session, f"&RYou cast {mob.name} into a pocket dimension. Cast Kamui on yourself to enter it.&x")
    else:
        if key != "kamui limb removal" and "Silent Genjutsu" in player.learned_skills:
            resolve(session, key, mob)
            return
        combat.begin_pending_cast(session, key, mob, is_pvp=False)
        if key == "kamui limb removal":
            session.pending_cast.remaining_seconds = random.uniform(*data_mangekyo.KAMUI_LIMB_REMOVAL_CAST_SECONDS)


def resolve(session, key, mob):
    """Resolve a delayed mob cast only while its original target is present."""
    player = session.player
    if mob not in combat.mobs_in_room(player.room_vnum) or mob.health <= 0:
        jutsu_colors.send(session, "&DYour target is no longer there!&x")
        return
    if not combat.engage_damage_attack(session, mob):
        return
    if key == "amaterasu":
        mob.mangekyo_amaterasu_caster = player.name
        room = world.WORLD.get(mob.room_vnum)
        if room:
            room.amaterasu_fire_caster = player.name
            room.amaterasu_fire_expires_at = time.time() + data_mangekyo.AMATERASU_ROOM_FIRE_DURATION_SECONDS
        # The flame lands immediately when the hand signs finish; the
        # separate target burn and lingering room fire tick afterward.
        damage = data_mangekyo.AMATERASU_INITIAL_DAMAGE
        damage = status_effects.reduce_incoming_damage(mob.active_status_effects, damage)
        mob.health = max(0, mob.health - damage)
        jutsu_colors.send(
            session,
            f"&RAmaterasu's black flames engulf {mob.name} for "
            f"{damage_messages.describe_damage(damage)} damage on impact!&x",
        )
        if mob.health <= 0:
            combat.handle_mob_defeat(session, mob)
    elif key == "kamui limb removal":
        damage = random.randint(*data_mangekyo.KAMUI_LIMB_REMOVAL_DAMAGE)
        mob.health -= status_effects.reduce_incoming_damage(mob.active_status_effects, damage)
        jutsu_colors.send(session, f"&RKamui tears into {mob.name} for {damage} damage!&x")
        if mob.health <= 0:
            combat.handle_mob_defeat(session, mob)
    elif key == "tsukuyomi":
        status_effects.apply_effect(mob.active_status_effects, "genjutsu_locked",
                                    source=player.name, duration_override=10)
        jutsu_colors.send(session, f"&R{mob.name} is trapped in Tsukuyomi and cannot act for ten pulses!&x")
    elif key == "izanami":
        status_effects.apply_effect(mob.active_status_effects, "genjutsu_locked",
                                    source=player.name, duration_override=25)
        jutsu_colors.send(session, f"&R{mob.name} is caught in Izanami's repeating loop for 25 pulses!&x")
    else:
        return
    mangekyo_discovery.record_use(player, key)
    combat.grow_skill_from_usage(player, "Handsigns")


def extinguish(session, args):
    """Only the temporary room fire can be dismissed; target flames never die."""
    caster = session.player.name
    query = " ".join(args).lower().strip()
    if not query:
        jutsu_colors.send(session, "Usage: perform amaterasu extinguish <room|all>")
        return
    if query not in ("room", "all"):
        jutsu_colors.send(session, "&RAmaterasu's flames on a living target burn until that target dies; they cannot be manually extinguished.&x")
        return

    removed = 0
    rooms = world.WORLD.rooms.values() if query == "all" else [world.WORLD.get(session.player.room_vnum)]
    for room in rooms:
        if room and room.amaterasu_fire_caster == caster:
            room.amaterasu_fire_caster = None
            room.amaterasu_fire_expires_at = 0.0
            removed += 1
    jutsu_colors.send(session, f"&YYou extinguish {removed} temporary Amaterasu room fire{'s' if removed != 1 else ''}.&x")
