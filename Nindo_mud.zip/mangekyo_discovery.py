"""Persist which Mangekyo eye techniques a character has actually used."""

import data_jutsu


def roster_key(jutsu_key: str) -> str:
    jutsu = data_jutsu.JUTSU[jutsu_key]
    return jutsu.get("mangekyo_roster_key", jutsu_key)


def record_use(player, jutsu_key: str) -> None:
    key = roster_key(jutsu_key) if jutsu_key in data_jutsu.JUTSU else jutsu_key
    if key not in player.mangekyo_eyes_used:
        player.mangekyo_eyes_used.append(key)
        import storage
        storage.save_player(player)


def can_read(session, entry: dict) -> bool:
    key = entry["primary_keyword"].lower()
    staff = getattr(getattr(session, "account", None), "staff_level", "player") != "player"
    player = getattr(session, "player", None)
    # Rare celestial and Tenseigan-family Hyuga help is equally private.
    # A character must personally satisfy level, mastery and Potential.
    import hyuga
    hyuga_art = hyuga.REGISTRY.get(key)
    if hyuga_art and hyuga_art.get("hyuga_potential", 0) >= 95:
        return staff or bool(player and hyuga.unlocked(player, key))
    if key == "mangekyo help":
        return staff or bool(player and player.bloodline_id == "sharingan"
                             and player.bloodline_mangekyo)
    if key in {"stab", "impale", "burn", "crush", "unmake"}:
        key = "tsukuyomi"
    jutsu = data_jutsu.JUTSU.get(key)
    if key != "izanagi" and (jutsu is None or jutsu.get("kkg_gate") != "mangekyo_technique"):
        return True
    if session.account is not None and session.account.staff_level != "player":
        return True
    player = session.player
    if not player or player.bloodline_id != "sharingan" or not player.bloodline_mangekyo:
        return False
    eye = roster_key(key) if jutsu else "izanagi"
    # An assigned eye is unlocked immediately. First use is no longer
    # necessary to read its helpfile.
    return eye in (player.mangekyo_eye_1, player.mangekyo_eye_2)
